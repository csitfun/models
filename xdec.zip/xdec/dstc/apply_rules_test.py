import unittest
from dstc.apply_rules import postprocess
import logging
import json

logger = logging.getLogger(__name__)


class TestApplyRules(unittest.TestCase):

    def test_postprocess(self):
        four_user_frames_union = [{
            "service": "Events_1",
            "slots": [],
            "state": {
                "active_intent": "BuyEventTickets",
                "slot_values": {
                    "event_name": ["Mets Vs Pirates"],
                    "date": ["March 12th"],
                    "city_of_event": ["NY"],
                    "number_of_seats": ["1"]
                },
                "requested_slots": ["event_location", "time"]
            }
        }]

        mid_user_frames = [{
            "service": "Buses_1",
            "slots": [],
            "state": {
                "active_intent": "FindBus",
                "slot_values": {
                    "from_location": ["Washington"],
                    "to_location": ["New York"],
                    "leaving_date": ["7th of March"],
                    "travelers": ["1"]
                },
                "requested_slots": []
            }
        }]

        acc_user_frames = [{
            "service": "Buses_1",
            "slots": [],
            "state": {
                "active_intent": "BuyBusTicket",
                "slot_values": {
                    "from_location": ["Washington"],
                    "to_location": ["New York"],
                    "leaving_date": ["March 7th"],
                    "leaving_time": ["8:10 am"],
                    "travelers": ["1"]
                },
                "requested_slots": []
            }
        }]

        recovered_dont_care, dialogues = postprocess(
            "test_data/unittest/data/train/schema.json",
            "test_data/unittest/data/dev/schema.json",
            "test_data/unittest/eval",
            "/tmp/",
            union_all=True,
            dump_file=False)

        self.assertEqual(1, len(dialogues))
        self.assertEqual(0, recovered_dont_care)
        self.assertEqual(four_user_frames_union,
                         dialogues[0][0]["turns"][4]["frames"])
        self.assertEqual(mid_user_frames,
                         dialogues[0][0]["turns"][-8]["frames"])

        self.assertEqual(acc_user_frames,
                         dialogues[0][0]["turns"][-2]["frames"])

        four_user_frames_nounion = [{
            "service": "Events_1",
            "slots": [],
            "state": {
                "active_intent": "BuyEventTickets",
                "slot_values": {
                    "event_name": ["Mets Vs Pirates"],
                    "date": ["March 12th"]
                },
                "requested_slots": ["event_location", "time"]
            }
        }]
        recovered_dont_care, dialogues = postprocess(
            "test_data/unittest/data/train/schema.json",
            "test_data/unittest/data/dev/schema.json",
            "test_data/unittest/eval",
            "/tmp/",
            union_all=False,
            dump_file=False)

        self.assertEqual(1, len(dialogues))
        self.assertEqual(0, recovered_dont_care)
        self.assertEqual(four_user_frames_nounion,
                         dialogues[0][0]["turns"][4]["frames"])
        self.assertEqual(mid_user_frames,
                         dialogues[0][0]["turns"][-8]["frames"])

        self.assertEqual(acc_user_frames,
                         dialogues[0][0]["turns"][-2]["frames"])


if __name__ == '__main__':
    logging.basicConfig(datefmt="%m/%d/%Y %H:%M:%S", level=logging.INFO)
    unittest.main()
