import unittest
import torch
from transformers import RobertaTokenizer
from dstc.processors import (dstc_convert_examples_to_features,
                             dstc_convert_pair_examples_to_features,
                             dstc_convert_examples_to_features_with_pos,
                             DSTCPairClassificationInputFeatures,
                             DSTCClassificationInputFeatures,
                             DSTCClassificationInputExample)
from xdec_config import get_logger

logger = get_logger(__name__)


class TestProcessors(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.tokenizer = RobertaTokenizer.from_pretrained(
            'roberta-base', cache_dir=".transformers_cache")

    def test_dstc_convert_pair_examples_to_features(self):
        ex = DSTCClassificationInputExample(
            guid="guid", text_a="<pad>", text_b="<pad>", label="True")

        features = dstc_convert_pair_examples_to_features(
            [ex],
            self.tokenizer,
            max_length=4,
            max_query_length=4,
            output_mode="classification",
            label_list=["True", "False"],
        )
        logger.debug("features: {}".format(features))
        feature = features[0]
        gold_feature = DSTCPairClassificationInputFeatures(
            input_ids=[0, 1, 2, 0],
            attention_mask=[1, 1, 1, 0],
            token_type_ids=[0, 0, 0, 0],
            query_input_ids=[0, 1, 2, 0],
            query_attention_mask=[1, 1, 1, 0],
            query_token_type_ids=[0, 0, 0, 0],
            wide_ids=None,
            label=0)
        self.assertEqual(feature, gold_feature)

    def test_dstc_convert_examples_to_features_with_pos(self):
        ex = DSTCClassificationInputExample(
            guid="guid|type|class",
            text_a="this is a history session",
            text_b="type is class",
            label="True")

        features = dstc_convert_examples_to_features_with_pos(
            [ex],
            self.tokenizer,
            max_length=16,
            output_mode="classification",
            label_list=["True", "False"],
        )
        input_ids = features[0].input_ids
        toks = self.tokenizer.convert_ids_to_tokens(input_ids)
        logger.debug(f"a ({len(ex.text_a.split())}): {ex.text_a}")
        logger.debug(f"b ({len(ex.text_b.split())}): {ex.text_b}")
        logger.debug(f"input_ids ({len(input_ids)}): {input_ids}")
        logger.debug(f"toks ({len(toks)}): {toks}")
        class_toks = self.tokenizer.convert_ids_to_tokens(
            self.tokenizer.encode("a class"))
        logger.debug(f"class_toks ({len(class_toks)}): {class_toks}")
        self.assertEqual(features[0].class_pos, 10)

    def test_dstc_convert_examples_to_features_trunk(self):
        ex = DSTCClassificationInputExample(
            guid="guid",
            text_a="<unk> <pad> <pad> <pad>",
            text_b="<pad> <pad> <pad>",
            label="True")

        features = dstc_convert_examples_to_features(
            [ex],
            self.tokenizer,
            max_length=8,
            output_mode="classification",
            label_list=["True", "False"],
        )
        # <cls> <unk> <pad> <pad> <pad> </s> </s> <pad> <pad> <pad> </s>
        # trunk right:
        # <cls> <unk> <pad> </s> </s> <pad> <pad> </s>
        # trunk left
        # <cls> <pad> </s> </s> <pad> <pad> <pad> </s>
        feature = features[0]
        gold_feature = DSTCClassificationInputFeatures(
            input_ids=[0, 3, 1, 2, 2, 1, 1, 2],
            attention_mask=[1, 1, 1, 1, 1, 1, 1, 1],
            token_type_ids=[0, 0, 0, 0, 0, 0, 0, 0],
            wide_ids=None,
            label=0)

        self.assertEqual(feature, gold_feature)

        left_features = dstc_convert_examples_to_features(
            [ex],
            self.tokenizer,
            max_length=8,
            output_mode="classification",
            label_list=["True", "False"],
            trunk_left=True,
        )
        # <cls> <unk> <pad> <pad> <pad> </s> </s> <pad> <pad> <pad> </s>
        # trunk right
        # <cls> <unk> </s> </s> <pad> <pad> <pad> </s>
        # trunk left
        # <cls> <pad> </s> </s> <pad> <pad> <pad> </s>
        left_feature = left_features[0]
        left_gold_feature = DSTCClassificationInputFeatures(
            input_ids=[0, 1, 2, 2, 1, 1, 1, 2],
            attention_mask=[1, 1, 1, 1, 1, 1, 1, 1],
            token_type_ids=[0, 0, 0, 0, 0, 0, 0, 0],
            wide_ids=None,
            label=0)

        self.assertEqual(left_feature, left_gold_feature)
