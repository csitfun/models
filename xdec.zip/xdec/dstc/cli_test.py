import unittest
import dstc.cli as cli
from click.testing import CliRunner
from dstc.cli import read_tsv, read_squad_file, load_ontology
import logging

logger = logging.getLogger(__name__)


class TestCli(unittest.TestCase):

    def test_compute_f1(self):

        runner = CliRunner()
        result = runner.invoke(cli.compute_f1, [
            "--input_file",
            "test_data/unittest/predictions/cat_pred_results.txt",
            "--ref_file",
            "test_data/unittest/train/dev.jsonl.gz",
        ])
        self.assertEqual(0, result.exit_code)
        self.assertIn("'f1': 97.29729729729729", result.output)

    def test_read_tsv(self):

        result = read_tsv(
            ["test_data/unittest/predictions/cat_pred_results.txt"],
            multi_line=True,
            use_max_score=True)
        res_key_0 = ("19_00000", 0, "Events_1")
        res_key_2 = ("19_00000", 2, "Events_1")
        slot_name = "category"
        slot_value_0 = ["Sports"]
        self.assertEqual(slot_value_0, result[res_key_0][slot_name])
        self.assertTrue(res_key_2 not in result)  # None

        result = read_tsv(
            ["test_data/unittest/predictions/cat_pred_results.txt"],
            multi_line=True,
            use_max_score=False)
        slot_value_first_ture = ["Sports"]
        self.assertEqual(slot_value_0, result[res_key_0][slot_name])
        self.assertEqual(slot_value_first_ture, result[res_key_2][slot_name])

    def test_read_squad_file(self):

        result = read_squad_file(
            ["test_data/unittest/predictions/squad_nbest.json"])
        res_key_0 = ("9_00000", 0, "Events_1")
        res_key_2 = ("9_00000", 2, "Events_1")
        slot_name = "event_name"
        slot_value = ["cool"]
        self.assertTrue(slot_name not in result[res_key_0])  # None
        self.assertEqual(slot_value, result[res_key_2][slot_name])

    def test_ontology(self):
        ontology_ref = {
            "Events_1-event_name": ["cool event", "park", "dontcare"],
            "Events_1-subcategory": ["nothing"]
        }
        ontology = load_ontology("test_data/unittest/multiwoz/ontology.json")

        self.assertEqual(ontology, ontology_ref)

        result = read_squad_file(
            ["test_data/unittest/predictions/squad_nbest.json"],
            ontology=ontology,
            threshold=0.7)
        res_key_0 = ("9_00000", 0, "Events_1")
        res_key_2 = ("9_00000", 2, "Events_1")
        slot_name = "event_name"
        slot_value = ["cool event"]
        self.assertTrue(slot_name not in result[res_key_0])  # None
        self.assertEqual(slot_value, result[res_key_2][slot_name])


if __name__ == '__main__':
    logging.basicConfig(datefmt="%m/%d/%Y %H:%M:%S", level=logging.INFO)
    unittest.main()