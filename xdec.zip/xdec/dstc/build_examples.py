import os
import json
import logging

from xdec_config import get_logger
logger = get_logger(__name__)
logger.setLevel(logging.DEBUG)


def get_system_context(system_turn_former, system_turn_later=None):
    context = ''

    def generate_turn_context(turn):
        context = ''
        for frame in turn['frames']:
            context += "Service: " + frame['service'] + ': '
            for action in frame['actions']:
                context += 'action is ' + action['act']
                if len(action['slot']) > 0:
                    context += ', ' + 'has slot ' + action['slot']
                if len(action['values']) > 0:
                    context += ', has values ' + ' and '.join(action['values'])
                context += ' . '
        return context

    if system_turn_former:
        context += 'System summary: '
        context += generate_turn_context(system_turn_former)

    return context


def dstc2squad(data_path, output_path):
    MAX_TURN_SIZE = 30
    dirname = os.path.dirname(data_path)
    table_path = os.path.basename(data_path)
    table_path = os.path.splitext(table_path)
    expanded_path = os.path.join(dirname, table_path[0])
    logger.info("DSTC path: {}".format(expanded_path))

    service_dict = {}
    with open(os.path.join(expanded_path, "schema.json")) as example_file:
        entry = json.load(example_file)
        for schema_frame in entry:
            service_name = schema_frame["service_name"]
            service_dict[service_name] = schema_frame
    # logger.debug("Service mapping: {}".format(
    #     json.dumps(service_dict, sort_keys=True, indent=2)))

    data = []
    for root, dirs, files in os.walk(expanded_path):
        for f in files:
            if "dialogues_" in f:
                with open(os.path.join(expanded_path, f)) as example_file:
                    logger.info("Processing: {}\t{}".format(data_path, f))
                    entry = json.load(example_file)
                    paragraphs = []
                    title = 'Dialog state: {}'.format(f)
                    for dialogue in entry:
                        # logging.debug("\nDialog:\n{}".format(
                        #     json.dumps(dialogue, sort_keys=True, indent=2)))
                        services = dialogue["services"]
                        dialogue_id = dialogue["dialogue_id"]
                        for i in range(len(dialogue["turns"])):
                            if dialogue["turns"][i]["speaker"] == "USER":
                                context_turns = dialogue["turns"][
                                    max(0, i - MAX_TURN_SIZE + 1):i + 1]
                                context = ""
                                if i > MAX_TURN_SIZE:
                                    logger.warning(
                                        "LARGE TURN SIZE: {} | context: {}"
                                        .format(i, context))
                                # extract current state
                                current_states = {}
                                for frame in dialogue["turns"][i]["frames"]:
                                    current_states[frame["service"]] = frame[
                                        "state"]["slot_values"]

                                # print('file', f, 'dialogue_id', dialogue_id)
                                # print('current_states', current_states)
                                for context_turn in context_turns:
                                    context += context_turn["speaker"] + \
                                        ": " + context_turn["utterance"] + " "
                                system_context = get_system_context(dialogue["turns"][i-1]).strip() \
                                    if i > 0 else None
                                if system_context:
                                    context = system_context + " " + context.strip(
                                    )
                                qas = []
                                for service_name in services:
                                    for slot_in_schema in service_dict[
                                            service_name]["slots"]:
                                        slot_name = slot_in_schema["name"]
                                        if slot_in_schema["is_categorical"]:
                                            continue
                                        if service_name in current_states and slot_name in current_states[
                                                service_name]:
                                            qas_item = tag_slot(
                                                service_name, slot_in_schema,
                                                context,
                                                current_states[service_name]
                                                [slot_name][0])
                                        else:
                                            qas_item = tag_slot(
                                                service_name, slot_in_schema,
                                                context, "__none__")
                                        qas_item["id"] = "{}|{}|{}|{}".format(
                                            dialogue_id, i, service_name,
                                            slot_name)
                                        qas.append(qas_item)
                                paragraphs.append({
                                    "context": context,
                                    "qas": qas
                                })
                    datum = {"title": title, "paragraphs": paragraphs}
                # logger.info("datum: {}".format(datum))
                # logger.info("")
                data.append(datum)

    # logger.info("Data:\n{}".format(data[-20:]))
    with open(output_path, 'w') as output:
        output.write(
            json.dumps({
                "data": data,
                "version": "2.0"
            }, indent=2) + '\n')


def tag_slot(service_name, slot, context, value):
    # val = value if value != "dontcare" else "Don't care"
    # print(full_context)
    # print('val', val)
    is_possible = True
    start = context.find(value)
    if start < 0:
        if value != "__none__":
            logger.warning("Value not found: {} _IN_ {}".format(value, context))
        is_possible = False
    question = slot["description"]
    qas_item = {"question": question, "is_impossible": not is_possible}
    qas_item["answers"] = [{"answer_start": start, "text": value}] \
            if is_possible else []
    return qas_item


if __name__ == '__main__':
    dstc2squad(".data/dstc8-schema-guided-dialogue/train",
               "dstc8-squad-30/train.json")
    dstc2squad(".data/dstc8-schema-guided-dialogue/dev",
               "dstc8-squad-30/dev.json")
