import os
import re
import zipfile
import torch
import io
import csv
import json
import glob
import hashlib
import unicodedata
import re
import logging
import copy
from nltk.tokenize import TreebankWordTokenizer
from nltk.tokenize.treebank import TreebankWordDetokenizer

CONTEXT_CMP = ["context_tok", "context_pos", "context_ner", "context_tag"]
QUESTION_CMP = ["question_tok", "question_pos", "question_ner", "question_tag"]
CONTEXT_SPECIAL = 'Context:'
QUESTION_SPECIAL = 'Question:'
SERVICE_SPECIAL = 'Service:'
EMPTY = 'EMPTY'
TOKEN = "token"
POS = "pos"
NER = "ner"
SYSTEM_TAG = "system_tag"
DESCRIPTION = "description"
ACT = 'act'
SLOT = 'slot'
POSSIBLE_VALUES = 'possible_values'
TRUE_FALSE = set(["True", "False"])
SYSTAGS = {
    "name": "name",
    'time': 'time',
    'date': 'date',
    'location': 'location',
    'station': 'location',
    'city': 'location',
    'destination': 'location',
    'number': 'number',
    'address': 'address',
    'rating': 'rating',
    'price': 'price',
    'fare': 'fare',
    'type': 'type'
}
VALUE_ACTIONS = ["CONFIRM", "OFFER", "INFORM"]
REQUEST_ACTIONS = ["REQUEST"]
ACCEPT = [
    'yes', 'wonderful', 'correct', 'excellent', 'perfect', 'works', 'great'
]

GENERATION = "generation"
FOUR_WAY = "four_way"
BINARY = "binary"
UNIFY = "unify"

MAP_TASK_TYPE = {
    GENERATION: [1, 0, 0],
    FOUR_WAY: [0, 1, 0],
    BINARY: [0, 0, 1],
    UNIFY: [1, 0, 1]
}

DONTCARE = "dontcare"
MAP_FOUR_WAY = {"True": 0, "False": 1, DONTCARE: 2, "None": 3}
MAP_ANSWER_TYPE = {"Active": 0, DONTCARE: 1, "None": 2}
OTHER = "other"

SHORT_YEARS = {
    "'10": "2010",
    "'11": "2011",
    "'12": "2012",
    "'13": "2013",
    "'14": "2014",
    "'15": "2015",
    "'16": "2016",
    "'17": "2017",
    "'18": "2018",
    "'19": "2019",
    "'20": "2020",
    " ' 10": " ' 2010",
    " ' 11": " ' 2011",
    " ' 12": " ' 2012",
    " ' 13": " ' 2013",
    " ' 14": " ' 2014",
    " ' 15": " ' 2015",
    " ' 16": " ' 2016",
    " ' 17": " ' 2017",
    " ' 18": " ' 2018",
    " ' 19": " ' 2019",
}
YEARS = {
    2018: ["last year", "one years ago", "one year ago", "one years back"],
    2019: ["this year"],
    2020: ["next year"]
}


def int_to_english(num):
    d = {
        0: 'zero',
        1: 'one',
        2: 'two',
        3: 'three',
        4: 'four',
        5: 'five',
        6: 'six',
        7: 'seven',
        8: 'eight',
        9: 'nine',
        10: 'ten',
        11: 'eleven',
        12: 'twelve',
        13: 'thirteen',
        14: 'fourteen',
        15: 'fifteen',
        16: 'sixteen',
        17: 'seventeen',
        18: 'eighteen',
        19: 'nineteen',
        20: 'twenty',
        30: 'thirty',
        40: 'forty',
        50: 'fifty',
        60: 'sixty',
        70: 'seventy',
        80: 'eighty',
        90: 'ninety'
    }

    if num in d:
        return [d[num]]
    elif num < 100:
        return [d[num // 10 * 10] + ' ' + d[num % 10]]

    elif 1919 < num < 2018:
        pre_num = 2019 - num
        pre_eng = int_to_english(pre_num)[0]
        return ["{} years ago".format(pre_eng), "{} years back".format(pre_eng)]
    elif num in YEARS:
        return YEARS[num]
    else:
        return None


def is_boolean_slot(system_slot):
    possible_values = system_slot.get(POSSIBLE_VALUES, [])
    return set(possible_values) == TRUE_FALSE


def is_number_slot(system_slot):
    if len(system_slot[POSSIBLE_VALUES]) > 0:
        is_number = True
        for value in system_slot[POSSIBLE_VALUES]:
            if not value.isnumeric():
                is_number = False
        return is_number
    else:
        return False


def get_slot_type(system_slot):
    is_categorical = system_slot['is_categorical']
    if not is_categorical:
        return "noncategorical"
    if is_number_slot(system_slot):
        return "number"
    if is_boolean_slot(system_slot):
        return "boolean"
    return "categorical"


def get_meaningful_value(cand, system_slot, context, positive=False):
    slot_name = system_slot["name"]
    q = " ".join(slot_name.split("_")).replace("number of ", "")
    context_tok = " ".join([x for (_, x, _, _, _, _) in context]).lower()
    context_tok = " " + context_tok + " "

    match_type = "raw"
    if cand == DONTCARE:
        return "any {} , don't care {}".format(q, q), match_type
    elif cand == "None":
        return cand, match_type
    elif is_number_slot(system_slot):
        # try to find the longest match string in context
        # travelers (people, passengers, person)
        # transfers (stops)
        # group_size (people, person, group)
        # number_of_seats (seats, seat, tickets)
        # number_of_beds (beds, bed)
        # number_of_rooms (rooms, room)
        # star_rating (stars, ratings)
        # number_of_tickets (tickets, person, people)
        # party_size (people?)
        # number_of_riders (riders)

        if cand.strip().isnumeric():
            alt_cands = []
            eng = int_to_english(int(cand))
            if eng is not None:
                eng.append(cand)
            else:
                eng = [cand]

            for e in eng:
                alt_cands.append(" " + e + " " + q)
            if q[-1] == "s":
                for e in eng:
                    alt_cands.append(" " + e + " " + q[:-1])
            for e in eng:
                alt_cands.append(" " + e)

            for acand in alt_cands:
                if acand in context_tok:
                    match_type = "long"
                    if len(acand.strip().split()) == 1:
                        if positive:
                            logging.info("Can only find {}".format(acand))
                        acand = "{} {}".format(acand, q)
                        match_type = "short"
                    elif positive:
                        logging.info("Find longer value")
                    return acand, match_type
            if positive:
                logging.info("Value cannot find {} candiates in {}".format(
                    alt_cands, context_tok))
        return "{} {}".format(cand, q), match_type
    elif cand == "True":
        return "yes {}".format(q), match_type
    elif cand == "False":
        return "not {}".format(q), match_type

    return cand, match_type


def find_start_end(context_tok, answer, answer_tok, is_num, slot_name):
    """
        find the postion of answer in context, handcarfted rules
    """
    rewrite_answer, rewrite_answer_tok = None, None
    q = " ".join(slot_name.split("_")).replace("number of ", "")

    # rfind the answer tok in context tok, it's a close span: []
    context_tok_lower = " " + context_tok.lower() + " "
    answer_tok_lower = " " + answer_tok.lower() + " "

    alt_cands = []
    if is_num:
        # find num + quantifier first
        if answer_tok.strip().isnumeric():
            eng = int_to_english(int(answer_tok.strip()))
            if eng is not None:
                eng.append(answer_tok_lower)
            else:
                eng = [answer_tok_lower]
            # put num + quantifer first
            for e in eng:
                alt_cands.append(" " + e + " " + q)
            if q[-1] == "s":
                for e in eng:
                    alt_cands.append(" " + e + " " + q[:-1])
            for e in eng:
                alt_cands.append(" " + e + " ")

        elif answer_tok.strip() not in ["None", "none"]:
            logging.warn("answer is not numberic! {}".format(answer_tok))

    alt_cands.append(answer_tok_lower)
    if " the " in answer_tok_lower and len(answer_tok_lower) > 6:
        alt_cands.append(answer_tok_lower.replace(" the ", " "))
    # remove the " . " in the end
    if " . " in answer_tok_lower:
        alt_cands.append(answer_tok_lower.replace(" . ", " "))
    # put a dot at the end of answer: la , ca ==> la , ca.
    alt_cands.append(" " + answer_tok.lower() + ". ")
    if "." in answer_tok_lower:
        alt_cands.append(answer_tok_lower.replace(".", " . "))

    start_, end_ = 0, 0
    find = False
    for atl in alt_cands:
        answer_tok_spos = context_tok_lower.rfind(atl)
        if answer_tok_spos > 0:
            start_ = context_tok_lower[:answer_tok_spos].count(" ")
            end_ = start_ + atl.strip().count(" ")
            find = True

            # lets change the answer
            new_answer_tok = " ".join(context_tok.split(" ")[start_:end_ + 1])

            if is_num and atl.strip() not in ["None", "none"
                                             ] and atl.strip().count(" ") == 0:
                # atl: "three" or "2"
                new_answer_tok += (" " + q)

            new_answer = TreebankWordDetokenizer().detokenize(
                new_answer_tok.split())
            if new_answer != answer or new_answer_tok != answer_tok:
                logging.info("Replacing {}answer '{}' with '{}'".format(
                    " number " if is_num else "", answer, new_answer) +
                             ", answer_tok '{}' with '{}'".format(
                                 answer_tok, new_answer_tok))
                rewrite_answer = new_answer
                rewrite_answer_tok = new_answer_tok

            break

    return (find, start_, end_, rewrite_answer, rewrite_answer_tok, alt_cands)


def gen_slot_value_features(slot_value,
                            features,
                            trans=None,
                            curr=None,
                            pre=None,
                            his=None,
                            dialogue_type="single"):

    def find_trans(utt):
        contain_tran = "False"
        if trans is not None:
            for t in trans:
                if len(t) > 0 and (" " + t.lower() + " ") in utt:
                    contain_tran = "True"
                    break
        return contain_tran

    if slot_value not in ["None", 'none', DONTCARE]:
        # skip generate features for None slot value
        low_sv = " " + slot_value.lower() + " "
        low_partial = []
        if len(low_sv.strip().split()) > 0:
            for part in low_sv.strip().split():
                if len(part) > 4:  # simply check long words
                    low_partial.append(" " + part + " ")

        # current turn
        curr = (" " + curr.lower() + " ") if curr is not None else ""
        features["curr_contain_slot_value"] = str(low_sv in curr)
        features["curr_contain_slot_value_tran"] = find_trans(curr)
        features["curr_contain_slot_value_partial"] = str(
            sum([1 for lp in low_partial if lp in curr]))

        # history
        his_tok = (" " + " ".join([x[1] for x in his]) +
                   " ").lower() if his is not None else ""
        features["his_contain_slot_value"] = str(low_sv in his_tok)
        features["his_contain_slot_value_tran"] = find_trans(his_tok)
        features["his_contain_slot_value_partial"] = str(
            sum([1 for lp in low_partial if lp in his_tok]))

        # previous system turn
        pre = " " + pre.lower() + " " if pre is not None else ""
        features["pre_contain_slot_value"] = str(low_sv in pre)
        features["pre_contain_slot_value_tran"] = find_trans(pre)
        features["pre_contain_slot_value_partial"] = str(
            sum([1 for lp in low_partial if lp in pre]))

        if "pre_sys_value" in features:
            pre_sys_value_low = features["pre_sys_value"].lower()
            is_contain = slot_value.lower() == pre_sys_value_low
            if is_contain:
                features["pre_sys_value_contain_slot_value"] = str(is_contain)
                features["pre_sys_act_contain"] = features["pre_sys_act"]

            contain_tran = "False"
            if trans is not None:
                for t in trans:
                    if len(t) > 0 and t.lower() == pre_sys_value_low:
                        contain_tran = "True"
            features["pre_sys_act_contain_tran"] = contain_tran

    # clean features
    if "pre_sys_value" in features:
        del features["pre_sys_value"]
    if "pre_sys_act" in features:
        del features["pre_sys_act"]
    # delete all "False" value features:
    del_keys = [k for (k, v) in features.items() if v in ["False", '0']]
    for k in del_keys:
        del features[k]

    if False:
        logging.info("Extract featurs:\nCurr: {}\nPre: {} \nHis: {}".format(
            curr, pre, his_tok if his is not None else None))
        logging.info("Trans: {}".format(trans))
        logging.info("Slot: {}\nFeatures: {}".format(slot_value, features))


def gen_slot_features(turn,
                      system_slot,
                      pre_turn,
                      pre_sys_acts={},
                      turn_idx=0,
                      history=None):
    '''
    generation sparse features for W&D classfication
      https://drive.google.com/file/d/1lQtZBOQwico4Kz8sXRcAguOYOMdTdQJx/view
    The tone of the utterance: interrogative, negative, declarative 
       (by using regular expressions which generated from training dataset).
    Whether the utterance contains boolean slot descriptions or synonyms of 
      these descriptions.
    Whether the utterance contains the values of text-based slots and synonyms
       of these slot values.
    Does the slot exist in the previous system actions? If it exists, 
      which action? INFORM, REQUEST, OFFER or CONFIRM?
    The answer is yes or no.
    Whether the slot appears in requested slots in the current turn?
      Q: we need to predict requested slots first?
    The information of the current turn throughout the whole dialogue, 
     e.g., turn number.
    Whether the slot is mentioned in the history?
    '''

    def gen_feats(utterance):
        # feature: tone of the utterance
        utterance = " " + utterance.strip().lower() + " "
        utt_type = "statement"
        if "?" in utterance:
            utt_type = "question"
        elif (" n't " in utterance or " not " in utterance or
              " no " in utterance):
            utt_type = "negative"
        else:
            for positive in ACCEPT:
                if positive in utterance:
                    utt_type = "positive"
                    break

        return utt_type

    features = {}
    slot_name = system_slot["name"]

    features["curr_utt_type"] = gen_feats(turn["token"])
    if pre_turn is not None:
        features["pre_utt_type"] = gen_feats(pre_turn["token"])

    # feature: system action
    if slot_name in pre_sys_acts:
        (act_name_value, _) = pre_sys_acts[slot_name]
        sys_act, sys_value = act_name_value.split(":", 1)
        features["pre_sys_act"] = sys_act.strip()
        features["pre_sys_value"] = sys_value.strip()

    if turn_idx < 7:
        feat_turn_idx = turn_idx
    elif turn_idx < 15:
        feat_turn_idx = 10
    else:
        feat_turn_idx = 15
    features["turn_idx"] = str(feat_turn_idx)

    return features


def process_system_tag(sys_tag):
    class_tags = []
    for tag in sys_tag.split():
        ctag = "OTHER" if tag != "O" else "S"
        for k, v in SYSTAGS.items():
            if k in tag:
                ctag = v
                break
        class_tags.append(ctag)
    return " ".join(class_tags)


def get_context_question(context, question):
    return ' '.join([CONTEXT_SPECIAL, context, QUESTION_SPECIAL, question])


def load_schema_info(schema_file):
    schema_dict = {}
    with open(schema_file) as example_file:
        logging.info("Loading schema from {}".format(schema_file))
        entry = json.load(example_file)
        for schema_frame in entry:
            schema_dict[schema_frame['service_name']] = {
                'slots': schema_frame['slots'],
                'intents': schema_frame['intents']
            }
    return schema_dict


class DSTCReranking:

    @staticmethod
    def build_examples(ref_path,
                       hyp_path,
                       output_file,
                       subsample=None,
                       use_stream=False,
                       is_reranking=True,
                       is_gpt2=False,
                       add_cands=False,
                       turn_round=20):
        """
        generate reranking examples from DSTC decode and refe dialogue files
        """

        schema_file = os.path.join(ref_path, 'schema.json')
        schema_dict = load_schema_info(schema_file)
        output = open(output_file, 'w')
        if is_gpt2:
            output_txt = open(output_file[:output_file.rindex(".")] + ".txt",
                              "w")
            output_src_txt = open(
                output_file[:output_file.rindex(".")] + ".src.txt", "w")

        tot_examples = 0
        if is_reranking:
            logging.info("Loading hyps from {}".format(hyp_path))
        for root, dirs, files in os.walk(ref_path):
            logging.info("Loading references from {} {}".format(root, dirs))
            for f in files:
                if 'dialogues_' not in f:
                    continue

                logging.info("Loading file {}".format(f))
                hyp_file = os.path.join(hyp_path, f) if is_reranking else None
                examples = DSTCReranking.extract_examples_from_file(
                    os.path.join(ref_path, f),
                    hyp_file,
                    schema_dict,
                    use_stream,
                    add_cands=add_cands,
                    use_special_token=is_gpt2,
                    turn_round=turn_round)

                tot_examples += len(examples)

                for example in examples:
                    output.write(json.dumps(example) + "\n")
                    if is_gpt2:
                        content = example["src"].strip(
                        ) + " <beginofstates> " + example["tgt"]
                        output_txt.write(content + "\n")
                        output_src_txt.write(example["src"].strip() +
                                             " <beginofstates> " + "\n")

        output.close()
        logging.info("Total number of examples: {}".format(tot_examples))
        return tot_examples

    @staticmethod
    def gen_cands_string(slots_intents, service_name):
        '''
        schema:
            "slots": [
                {
                    "name": "number_of_seats",
                    "description": "number of seats",
                    "is_categorical": true,
                    "possible_values": ['1', '2', '3', '4', '5', '6', '7']
                ...
            "intents": [
                {
                    "name": "ReserveRestaurant",
                    "description": "Make a table reservation",
                    "is_transactional": true,
        '''
        cands = "CANDS: "
        for slot in slots_intents["slots"]:
            slot_name = slot["name"]
            slot_values = ' , '.join(slot["possible_values"])
            cands += f" {service_name} # {slot_name} # {slot_values} ;"
        return cands.strip(" ;")

    @staticmethod
    def gen_state_string(frame,
                         schema,
                         service_name="",
                         use_special_token=False,
                         is_ref=True):
        '''
        frame: 
            "service": "Restaurants_2",
            "state": {
                "active_intent": "ReserveRestaurant",
                "requested_slots": [],
                "slot_values": {
                    "number_of_seats": ["2"],
                    "time": ["half past 11 in the morning"]
                }
            }
        schema:
            "slots": [
                {
                    "name": "number_of_seats",
                    "description": "number of seats",
                    "is_categorical": true,
                    "possible_values": ['1', '2', '3', '4', '5', '6', '7']
                ...
            "intents": [
                {
                    "name": "ReserveRestaurant",
                    "description": "Make a table reservation",
                    "is_transactional": true,
        '''
        state_str = "HYP:" if not is_ref else ""
        slot_values = frame["state"]["slot_values"]
        for slot in schema["slots"]:
            slot_name = slot["name"]
            slot_value = slot_values.get(slot_name, ["None"])
            if use_special_token:
                state_str += f" <servicename> {service_name} <slotname> {slot_name} <slotvalue> {slot_value[0]} ;"
            else:
                state_str += f" {service_name} # {slot_name} # {slot_value[0]} ;"
        return state_str.strip(" ;")

    @staticmethod
    def extract_examples_from_file(ref_file_name,
                                   hyp_file_name,
                                   schema_dict,
                                   use_stream,
                                   add_cands=False,
                                   use_special_token=False,
                                   turn_round=20):
        examples = []

        with open(ref_file_name) as ref_file:
            ref_entry = json.load(ref_file)
        if hyp_file_name is not None:
            with open(hyp_file_name) as hyp_file:
                hyp_entry = json.load(hyp_file)
        is_reranking = hyp_file_name is not None

        for d_id, dialogue in enumerate(ref_entry):
            turns = dialogue['turns']
            dialogue_id = dialogue['dialogue_id']
            if is_reranking:
                hyp_dialogue = hyp_entry[d_id]
                hyp_dialogue_id = hyp_dialogue['dialogue_id']
                assert (
                    dialogue_id == hyp_dialogue_id
                ), f"Ref hyp missmatch: {dialogue_id} VS {hyp_dialogue_id}"
                hyp_turns = hyp_dialogue['turns']

            turns_list = []
            for t in turns:
                turn_u = t['utterance']
                us = 'User' if t['speaker'] == 'USER' else 'SYSTEM'
                turns_list.append('{}: {}'.format(us, turn_u))

            for t_id, turn in enumerate(turns):
                if turn['speaker'] == 'USER':
                    start = t_id - turn_round if (t_id - turn_round) >= 0 else 0
                    context = " ".join(turns_list[start:t_id + 1]).strip()

                    for frame in turn['frames']:
                        service_name = frame["service"]
                        slots_intents = schema_dict[service_name]
                        hyp = ""
                        # generate an example for each frame
                        if is_reranking:
                            hyp_turn = hyp_turns[t_id]
                            tmp_hyp_frame = {"state": {"slot_values": {}}}
                            for hyp_frame in hyp_turn["frames"]:
                                if hyp_frame["service"] == service_name:
                                    tmp_hyp_frame = hyp_frame
                                    break
                            hyp = ". " + DSTCReranking.gen_state_string(
                                tmp_hyp_frame,
                                slots_intents,
                                service_name=service_name,
                                is_ref=False)

                        cands = DSTCReranking.gen_cands_string(
                            slots_intents, service_name) if add_cands else ""
                        if cands != "":
                            cands = ". " + cands
                        if use_special_token:
                            src = f"{context} <servicename> {service_name} {cands} {hyp}"
                        else:
                            src = f"{context} . {service_name} {cands} {hyp}"
                        tgt = DSTCReranking.gen_state_string(
                            frame,
                            slots_intents,
                            service_name=service_name,
                            use_special_token=use_special_token,
                            is_ref=True)

                        aux_id = "{}|{}|{}".format(dialogue_id, t_id,
                                                   service_name)

                        example = {'src': src, 'tgt': tgt, 'aux_id': aux_id}
                        examples.append(example)
        return examples


class DSTCSlot:

    @staticmethod
    def gen_an_example(system_slot,
                       turn_id,
                       question_streams,
                       answer_streams,
                       slot_value="",
                       ds_name=None,
                       slot_type="categorical",
                       dialogue_id=None,
                       context=None,
                       unify=False,
                       fields=None,
                       features={},
                       is_num=False):
        slot_name = system_slot["name"]

        (question_utt, question_tok, question_pos, question_ner,
         question_tag) = question_streams

        (task_type, answer_type, answer, answer_tok, answer_four_way,
         answer_binary) = answer_streams

        # extract preceding system turn_acts first, add insert those strings
        # before the user turn
        pre_sys_acts = None
        if len(context) > 1:
            pre_sys_acts = context[-2][-1].get(system_slot["name"], None)

        # history of the last user turn
        context_utt = " ".join([x for (x, _, _, _, _, _) in context[:-1]])
        context_tok = " ".join([x for (_, x, _, _, _, _) in context[:-1]])
        context_pos = " ".join([x for (_, _, x, _, _, _) in context[:-1]])
        context_ner = " ".join([x for (_, _, _, x, _, _) in context[:-1]])
        context_tag = " ".join([x for (_, _, _, _, x, _) in context[:-1]])

        if slot_type == "categorical" and False:
            logging.info("Context_tok:\n\t{}".format("\n\t".join(
                [x for (_, x, _, _, _, _) in context])))
            logging.info("Question_tok: {}".format(question_tok))
            logging.info("slot_name: {}, slot_type: {}, slot_value: {}".format(
                slot_name, slot_type, slot_value))
            if pre_sys_acts is not None:
                (pre_sys_tok, _) = pre_sys_acts
                logging.info("pre_sys_acts: {}".format(pre_sys_tok))
            logging.info("Answer: {}".format(answer_binary))
            logging.info("Features:\n\t{}\n\n".format("\n\t".join(
                ["{}: {}".format(k, v) for (k, v) in features.items()])))

        # append system actions
        if pre_sys_acts is not None:
            (pre_sys_tok, pre_sys_pos) = pre_sys_acts
            context_utt += (" " + pre_sys_tok)
            context_tok += (" " + pre_sys_tok)
            context_pos += (" " + pre_sys_pos)
            context_ner += (" " + pre_sys_pos)
            context_tag += (" " + " ".join("S" for _ in pre_sys_pos.split()))

        # append the last user turn
        context_utt += (" " + context[-1][0])
        context_tok += (" " + context[-1][1])
        context_pos += (" " + context[-1][2])
        context_ner += (" " + context[-1][3])
        context_tag += (" " + context[-1][4])

        if unify:
            # append the True False dontcare None
            common_ = " ".join(["True", "False", DONTCARE, "None"])
            context_utt += (" " + common_)
            context_tok += (" " + common_)
            context_pos += (" " + common_)
            context_ner += (" " + common_)
            context_tag += (" " + common_)

        # strip before processing anything
        context_utt = context_utt.strip()
        context_tok = context_tok.strip()
        context_pos = context_pos.strip()
        context_ner = context_ner.strip()
        context_tag = context_tag.strip()

        if EMPTY not in context_ner:
            len_tok = len(context_tok.split())
            len_pos = len(context_pos.split())
            len_ner = len(context_ner.split())
            len_tag = len(context_tag.split())

            if not len_tok == len_pos == len_ner == len_tag:
                for p, l in [(context_tok, len_tok), (context_pos, len_pos),
                             (context_ner, len_ner), (context_tag, len_tag)]:
                    logging.info("{} : {}".format(
                        l, " ".join([
                            "{}:{}".format(i, v)
                            for i, v in enumerate(p.split())
                        ])))
            assert len_tok == len_pos == len_ner == len_tag

        (find, start_, end_, rewrite_answer, rewrite_answer_tok,
         alt_cands) = find_start_end(context_tok, answer, answer_tok,
                                     is_num if not unify else False, slot_name)
        if rewrite_answer is not None:
            answer = rewrite_answer
            answer_tok = rewrite_answer_tok

        if (not find and task_type[0] == 1 and
                answer_tok not in ["None", DONTCARE, "none"]):
            # this is a generation task, but cannot find the answer, here
            # we return a None.
            logging.warn("cannot find {} '{}' in dialogue history: {}".format(
                "num" if is_num else "", "' or '".join(alt_cands),
                context_tok.replace("System : ", "\n  System : ").replace(
                    "User : ", "\n  User : ")))
            logging.warn("\nquestion_tok: {}\n\n".format(question_tok))
            return None

        ex = {
            "context":
                context_utt,
            "question":
                question_utt,
            "answer":
                answer,
            "context_tok":
                context_tok,
            "context_pos":
                context_pos,
            "context_ner":
                context_ner,
            "context_tag":
                context_tag,
            "question_tok":
                question_tok,
            "question_pos":
                question_pos,
            "question_ner":
                question_ner,
            "question_tag":
                question_tag,
            "answer_tok":
                answer_tok,
            "answer_type":
                answer_type,
            "answer_four_way":
                answer_four_way,
            "answer_binary":
                answer_binary,
            "answer_span_start":
                start_,
            "answer_span_end":
                end_,
            "task_type":
                task_type,
            "slot_type":
                slot_type,
            "features":
                features,
            "aux":
                "{}|{}|{}|{}|{}".format(dialogue_id, turn_id, ds_name,
                                        system_slot["name"], slot_value)
        }
        return ex

    @staticmethod
    def build_unify_example(system_slot,
                            turn,
                            i,
                            ds_info=None,
                            ds_name=None,
                            add_back_trans=False,
                            add_service_des=False,
                            dialogue_id=False,
                            context=None,
                            fields=None):
        (question_utt, question_tok, question_pos, question_ner, question_tag,
         (_, answer_cands)) = DSTCSlot.get_slot_description(
             system_slot,
             ds_info=(ds_info if add_service_des else None),
             add_back_trans=add_back_trans,
             unify=True)

        task_type = MAP_TASK_TYPE[UNIFY]
        is_categorical = system_slot['is_categorical']
        is_num = is_number_slot(system_slot)
        slot_type = get_slot_type(system_slot)
        slot_name = system_slot["name"]

        answer_str, answer_str_tok = "None", "None"
        for frame in turn["frames"]:
            if frame["service"] == ds_name:
                state = frame["state"]
                slot_values = state["slot_values"]
                tok_slot_values = state.get("tok_slot_values", {})
                slot_name = system_slot["name"]
                if slot_name in slot_values:
                    answer_str = slot_values[slot_name][-1]
                    answer_str_tok = " ".join(
                        TreebankWordTokenizer().tokenize(answer_str))
                    if slot_name in tok_slot_values:
                        answer_str_tok = tok_slot_values[slot_name][-1]
                break

        answer_cands_ori = [x for x in answer_cands[0]]
        answer_cands_trans = [x for x in answer_cands[1]]
        # append all the possibe results
        if not is_categorical:
            answer_cands_ori.append("generation")
            answer_cands_trans.append("generation")

        answer_cands_ori.extend([DONTCARE, "None"])
        answer_cands_trans.extend([DONTCARE, "None"])

        # answer_cands_ori: ["Film", "Music"]
        # answer_cands_trans: ["Movie", "Songs"]
        has_trans = len(answer_cands_ori) == len(answer_cands_trans)
        exs = []

        if answer_str == "None":
            answer_type_str = "None"
        elif answer_str == DONTCARE:
            answer_type_str = DONTCARE
        else:
            answer_type_str = "Active"
        answer_type = MAP_ANSWER_TYPE[answer_type_str]

        for idx, cand in enumerate(answer_cands_ori):
            answer_binary = 0 if cand != answer_str else 1
            if not is_categorical and cand == "generation":
                # generation task
                if answer_str not in [DONTCARE, "None"]:
                    answer_binary = 1

            m_value, _ = get_meaningful_value(cand, system_slot, context,
                                              answer_binary)
            m_value = m_value.strip()
            # append value to the end of question
            if is_num:
                value = " is {}".format(m_value)
                # append quantifier
                quantifier = " ".join(slot_name.lower().split("_"))
                quantifier = quantifier.replace("number of", "")
                if m_value.split() == 1:
                    # only have a number
                    value += " " + quantifier
            else:
                value = " is {}{}".format(
                    m_value, " , {}".format(answer_cands_trans[idx]) if
                    has_trans and cand not in answer_cands_trans[idx] else "")

            answer = "True" if answer_binary else "False"
            answer_tok = answer
            if not is_categorical and cand == "generation":
                # generation task
                if answer_str not in [DONTCARE, "None"]:
                    answer = answer_str
                    answer_tok = answer_str_tok

            qu_ = question_utt + " " + value
            qt_ = question_tok + " " + value
            qp_ = question_pos + " " + " ".join(["V" for _ in value.split()])
            qn_ = question_ner + " " + " ".join(["V" for _ in value.split()])
            qg_ = question_tag + " " + " ".join(["Q" for _ in value.split()])
            ex = DSTCSlot.gen_an_example(
                system_slot,
                i, (qu_, qt_, qp_, qn_, qg_),
                (task_type, answer_type, answer, answer_tok, 0, answer_binary),
                slot_value=cand,
                ds_name=ds_name,
                slot_type=slot_type,
                dialogue_id=dialogue_id,
                context=context,
                unify=True,
                fields=fields)
            if ex is not None:
                exs.append(ex)
        return exs

    @staticmethod
    def build_categorical_example(system_slot,
                                  turn,
                                  turn_id,
                                  ds_info=None,
                                  ds_name=None,
                                  add_back_trans=False,
                                  add_service_des=False,
                                  dialogue_id=None,
                                  context=None,
                                  pre_turn=None,
                                  history=None,
                                  features={},
                                  dontcare=False,
                                  fields=None,
                                  dialogue_type="single"):
        (question_utt, question_tok, question_pos, question_ner, question_tag,
         (task_type_str, answer_cands)) = DSTCSlot.get_slot_description(
             system_slot,
             ds_info=(ds_info if add_service_des else None),
             add_back_trans=add_back_trans,
             dontcare=dontcare)
        task_type = MAP_TASK_TYPE[task_type_str]
        slot_type = get_slot_type(system_slot)
        slot_name = system_slot["name"]
        is_num = is_number_slot(system_slot)

        if task_type_str == FOUR_WAY:
            answer_binary = 0
            # only one instance
            answer_four_way_str = "None"
            for frame in turn["frames"]:
                if frame["service"] == ds_name:
                    state = frame["state"]
                    slot_values = state["slot_values"]
                    if slot_name in slot_values:
                        answer_four_way_str = slot_values[slot_name][-1]
                    break
            answer_four_way = MAP_FOUR_WAY[answer_four_way_str]

            if answer_four_way == "None":
                answer_type_str = "None"
            elif answer_four_way == DONTCARE:
                answer_type_str = DONTCARE
            else:
                answer_type_str = "Active"
            answer_type = MAP_ANSWER_TYPE[answer_type_str]

            # a four-way class: the truth is the answer
            answer = answer_four_way_str
            ex = DSTCSlot.gen_an_example(
                system_slot,
                turn_id, (question_utt, question_tok, question_pos,
                          question_ner, question_tag),
                (task_type, answer_type, answer, answer, answer_four_way,
                 answer_binary),
                slot_value="",
                ds_name=ds_name,
                slot_type=slot_type,
                dialogue_id=dialogue_id,
                context=context,
                features=features,
                fields=fields)
            return [] if ex is None else [ex]

        else:  # BINARY
            answer_four_way = 0

            answer_binary_str = "None"
            for frame in turn["frames"]:
                if frame["service"] == ds_name:
                    state = frame["state"]
                    slot_values = state["slot_values"]
                    if slot_name in slot_values:
                        answer_binary_str = slot_values[slot_name][-1]
                    break
            (answer_cands_ori, answer_cands_trans,
             answer_cands_trans_ll) = answer_cands
            # answer_cands_ori: ["Film", "Music", "None", DONTCARE]
            # answer_cands_trans: ["Movie", "Songs", "None", DONTCARE]
            has_trans = len(answer_cands_ori) == len(answer_cands_trans)
            exs = []
            for idx, cand in enumerate(answer_cands_ori):
                slot_features = copy.deepcopy(features)

                gen_slot_value_features(
                    cand,
                    slot_features,
                    trans=answer_cands_trans_ll[idx] if has_trans else None,
                    curr=turn["token"],
                    pre=pre_turn["token"] if pre_turn is not None else None,
                    his=history if history is not None else None,
                    dialogue_type=dialogue_type)

                answer_binary = 0 if cand != answer_binary_str else 1
                # append value to the end of question
                m_value, match_type = get_meaningful_value(
                    cand, system_slot, context, answer_binary)
                m_value = m_value.strip()
                if is_num:
                    value = " is {}".format(m_value)
                    # append quantifier
                    quantifier = " ".join(slot_name.lower().split("_"))
                    quantifier = quantifier.replace("number of", "")
                    if m_value.split() == 1:
                        # only have a number
                        value += " " + quantifier
                    # add slot featrues
                    match_level = 0
                    if match_type == "short":
                        # can only find the raw slot value
                        match_level = 0.2
                    elif match_type == "long":
                        match_level = 1.0
                    slot_features["num_match_level"] = str(match_level)
                else:
                    value = " is {}{}".format(
                        m_value,
                        " , {}".format(answer_cands_trans[idx]) if has_trans and
                        cand not in answer_cands_trans[idx] else "")

                if answer_binary_str == "None":
                    answer_type_str = "None"
                elif answer_binary_str == DONTCARE:
                    answer_type_str = DONTCARE
                else:
                    answer_type_str = "Active"
                answer_type = MAP_ANSWER_TYPE[answer_type_str]

                # binary class: True or False
                # this change will fix a learning problem in decaNLP, where
                # value: None T/F: True  answer: None
                # value: None T/F: False answer: None
                answer = "False" if cand != answer_binary_str else "True"
                qu_ = question_utt + " " + value
                qt_ = question_tok + " " + value
                qp_ = question_pos + " " + " ".join(
                    ["V" for _ in value.split()])
                qn_ = question_ner + " " + " ".join(
                    ["V" for _ in value.split()])
                qg_ = question_tag + " " + " ".join(
                    ["Q" for _ in value.split()])
                ex = DSTCSlot.gen_an_example(
                    system_slot,
                    turn_id, (qu_, qt_, qp_, qn_, qg_),
                    (task_type, answer_type, answer, answer, answer_four_way,
                     answer_binary),
                    slot_value=cand,
                    ds_name=ds_name,
                    slot_type=slot_type,
                    dialogue_id=dialogue_id,
                    context=context,
                    features=slot_features,
                    fields=fields)
                if ex is not None:
                    exs.append(ex)
            return exs

    @staticmethod
    def build_noncategorical_example(system_slot,
                                     turn,
                                     turn_id,
                                     ds_info=None,
                                     ds_name=None,
                                     add_back_trans=False,
                                     add_service_des=False,
                                     dialogue_id=None,
                                     context=None,
                                     fields=None,
                                     is_num=False):
        (question_utt, question_tok, question_pos, question_ner, question_tag,
         (task_type_str, _)) = DSTCSlot.get_slot_description(
             system_slot,
             ds_info=(ds_info if add_service_des else None),
             add_back_trans=add_back_trans)
        if is_num:  # force the number slots into generation
            task_type_str = GENERATION
        assert task_type_str == GENERATION

        task_type = MAP_TASK_TYPE[task_type_str]
        slot_type = get_slot_type(system_slot)
        answer_four_way = 0
        answer_binary = 0

        answer, answer_tok = "None", "None"
        for frame in turn["frames"]:
            if frame["service"] == ds_name:
                state = frame["state"]
                slot_values = state["slot_values"]
                tok_slot_values = state.get("tok_slot_values", {})
                slot_name = system_slot["name"]
                if slot_name in slot_values:
                    answer = slot_values[slot_name][-1]
                    answer_tok = " ".join(
                        TreebankWordTokenizer().tokenize(answer))
                    if slot_name in tok_slot_values:
                        answer_tok = tok_slot_values[slot_name][-1]

                break

        if answer == "None":
            answer_type_str = "None"
        elif answer == DONTCARE:
            answer_type_str = DONTCARE
        else:
            answer_type_str = "Active"
        answer_type = MAP_ANSWER_TYPE[answer_type_str]

        return DSTCSlot.gen_an_example(
            system_slot,
            turn_id, (question_utt, question_tok, question_pos, question_ner,
                      question_tag),
            (task_type, answer_type, answer, answer_tok, answer_four_way,
             answer_binary),
            slot_value="",
            ds_name=ds_name,
            slot_type=slot_type,
            dialogue_id=dialogue_id,
            context=context,
            fields=fields,
            is_num=is_num)

    @staticmethod
    def gen_turn_acts(frames):
        """
        add question related action and
        values in system turn for each slot prediction.
        e.g. when pred. this slot
        CONFIRM : Slot value
        REQUEST : Slot name.split("_")
        
        "actions": [ {
            "act": "REQUEST",
            "slot": "restaurant_name",
            "values": []
        }, {
            "act": "OFFER",
            "slot": "date",
            "values":  [ "v1", "v2", ...]
            "tok_values": [ "v1", "v2", ...]
        """
        turn_acts = {}
        for frame in frames:
            actions = frame.get("actions", [])
            for act in actions:
                act_name = act[ACT]
                act_slot = act[SLOT]
                if act_name in VALUE_ACTIONS:
                    if 'tok_values' in act:
                        vs_str = act['tok_values'][-1]
                    else:
                        vs_str = act['values'][-1]

                    vs_pos = " ".join(["VALUE" for _ in vs_str.split()])
                    turn_acts[act_slot] = (act_name + " : " + vs_str,
                                           act_name + " : " + vs_pos)
                elif act_name in REQUEST_ACTIONS:
                    vs_str = " ".join(act_slot.split("_"))
                    vs_pos = " ".join(["NAME" for _ in vs_str.split()])
                    turn_acts[act_slot] = (act_name + " : " + vs_str,
                                           act_name + " : " + vs_pos)
        return turn_acts

    @staticmethod
    def build_examples(turn_rounds,
                       expanded_path,
                       schema_dict,
                       add_service_des=False,
                       add_back_trans=False,
                       skip_history=False,
                       unify=False,
                       number_gen=False,
                       output_file=None,
                       use_tok=False,
                       dontcare=False,
                       fields=None):

        tot_examples, skip_ds = 0, 0
        output = open(output_file, "w")
        for root, dirs, files in os.walk(expanded_path):
            for f in files:
                if 'dialogues_' not in f:
                    continue

                logging.info("Loading file {}".format(f))
                examples = []

                with open(os.path.join(expanded_path, f)) as example_file:
                    entry = json.load(example_file)
                for dialogue in entry:
                    turns = dialogue['turns']
                    dialogue_services = dialogue["services"]
                    dialogue_id = dialogue['dialogue_id']
                    turns_list = []
                    dialogue_type = ("multi" if len(dialogue_services) > 1 else
                                     "single")

                    for i in turns:
                        turn_u = i['utterance']
                        turn_tok = i[TOKEN] if TOKEN in i else EMPTY
                        turn_pos = i[POS] if POS in i else EMPTY
                        turn_ner = i[NER] if NER in i else EMPTY

                        for k, v in SHORT_YEARS.items():
                            turn_u = turn_u.replace(k, v)
                            turn_tok = turn_tok.replace(k, v)

                        # turn_tag: user: U, system: S or system tags
                        if i['speaker'] == 'USER':
                            us = 'User'
                            turn_tag = " ".join(["U" for _ in turn_ner.split()])
                        else:
                            us = 'System'
                            turn_tag = process_system_tag(
                                i[SYSTEM_TAG]) if SYSTEM_TAG in i else EMPTY

                        turn_acts = ({} if us != "System" else
                                     DSTCSlot.gen_turn_acts(i["frames"]))

                        turns_list.append(
                            ('{} : {}'.format(us, turn_u), \
                                '{} : {}'.format(us, turn_tok), \
                                '{} : {}'.format(us, turn_pos), \
                                '{} : {}'.format(us, turn_ner), \
                                '{} : {}'.format(us, turn_tag), turn_acts))

                    seen_services = set()
                    for i in range(len(turns)):
                        turn = turns[i]
                        if turn['speaker'] != 'USER':
                            continue

                        frames = turn["frames"]
                        num_frames = len(frames)
                        if num_frames == 1:
                            cser = frames[0]['service']
                            seen_services.add(cser)

                        cur_services = [frm["service"] for frm in frames]

                        start = i - turn_rounds if (i - turn_rounds) >= 0 else 0
                        if i == 0:
                            context = [turns_list[i]]
                        else:
                            context = turns_list[start:i + 1]
                        for dialogue_service in dialogue_services:
                            if (skip_history and
                                    dialogue_service not in cur_services and
                                    dialogue_service in seen_services):
                                # NOTE: skip false negative services
                                # e.g. X means don't generate instances
                                # turn         Event   Banks
                                #  1   Banks   None   State
                                #  2   Event   State    X
                                #  3   Banks     X    State
                                skip_ds += 1
                                continue
                            ds_info = schema_dict[dialogue_service]
                            system_slots = ds_info["slots"]

                            for system_slot in system_slots:
                                is_num = is_number_slot(system_slot)

                                if unify:
                                    # use binary classification for all
                                    exs = DSTCSlot.build_unify_example(
                                        system_slot,
                                        turn,
                                        i,
                                        ds_info=ds_info,
                                        ds_name=dialogue_service,
                                        add_back_trans=add_back_trans,
                                        add_service_des=add_service_des,
                                        dialogue_id=dialogue_id,
                                        context=context,
                                        fields=fields)
                                    examples.extend(exs)

                                elif not system_slot["is_categorical"] or (
                                        is_num and number_gen):
                                    ex = DSTCSlot.build_noncategorical_example(
                                        system_slot,
                                        turn,
                                        i,
                                        ds_info=ds_info,
                                        ds_name=dialogue_service,
                                        add_back_trans=add_back_trans,
                                        add_service_des=add_service_des,
                                        dialogue_id=dialogue_id,
                                        context=context,
                                        fields=fields,
                                        is_num=is_num)
                                    if ex is not None:
                                        examples.append(ex)
                                else:
                                    pre_sys_acts = turns_list[
                                        i - 1][-1] if i > 0 else {}
                                    # prepare features for each slot
                                    features = gen_slot_features(
                                        turn,
                                        system_slot,
                                        turns[i - 1] if i > 0 else None,
                                        pre_sys_acts=pre_sys_acts,
                                        history=turns_list[:i - 1]
                                        if i > 1 else None,
                                        turn_idx=i)
                                    exs = DSTCSlot.build_categorical_example(
                                        system_slot,
                                        turn,
                                        i,
                                        ds_info=ds_info,
                                        ds_name=dialogue_service,
                                        add_back_trans=add_back_trans,
                                        add_service_des=add_service_des,
                                        dialogue_id=dialogue_id,
                                        context=context,
                                        pre_turn=turns[i -
                                                       1] if i > 0 else None,
                                        history=turns_list[:i - 1]
                                        if i > 1 else None,
                                        features=features,
                                        dontcare=dontcare,
                                        fields=fields,
                                        dialogue_type=dialogue_type)

                                    examples.extend(exs)

                # dump examples
                tot_examples += len(examples)
                for _, example in enumerate(examples):
                    for cand in [CONTEXT_CMP, QUESTION_CMP]:
                        lens = [(k, len(v.split()), v)
                                for k, v in example.items()
                                if k in cand]
                        eq_len = lens[0][1]
                        mismatch = False
                        for (k, l, v) in lens:
                            if l != eq_len:
                                mismatch = True
                        if mismatch:
                            for (k, l, v) in lens:
                                logging.error(
                                    "MISMATCH: {} len: {}, value: {}".format(
                                        k, l, v))
                        assert not mismatch, "mismatch candidate, check please."
                    if use_tok:
                        new_example = {
                            "context": example["context_tok"].strip(),
                            "answer": example["answer_tok"].strip(),
                            "question": example["question_tok"].strip(),
                            "aux": example["aux"].strip()
                        }
                        example = new_example
                    output.write(json.dumps(example) + "\n")
        output.close()
        logging.info('Total number of examples: {}'.format(tot_examples))
        logging.info("Skiped {} false negative services.".format(skip_ds))

    @staticmethod
    def load_schema_dict(expanded_path):
        schema_dict = {}
        with open(os.path.join(expanded_path, 'schema.json')) as example_file:
            logging.info("Reading schema.json")
            entry = json.load(example_file)
            for schema_frame in entry:
                schema_dict[schema_frame['service_name']] = schema_frame
        return schema_dict

    @staticmethod
    def get_slot_description(system_slot,
                             ds_info=None,
                             add_back_trans=False,
                             unify=False,
                             dontcare=False):
        raw = system_slot[DESCRIPTION]
        tok = system_slot[TOKEN] if TOKEN in system_slot else EMPTY
        pos = system_slot[POS] if POS in system_slot else EMPTY
        ner = system_slot[NER] if NER in system_slot else EMPTY

        if add_back_trans and "back_trans_tok" in system_slot:
            raw += (" , " + system_slot["back_trans_tok"])
            tok += (" , " + system_slot["back_trans_tok"])
            pos += (" , " + system_slot["back_trans_pos"])
            ner += (" , " + system_slot["back_trans_ner"])

        if ds_info is not None:
            raw = ds_info[DESCRIPTION] + ": " + raw
            tok = (ds_info[TOKEN] if TOKEN in ds_info else EMPTY) + " : " + tok
            pos = (ds_info[POS] if POS in ds_info else EMPTY) + " : " + pos
            ner = (ds_info[NER] if NER in ds_info else EMPTY) + " : " + ner

        tag = " ".join(["Q" for _ in ner.split()])

        if EMPTY not in ner:
            len_tok = len(tok.split())
            len_pos = len(pos.split())
            len_ner = len(ner.split())
            len_tag = len(tag.split())
            if not (len_tok == len_pos == len_ner == len_tag):
                for p, l in [(tok, len_tok), (pos, len_pos), (ner, len_ner),
                             (tag, len_tag)]:
                    logging.info("{} : {}".format(
                        l, " ".join([
                            "{}:{}".format(i, v)
                            for i, v in enumerate(p.split())
                        ])))
            assert len_tok == len_pos == len_ner == len_tag

        is_categorical = system_slot['is_categorical']

        if unify:
            # only return the possible_values
            possible_values = system_slot.get('possible_values', [])
            answer_cands_listoflist = system_slot.get(
                'possible_values_bak_trans', [])
            pv_bak_trans = [" ".join(x) for x in answer_cands_listoflist]
            answer_cands = (possible_values,
                            pv_bak_trans if len(pv_bak_trans) > 0 else [],
                            answer_cands_listoflist)
            task_type_str = UNIFY

        elif is_categorical:
            possible_values = system_slot['possible_values']
            answer_cands_listoflist = system_slot.get(
                'possible_values_bak_trans', [])
            # change list of list into list, we may have n-best translations
            pv_bak_trans = [" ".join(x) for x in answer_cands_listoflist]
            if "True" in possible_values and "False" in possible_values:
                task_type_str = FOUR_WAY
                # this answer_cands wont be used, as this is a four way
                # classification problem, only need the truth in state.
                answer_cands = (possible_values + [DONTCARE, "None"],
                                (pv_bak_trans +
                                 ["", ""]) if len(pv_bak_trans) > 0 else [],
                                (answer_cands_listoflist +
                                 [[], []]) if len(pv_bak_trans) > 0 else [])
            else:
                task_type_str = BINARY
                add_cands = ["None"] if not dontcare else ["None", DONTCARE]
                add_cands_ll = [["None"]] if not dontcare else [["None"],
                                                                [DONTCARE]]
                answer_cands = (possible_values + add_cands,
                                (pv_bak_trans +
                                 add_cands) if len(pv_bak_trans) > 0 else [],
                                answer_cands_listoflist +
                                add_cands_ll if len(pv_bak_trans) > 0 else [])

        else:
            task_type_str = GENERATION
            answer_cands = ([], [], [])
        return (raw, tok, pos, ner, tag, (task_type_str, answer_cands))
