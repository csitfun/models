import json
import os
import logging
from dstc.generic import DSTCSlot
from xdec_config import get_logger

logger = get_logger("__name__")


def get_service(train_schema_file, dev_schema_file):
    schema_dict = {}
    train_schema = []
    dev_unseen_schema = []
    dev_seen_schema = []
    with open(train_schema_file) as example_file:
        schemas = json.load(example_file)
        for schema_frame in schemas:
            train_schema.append(schema_frame['service_name'])
            schema_dict[schema_frame['service_name']] = sorted(
                s["name"] for s in schema_frame["slots"])
    with open(dev_schema_file) as example_file:
        schemas = json.load(example_file)
        for schema_frame in schemas:
            if schema_frame['service_name'] not in schema_dict:
                dev_unseen_schema.append(schema_frame['service_name'])
                schema_dict[schema_frame['service_name']] = sorted(
                    s["name"] for s in schema_frame["slots"])
            else:
                dev_seen_schema.append(schema_frame['service_name'])
    return schema_dict, train_schema, dev_seen_schema, dev_unseen_schema


def process_confirm_slots(utterance, frame, system_frame):
    for token in [
            'yes', 'wonderful', 'correct', 'excellent', 'perfect', 'works',
            'great'
    ]:
        if token in utterance.lower():
            for sysframe in system_frame:
                if sysframe['service'] == frame['service']:
                    for action in sysframe['actions']:
                        if action['act'] == 'CONFIRM':
                            frame['state']['slot_values'][
                                action['slot']] = action['values']
            break


def process_slot_name(frame, system_frame, schema_dict):
    """
    when the generation model predicts a slot name that is
    not in the schema, infer the correct slot name by its
    value
    """
    slots = frame['state']['slot_values'].copy()
    for name in slots:
        if name not in schema_dict[frame['service']]:
            value = frame['state']['slot_values'][name]
            for sysframe in system_frame:
                if sysframe['service'] == frame['service']:
                    OK = False
                    for action in sysframe['actions']:
                        if OK:
                            break
                        if 'slot' in action:
                            for v in value:
                                if v in action['values']:
                                    frame['state']['slot_values'][
                                        action['slot']] = \
                                        frame['state']['slot_values'][name]
                                    frame['state']['slot_values'].pop(name)
                                    OK = True
                                    break


def process_year(utterance, frame):
    if 'year' in utterance:
        year_word = utterance.split(' year')[0].split(' ')[-1]
        dict = {
            'one': 1,
            'two': 2,
            'three': 3,
            'four': 4,
            'five': 5,
            'six': 6,
            'seven': 7,
            'eight': 8,
            'nine': 9
        }
        year_word = dict.get(year_word, 0)
        if year_word > 0 and 'year' in frame['state']['slot_values']:
            frame['state']['slot_values']['year'] = [str(2019 - year_word)]


def process_packages(utterance, frame):
    if ' bags' in utterance:
        bags_num = utterance.split(' bags')[0].strip(' checked').strip(
            ' check in').split(' ')[-1]
        dict = {
            '0': 0,
            '1': 1,
            '2': 2,
            'zero': 0,
            'one': 1,
            'two': 2,
        }
        if bags_num in dict:
            frame['state']['slot_values']['number_checked_bags'] = [
                str(dict[bags_num])
            ]


def process_dontcare(utterance, schema):
    """
    :return: the dont care slots found by this function
    """
    dont_care_slots = set()
    service_name = schema["service_name"]
    for s in schema["slots"]:
        any_slot_name = " any " + s["name"].replace("_", " ") + " "
        utterance = " " + utterance.lower() + " "
        if any_slot_name in utterance:
            dont_care_slots.add("{}:{}".format(service_name, s["name"]))
    return dont_care_slots


def postprocess(train_schema_file,
                dev_schema_file,
                input_dir,
                output_dir,
                union_all=True,
                dump_file=True):
    recovered_dontcare = 0
    schema_dict, _, _, dev_unseen_schema = get_service(train_schema_file,
                                                       dev_schema_file)
    sys_schemas = DSTCSlot.load_schema_dict(os.path.dirname(dev_schema_file))
    all_dialogues = []
    for res_file in os.listdir(input_dir):
        if 'dialogues' not in res_file or 'metrics' in res_file:
            continue
        with open(os.path.join(input_dir, res_file)) as example_file:
            entry = json.load(example_file)
        new_entry = []
        for dialogue in entry:
            turns = dialogue['turns']
            # record last state for each service
            all_service_last_state = {}

            # record and recover all dontcare slots
            all_dont_care_slots = set()

            for turn_id, turn in enumerate(turns):

                if turn['speaker'] == 'USER':
                    utterance = turn['utterance']

                    # fix dontcare first
                    if union_all:
                        # no need to accumulation dont care slots
                        all_dont_care_slots = set()

                    for service_name in sys_schemas:
                        dont_care_slots = process_dontcare(
                            utterance, sys_schemas[service_name])
                        if dont_care_slots:
                            all_dont_care_slots |= dont_care_slots

                    # recover dontcare from history
                    for service_slot in all_dont_care_slots:
                        service_name, slot_name = service_slot.split(":")
                        for frame in turn["frames"]:
                            if frame["service"] == service_name:
                                frame["state"]["slot_values"][slot_name] = [
                                    "dontcare"
                                ]
                                recovered_dontcare += 1
                                break

                    for frame in turn['frames']:
                        service_name = frame["service"]
                        curr_slot_values = frame['state']['slot_values']
                        if turn_id > 0:
                            # update with system confirm actions
                            system_frame = turns[turn_id - 1]['frames']
                            process_confirm_slots(utterance, frame,
                                                  system_frame)
                        # fix year
                        if 'Music_' in service_name:
                            process_year(utterance, frame)
                        # fix checked bags
                        if 'Flights_' in service_name:
                            process_packages(utterance, frame)

                        if union_all or service_name in dev_unseen_schema:
                            if turn_id == 0:
                                all_service_last_state[
                                    service_name] = curr_slot_values
                            else:
                                last_state = all_service_last_state.get(
                                    service_name, None)
                                if last_state:
                                    for name in schema_dict[service_name]:
                                        if (name in last_state and
                                                name not in curr_slot_values):
                                            curr_slot_values[name] = last_state[
                                                name]
                                    # fix slot name for unseen service
                                    system_frame = dialogue['turns'][
                                        turn_id - 1]['frames']
                                    process_slot_name(frame, system_frame,
                                                      schema_dict)

                                all_service_last_state[
                                    service_name] = curr_slot_values

            new_entry.append(dialogue)
        if dump_file:
            with open(os.path.join(output_dir, res_file), 'w') as example_file:
                json.dump(new_entry, example_file)
        all_dialogues.append(new_entry)
    return recovered_dontcare, all_dialogues


if __name__ == "__main__":
    train_schema_file = 'multi_best_results/train/schema.json'
    dev_schema_file = 'multi_best_results/dev/schema.json'
    input_dir = 'multi_best_results/best_pred'
    output_dir = 'multi_best_results/predHandle'
    postprocess(
        train_schema_file=train_schema_file,
        dev_schema_file=dev_schema_file,
        input_dir=input_dir,
        output_dir=output_dir,
        union_all=True)
