import json
import logging
import os
from functools import partial
from multiprocessing import Pool, cpu_count

import numpy as np
from tqdm import tqdm
from uuid import uuid4
import gzip

from transformers.data.processors.squad import (
    SquadResult, SquadV1Processor, SquadV2Processor, SquadExample,
    SquadFeatures, squad_convert_example_to_features,
    squad_convert_example_to_features_init, _check_is_max_context,
    _improve_answer_span, _is_whitespace, _new_check_is_max_context)
from transformers.data.processors.utils import (InputExample, DataProcessor,
                                                InputFeatures)
from transformers.file_utils import is_tf_available, is_torch_available
from transformers.tokenization_bert import whitespace_tokenize

if is_torch_available():
    import torch
    from torch.utils.data import TensorDataset

if is_tf_available():
    import tensorflow as tf

from xdec_config import get_logger

logger = get_logger(__name__)


class DSTCClassificationInputFeatures(InputFeatures):
    """
    A single set of features of data.

    Args:
        input_ids: Indices of input sequence tokens in the vocabulary.
        attention_mask: Mask to avoid performing attention on padding 
            token indices. Mask values selected in ``[0, 1]``: Usually  ``1`` 
            for tokens that are NOT MASKED, ``0`` for MASKED (padded) tokens.
        token_type_ids: Segment token indices to indicate first and second 
            portions of the inputs.
        label: Label corresponding to the input
    """

    def __init__(self,
                 input_ids,
                 attention_mask=None,
                 token_type_ids=None,
                 wide_ids=None,
                 class_pos=None,
                 label=None):
        self.input_ids = input_ids
        self.attention_mask = attention_mask
        self.token_type_ids = token_type_ids
        self.wide_ids = wide_ids
        self.class_pos = class_pos
        self.label = label

    def __eq__(self, other):
        if not isinstance(other, DSTCClassificationInputFeatures):
            return False

        return self.input_ids == other.input_ids and \
            self.attention_mask == other.attention_mask and \
            self.token_type_ids == other.token_type_ids and \
            self.wide_ids == other.wide_ids and \
            self.class_pos == other.class_pos and \
            self.label == other.label


class DSTCPairClassificationInputFeatures(InputFeatures):
    """
    A single set of features of data.

    Args:
        input_ids: Indices of input sequence tokens in the vocabulary.
        attention_mask: Mask to avoid performing attention on padding 
            token indices. Mask values selected in ``[0, 1]``: Usually  ``1`` 
            for tokens that are NOT MASKED, ``0`` for MASKED (padded) tokens.
        token_type_ids: Segment token indices to indicate first and second 
            portions of the inputs.
        label: Label corresponding to the input
    """

    def __init__(self,
                 input_ids,
                 attention_mask=None,
                 token_type_ids=None,
                 query_input_ids=None,
                 query_attention_mask=None,
                 query_token_type_ids=None,
                 wide_ids=None,
                 label=None):
        self.input_ids = input_ids
        self.attention_mask = attention_mask
        self.token_type_ids = token_type_ids
        self.query_input_ids = query_input_ids
        self.query_attention_mask = query_attention_mask
        self.query_token_type_ids = query_token_type_ids
        self.wide_ids = wide_ids
        self.label = label

    def __eq__(self, other):
        if not isinstance(other, DSTCPairClassificationInputFeatures):
            return False

        return self.input_ids == other.input_ids and \
            self.attention_mask == other.attention_mask and \
            self.token_type_ids == other.token_type_ids and \
            self.query_input_ids == other.query_input_ids and \
            self.query_attention_mask == other.query_attention_mask and \
            self.query_token_type_ids == other.query_token_type_ids and \
            self.wide_ids == other.wide_ids and \
            self.label == other.label


def dstc_convert_examples_to_features(
    examples,
    tokenizer,
    max_length=512,
    label_list=None,
    output_mode=None,
    pad_on_left=False,
    pad_token=0,
    pad_token_segment_id=0,
    mask_padding_with_zero=True,
    use_wide=False,
    trunk_left=False,
):
    """
    Loads a data file into a list of ``DSTCClassificationInputFeatures``

    Args:
        examples: List of ``InputExamples`` or ``tf.data.Dataset`` 
            containing the examples.
        tokenizer: Instance of a tokenizer that will tokenize the examples
        max_length: Maximum example length
        label_list: List of labels. Can be obtained from the processor 
            using the ``processor.get_labels()`` method
        output_mode: String indicating the output mode. Either ``regression``
             or ``classification``
        pad_on_left: If set to ``True``, the examples will be padded on the 
            left rather than on the right (default)
        pad_token: Padding token
        pad_token_segment_id: The segment ID for the padding token (It is 
            usually 0, but can vary such as for XLNet where it is 4)
        mask_padding_with_zero: If set to ``True``, the attention mask will 
            be filled by ``1`` for actual values
            and by ``0`` for padded values. If set to ``False``, inverts it
            (``1`` for padded values, ``0`` for
            actual values)

    Returns:
        If the ``examples`` input is a ``tf.data.Dataset``, will return a 
        ``tf.data.Dataset`` containing the task-specific features. 
        If the input is a list of ``InputExamples``, will return
        a list of task-specific ``InputFeatures`` which can be fed to the model.

    """
    label_map = {label: i for i, label in enumerate(label_list)}
    logger.info(f"label_map: {label_map}")

    features = []
    len_examples = len(examples)
    for (ex_index, example) in enumerate(examples):
        if ex_index % 10000 == 0:
            logger.debug("Writing example %d/%d" % (ex_index, len_examples))

        inputs = tokenizer.encode_plus(
            example.text_a,
            example.text_b,
            add_special_tokens=True,
            max_length=max_length if not trunk_left else None,
        )

        input_ids, token_type_ids = (inputs["input_ids"],
                                     inputs["token_type_ids"])

        if trunk_left and len(input_ids) > max_length:
            input_ids = ([inputs["input_ids"][0]] +
                         inputs["input_ids"][-max_length + 1:])
            token_type_ids = ([inputs["token_type_ids"][0]] +
                              inputs["token_type_ids"][-max_length + 1:])

        # The mask has 1 for real tokens and 0 for padding tokens. Only real
        # tokens are attended to.
        attention_mask = [1 if mask_padding_with_zero else 0] * len(input_ids)

        # Zero-pad up to the sequence length.
        padding_length = max_length - len(input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            attention_mask = ([0 if mask_padding_with_zero else 1] *
                              padding_length) + attention_mask
            token_type_ids = ([pad_token_segment_id] *
                              padding_length) + token_type_ids
        else:
            input_ids = input_ids + ([pad_token] * padding_length)
            attention_mask = attention_mask + (
                [0 if mask_padding_with_zero else 1] * padding_length)
            token_type_ids = token_type_ids + ([pad_token_segment_id] *
                                               padding_length)


        assert (
            len(input_ids) == max_length == len(attention_mask) ==
            len(token_type_ids)
        ), f"Mismatch: max_lenght: {max_length}, " + \
            f"input_ids: {len(input_ids)}, " + \
            f"attention_mask: {len(attention_mask)}, " + \
            f"token_type_ids: {len(token_type_ids)}"

        if output_mode == "classification":
            label = label_map[example.label]
        elif output_mode == "regression":
            label = float(example.label)
        else:
            raise KeyError(output_mode)

        if ex_index < 5:
            logger.debug("*** Example ***")
            logger.debug("guid: %s" % (example.guid))
            logger.debug("input_ids: %s" % " ".join([str(x) for x in input_ids]))
            logger.debug("attention_mask: %s" %
                        " ".join([str(x) for x in attention_mask]))
            logger.debug("token_type_ids: %s" %
                        " ".join([str(x) for x in token_type_ids]))
            if use_wide:
                logger.debug("wide_ids: %s" %
                            " ".join([str(x) for x in example.wide_ids]))
            logger.debug("label: %s (id = %d)" % (example.label, label))

        features.append(
            DSTCClassificationInputFeatures(
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids,
                wide_ids=example.wide_ids,
                label=label))
    return features


def dstc_convert_examples_to_features_with_pos(
    examples,
    tokenizer,
    max_length=512,
    label_list=None,
    output_mode=None,
    pad_on_left=False,
    pad_token=0,
    pad_token_segment_id=0,
    mask_padding_with_zero=True,
    use_wide=False,
    trunk_left=False,
):
    """
    Loads a data file into a list of ``DSTCClassificationInputFeatures``

    Args:
        examples: List of ``InputExamples`` or ``tf.data.Dataset`` 
            containing the examples.
        tokenizer: Instance of a tokenizer that will tokenize the examples
        max_length: Maximum example length
        label_list: List of labels. Can be obtained from the processor 
            using the ``processor.get_labels()`` method
        output_mode: String indicating the output mode. Either ``regression``
             or ``classification``
        pad_on_left: If set to ``True``, the examples will be padded on the 
            left rather than on the right (default)
        pad_token: Padding token
        pad_token_segment_id: The segment ID for the padding token (It is 
            usually 0, but can vary such as for XLNet where it is 4)
        mask_padding_with_zero: If set to ``True``, the attention mask will 
            be filled by ``1`` for actual values
            and by ``0`` for padded values. If set to ``False``, inverts it
            (``1`` for padded values, ``0`` for
            actual values)

    Returns:
        If the ``examples`` input is a ``tf.data.Dataset``, will return a 
        ``tf.data.Dataset`` containing the task-specific features. 
        If the input is a list of ``InputExamples``, will return
        a list of task-specific ``InputFeatures`` which can be fed to the model.

    """

    def _find_last_pos(haystack, needle):
        for i in range(len(haystack) - 1, -1, -1):
            if haystack[i] == needle[0] and haystack[i:i +
                                                     len(needle)] == needle:
                return i
        return 0

    label_map = {label: i for i, label in enumerate(label_list)}

    features = []
    len_examples = len(examples)
    for (ex_index, example) in enumerate(examples):
        if ex_index % 10000 == 0:
            logger.info("Writing example %d/%d" % (ex_index, len_examples))

        # slot_description = text_b = sentence2
        inputs = tokenizer.encode_plus(
            example.text_a,
            example.text_b,
            add_special_tokens=True,
            max_length=max_length if not trunk_left else None,
            truncation_strategy="only_first")

        input_ids, token_type_ids = (inputs["input_ids"],
                                     inputs["token_type_ids"])

        if trunk_left and len(input_ids) > max_length:
            input_ids = ([inputs["input_ids"][0]] +
                         inputs["input_ids"][-max_length + 1:])
            token_type_ids = ([inputs["token_type_ids"][0]] +
                              inputs["token_type_ids"][-max_length + 1:])

        class_name = example.guid.split("|")[-1].strip()
        class_name_ids = tokenizer.encode(
            "a " + class_name, add_special_tokens=True)[2:-1]
        logger.debug("class_name: {} class_name_ids: {}".format(
            class_name, class_name_ids))
        class_pos = _find_last_pos(input_ids, class_name_ids)

        # The mask has 1 for real tokens and 0 for padding tokens. Only real
        # tokens are attended to.
        attention_mask = [1 if mask_padding_with_zero else 0] * len(input_ids)

        # Zero-pad up to the sequence length.
        padding_length = max_length - len(input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            attention_mask = ([0 if mask_padding_with_zero else 1] *
                              padding_length) + attention_mask
            token_type_ids = ([pad_token_segment_id] *
                              padding_length) + token_type_ids
        else:
            input_ids = input_ids + ([pad_token] * padding_length)
            attention_mask = attention_mask + (
                [0 if mask_padding_with_zero else 1] * padding_length)
            token_type_ids = token_type_ids + ([pad_token_segment_id] *
                                               padding_length)

        assert (
            len(input_ids) == max_length == len(attention_mask) ==
            len(token_type_ids)
        ), f"Mismatch: max_lenght: {max_length}, " + \
            f"input_ids: {len(input_ids)}, " + \
            f"attention_mask: {len(attention_mask)}, " + \
            f"token_type_ids: {len(token_type_ids)}"

        if output_mode == "classification":
            label = label_map[example.label]
        elif output_mode == "regression":
            label = float(example.label)
        else:
            raise KeyError(output_mode)

        if ex_index < 5:
            logger.info("*** Example ***")
            logger.info("guid: %s" % (example.guid))
            logger.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
            logger.info("attention_mask: %s" %
                        " ".join([str(x) for x in attention_mask]))
            logger.info("token_type_ids: %s" %
                        " ".join([str(x) for x in token_type_ids]))
            if use_wide:
                logger.info("wide_ids: %s" %
                            " ".join([str(x) for x in example.wide_ids]))
            logger.info("label: %s (id = %d)" % (example.label, label))

        features.append(
            DSTCClassificationInputFeatures(
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids,
                wide_ids=example.wide_ids,
                class_pos=class_pos,
                label=label))
    return features


def dstc_convert_pair_examples_to_features(
    examples,
    tokenizer,
    max_length=512,
    max_query_length=128,
    label_list=None,
    output_mode=None,
    pad_on_left=False,
    pad_token=0,
    pad_token_segment_id=0,
    mask_padding_with_zero=True,
    use_wide=False,
    trunk_left=False,
):
    """
    Loads a data file into a list of ``DSTCClassificationInputFeatures``

    Args:
        examples: List of ``InputExamples`` or ``tf.data.Dataset`` 
            containing the examples. text_a is context and text_b is query
        tokenizer: Instance of a tokenizer that will tokenize the examples
        max_length: Maximum example length
        label_list: List of labels. Can be obtained from the processor 
            using the ``processor.get_labels()`` method
        output_mode: String indicating the output mode. Either ``regression``
             or ``classification``
        pad_on_left: If set to ``True``, the examples will be padded on the 
            left rather than on the right (default)
        pad_token: Padding token
        pad_token_segment_id: The segment ID for the padding token (It is 
            usually 0, but can vary such as for XLNet where it is 4)
        mask_padding_with_zero: If set to ``True``, the attention mask will 
            be filled by ``1`` for actual values
            and by ``0`` for padded values. If set to ``False``, inverts it
            (``1`` for padded values, ``0`` for
            actual values)

    Returns:
        If the ``examples`` input is a ``tf.data.Dataset``, will return a 
        ``tf.data.Dataset`` containing the task-specific features. 
        If the input is a list of ``InputExamples``, will return
        a list of task-specific ``InputFeatures`` which can be fed to the model.

    """
    label_map = {label: i for i, label in enumerate(label_list)}

    features = []
    len_examples = len(examples)
    for (ex_index, example) in enumerate(examples):
        if ex_index % 10000 == 0:
            logger.info("Writing example %d/%d" % (ex_index, len_examples))

        inputs = tokenizer.encode_plus(
            example.text_a,
            add_special_tokens=True,
            max_length=max_length if not trunk_left else None,
        )

        input_ids, token_type_ids = (inputs["input_ids"],
                                     inputs["token_type_ids"])

        if trunk_left and len(input_ids) > max_length:
            input_ids = ([inputs["input_ids"][0]] +
                         inputs["input_ids"][-max_length + 1:])
            token_type_ids = ([inputs["token_type_ids"][0]] +
                              inputs["token_type_ids"][-max_length + 1:])

        query_inputs = tokenizer.encode_plus(
            example.text_b,
            add_special_tokens=True,
            max_length=max_query_length,
        )
        query_input_ids, query_token_type_ids = \
            query_inputs["input_ids"], query_inputs["token_type_ids"]

        # The mask has 1 for real tokens and 0 for padding tokens. Only real
        # tokens are attended to.
        attention_mask = [1 if mask_padding_with_zero else 0] * len(input_ids)
        query_attention_mask = [1 if mask_padding_with_zero else 0
                               ] * len(query_input_ids)

        # Zero-pad up to the sequence length.
        padding_length = max_length - len(input_ids)
        query_padding_length = max_query_length - len(query_input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            attention_mask = ([0 if mask_padding_with_zero else 1] *
                              padding_length) + attention_mask
            token_type_ids = ([pad_token_segment_id] *
                              padding_length) + token_type_ids
            query_input_ids = ([pad_token] *
                               query_padding_length) + query_input_ids
            query_attention_mask = ([0 if mask_padding_with_zero else 1] *
                                    query_padding_length) + query_attention_mask
            query_token_type_ids = ([pad_token_segment_id] *
                                    query_padding_length) + query_token_type_ids
        else:
            input_ids = input_ids + ([pad_token] * padding_length)
            attention_mask = attention_mask + (
                [0 if mask_padding_with_zero else 1] * padding_length)
            token_type_ids = token_type_ids + ([pad_token_segment_id] *
                                               padding_length)
            query_input_ids = query_input_ids + ([pad_token] *
                                                 query_padding_length)
            query_attention_mask = query_attention_mask + (
                [0 if mask_padding_with_zero else 1] * query_padding_length)
            query_token_type_ids = query_token_type_ids + (
                [pad_token_segment_id] * query_padding_length)

        assert len(
            input_ids) == max_length, "Error with input length {} vs {}".format(
                len(input_ids), max_length)
        assert len(
            attention_mask
        ) == max_length, "Error with attention mask length {} vs {}".format(
            len(attention_mask), max_length)
        assert len(
            token_type_ids
        ) == max_length, "Error with token type length {} vs {}".format(
            len(token_type_ids), max_length)

        assert len(
            query_input_ids
        ) == max_query_length, "Error with query input length {} vs {}".format(
            len(query_input_ids), max_query_length)
        assert len(
            query_attention_mask
        ) == max_query_length, "Error with query attention mask length {} vs {}".format(
            len(query_attention_mask), max_query_length)
        assert len(
            query_token_type_ids
        ) == max_query_length, "Error with query token type length {} vs {}".format(
            len(query_token_type_ids), max_query_length)

        if output_mode == "classification":
            label = label_map[example.label]
        elif output_mode == "regression":
            label = float(example.label)
        else:
            raise KeyError(output_mode)

        if ex_index < 5:
            logger.info("*** Example ***")
            logger.info("guid: %s" % (example.guid))
            logger.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
            logger.info("attention_mask: %s" %
                        " ".join([str(x) for x in attention_mask]))
            logger.info("token_type_ids: %s" %
                        " ".join([str(x) for x in token_type_ids]))
            logger.info("query_input_ids: %s" %
                        " ".join([str(x) for x in query_input_ids]))
            logger.info("query_attention_mask: %s" %
                        " ".join([str(x) for x in query_attention_mask]))
            logger.info("query_token_type_ids: %s" %
                        " ".join([str(x) for x in query_token_type_ids]))
            if use_wide:
                logger.info("wide_ids: %s" %
                            " ".join([str(x) for x in example.wide_ids]))
            logger.info("label: %s (id = %d)" % (example.label, label))

        features.append(
            DSTCPairClassificationInputFeatures(
                input_ids=input_ids,
                attention_mask=attention_mask,
                token_type_ids=token_type_ids,
                query_input_ids=query_input_ids,
                query_attention_mask=query_attention_mask,
                query_token_type_ids=query_token_type_ids,
                wide_ids=example.wide_ids,
                label=label))
    return features


class DSTCClassificationInputExample(InputExample):
    """
    A single training/test example for simple sequence classification.

    Args:
        guid: Unique id for the example.
        text_a: string. The untokenized text of the first sequence. For single
            sequence tasks, only this sequence must be specified.
        text_b: (Optional) string. The untokenized text of the second sequence.
            Only must be specified for sequence pair tasks.
        label: (Optional) string. The label of the example. This should be
            specified for train and dev examples, but not for test examples.
    """

    def __init__(self, guid, text_a, text_b=None, wide_ids=None, label=None):
        self.guid = guid
        self.text_a = text_a
        self.text_b = text_b
        self.label = label
        self.wide_ids = wide_ids


class DSTCClassificationProcessor(DataProcessor):
    """
    Processor for the jsonl XNLI dataset.
      convert raw jsonl data into examples 
    Input example:
    {"annotator_labels": ["True", "True", "True", "True", "True"], "genre": "dstc", "gold_label": "True", "language": "en", "match": "Tru
e", "pairID": "9_00000|0|Events_1|category|None", "promptID": "9_00000|0|Events_1|category|None", "sentence1": "User : Find me someth
ing cool to do.", "sentence1_tokenized": "User : Find me something cool to do .", "sentence2": "The comprehensive portal to find and
reserve seats at events near you: Type of event , Event type  is None", "sentence2_tokenized": "The comprehensive portal to find and
reserve seats at events near you : Type of event , Event type  is None"}
    """

    def __init__(self,
                 task_type,
                 use_tok=False,
                 use_wide=False,
                 label_file=None):
        """
        label_file=metal_labels.txt if the task is metal classification
        """
        self.labels = ["True", "False", "dontcare", "None"
                      ] if task_type == "bool" else ["True", "False"]
        if task_type not in ["cat", "bool"]:
            self.labels = []
            if label_file:
                with open(label_file) as input_:
                    for line in input_:
                        self.labels.append(line.strip())
        self.use_tok = use_tok
        self.use_wide = use_wide
        logger.debug("DSTCProcessor: use_tok = {}".format(self.use_tok))
        logger.debug("DSTCProcessor: use_wide = {}".format(self.use_wide))

    def _build_example(self, datum, guid=None):
        guid = datum["pairID"] if not guid else guid
        text_a = datum["sentence1{}".format(
            "_tokenized" if self.use_tok else "")]
        text_b = datum["sentence2{}".format(
            "_tokenized" if self.use_tok else "")]
        label = datum["gold_label"]
        if self.use_wide:
            wide_ids = datum['wide_ids']
            assert isinstance(wide_ids, list)
        assert isinstance(text_a, str) and isinstance(text_b, str)
        assert isinstance(label, str)
        return DSTCClassificationInputExample(
            guid=guid,
            text_a=text_a,
            text_b=text_b,
            wide_ids=wide_ids if self.use_wide else None,
            label=label)

    def get_train_examples(self, data_dir, train_file):
        """See base class."""
        examples = []
        is_gz = train_file.endswith(".gz")
        open_all = "gzip.open" if is_gz else "open"
        with eval(open_all)(os.path.join(data_dir, train_file)) as f:
            for idx, line in enumerate(f):
                examples.append(self._build_example(json.loads(line)))
                if idx % 500000 == 0:
                    logger.debug("Raw example {}: {}".format(idx, line))
        return examples

    def get_test_examples(self, data_dir, test_file):
        """See base class."""
        examples = []
        is_gz = test_file.endswith(".gz")
        open_all = "gzip.open" if is_gz else "open"
        with eval(open_all)(os.path.join(data_dir, test_file)) as f:
            for line in f:
                examples.append(self._build_example(json.loads(line)))
        return examples

    def get_labels(self):
        """See base class."""
        return self.labels


class DSTCProcessor(DataProcessor):
    """
    Processor for the DSTC four class data sest.
    Based on SquadProcessor
    """
    CLASS_LABEL = "class_label"
    train_file = None
    dev_file = None

    def _get_example_from_tensor_dict(self, tensor_dict, evaluate=False):
        if not evaluate:
            answer = tensor_dict["answers"]["text"][0].numpy().decode("utf-8")
            answer_start = tensor_dict["answers"]["answer_start"][0].numpy()
            answers = []
        else:
            answers = [{
                "answer_start": start.numpy(),
                "text": text.numpy().decode("utf-8")
            } for start, text in zip(tensor_dict["answers"]["answer_start"],
                                     tensor_dict["answers"]["text"])]

            answer = None
            answer_start = None

        return SquadExample(
            qas_id=tensor_dict["id"].numpy().decode("utf-8"),
            question_text=tensor_dict["question"].numpy().decode("utf-8"),
            context_text=tensor_dict["context"].numpy().decode("utf-8"),
            answer_text=answer,
            start_position_character=answer_start,
            title=tensor_dict["title"].numpy().decode("utf-8"),
            answers=answers,
        )

    def get_examples_from_dataset(self, dataset, evaluate=False):
        """
        Creates a list of :class:`~transformers.data.processors.squad.SquadExample` using a TFDS dataset.
        Args:
            dataset: The tfds dataset loaded from `tensorflow_datasets.load("squad")`
            evaluate: boolean specifying if in evaluation mode or in training mode
        Returns:
            List of SquadExample
        Examples::
            import tensorflow_datasets as tfds
            dataset = tfds.load("squad")
            training_examples = get_examples_from_dataset(dataset, evaluate=False)
            evaluation_examples = get_examples_from_dataset(dataset, evaluate=True)
        """

        if evaluate:
            dataset = dataset["validation"]
        else:
            dataset = dataset["train"]

        examples = []
        for tensor_dict in tqdm(dataset):
            examples.append(
                self._get_example_from_tensor_dict(
                    tensor_dict, evaluate=evaluate))

        return examples

    def get_train_examples(self, data_dir, filename=None):
        """
        Returns the training examples from the data directory.
        Args:
            data_dir: Directory containing the data files used for training and evaluating.
            filename: None by default, specify this if the training file has a different name than the original one.
        """
        if data_dir is None:
            data_dir = ""

        if self.train_file is None:
            raise ValueError("train file should be set")

        with open(
                os.path.join(data_dir,
                             self.train_file if filename is None else filename),
                "r",
                encoding="utf-8") as reader:
            input_data = json.load(reader)["data"]
        return self._create_examples(input_data, "train")

    def get_dev_examples(self, data_dir, filename=None):
        """
        Returns the evaluation example from the data directory.
        Args:
            data_dir: Directory containing the data files used for training and evaluating.
            filename: None by default, specify this if the evaluation file has a different name than the original one.
        """
        if data_dir is None:
            data_dir = ""

        if self.dev_file is None:
            raise ValueError(
                "SquadProcessor should be instantiated via SquadV1Processor or SquadV2Processor"
            )

        with open(
                os.path.join(data_dir,
                             self.dev_file if filename is None else filename),
                "r",
                encoding="utf-8") as reader:
            input_data = json.load(reader)["data"]
        return self._create_examples(input_data, "dev")

    def _create_examples(self, input_data, set_type):
        is_training = set_type == "train"
        examples = []
        for entry in tqdm(input_data):
            title = entry["title"]
            for paragraph in entry["paragraphs"]:
                context_text = paragraph["context"]
                for qa in paragraph["qas"]:
                    qas_id = qa["id"]
                    question_text = qa["question"]
                    start_position_character = None
                    answer_text = None
                    answers = []

                    if "is_impossible" in qa:
                        is_impossible = qa["is_impossible"]
                    else:
                        is_impossible = False

                    if self.CLASS_LABEL in qa:
                        class_label = qa[self.CLASS_LABEL]
                    else:
                        class_label = 0

                    if not is_impossible:
                        if is_training:
                            answer = qa["answers"][0]
                            answer_text = answer["text"]
                            start_position_character = answer["answer_start"]
                        else:
                            answers = qa["answers"]

                    example = DSTCExample(
                        qas_id=qas_id,
                        question_text=question_text,
                        context_text=context_text,
                        answer_text=answer_text,
                        start_position_character=start_position_character,
                        title=title,
                        is_impossible=is_impossible,
                        answers=answers,
                        class_label=class_label)

                    examples.append(example)
        return examples


class DSTCExample(SquadExample):
    """
    A single training/test example for the Squad dataset, as loaded from disk.
    Args:
        qas_id: The example's unique identifier
        question_text: The question string
        context_text: The context string
        answer_text: The answer string
        start_position_character: The character position of the start of the answer
        title: The title of the example
        answers: None by default, this is used during evaluation. Holds answers as well as their start positions.
        is_impossible: False by default, set to True if the example has no possible answer.
        class_label: class_label
    """

    def __init__(self,
                 qas_id,
                 question_text,
                 context_text,
                 answer_text,
                 start_position_character,
                 title,
                 answers=[],
                 is_impossible=False,
                 class_label=0):
        super(DSTCExample, self).__init__(
            qas_id,
            question_text,
            context_text,
            answer_text,
            start_position_character,
            title,
            answers=answers,
            is_impossible=is_impossible)
        self.class_label = class_label


class DSTCFeatures(SquadFeatures):
    """
    Single squad example features to be fed to a model.
    Those features are model-specific and can be crafted from :class:`~transformers.data.processors.squad.SquadExample`
    using the :method:`~transformers.data.processors.squad.squad_convert_examples_to_features` method.
    Args:
        input_ids: Indices of input sequence tokens in the vocabulary.
        attention_mask: Mask to avoid performing attention on padding token indices.
        token_type_ids: Segment token indices to indicate first and second portions of the inputs.
        cls_index: the index of the CLS token.
        p_mask: Mask identifying tokens that can be answers vs. tokens that cannot.
            Mask with 1 for tokens than cannot be in the answer and 0 for token that can be in an answer
        example_index: the index of the example
        unique_id: The unique Feature identifier
        paragraph_len: The length of the context
        token_is_max_context: List of booleans identifying which tokens have their maximum context in this feature object.
            If a token does not have their maximum context in this feature object, it means that another feature object
            has more information related to that token and should be prioritized over this feature for that token.
        tokens: list of tokens corresponding to the input ids
        token_to_orig_map: mapping between the tokens and the original text, needed in order to identify the answer.
        start_position: start of the answer token index
        end_position: end of the answer token index
    """

    def __init__(self, input_ids, attention_mask, token_type_ids, cls_index,
                 p_mask, example_index, unique_id, paragraph_len,
                 token_is_max_context, tokens, token_to_orig_map,
                 start_position, end_position, is_impossible, class_label):
        super(DSTCFeatures,
              self).__init__(input_ids, attention_mask, token_type_ids,
                             cls_index, p_mask, example_index, unique_id,
                             paragraph_len, token_is_max_context, tokens,
                             token_to_orig_map, start_position, end_position,
                             is_impossible)
        self.class_label = class_label


def squad_convert_example_to_features_multi_class(example, max_seq_length,
                                                  doc_stride, max_query_length,
                                                  is_training):
    features = []
    if is_training and not example.is_impossible:
        # Get start and end position
        start_position = example.start_position
        end_position = example.end_position

        # If the answer cannot be found in the text, then skip this example.
        actual_text = " ".join(example.doc_tokens[start_position:(end_position +
                                                                  1)])
        cleaned_answer_text = " ".join(whitespace_tokenize(example.answer_text))
        if actual_text.find(cleaned_answer_text) == -1:
            logger.warning("Could not find answer: '%s' vs. '%s'", actual_text,
                           cleaned_answer_text)
            return []

    tok_to_orig_index = []
    orig_to_tok_index = []
    all_doc_tokens = []
    for (i, token) in enumerate(example.doc_tokens):
        orig_to_tok_index.append(len(all_doc_tokens))
        sub_tokens = tokenizer.tokenize(token)
        for sub_token in sub_tokens:
            tok_to_orig_index.append(i)
            all_doc_tokens.append(sub_token)

    if is_training and not example.is_impossible:
        tok_start_position = orig_to_tok_index[example.start_position]
        if example.end_position < len(example.doc_tokens) - 1:
            tok_end_position = orig_to_tok_index[example.end_position + 1] - 1
        else:
            tok_end_position = len(all_doc_tokens) - 1

        (tok_start_position, tok_end_position) = _improve_answer_span(
            all_doc_tokens, tok_start_position, tok_end_position, tokenizer,
            example.answer_text)

    spans = []

    truncated_query = tokenizer.encode(
        example.question_text,
        add_special_tokens=False,
        max_length=max_query_length)
    sequence_added_tokens = (
        tokenizer.max_len - tokenizer.max_len_single_sentence +
        1 if "roberta" in str(type(tokenizer)) or
        "camembert" in str(type(tokenizer)) else tokenizer.max_len -
        tokenizer.max_len_single_sentence)
    sequence_pair_added_tokens = tokenizer.max_len - tokenizer.max_len_sentences_pair

    span_doc_tokens = all_doc_tokens
    while len(spans) * doc_stride < len(all_doc_tokens):

        encoded_dict = tokenizer.encode_plus(
            truncated_query
            if tokenizer.padding_side == "right" else span_doc_tokens,
            span_doc_tokens
            if tokenizer.padding_side == "right" else truncated_query,
            max_length=max_seq_length,
            return_overflowing_tokens=True,
            pad_to_max_length=True,
            stride=max_seq_length - doc_stride - len(truncated_query) -
            sequence_pair_added_tokens,
            truncation_strategy="only_second"
            if tokenizer.padding_side == "right" else "only_first",
        )

        paragraph_len = min(
            len(all_doc_tokens) - len(spans) * doc_stride,
            max_seq_length - len(truncated_query) - sequence_pair_added_tokens,
        )

        if tokenizer.pad_token_id in encoded_dict["input_ids"]:
            if tokenizer.padding_side == "right":
                non_padded_ids = encoded_dict[
                    "input_ids"][:encoded_dict["input_ids"]
                                 .index(tokenizer.pad_token_id)]
            else:
                last_padding_id_position = (
                    len(encoded_dict["input_ids"]) - 1 -
                    encoded_dict["input_ids"][::-1].index(
                        tokenizer.pad_token_id))
                non_padded_ids = encoded_dict["input_ids"][
                    last_padding_id_position + 1:]

        else:
            non_padded_ids = encoded_dict["input_ids"]

        tokens = tokenizer.convert_ids_to_tokens(non_padded_ids)

        token_to_orig_map = {}
        for i in range(paragraph_len):
            index = len(
                truncated_query
            ) + sequence_added_tokens + i if tokenizer.padding_side == "right" else i
            token_to_orig_map[index] = tok_to_orig_index[len(spans) * doc_stride
                                                         + i]

        encoded_dict["paragraph_len"] = paragraph_len
        encoded_dict["tokens"] = tokens
        encoded_dict["token_to_orig_map"] = token_to_orig_map
        encoded_dict["truncated_query_with_special_tokens_length"] = len(
            truncated_query) + sequence_added_tokens
        encoded_dict["token_is_max_context"] = {}
        encoded_dict["start"] = len(spans) * doc_stride
        encoded_dict["length"] = paragraph_len

        spans.append(encoded_dict)

        if "overflowing_tokens" not in encoded_dict:
            break
        span_doc_tokens = encoded_dict["overflowing_tokens"]

    for doc_span_index in range(len(spans)):
        for j in range(spans[doc_span_index]["paragraph_len"]):
            is_max_context = _new_check_is_max_context(
                spans, doc_span_index, doc_span_index * doc_stride + j)
            index = (
                j if tokenizer.padding_side == "left" else spans[doc_span_index]
                ["truncated_query_with_special_tokens_length"] + j)
            spans[doc_span_index]["token_is_max_context"][
                index] = is_max_context

    for span in spans:
        # Identify the position of the CLS token
        cls_index = span["input_ids"].index(tokenizer.cls_token_id)

        # p_mask: mask with 1 for token than cannot be in the answer (0 for token which can be in an answer)
        # Original TF implem also keep the classification token (set to 0) (not sure why...)
        p_mask = np.array(span["token_type_ids"])

        p_mask = np.minimum(p_mask, 1)

        if tokenizer.padding_side == "right":
            # Limit positive values to one
            p_mask = 1 - p_mask

        p_mask[np.where(
            np.array(span["input_ids"]) == tokenizer.sep_token_id)[0]] = 1

        # Set the CLS index to '0'
        p_mask[cls_index] = 0

        span_is_impossible = example.is_impossible
        class_label = example.class_label
        start_position = 0
        end_position = 0
        if is_training and not span_is_impossible:
            # For training, if our document chunk does not contain an annotation
            # we throw it out, since there is nothing to predict.
            doc_start = span["start"]
            doc_end = span["start"] + span["length"] - 1
            out_of_span = False

            if not (tok_start_position >= doc_start and
                    tok_end_position <= doc_end):
                out_of_span = True

            if out_of_span:
                start_position = cls_index
                end_position = cls_index
                span_is_impossible = True
            else:
                if tokenizer.padding_side == "left":
                    doc_offset = 0
                else:
                    doc_offset = len(truncated_query) + sequence_added_tokens

                start_position = tok_start_position - doc_start + doc_offset
                end_position = tok_end_position - doc_start + doc_offset

        features.append(
            DSTCFeatures(
                span["input_ids"],
                span["attention_mask"],
                span["token_type_ids"],
                cls_index,
                p_mask.tolist(),
                example_index=0,  # Can not set unique_id and example_index here. They will be set after multiple processing.
                unique_id=0,
                paragraph_len=span["paragraph_len"],
                token_is_max_context=span["token_is_max_context"],
                tokens=span["tokens"],
                token_to_orig_map=span["token_to_orig_map"],
                start_position=start_position,
                end_position=end_position,
                is_impossible=span_is_impossible,
                class_label=class_label))
    return features


def squad_convert_examples_to_features_multi_class(examples,
                                                   tokenizer,
                                                   max_seq_length,
                                                   doc_stride,
                                                   max_query_length,
                                                   is_training,
                                                   return_dataset=False,
                                                   threads=1):
    """
    Converts a list of examples into a list of features that can be directly given as input to a model.
    It is model-dependant and takes advantage of many of the tokenizer's features to create the model's inputs.
    Args:
        examples: list of :class:`~transformers.data.processors.squad.SquadExample`
        tokenizer: an instance of a child of :class:`~transformers.PreTrainedTokenizer`
        max_seq_length: The maximum sequence length of the inputs.
        doc_stride: The stride used when the context is too large and is split across several features.
        max_query_length: The maximum length of the query.
        is_training: whether to create features for model evaluation or model training.
        return_dataset: Default False. Either 'pt' or 'tf'.
            if 'pt': returns a torch.data.TensorDataset,
            if 'tf': returns a tf.data.Dataset
        threads: multiple processing threadsa-smi
    Returns:
        list of :class:`~transformers.data.processors.squad.SquadFeatures`
    Example::
        processor = SquadV2Processor()
        examples = processor.get_dev_examples(data_dir)
        features = squad_convert_examples_to_features(
            examples=examples,
            tokenizer=tokenizer,
            max_seq_length=args.max_seq_length,
            doc_stride=args.doc_stride,
            max_query_length=args.max_query_length,
            is_training=not evaluate,
        )
    """

    # Defining helper methods
    features = []
    threads = min(threads, cpu_count())
    with Pool(
            threads,
            initializer=squad_convert_example_to_features_init,
            initargs=(tokenizer,)) as p:
        annotate_ = partial(
            squad_convert_example_to_features_multi_class,
            max_seq_length=max_seq_length,
            doc_stride=doc_stride,
            max_query_length=max_query_length,
            is_training=is_training,
        )
        features = list(
            tqdm(
                p.imap(annotate_, examples, chunksize=32),
                total=len(examples),
                desc="convert squad examples to features",
            ))
    new_features = []
    unique_id = 1000000000
    example_index = 0
    for example_features in tqdm(
            features, total=len(features),
            desc="add example index and unique id"):
        if not example_features:
            continue
        for example_feature in example_features:
            example_feature.example_index = example_index
            example_feature.unique_id = unique_id
            new_features.append(example_feature)
            unique_id += 1
        example_index += 1
    features = new_features
    del new_features
    if return_dataset == "pt":
        if not is_torch_available():
            raise RuntimeError(
                "PyTorch must be installed to return a PyTorch dataset.")

        # Convert to Tensors and build dataset
        all_input_ids = torch.tensor([f.input_ids for f in features],
                                     dtype=torch.long)
        all_attention_masks = torch.tensor([f.attention_mask for f in features],
                                           dtype=torch.long)
        all_token_type_ids = torch.tensor([f.token_type_ids for f in features],
                                          dtype=torch.long)
        all_cls_index = torch.tensor([f.cls_index for f in features],
                                     dtype=torch.long)
        all_p_mask = torch.tensor([f.p_mask for f in features],
                                  dtype=torch.float)
        all_is_impossible = torch.tensor([f.is_impossible for f in features],
                                         dtype=torch.float)
        all_class_label = torch.tensor([f.class_label for f in features],
                                       dtype=torch.float)

        if not is_training:
            all_example_index = torch.arange(
                all_input_ids.size(0), dtype=torch.long)
            dataset = TensorDataset(all_input_ids, all_attention_masks,
                                    all_token_type_ids, all_example_index,
                                    all_cls_index, all_p_mask)
        else:
            all_start_positions = torch.tensor(
                [f.start_position for f in features], dtype=torch.long)
            all_end_positions = torch.tensor([f.end_position for f in features],
                                             dtype=torch.long)
            dataset = TensorDataset(all_input_ids, all_attention_masks,
                                    all_token_type_ids, all_start_positions,
                                    all_end_positions, all_cls_index,
                                    all_p_mask, all_is_impossible,
                                    all_class_label)

        return features, dataset
    # TODO: change tf version when necessary
    elif return_dataset == "tf":
        if not is_tf_available():
            raise RuntimeError(
                "TensorFlow must be installed to return a TensorFlow dataset.")

        def gen():
            for ex in features:
                yield (
                    {
                        "input_ids": ex.input_ids,
                        "attention_mask": ex.attention_mask,
                        "token_type_ids": ex.token_type_ids,
                    },
                    {
                        "start_position": ex.start_position,
                        "end_position": ex.end_position,
                        "cls_index": ex.cls_index,
                        "p_mask": ex.p_mask,
                        "is_impossible": ex.is_impossible,
                    },
                )

        return tf.data.Dataset.from_generator(
            gen,
            (
                {
                    "input_ids": tf.int32,
                    "attention_mask": tf.int32,
                    "token_type_ids": tf.int32
                },
                {
                    "start_position": tf.int64,
                    "end_position": tf.int64,
                    "cls_index": tf.int64,
                    "p_mask": tf.int32,
                    "is_impossible": tf.int32,
                },
            ),
            (
                {
                    "input_ids": tf.TensorShape([None]),
                    "attention_mask": tf.TensorShape([None]),
                    "token_type_ids": tf.TensorShape([None]),
                },
                {
                    "start_position": tf.TensorShape([]),
                    "end_position": tf.TensorShape([]),
                    "cls_index": tf.TensorShape([]),
                    "p_mask": tf.TensorShape([None]),
                    "is_impossible": tf.TensorShape([]),
                },
            ),
        )

    return features
