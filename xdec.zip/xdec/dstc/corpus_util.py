import os
import re
import json
import click
import pickle
import logging
import random
import uuid
from tqdm import tqdm
from xdec_config import get_logger
import spacy
from spacy.tokens import DocBin

logger = get_logger(__name__)
logger.setLevel(logging.INFO)

try:
    from dstc.translate import do_backtranslation
except:
    logger.warning("Unable to import translate package")


@click.group()
def cli():
    pass


@click.command()
@click.option(
    '--metal_dir', default="dialog_data/dialogues", help="input data path")
@click.option(
    '--output_dir',
    default="dialog_data/processed_metal",
    help="output data file")
def process_metal(metal_dir, output_dir):
    try:
        os.makedirs(output_dir)
    except:
        logger.warn("Unable to create dir, probably already exists: {}".format(
            output_dir))
    spacy_model = "en_core_web_lg"
    logger.info("Loading spacy model: {}".format(spacy_model))
    nlp = spacy.load(spacy_model)

    for root, dirs, files in os.walk(metal_dir):
        for f in files:
            logger.info("Processing {}".format(f))
            with open(os.path.join(root, f)) as input_:
                dump_obj = []
                for line in input_:
                    datum = json.loads(line)
                    doc_bin = DocBin(
                        attrs=["LEMMA", "ENT_IOB", "ENT_TYPE"],
                        store_user_data=True)
                    for doc in nlp.pipe(datum["turns"]):
                        doc_bin.add(doc)
                        bytes_data = doc_bin.to_bytes()
                    datum["turn_bytes"] = bytes_data
                    dump_obj.append(datum)
            with open(os.path.join(output_dir, f) + ".pkl", "wb") as output_:
                logger.info("Writing {}".format(f))
                pickle.dump(dump_obj, output_)


@click.command()
@click.option(
    '--input_dir', default="dialog_data/dialogues", help="input data path")
@click.option(
    '--output_file', default="dialog_data/metal_all.txt", help="output path")
@click.option('--task', default="metalwoz", help="task: metalwoz, dstc, woz")
def dump_text(input_dir, output_file, task):
    if task == "metalwoz":
        _dump_metal(input_dir, output_file)
    if task == "dstc":
        _dump_dstc(input_dir, output_file)
    if task == "woz":
        _dump_woz(input_dir, output_file)


def _dump_metal(input_dir, output_file):
    with open(output_file, "w") as output:
        for root, _, files in os.walk(input_dir):
            for f in files:
                logger.info("Processing {}".format(f))
                with open(os.path.join(root, f)) as input_:
                    for line in input_:
                        datum = json.loads(line)
                        for turn in datum["turns"]:
                            output.write(turn.strip() + "\n")


def _dump_dstc(input_dir, output_file):
    with open(output_file, "w") as output:
        for _, _, files in os.walk(input_dir):
            for f in files:
                if "dialogues_0" not in f and "dialogues_1" not in f:
                    continue
                logging.info("Loading file {}".format(f))
                with open(os.path.join(input_dir, f)) as example_file:
                    entry = json.load(example_file)
                    for dialogue in entry:
                        dialogue_id = dialogue["dialogue_id"]
                        turns = dialogue["turns"]
                        for turn in dialogue["turns"]:
                            output.write(turn["utterance"].strip() + "\n")


def _dump_woz(input_dir, output_file):
    with open(output_file, "w") as output:
        with open(os.path.join(input_dir, "data.json")) as input_:
            data = json.load(input_)
        for v in data.values():
            for item in v["log"]:
                output.write(item["text"].strip() + "\n")


@click.command()
@click.option(
    '--input_dir', default="dialog_data/dialogues", help="input data path")
@click.option(
    '--output_file', default="dialog_data/metal_all.txt", help="output path")
def dump_metal_classification(input_dir, output_file):
    labels = []
    with open("metal_labels.txt") as input_:
        for line in input_:
            labels.append(line.strip())
    with open(output_file, "w") as output:
        for root, _, files in os.walk(input_dir):
            for f in files:
                logger.info("Processing {}".format(f))
                label = f[:-4]
                with open(os.path.join(root, f)) as input_:
                    i = 0
                    for line in input_:
                        datum = json.loads(line)
                        turns = datum["turns"]
                        buf = ""
                        for turn in turns:
                            speaker = "SYSTEM" if speaker == "USER" else "USER"
                            buf = buf + " {}: ".format(speaker) + turn
                            # output.write(turn.strip() + "\n")
                        gold_label = label.replace("_", " ").lower()
                        datum = {
                            "annotator_labels": ["True"],
                            "genre": "dstc",
                            "gold_label": "True",
                            "language": "en",
                            "match": "True",
                            "pairID": "{}-{}".format(f, i),
                            "promptID": "{}-{}".format(f, i),
                            "sentence1": gold_label,
                            "sentence1_tokenized": gold_label,
                            "sentence2": buf,
                            "sentence2_tokenized": buf
                        }
                        output.write(json.dumps(datum) + "\n")
                        random.shuffle(labels)
                        logger.debug("labels: {}".format(labels))
                        for label in labels[:5]:
                            label = label[:-4].replace("_", " ").lower()
                            logger.debug("label: {}; gold_label: {}".format(
                                label, gold_label))
                            if label == gold_label:
                                continue
                            datum = {
                                "annotator_labels": ["False"],
                                "genre": "dstc",
                                "gold_label": "False",
                                "language": "en",
                                "match": "True",
                                "pairID": "{}-{}".format(f, i),
                                "promptID": "{}-{}".format(f, i),
                                "sentence1": label,
                                "sentence1_tokenized": label,
                                "sentence2": buf,
                                "sentence2_tokenized": buf
                            }
                            output.write(json.dumps(datum) + "\n")
                        i += 1


def norm_multiwoz_key(k):
    k = k.lower()
    k = k.replace("-semi", "").replace("-book", "").replace("-booked", "")
    k = k.strip().replace(" ", "-")
    return k


def norm_multiwoz_slot_value(value):
    if value == 'not mentioned':
        return ""
    if value in ['dont care', 'dontcare', "don't care", "do not care"]:
        return "dontcare"
    return value


def build_xnli_datum(sentence1, sentence2, label, sid):
    return {
        "annotator_labels": [label],
        "genre": "dstc",
        "gold_label": label,
        "language": "en",
        "match": "True",
        "pairID": sid,
        "promptID": sid,
        "sentence1": sentence1,
        "sentence1_tokenized": sentence1,
        "sentence2": sentence2,
        "sentence2_tokenized": sentence2
    }


@click.command()
@click.option(
    '--multiwoz_dir',
    default="dialog_data/MultiWOZ_2.1",
    help="dir of multiwoz files")
@click.option(
    '--output_file',
    default="dialog_data/multiwoz_xnli_augment.jsonl",
    help="output file name")
def build_xnli_from_multiwoz(multiwoz_dir, output_file):
    with open(os.path.join(multiwoz_dir, "slot_descriptions.json")) as input_:
        slot_descriptions = json.load(input_)
        slot_descriptions = {
            norm_multiwoz_key(k): slot_descriptions[k]
            for k in slot_descriptions
        }
    # find categorical features
    with open(os.path.join(multiwoz_dir, "ontology.json")) as input_:
        ontology = json.load(input_)
        slot_values = {}
        for k, v in ontology.items():
            if len(v) < 10:
                # logger.info("Categorical {}: {}".format(k, v))
                slot_values[norm_multiwoz_key(k)] = [
                    _v for _v in v
                    if "|" not in _v and ">" not in _v and "<" not in _v
                ]
                if "dontcare" not in slot_values[norm_multiwoz_key(k)]:
                    slot_values[norm_multiwoz_key(k)].append("dontcare")
    logger.info("Slot descriptions: {}".format(slot_descriptions))
    logger.info("Slot values: {}".format(slot_values))
    # read data and build xnli format
    with open(os.path.join(multiwoz_dir, "data.json")) as input_:
        logs = json.load(input_)

    with open(output_file, "w") as output:
        sid = 0
        for k in logs:
            buf = ""
            log_list = logs[k]["log"]
            for i, item in enumerate(log_list):
                buf += (" User: " if i % 2 == 0 else " System: ") + item["text"]
                if i % 2 == 0 and i < len(log_list) - 1:
                    next_item = log_list[i + 1]
                    logger.info("buf: {}".format(buf))
                    meta_data = next_item["metadata"]
                    # logger.info("metadata: {}".format(meta_data))
                    for service_name in meta_data:
                        for type_ in meta_data[service_name]:
                            for slot_name in meta_data[service_name][type_]:
                                if slot_name == "booked":
                                    continue
                                slot_value = meta_data[service_name][type_][
                                    slot_name]
                                slot_value = norm_multiwoz_slot_value(
                                    slot_value)
                                slot_name = norm_multiwoz_key(service_name +
                                                              "-" + slot_name)
                                if slot_name not in slot_values:
                                    continue
                                sentence1_description = slot_descriptions[
                                    slot_name][random.randint(
                                        0,
                                        len(slot_descriptions[slot_name]) -
                                        1)].strip()
                                sentence2 = buf.strip()
                                for the_value in slot_values[slot_name]:
                                    sentence1 = sentence1_description + " is " + the_value
                                    if slot_value == the_value:
                                        label = "True"
                                    else:
                                        label = "False"
                                    datum = build_xnli_datum(
                                        sentence2, sentence1, label, str(sid))
                                    output.write(json.dumps(datum) + "\n")
                                    sid += 1

                                sentence1 = sentence1_description + " is None"
                                label = "True" if not slot_value else "False"
                                datum = build_xnli_datum(
                                    sentence2, sentence1, label, str(sid))
                                output.write(json.dumps(datum) + "\n")
                                sid += 1


@click.command()
@click.option(
    '--preprocessed_dir',
    default="dialog_data/processed_metal",
    help="output data file")
@click.option(
    '--output_file',
    default="dialog_data/processed_metal.pretrain.json",
    help="output data file")
def load_processed(preprocessed_dir, output_file):
    spacy_model = "en_core_web_lg"
    logger.info("Loading spacy model: {}".format(spacy_model))
    nlp = spacy.load(spacy_model)
    data = []
    for root, dirs, files in os.walk(preprocessed_dir):
        for f in files:
            logger.info("Loading {}".format(f))
            if "AGREEMENT" in f:
                logger.info("Skip {}".format(f))
                continue
            with open(os.path.join(preprocessed_dir, f), "rb") as input_:
                dump_obj = pickle.load(input_)
                for idx, dialog in enumerate(dump_obj):
                    title = "{} Dialog {}".format(f, idx)
                    doc_bin = DocBin().from_bytes(dialog["turn_bytes"])
                    docs = list(doc_bin.get_docs(nlp.vocab))
                    # for doc in docs:
                    #     logger.debug("Text: {}".format(doc.text))
                    #     for entity in doc.ents:
                    #         logger.debug("Entity: {}".format(entity))
                    turns = zip(docs[::2], docs[1::2])
                    last_occur = {}
                    for i, (sys_u, user_u) in enumerate(turns):
                        for entity in sys_u.ents:
                            last_occur[re.sub(r"\s+", "",
                                              entity.text.lower())] = i
                        for entity in user_u.ents:
                            last_occur[re.sub(r"\s+", "",
                                              entity.text.lower())] = i
                    # logger.debug("last occur: {}".format(last_occur))
                    context = ""
                    visited_entities = set()
                    turns = zip(docs[::2], docs[1::2])
                    paragraphs = []
                    negative_count = 0
                    positive_count = 0
                    for i, (sys_u, user_u) in enumerate(turns):
                        if not context:
                            context = "SYSTEM: " + sys_u.text + " USER: " + user_u.text
                        else:
                            context += " SYSTEM: " + sys_u.text + " USER: " + user_u.text
                        logger.debug("context: {}".format(context))
                        if i == 0:
                            continue
                        nlp(str(sys_u.text))
                        question = list(nlp(str(sys_u.text)).sents)[-1].text
                        found_entity = False
                        for entity in user_u.ents:
                            entity = entity.text
                            norm_entity = re.sub(r"\s+", "", entity.lower())
                            if norm_entity in last_occur and last_occur[
                                    norm_entity] > i and norm_entity not in visited_entities:
                                visited_entities.add(norm_entity)
                                qas_item = tag_slot(question, context, entity)
                                paragraph = {
                                    "context": context,
                                    "qas": [qas_item]
                                }
                                logger.info(
                                    "positive paragraph: {}".format(paragraph))
                                paragraphs.append(paragraph)
                                found_entity = True
                                positive_count += 1
                                break
                        if positive_count > 0 and (
                                negative_count / positive_count <
                                3) and not found_entity:
                            qas_item = tag_slot(question, context, "__none__")
                            paragraph = {"context": context, "qas": [qas_item]}
                            logger.info("negative paragraph {}/{}: {}".format(
                                negative_count, positive_count, paragraph))
                            paragraphs.append(paragraph)
                            negative_count += 1
                    datum = {"title": title, "paragraphs": paragraphs}
                    if datum["paragraphs"]:
                        data.append(datum)

    with open(output_file, 'w') as output:
        output.write(
            json.dumps({
                "data": data,
                "version": "2.0"
            }, indent=2) + '\n')


@click.command()
@click.option(
    '--input_file',
    default="dialog_data/processed_metal.pretrain.json",
    help="input data file")
@click.option(
    '--output_file',
    default="dialog_data/processed_metal.pretrain_fixed.json",
    help="output data file")
def fix_preprocessed(input_file, output_file):
    with open(input_file) as input_:
        data = json.load(input_)["data"]
    new_data = []
    for datum in data:
        if not datum["paragraphs"]:
            continue
        for paragraph in datum["paragraphs"]:
            qa_item = paragraph["qas"]
            qa_item["id"] = str(uuid.uuid4())
            paragraph["qas"] = [qa_item]
        new_data.append(datum)
    with open(output_file, "w") as output_:
        output_.write(
            json.dumps({
                "data": new_data,
                "version": "2.0"
            }, indent=2) + '\n')


def tag_slot(question, context, value):
    # val = value if value != "dontcare" else "Don't care"
    # print(full_context)
    # print('val', val)
    is_possible = True
    start = context.find(value)
    if start < 0:
        if value != "__none__":
            logger.warning("Value not found: {} _IN_ {}".format(value, context))
        is_possible = False
    qas_item = {
        "question": do_backtranslation(question),
        "is_impossible": not is_possible,
        "id": str(uuid.uuid4())
    }
    qas_item["answers"] = [{"answer_start": start, "text": value}] \
            if is_possible else []
    return qas_item


@click.command()
@click.option(
    "--squad_file_name",
    default="dstc8-squad/dev.squad.json",
    help="squad training input file")
@click.option(
    "--seq_file_name",
    default="dstc8-squad/dev.seq.jsonl",
    help="seq2seq input file for question generation")
def squad_to_seq(squad_file_name, seq_file_name):
    with open(squad_file_name) as input_, open(seq_file_name, "w") as output:
        logger.info("Reading input: {}".format(squad_file_name))
        data = json.load(input_)["data"]
        for datum in data:
            for paragraph in datum["paragraphs"]:
                context = paragraph["context"]
                if "System summary:" in context:
                    context = context[:context.index("System summary:")].strip()
                if len(context.split()) > 256:
                    continue
                for qa in paragraph["qas"]:
                    if not qa["answers"]:
                        continue
                    answer = qa["answers"][0]["text"]
                    question = qa["question"]
                    output_datum = {
                        "src":
                            "CONTEXT: {} # ANSWER: {}".format(context, answer),
                        "tgt":
                            question
                    }
                    output.write(json.dumps(output_datum) + "\n")


@click.command()
@click.option(
    "--metal_dir_name",
    default="dialog_data/dialogues",
    help="squad input file")
@click.option(
    "--seq_file_name",
    default="dstc8-squad/metal.seq.jsonl",
    help="file in seq2seq format")
def metal_to_seq(metal_dir_name, seq_file_name):
    """
    Generate Seq2Seq input from MetalWoz
    """
    spacy_model = "en_core_web_lg"
    logger.info("Loading spacy model: {}".format(spacy_model))
    nlp = spacy.load(spacy_model)

    with open(seq_file_name, "w") as output:
        for root, dirs, files in os.walk(metal_dir_name):
            for f in files:
                logger.info("Processing {}".format(f))
                with open(os.path.join(root, f)) as input_:
                    for line in tqdm(input_):
                        datum = json.loads(line)
                        logger.debug("turns: {}".format(datum["turns"]))
                        turns = datum["turns"][1::2]
                        for doc in nlp.pipe(turns):
                            logger.debug("Text: {}".format(doc.text))
                            for entity in doc.ents:
                                logger.debug("Entity: {}".format(entity))
                                # build input. target is unknown for the metal dataset
                                context = doc.text
                                answer = entity
                                question = "unknown"
                                output_datum = {
                                    "src":
                                        "CONTEXT: {} # ANSWER: {}".format(
                                            context, answer),
                                    "tgt":
                                        question
                                }
                                output.write(json.dumps(output_datum) + "\n")


if __name__ == "__main__":
    cli.add_command(process_metal)
    cli.add_command(load_processed)
    cli.add_command(fix_preprocessed)
    cli.add_command(dump_text)
    cli.add_command(dump_metal_classification)
    cli.add_command(build_xnli_from_multiwoz)
    cli.add_command(squad_to_seq)
    cli.add_command(metal_to_seq)
    cli()
