import os
import json
import logging
import click
import random
import pprint
import gzip
import math
import re
import sys
from collections import (OrderedDict, defaultdict)
from fuzzywuzzy import fuzz

from word2number import w2n
from xdec_config import get_logger, open_all
from nltk.tokenize.treebank import TreebankWordDetokenizer
from dstc.apply_rules import postprocess, get_service
from dstc.generic import (DSTCReranking, DSTCSlot, int_to_english,
                          is_number_slot, load_schema_info)
from schema_guided_dst.evaluate import get_dstc_metrics
from tqdm import tqdm
from multiwoz.create_schemaguided_data import norm_slot_name
from multiwoz.utils.util import find_sim

pp = pprint.PrettyPrinter(indent=2)

PREDICT = ["None", "dontcare"]

DONTCARE = "dontcare"
MAP_FOUR_WAY = {0: "True", 1: "False", 2: DONTCARE, 3: "None"}
MAP_BINARY = {0: "False", 1: "True"}

# NOTE: we change the 0 to be None, meaning no answer type, then we can
#       compute the F1 score for the True results
NONE_MAP_BINARY = {0: "None", 1: "True"}
CONST_NUM = "99"
ONE_TO_NINE = {
    'zero': 0,
    'one': 1,
    'two': 2,
    'three': 3,
    'four': 4,
    'five': 5,
    'six': 6,
    'seven': 7,
    'eight': 8,
    'nine': 9
}
SIM_ORD = [
    '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th',
    '11th', '12th', '13th', '14th', '15th', '16th', '17th', '18th', '19th',
    '20th', '21st', '22nd', '23rd', '24th', '25th', '26th', '27th', '28th',
    '29th', '30th', '31st'
]

logger = get_logger(__name__)
detok = TreebankWordDetokenizer()

TMP_SET = set()


def dstc_detok(value, slot_name=''):
    detok_value = re.sub(r"(\$) (\d)", r"\1\2", detok.detokenize(value.split()))
    detok_value = re.sub(r"(\#)(\d)", r"\1 \2",
                         detok.detokenize(detok_value.split()))
    detok_value = " " + detok_value + " "
    detok_value = detok_value.replace(" 's ", "'s ")
    detok_value = detok_value.replace("o``clock", 'o"clock')
    detok_value = detok_value.replace(" s ", "s ")

    if slot_name.endswith("_time"):
        if '$' in value or "dollar" in value or 'bucks' in value:
            return ""
    return detok_value.strip()


def norm_number(input, postaggings):
    words = input.strip().split()
    taggings = postaggings.strip().split()
    output = ""
    start_ = -1
    for idx, (word, pos) in enumerate(zip(words, taggings)):
        is_year = word.isnumeric() and 2099 > int(word) > 1900
        is_num = (
            pos == "CD" and word != "999-999-9999" and word not in SIM_ORD and
            not is_year)
        if (is_num and word.lower() == "one" and idx > 0 and
                words[idx - 1].lower() in ['that', 'this']):
            is_num = False
        if is_num:
            if start_ == -1:
                start_ = idx
        else:
            if start_ != -1:
                a_num = " ".join(words[start_:idx])
                # e.g. 10:20, 10,991.31
                if ":" in a_num or "," in a_num:
                    logging.debug("Replace {} with {}".format(a_num, CONST_NUM))
                    output += " " + CONST_NUM
                else:
                    try:
                        digits = w2n.word_to_num(a_num)
                        if digits > 9:
                            digits = CONST_NUM
                            logging.debug("Replace {} with {}".format(
                                a_num, CONST_NUM))
                        output += " " + str(digits)
                    except Exception as e:
                        logging.error("NOT number? {} {}".format(a_num, e))
                        output += " " + a_num
            # this is a word, try ONE_TO_NINE map
            cur = (
                word if word.lower() not in ONE_TO_NINE else
                ONE_TO_NINE[word.lower()])
            output += " " + str(cur)
            start_ = -1
    input = " ".join(words)
    output = output.strip()
    is_diff = False
    if input != output:
        is_diff = True
        if input not in TMP_SET:
            TMP_SET.add(input)
            logging.info("Norm numbers: \n{}\n{}\n".format(input, output))
    return output, is_diff


def locate_slot(schema_dict, service_name, slot_name):
    for slot in schema_dict[service_name]["slots"]:
        if slot["name"] == slot_name:
            return slot
    return None


def load_ontology(ontology_file):
    ontology = {}
    if len(ontology_file) > 0:
        with open(ontology_file, 'r') as cands_file:
            raw_ontology = json.load(cands_file)
            for domain_slot, values in raw_ontology.items():
                split_s = "-semi-" if "-semi-" in domain_slot else "-book-"
                domain, slot_name = domain_slot.strip().split(split_s, 1)
                slot_name = norm_slot_name(slot_name)
                ontology[f"{domain}-{slot_name}"] = values
    return ontology


def load_dontcare(dontcare_file, dontcare_threshold):
    dontcare = defaultdict(lambda: {})
    if len(dontcare_file) > 0:
        logging.info(f"Reading dontcare file {dontcare_file}")
        with open(dontcare_file, 'r') as d_file:
            for line in d_file:
                aux, _, probs = line.strip().split("\t")
                probs = eval(probs)
                e_sum = sum([math.exp(x) for x in probs])
                true_prob = math.exp(probs[0]) / e_sum
                if true_prob > dontcare_threshold:
                    (dialogue_id, turn_id, service_name, slot_name,
                     slot_value) = aux.split("|")
                    turn_id = int(turn_id)
                    res_key = (dialogue_id, turn_id, service_name)
                    dontcare[res_key][slot_name] = slot_value
    return dontcare


@click.group()
def cli():
    pass


def merge(slot_name_values):
    merged_slot_values = {}
    for slot_name, slot_values in slot_name_values.items():
        value_count = defaultdict(int)
        for (_, v) in slot_values:
            value_count[v] += 1
        max_value, max_count = "", 0
        for value, c in value_count.items():
            if c > max_count:
                max_value = value
                max_count = c
        merged_slot_values[slot_name] = max_value

    return merged_slot_values


def acc_merge(acc_results, acc_key, merged_slot_values, use_acc):
    acc_slot_values = {}
    # acc_results: {(dialog_id, service_name): {slot_name: value}}
    acc_sv = acc_results[acc_key] if use_acc else {}
    for name, value in merged_slot_values.items():
        acc_sv[name] = value

    for n, v in acc_sv.items():
        acc_slot_values[n] = [v]
    return acc_slot_values


@click.command()
@click.option(
    "--eval_type", default="all", help="evaluation type all/single/multi")
@click.option("--eval_set", default="dev", help="evaluation set dev/test")
@click.option("--result_path", multiple=True, default=[])
@click.option(
    "--output_path", default=".data/merge/dev", help="output merged results")
@click.option(
    '--dstc_path', default=".data/dstc/data/all_lower", help="ref path")
@click.option('--lower/--no_lower', default=False, help="lower case eval")
@click.option('--use_acc/--no_use_acc', default=False, help="carry over")
def reranker(eval_type, eval_set, result_path, output_path, dstc_path, lower,
             use_acc):

    results = defaultdict(lambda: defaultdict(list))
    # {(dialog_id, turn_id, service_name): {slot_name: [(sys_id, value)]}}
    for sys_id, res in enumerate(result_path):
        logging.info("Loading result from {}".format(res))
        for _, _, files in os.walk(res):
            for f in files:
                if 'dialogues_0' not in f and 'dialogues_1' not in f:
                    continue
                logging.info("Loading file {}".format(f))
                with open(os.path.join(res, f)) as example_file:
                    entry = json.load(example_file)
                    for dialogue in entry:
                        dialogue_id = dialogue["dialogue_id"]
                        turns = dialogue['turns']
                        for turn_id, t in enumerate(turns):
                            if t["speaker"] == "USER":
                                for frame in t["frames"]:
                                    service_name = frame["service"]
                                    state = frame["state"]
                                    slot_values = state["slot_values"]
                                    for k, v in slot_values.items():
                                        val = v[0].replace("``clock", "\"clock")
                                        results[(dialogue_id, turn_id,
                                                 service_name)][k].append(
                                                     (sys_id, val if not lower
                                                      else val.lower()))

    acc_results = defaultdict(lambda: defaultdict(str))
    # {(dialog_id, service_name): {slot_name: value}}
    for _, _, files in os.walk(result_path[0]):
        for f in files:
            if 'dialogues_0' not in f and 'dialogues_1' not in f:
                continue
            logging.info("Ranking file {}".format(f))
            with open(os.path.join(res, f)) as example_file:
                entry = json.load(example_file)
                for dialogue in entry:
                    dialogue_id = dialogue["dialogue_id"]
                    turns = dialogue['turns']
                    for turn_id, t in enumerate(turns):
                        if t["speaker"] == "USER":
                            for frame in t["frames"]:
                                service_name = frame["service"]
                                state = frame["state"]
                                merged_slot_values = merge(
                                    results[(dialogue_id, turn_id,
                                             service_name)])
                                acc_slot_values = acc_merge(
                                    acc_results, (dialogue_id, service_name),
                                    merged_slot_values,
                                    use_acc=use_acc)
                                state["slot_values"] = acc_slot_values
                logging.info("Saving file {}".format(f))
                with open(os.path.join(output_path, f), 'w') as output_file:
                    json.dump(entry, output_file, indent=2)

    metrics = get_dstc_metrics(
        eval_type=eval_type,
        eval_set=eval_set,
        output_metric_file=output_path + "/eval.txt",
        prediction_dir=output_path,
        dstc8_data_dir=dstc_path,
        reconstruct_paths=False)
    logging.info(pp.pformat(metrics))


@click.command()
@click.option(
    '--input_path', default=".data/dstc/data/all/dev", help="input data path")
@click.option(
    '--output', default=".data/dstcslot30/val.jsonl", help="output data file")
@click.option(
    '--service_des/--no_service_des',
    default=False,
    help="whether output service description for each quesiton")
@click.option(
    '--add_back_trans/--no_add_back_trans',
    default=False,
    help="whether add back translations for each description.")
@click.option(
    '--skip_history/--no_skip_history',
    default=False,
    help="skip generating services that shown in history. e.g. S1 S2 S1(skip)")
@click.option(
    '--use_tok/--no_use_tok',
    default=False,
    help="whether use context_tok, question_tok, and answer_tok to replace original fields"
)
@click.option(
    '--turn_rounds', default=30, help="how many turns to keep in context")
@click.option(
    '--unify/--no_unify',
    default=False,
    help="unify all the tasks into binary classification")
@click.option(
    '--number_gen/--no_number_gen',
    default=False,
    help="add number type categorical slots as a generation task")
@click.option(
    '--dontcare/--no_dontcare', default=False, help="output dontcare class")
def build_examples(input_path, output, service_des, add_back_trans, use_tok,
                   turn_rounds, unify, number_gen, skip_history, dontcare):
    TURN_ROUNDS = turn_rounds
    schema_dict = DSTCSlot.load_schema_dict(input_path)

    if service_des:
        logging.info("Add service description before each slot description")
    if unify:
        logging.info("Convert all examples into binary classfication task")
    if number_gen:
        logging.info("Convert number type slots into generation task")
    if dontcare:
        logging.info("Output dontcare class")

    DSTCSlot.build_examples(
        TURN_ROUNDS,
        input_path,
        schema_dict,
        add_service_des=service_des,
        add_back_trans=add_back_trans,
        skip_history=skip_history,
        unify=unify,
        number_gen=number_gen,
        output_file=output,
        dontcare=dontcare,
        use_tok=use_tok)


@click.command()
@click.option(
    "--slot_input_file_path",
    default=".data/merge/slot/val.jsonl",
    help="input (valid.jsonl) file")
@click.option(
    "--slot_prediction_file_path",
    default=".data/merge/slot/dstcslot.txt",
    help="slot level prediction file")
@click.option(
    "--old_predictions_path",
    default=".data/merge/dev",
    help="DSTC files path to be merged")
@click.option(
    "--new_predictions_path",
    default=".data/merge/newdev",
    help="path for new DSTC files")
@click.option(
    "--eval_type", default="all", help="evaluation type all/single/multi")
@click.option("--eval_set", default="dev", help="evaluation set dev/test")
@click.option(
    "--dstc_path", default=".data/dstc/data/all", help="original DSTC files")
@click.option(
    "--output_metric_file",
    default=".data/merge/result.json",
    help="output metric file")
@click.option(
    "--use_validator/--no_use_validator",
    default=False,
    help="whether multi-stream should be used")
@click.option(
    "--validator_input_file_path",
    default=".data/merge/validator/val.jsonl",
    help="input (valid.jsonl) file")
@click.option(
    "--validator_prediction_file_path",
    default=".data/merge/validator/dstcslot.txt",
    help="slot level validation prediction file")
def merge_slots(slot_input_file_path, slot_prediction_file_path,
                old_predictions_path, new_predictions_path, eval_type, eval_set,
                dstc_path, output_metric_file, use_validator,
                validator_input_file_path, validator_prediction_file_path):
    valid_slots = read_validation_file(
        validator_input_file_path,
        validator_prediction_file_path) if use_validator else None
    os.makedirs(new_predictions_path, exist_ok=True)
    logging.debug("Valid slots: {}".format(valid_slots))
    logging.info("Read slot file: {} & {}".format(slot_input_file_path,
                                                  slot_prediction_file_path))
    slot_predictions = read_slot_file(
        slot_input_file_path,
        slot_prediction_file_path,
        valid_slots=valid_slots)
    logging.info("Traverse DSTC data: {}".format(old_predictions_path))
    for _, dirs, files in os.walk(old_predictions_path):
        for f in files:
            logging.info("Processing file {}".format(f))
            if 'dialogues_' in f:
                with open(os.path.join(old_predictions_path,
                                       f)) as example_file:
                    entry = json.load(example_file)
                    process_entry(
                        entry,
                        slot_predictions,
                        os.path.join(new_predictions_path, f),
                        validated=False)
    metrics = get_dstc_metrics(
        eval_type=eval_type,
        eval_set=eval_set,
        output_metric_file=output_metric_file,
        prediction_dir=new_predictions_path,
        dstc8_data_dir=dstc_path,
        reconstruct_paths=False)
    logging.info(pp.pformat(metrics))


@click.command()
@click.option(
    "--slot_input_file_path",
    default=".data/merge/span/val.jsonl",
    help="input (valid.jsonl) file")
@click.option(
    "--slot_prediction_file_path",
    default=".data/merge/span/dstctok2.txt",
    help="slot level prediction file")
@click.option(
    "--squad_file_name",
    default=".data/merge/roberta_norm_nbest.gz",
    help="squad prediction gzip file")
@click.option(
    "--old_predictions_path",
    default=".data/merge/dev",
    help="DSTC files path to be merged")
@click.option(
    "--new_predictions_path",
    default=".data/merge/spandev",
    help="path for new DSTC files")
@click.option(
    "--eval_type", default="all", help="evaluation type all/single/multi")
@click.option("--eval_set", default="dev", help="evaluation set dev/test")
@click.option(
    "--dstc_path", default=".data/dstc/data/all", help="original DSTC files")
@click.option(
    "--output_metric_file",
    default=".data/merge/spandev-result.json",
    help="output metric file")
@click.option(
    "--squad/--no_squad",
    default=False,
    help="if input is squad gzip nbest file")
@click.option(
    "--merge_history/--no_merge_history",
    default=False,
    help="merge slots in history")
def merge_slot_spans(slot_input_file_path, slot_prediction_file_path,
                     squad_file_name, old_predictions_path,
                     new_predictions_path, eval_type, eval_set, dstc_path,
                     output_metric_file, squad, merge_history):
    try:
        os.makedirs(new_predictions_path)
    except:
        pass
    logger.info("SQUAD: {}".format(squad))
    schema_dict = load_schema_info(
        os.path.join(dstc_path, eval_set, "schema.json"))
    logger.debug("schema_dict: {}".format(json.dumps(schema_dict, indent=2)))
    if squad:
        slot_predictions = read_squad_file(squad_file_name)
        if merge_history:
            service_dict, len_dict = read_dialog_schema(
                os.path.join(dstc_path, eval_set))
            slot_predictions = merge_slots_in_history(slot_predictions,
                                                      service_dict, len_dict,
                                                      schema_dict)
    else:
        raise Exception("Only squad format is supported!")
    logger.info("Traverse DSTC data: {}".format(old_predictions_path))
    for _, dirs, files in os.walk(old_predictions_path):
        for f in files:
            logger.info("Processing file {}".format(f))
            if 'dialogues_' in f:
                with open(os.path.join(old_predictions_path,
                                       f)) as example_file:
                    entry = json.load(example_file)
                    process_entry(
                        entry,
                        slot_predictions,
                        os.path.join(new_predictions_path, f),
                        validated=False,
                        detect_conflicts=False,
                        schema_dict=schema_dict)
    metrics = get_dstc_metrics(
        eval_type=eval_type,
        eval_set=eval_set,
        output_metric_file=output_metric_file,
        prediction_dir=new_predictions_path,
        dstc8_data_dir=dstc_path,
        reconstruct_paths=False)
    logging.info(pp.pformat(metrics))


@click.command()
@click.option(
    "--non_cat_file_name",
    multiple=True,
    default=[".data/merge/roberta_norm_pretrained.nbest.json.gz"],
    help="squad prediction gzip file: non_cat")
@click.option(
    "--num_file_name",
    multiple=True,
    default=[".data/merge/xnli_final/num_norm_wd_pred_results.txt"],
    help="squad prediction gzip file: num")
@click.option(
    "--bool_file_name",
    multiple=True,
    default=[".data/merge/xnli_final/bool_pred_results.txt"],
    help="boolean slots tab separated prediction file")
@click.option(
    "--cat_file_name",
    multiple=True,
    default=[".data/merge/xnli_final/cat_pred_results.txt"],
    help="cat slots tab separated prediction file")
@click.option(
    "--old_predictions_path",
    default=".data/merge/dev",
    help="DSTC files path for reference")
@click.option(
    "--new_predictions_path",
    default=".data/merge/pretrained_dev_30",
    help="path for new DSTC files")
@click.option(
    "--eval_type", default="all", help="evaluation type all/single/multi")
@click.option("--eval_set", default="dev", help="evaluation set dev/test")
@click.option(
    "--dstc_path",
    default=".data/dstc8-schema-guided-dialogue",
    help="original DSTC files")
@click.option(
    "--output_metric_file",
    default=".data/merge/spandev-result.json",
    help="output metric file")
@click.option(
    "--merge_history/--no_merge_history",
    default=False,
    help="merge slots in history")
@click.option(
    "--use_max_score/--no_use_max_score",
    default=True,
    help="use max score instead of the last True for candidate selection")
@click.option("--lower/--no_lower", default=False, help="lower all slot values")
@click.option(
    "--prob_threshold",
    default=-1.0,
    help="min prob for a categorical label other than None. ignored if negative"
)
@click.option(
    "--ontology_file",
    default="",
    help="Slot value candidate file, ontology of Multiwoz 2.1")
@click.option(
    "--ontology_threshold",
    default=0.75,
    help="similarity threshold, lower than this returns None")
@click.option(
    "--dontcare_file", default="", help="dontcare classification results")
@click.option(
    "--dontcare_threshold",
    default=0.95,
    help="similarity threshold, lower than this returns None")
def merge_pretrained(non_cat_file_name, num_file_name, bool_file_name,
                     cat_file_name, old_predictions_path, new_predictions_path,
                     eval_type, eval_set, dstc_path, output_metric_file,
                     merge_history, use_max_score, lower, prob_threshold,
                     ontology_file, ontology_threshold, dontcare_file,
                     dontcare_threshold):
    _merge_pretrained(non_cat_file_name, num_file_name, bool_file_name,
                      cat_file_name, old_predictions_path, new_predictions_path,
                      eval_type, eval_set, dstc_path, output_metric_file,
                      merge_history, use_max_score, lower, prob_threshold,
                      ontology_file, ontology_threshold, dontcare_file,
                      dontcare_threshold)


def _merge_pretrained(non_cat_file_name, num_file_name, bool_file_name,
                      cat_file_name, old_predictions_path, new_predictions_path,
                      eval_type, eval_set, dstc_path, output_metric_file,
                      merge_history, use_max_score, lower, prob_threshold,
                      ontology_file, ontology_threshold, dontcare_file,
                      dontcare_threshold):
    try:
        os.makedirs(new_predictions_path)
    except:
        pass
    schema_dict = load_schema_info(
        os.path.join(dstc_path, eval_set, "schema.json"))
    logger.debug("schema_dict: {}".format(json.dumps(schema_dict, indent=2)))
    service_dict, len_dict = read_dialog_schema(
        os.path.join(dstc_path, eval_set))

    ontology = load_ontology(ontology_file)
    dontcare_predictions = load_dontcare(dontcare_file, dontcare_threshold)

    slot_predictions = read_squad_file(
        non_cat_file_name, ontology=ontology, threshold=ontology_threshold)
    if merge_history:
        slot_predictions = merge_slots_in_history(slot_predictions,
                                                  service_dict, len_dict,
                                                  schema_dict)
    num_predictions = read_tsv(
        num_file_name, multi_line=True, use_max_score=use_max_score)
    if merge_history:
        num_predictions = merge_slots_in_history(num_predictions, service_dict,
                                                 len_dict, schema_dict)
    bool_predictions = read_tsv(bool_file_name)
    if merge_history:
        bool_predictions = merge_slots_in_history(bool_predictions,
                                                  service_dict, len_dict,
                                                  schema_dict)
    cat_predictions = read_tsv(
        cat_file_name,
        multi_line=True,
        use_max_score=use_max_score,
        prob_threshold=prob_threshold)
    if merge_history:
        cat_predictions = merge_slots_in_history(cat_predictions, service_dict,
                                                 len_dict, schema_dict)

    logger.info("Traverse DSTC data: {}".format(old_predictions_path))
    for _, _, files in os.walk(old_predictions_path):
        for f in files:
            logger.info("Processing file {}".format(f))
            if 'dialogues_' in f:
                with open(os.path.join(old_predictions_path,
                                       f)) as example_file:
                    entry = json.load(example_file)
                    override_entry(
                        entry,
                        os.path.join(new_predictions_path, f),
                        dontcare_predictions,
                        slot_predictions,
                        cat_predictions,
                        num_predictions,
                        bool_predictions,
                        lower=lower)
    metrics = get_dstc_metrics(
        eval_type=eval_type,
        eval_set=eval_set,
        output_metric_file=output_metric_file,
        prediction_dir=new_predictions_path,
        dstc8_data_dir=dstc_path,
        reconstruct_paths=False)
    logging.info(pp.pformat(metrics))


@click.command()
@click.option(
    "--non_cat_file_name",
    multiple=True,
    default=[".data/multiwoz_test/nbest_predictions_final_step.json"],
    help="squad prediction gzip file: non_cat")
@click.option(
    "--num_file_name",
    multiple=True,
    default=[".data/multiwoz_test/num_pred_results.txt"],
    help="squad prediction gzip file: num")
@click.option(
    "--bool_file_name",
    multiple=True,
    default=[".data/multiwoz_test/bool_pred_results.txt"],
    help="boolean slots tab separated prediction file")
@click.option(
    "--cat_file_name",
    multiple=True,
    default=[".data/multiwoz_test/cat_pred_results.txt"],
    help="cat slots tab separated prediction file")
@click.option(
    "--old_predictions_path",
    default=".data/multiwoz_act/all_multiwoz_only_act/test",
    help="DSTC files path for reference")
@click.option(
    "--new_predictions_path",
    default=".data/multiwoz_test_output",
    help="path for new DSTC files")
@click.option(
    "--eval_type", default="all", help="evaluation type all/single/multi")
@click.option("--eval_set", default="test", help="evaluation set dev/test")
@click.option(
    "--dstc_path",
    default=".data/multiwoz_act/all_multiwoz_only_act",
    help="original DSTC files")
@click.option(
    "--output_metric_file",
    default=".data/multiwoz_test_output.metric.json",
    help="output metric file")
@click.option(
    "--merge_history/--no_merge_history",
    default=False,
    help="merge slots in history")
@click.option(
    "--use_max_score/--no_use_max_score",
    default=True,
    help="use max score instead of the last True for candidate selection")
@click.option("--lower/--no_lower", default=False, help="lower all slot values")
@click.option(
    "--prob_threshold",
    default=-1.0,
    help="min prob for a categorical label other than None. ignored if negative"
)
@click.option(
    "--ontology_file",
    default=".data/multiwoz_act/all_multiwoz_only_act/ontology.json",
    help="Slot value candidate file, ontology of Multiwoz 2.1")
@click.option(
    "--ontology_threshold",
    default=0.75,
    help="similarity threshold, lower than this returns None")
@click.option(
    "--dontcare_file", default="", help="dontcare classification results")
@click.option(
    "--dontcare_threshold",
    default=0.95,
    help="similarity threshold, lower than this returns None")
def merge_pretrained_mwoz(non_cat_file_name, num_file_name, bool_file_name,
                          cat_file_name, old_predictions_path,
                          new_predictions_path, eval_type, eval_set, dstc_path,
                          output_metric_file, merge_history, use_max_score,
                          lower, prob_threshold, ontology_file,
                          ontology_threshold, dontcare_file,
                          dontcare_threshold):
    _merge_pretrained(non_cat_file_name, num_file_name, bool_file_name,
                      cat_file_name, old_predictions_path, new_predictions_path,
                      eval_type, eval_set, dstc_path, output_metric_file,
                      merge_history, use_max_score, lower, prob_threshold,
                      ontology_file, ontology_threshold, dontcare_file,
                      dontcare_threshold)


@click.command()
@click.option(
    "--schema_file",
    default=".data/dstc/data/all_multiwoz_only/train/schema.json",
    help="Schema file")
@click.option(
    "--data_path",
    default=".data/dstc/data/all_multiwoz_only/test/",
    help="data path")
def validate(schema_file, data_path):
    schema_dict = load_schema_info(schema_file)
    service_slots = {}
    for service, ssinfo in schema_dict.items():
        for slot in ssinfo["slots"]:
            service_slots[(service, slot["name"])] = slot["possible_values"]

    def check_(entry):
        for dialog in entry:
            for turn in dialog["turns"]:
                for frame in turn["frames"]:
                    service = frame["service"]
                    state = frame.get("state", {})
                    slot_values = state.get("slot_values", {})
                    for name, values in slot_values.items():
                        if (service, name) not in service_slots:
                            logger.error(f"No {service} {name}")
                            continue

                        cands = service_slots[(service, name)]
                        if len(cands) == 0:
                            # non categorical slots, skip checking values
                            continue
                        for v in values:
                            if v in ["dontcare"]:  # skip dontcare value
                                continue
                            if v not in cands:
                                logger.error(f"No value: {v} in {cands}")

    for _, _, files in os.walk(data_path):
        for f in files:
            if 'dialogues_' not in f:
                continue

            logger.info("Processing file {}".format(f))
            with open(os.path.join(data_path, f)) as example_file:
                entry = json.load(example_file)
                check_(entry)


@click.command()
@click.option(
    "--input_jsonl_file",
    default=".data/dstcslot/train.jsonl",
    help="input file for downsampling")
@click.option(
    "--output_jsonl_file",
    default=".data/ddstcslot/train.jsonl",
    help="output file for downsampling")
@click.option(
    "--ratio",
    default=3.0,
    type=float,
    help="max ratio between negative and positive examples")
@click.option(
    '--unify/--no_unify',
    default=False,
    help="unify all the tasks into binary classification")
@click.option(
    '--service_level/--no_service_level',
    default=False,
    help="sampling id is service level, default is slot level")
@click.option(
    '--use_false/--no_use_false',
    default=False,
    help="use 'False' as a negative sign")
def down_sample(input_jsonl_file, output_jsonl_file, ratio, unify,
                service_level, use_false):
    if service_level:
        logging.info("Sampling on service_level!")
    if use_false:
        logging.info("Use False as negative sign!")

    def _down_sample(pos_buf, neg_buf, output_):
        pos_sample_num = len(pos_buf)
        for pos_line in pos_buf:
            output_.write(pos_line)

        neg_sample_num = 0
        if neg_buf:
            random.shuffle(neg_buf)
            neg_sample_num = max(1, int(len(pos_buf) * ratio))

            neg_sample_num = min(neg_sample_num, len(neg_buf))
            for neg_line in neg_buf[:neg_sample_num]:
                output_.write(neg_line)

        return (pos_sample_num, neg_sample_num)

    pos_buf, neg_buf = [], []
    prev_id = ""

    with open_all(input_jsonl_file) as input_:
        tot_num, pos_num, sam_num = 0, 0, 0
        with open(output_jsonl_file, "w") as output_:
            for line in input_:
                try:
                    line = line.decode('utf-8')
                except Exception as e:
                    pass
                tot_num += 1
                item = json.loads(line)
                aux = item["aux"]
                # "aux": "11_00000|18|Music_1|year|2017"
                if service_level:
                    id = "|".join(aux.split("|")[:3])
                else:
                    id = aux[:aux.rindex("|")]
                slot_value = aux.split("|")[-1]

                if unify:
                    is_pos = item["answer"] not in ["None", "False"]
                    # remove the slot values are None or dontcare
                    if is_pos and slot_value in ["None", "dontcare"]:
                        is_pos = False
                else:
                    neg_str = "False" if use_false else "None"
                    is_pos = item["answer"] != neg_str

                pos_num += 1 if is_pos else 0

                if id != prev_id:
                    (pos_sam_num,
                     neg_sam_num) = _down_sample(pos_buf, neg_buf, output_)
                    sam_num += (neg_sam_num + pos_sam_num)

                    pos_buf, neg_buf = [], []
                    prev_id = id
                if is_pos:
                    pos_buf.append(line)
                else:
                    neg_buf.append(line)
            (pos_sam_num, neg_sam_num) = _down_sample(pos_buf, neg_buf, output_)
            sam_num += (neg_sam_num + pos_sam_num)

    logging.info("Total number of instances: {}".format(tot_num))
    logging.info("Sampled {} ({:.2f}%)".format(sam_num,
                                               100 * float(sam_num) / tot_num))
    logging.info(
        "Including {} ({:.2f}%) positive and {} ({:.2f}%) negative".format(
            pos_num, 100 * float(pos_num) / sam_num, sam_num - pos_num,
            100 - 100 * float(pos_num) / sam_num))


@click.command()
@click.option(
    "--ref_path",
    default=".data/dstc/data/all_multiwoz_only_act/test",
    help="reference path")
@click.option(
    "--hyp_path",
    default="merge/multiwozonly_act_base_test_final",
    help="prediction path")
@click.option(
    "--output_file",
    default=".data/gen_multiwoz/gen_test.jsonl",
    help="output file")
@click.option("--turn_round", default=20, help="size of dialog history")
@click.option(
    "--use_stream/--no_use_stream",
    default=False,
    help="whether multi-stream should be used")
@click.option(
    "--is_reranking/--no_is_reranking",
    default=False,
    help="generate reranking examples or not")
@click.option(
    "--is_gpt2/--no_is_gpt2",
    default=False,
    help="generate reranking examples or not")
@click.option(
    "--add_cands/--no_add_cands",
    default=False,
    help="whether add candidate list to the context")
def build_generation_examples(ref_path, hyp_path, output_file, turn_round,
                              use_stream, is_reranking, is_gpt2, add_cands):
    """
    Build generation examples: 
        Reranking task: ref_path and hyp_path are required 
        Generation task: ref_path is required
    """

    DSTCReranking.build_examples(
        ref_path,
        hyp_path,
        output_file,
        use_stream=use_stream,
        is_reranking=is_reranking,
        is_gpt2=is_gpt2,
        add_cands=add_cands,
        turn_round=turn_round)


@click.command()
@click.option(
    "--schema_file",
    default=".data/dstc/data/all_multiwoz_only_act/test/schema.json",
    help="training data of seq file")
@click.option(
    "--seq_file",
    default=".data/gen_multiwoz/gen_test.jsonl",
    help="training data of seq file")
@click.option(
    "--hyp_file",
    default="transformer_models/seq_gen_multiwoz/ckpt-53481/trunkleft_test.output.txt",
    help="prediction file")
@click.option(
    "--cat_output_file",
    default="transformer_models/seq_gen_multiwoz/ckpt-53481/cat_pred_results.txt",
    help="output file")
@click.option(
    "--non_output_file",
    default="transformer_models/seq_gen_multiwoz/ckpt-53481/non_pred_results.txt",
    help="output file")
def convert_seq_to_pred(schema_file, seq_file, hyp_file, cat_output_file,
                        non_output_file):
    """
    Convert seq to seq output into classification task output

    seq_file: 
        {"src": "User: ...", "tgt": "service train : slot_name value , ...."}
    hyp_file:
        domain # slot_name # slot value ; domain # slot_name # slot value
    output_file:
        PMUL4317.json|0|train|day|monday	False	[-4.61, 4.40]
    """

    schema = load_schema_info(schema_file)
    s_name_cands, s_value_cands = defaultdict(set), defaultdict(set)
    s_name_iscat = {}
    for sev_name, slots in schema.items():
        for slot in slots['slots']:
            s_name = slot["name"]
            s_name_cands[sev_name].add(s_name)
            s_key = (sev_name, s_name)
            s_value_cands[s_key] |= set(slot["possible_values"])
            s_name_iscat[s_key] = slot["is_categorical"]

    aux_ids, hyp_outputs = [], []

    with open_all(seq_file) as seq_f:
        for line in seq_f:
            seq_ = json.loads(line)
            d_id, t_id, s_name = seq_["aux_id"].split("|")
            aux_ids.append((d_id, t_id, s_name))
    aux_len = len(aux_ids)

    with open_all(hyp_file) as hyp_f:
        for line in hyp_f:
            hyp_outputs.append(line.strip())
    hyp_len = len(hyp_outputs)

    assert aux_len == hyp_len, f"Mismatch size: {aux_len} VS {hyp_len}"

    cat_output = open(cat_output_file, 'w')

    non_nbest = {}
    for ((d_id, t_id, sev_name), hyp) in zip(aux_ids, hyp_outputs):
        hyp = hyp.decode("utf-8")
        # domain # slot_name # slot value ; domain # slot_name # slot value
        for domain_slot_value in hyp.split(" ; "):
            if domain_slot_value.count(" # ") != 2:
                logging.warning(f"Invalid triple: {domain_slot_value}")
                continue

            psev_name, s_name, s_value = domain_slot_value.split(" # ")
            if psev_name != sev_name:
                logging.warning(
                    f"Mismatch sevice name: {sev_name} VS {psev_name}")

            s_name = s_name.replace(" ", "")
            ss_name_cands = s_name_cands[sev_name]
            vs_name = find_sim(s_name, ss_name_cands, threshold=0.75)
            if vs_name == "None":
                logging.info(f"Invalid slot name: {s_name} # {ss_name_cands}")
                continue

            is_cat = s_name_iscat[(sev_name, vs_name)]
            s_value = s_value.replace(" : ", ":")
            ss_value_cands = s_value_cands.get((sev_name, vs_name), set())
            if (s_value not in ["None", "none", DONTCARE] and
                    len(ss_value_cands) > 0):
                vs_value = find_sim(s_value, ss_value_cands, threshold=0.75)
                if vs_value == "None":
                    logging.info(
                        f"Invalid slot value: {s_value} # {domain_slot_value}")
            else:
                vs_value = s_value
            if vs_value == "none":
                vs_value = "None"
            # TODO(haitao.mi): recover the prediction scores.
            if is_cat:
                aux = f"{d_id}|{t_id}|{sev_name}|{vs_name}|{vs_value}"
                scores = "[1, 0.3]"
                cat_output.write(f"{aux}\tTrue\t{scores}\n")
            else:
                non_nbest[f"{d_id}|{t_id}|{sev_name}|{vs_name}|"] = [{
                    "text": vs_value,
                    "probability": 0.8
                }]
    cat_output.close()

    with open(non_output_file, "w") as non_output:
        json.dump(non_nbest, non_output, indent=2)


def process_entry(entry,
                  slot_predictions,
                  new_predictions_file,
                  validated=False,
                  detect_conflicts=True,
                  schema_dict={}):

    def _is_categorical(slot_name, slots):
        for slot in slots:
            if slot["name"] == slot_name:
                return slot["is_categorical"]
        return False

    for dialogue in entry:
        dialogue_id = dialogue["dialogue_id"]
        for turn_id in range(len(dialogue["turns"])):
            for frame in dialogue["turns"][turn_id]["frames"]:
                if "state" not in frame:
                    continue
                used_values = []
                service_name = frame["service"]
                if (dialogue_id, turn_id, service_name) in slot_predictions:
                    predicted_values = set()
                    conflicting_value_prediction = False
                    for v in slot_predictions[(dialogue_id, turn_id,
                                               service_name)].values():
                        v = v[0]
                        for _v in predicted_values:
                            if v in _v or _v in v:
                                conflicting_value_prediction = True
                                break
                        predicted_values.add(v)
                    if conflicting_value_prediction and detect_conflicts:
                        logging.info(
                            "Skip conflicting value prediction: {}".format(
                                slot_predictions[(dialogue_id, turn_id,
                                                  service_name)]))
                        continue
                    for slot_name in slot_predictions[(dialogue_id, turn_id,
                                                       service_name)]:
                        if _is_categorical(slot_name,
                                           schema_dict[service_name]["slots"]):
                            continue
                        v = slot_predictions[(dialogue_id, turn_id,
                                              service_name)][slot_name]
                        conflicting_value = False
                        used_values = [frame["state"]["slot_values"][slot_name]] \
                            if slot_name in frame["state"]["slot_values"] \
                            else []
                        for used_value in used_values:
                            logging.debug("used_value: {}".format(used_value))
                            logging.debug("v: {}".format(v))
                            if used_value[0] in v[0] or v[0] in used_value[0]:
                                conflicting_value = True
                                break

                        if conflicting_value and detect_conflicts:
                            logging.debug(
                                "CONFLICT\tservice[{}] slot[{}] value[{}] used values:{}"
                                .format(service_name, slot_name, v,
                                        used_values))
                            continue
                        else:
                            if detect_conflicts:
                                logging.debug(
                                    "NO CONFLICT\tservice[{}] slot[{}] value[{}] used values:{}"
                                    .format(service_name, slot_name, v,
                                            used_values))

                        if frame["state"]["slot_values"]:
                            if slot_name not in frame["state"]["slot_values"]:
                                logging.debug(
                                    "\tADD\tservice[{}] slot [{}] value [{}]"
                                    .format(service_name, slot_name, v))
                            else:
                                if frame["state"]["slot_values"][slot_name] != v:
                                    logging.debug(
                                        "\tFIX\tservice[{}] slot [{}] old value [{}] new value [{}]"
                                        .format(
                                            service_name, slot_name,
                                            frame["state"]["slot_values"]
                                            [slot_name], v))
                            frame["state"]["slot_values"][slot_name] = v
    with open(new_predictions_file, "w") as output_file:
        json.dump(entry, output_file, indent=2)


def override_entry(entry, new_predictions_file, *slot_predictions, lower=False):
    for dialogue in entry:
        dialogue_id = dialogue["dialogue_id"]
        for turn_id in range(len(dialogue["turns"])):
            for frame in dialogue["turns"][turn_id]["frames"]:

                service_name = frame["service"]
                if "state" not in frame:
                    frame["state"] = {}
                frame["state"]["slot_values"] = {}
                for slot_prediction in slot_predictions:
                    if (dialogue_id, turn_id, service_name) in slot_prediction:
                        slot_cands = slot_prediction[(dialogue_id, turn_id,
                                                      service_name)]
                        for slot_name, slot_value in slot_cands.items():
                            if lower:
                                slot_value = [x.lower() for x in slot_value]
                            frame["state"]["slot_values"][
                                slot_name] = slot_value
        if dialogue_id == "1_00036":
            logger.debug("TRACE dialogue: {}".format(dialogue))

    with open(new_predictions_file, "w") as output_file:
        json.dump(entry, output_file, indent=2)


def read_slot_file(slot_input_file_path,
                   slot_prediction_file_path,
                   valid_slots=None):
    result = {}
    old_dialog_id = ""
    with open(slot_input_file_path) as input_:
        slot_inputs = input_.readlines()
    # MRC slot predictions e.g.:
    # None
    # half past 11 in the morning
    with open(slot_prediction_file_path) as input_:
        slot_predictions = list(map(lambda x: x.strip(), input_.readlines()))
    for slot_input, slot_prediction in zip(slot_inputs, slot_predictions):
        turn_id = -1
        if slot_prediction == "None":
            continue
        slot_input = json.loads(slot_input)
        # handle aux field with or without turn_id
        try:
            dialogue_id, turn_id, service_name, slot_name = slot_input[
                "aux"].split("|")
            turn_id = int(turn_id)
        except:
            dialogue_id, service_name, slot_name = slot_input["aux"].split("|")
        if dialogue_id != old_dialog_id:
            old_dialog_id = dialogue_id
        if turn_id < 0:
            turn_id = (len(
                list(
                    filter(lambda x: x == "User:",
                           slot_input["context"].split()))) - 1) * 2
        if valid_slots and (dialogue_id, turn_id, service_name,
                            slot_name) not in valid_slots:
            continue
        if (dialogue_id, turn_id, service_name) not in result:
            result[(dialogue_id, turn_id, service_name)] = {}
        result[(dialogue_id, turn_id,
                service_name)][slot_name] = [slot_prediction]
    return result


def prune_slots(collection, squad=False):
    for (dialogue_id, turn_id, service_name), state in collection.items():
        logger.debug("State before pruning: {}".format(state))
        merge_spans(state, prune_span=not squad, prune_overlap_string=True)
        logger.debug("State after pruning: {}".format(state))
        for k in state:
            state[k] = [state[k]["value"]]
        logger.debug("State after cleaning: {}".format(state))
    return collection


def read_squad_file(squad_file_name,
                    schema_dict=None,
                    ontology={},
                    threshold=1.0):

    def _candidate_values(service_name, slot_name):
        for slot in schema_dict[service_name]["slots"]:
            if slot_name == slot["name"]:
                return slot["possible_values"]
        return []

    def _find_value(slot_value, possible_values):
        slot_value_exp = " " + slot_value + " "
        for cand in possible_values:
            if (cand == slot_value or (" " + cand + " ") in slot_value_exp):
                # find a match candidate, return directly
                return cand

            # check whether it's an english version
            eng_cands = int_to_english(int(cand))
            # logger.debug("eng_cands: {}".format(eng_cands))
            if eng_cands is None:
                continue
            for eng_cand in eng_cands:
                if (eng_cand == slot_value or
                    (" " + eng_cand + " ") in slot_value_exp):
                    return cand
        # in the current settings, we have two types of numbers
        # 1: year:
        # 2: number less than 10:
        # let's return None or the max number
        # this is a number slot, but cannot find any candidate
        logging.warn("'{}' in {}".format(slot_value, possible_values))
        return None

    result = defaultdict(lambda: defaultdict(list))
    tot_sys = len(squad_file_name)
    for sfn in squad_file_name:
        if sfn.strip() == "":
            continue
        with open_all(sfn) as f:
            data = json.load(f)
        logger.info(f"Reading squad file {sfn}")
        for k, datums in data.items():
            dialogue_id, turn_id, service_name, slot_name = k.split("|", 3)
            if "|" in slot_name:
                slot_name = slot_name.split("|", 1)[0]
            turn_id = int(turn_id)

            for datum in datums[:3]:
                value = datum["text"].strip()

                if len(value) == 0 or value in ['empty', 'none', 'None']:
                    value = "None"
                else:
                    if schema_dict:
                        candidate_values = _candidate_values(
                            service_name, slot_name)
                        value = _find_value(value.lower(), candidate_values)
                        if not value:
                            value = "None"
                    # post-processings
                    value = dstc_detok(value, slot_name=slot_name)

                prob = datum["probability"]
                result[(dialogue_id, turn_id, service_name)][slot_name].append(
                    (value, prob))

    merged_result = {}
    for dts, name_cands in result.items():
        merged_result[dts] = {}
        service_name = dts[2]
        for slot_name, slot_cands in name_cands.items():
            value_sumprob = defaultdict(float)
            for (v, p) in slot_cands:
                value_sumprob[v] += p

            max_value, max_prob = sorted(
                [(vv, pp) for vv, pp in value_sumprob.items()],
                key=lambda x: x[1],
                reverse=True)[0]

            ss_key = f"{service_name}-{slot_name}"
            if len(ontology) > 0 and ss_key not in ontology:
                logging.error(f"Cannot find {ss_key} in {ontology.keys()}")
            if max_value not in ["None", ""] and ss_key in ontology:
                max_value = find_sim(
                    max_value, ontology[ss_key], threshold=threshold)

            if max_value not in ["None", ""]:
                merged_result[dts][slot_name] = {
                    "value": max_value,
                    "begin": 0,
                    "end": 0,
                    "logprob": math.log(max_prob / float(tot_sys))
                }
    # prune duplicate predictions with probability
    return prune_slots(merged_result, squad=True)


def read_tsv(tsv_file,
             multi_line=False,
             use_max_score=False,
             prob_threshold=-1.0):
    """
    tsv format:
    9_00000|0|Events_1|number_of_seats|1	False	[-4.77977, 6.1833829]
    9_00000|0|Events_1|number_of_seats|2	False	[-4.80070, 6.1590313]
    9_00000|0|Events_1|number_of_seats|3	False	[-4.80598, 6.152444]
    9_00000|0|Events_1|number_of_seats|4	False	[-4.80957, 6.1457171]
    9_00000|0|Events_1|number_of_seats|5	False	[-4.79540, 6.1184439]
    9_00000|0|Events_1|number_of_seats|6	False	[-4.80115, 6.1208472]
    9_00000|0|Events_1|number_of_seats|7	False	[-4.79575, 6.1189436]
    9_00000|0|Events_1|number_of_seats|8	False	[-4.79825, 6.1197462]
    9_00000|0|Events_1|number_of_seats|9	False	[-4.79645, 6.1189551]
    9_00000|0|Events_1|number_of_seats|None	True	[6.953316, -2.2527792]
    """
    result = defaultdict(lambda: defaultdict(list))
    slot_score_value = defaultdict(list)
    for tsv in tsv_file:
        if tsv.strip() == "":
            continue
        logger.info(f"Reading xnli file {tsv}")
        uniq_slot_value = {}
        tsv_file = open(tsv)
        for line in tsv_file:
            aux, value, probs = line.strip().split("\t")
            if prob_threshold > 0 and aux.endswith("|None"):
                continue
            probs = eval(probs)
            sum_exp = sum([math.exp(x) for x in probs])
            probs = [math.exp(x) / sum_exp for x in probs]
            (dialogue_id, turn_id, service_name, slot_name,
             slot_value) = aux.split("|")
            turn_id = int(turn_id)
            curr_key = ((dialogue_id, turn_id, service_name, slot_name),
                        slot_value)

            res_key = (dialogue_id, turn_id, service_name)
            if multi_line:
                if use_max_score:
                    if curr_key in uniq_slot_value:
                        uniq_slot_value[curr_key] = max(
                            probs[0], uniq_slot_value[curr_key])
                    else:
                        uniq_slot_value[curr_key] = probs[0]

                elif value == "True" and slot_value != "None":
                    # NOTE: pick the first True one
                    if slot_name not in result[res_key]:
                        result[res_key][slot_name] = [slot_value]
            else:
                if value != "None":
                    result[res_key][slot_name] = [value]
        tsv_file.close()
        if multi_line and use_max_score:
            # push uniq slot value
            for (sk, sv), prob in uniq_slot_value.items():
                slot_score_value[sk].append((prob, sv))

    if multi_line and use_max_score:
        # go through each candidate list and pick the max score
        for k, score_values in slot_score_value.items():
            (dialogue_id, turn_id, service_name, slot_name) = k

            value_sumprob = defaultdict(float)
            for p, v in score_values:
                value_sumprob[v] += p

            max_value, max_prob = sorted(
                [(vv, pp) for vv, pp in value_sumprob.items()],
                key=lambda x: x[1],
                reverse=True)[0]
            if prob_threshold > 0 and max_prob < prob_threshold:
                max_value = "None"

            if max_value != "None":
                res_key = (dialogue_id, turn_id, service_name)
                result[res_key][slot_name] = [max_value]
    return result


def merge_spans(state, prune_span=True, prune_overlap_string=False):
    slots_to_remove = set()
    occupied_spans = {}
    if prune_span:
        for slot_name, slot_val in state.items():
            span = (slot_val["begin"], slot_val["end"])
            for occupied_span, (occupied_logprob,
                                occupied_slot_name) in occupied_spans.items():
                if span[0] <= occupied_span[1] and span[1] >= occupied_span[0]:
                    if occupied_logprob < slot_val["logprob"]:
                        slots_to_remove.add(occupied_slot_name)
                    else:
                        slots_to_remove.add(slot_name)
            occupied_spans[span] = (slot_val["logprob"], slot_name)
        logger.debug("Span based State: {} Remove {}".format(
            state, slots_to_remove))

    if prune_overlap_string:
        occupied_values = {}
        for slot_name, slot_val in state.items():
            value = slot_val["value"]
            for occupied_value, (occupied_logprob,
                                 occupied_slot_name) in occupied_values.items():
                if value == occupied_value:
                    if occupied_logprob < slot_val["logprob"]:
                        slots_to_remove.add(occupied_slot_name)
                    else:
                        slots_to_remove.add(slot_name)
            occupied_values[value] = (slot_val["logprob"], slot_name)
        logger.debug("Value based State: {} Remove {}".format(
            state, slots_to_remove))

    for slot_to_remove in slots_to_remove:
        del state[slot_to_remove]
    return state


def read_validation_file(validator_input_file_path,
                         validator_prediction_file_path):
    result = set()
    with open(validator_input_file_path) as input_:
        slot_inputs = input_.readlines()
    # MRC slot predictions e.g.:
    # None
    # half past 11 in the morning
    with open(validator_prediction_file_path) as input_:
        slot_predictions = list(
            map(lambda x: int(x.strip()) == 0, input_.readlines()))
    for slot_input, slot_prediction in zip(slot_inputs, slot_predictions):
        slot_input = json.loads(slot_input)
        dialogue_id, turn_id, service_name, slot_name = slot_input["aux"].split(
            "|")
        turn_id = int(turn_id)
        result.add((dialogue_id, turn_id, service_name, slot_name))
    return result


def find_all(context, value):
    answers = []

    context_lower = context.lower()
    value_lower = value.lower()

    answer_start = context_lower.find(value.lower())
    while answer_start != -1:
        cased_value = context[answer_start:answer_start + len(value)]
        answers.append({"text": cased_value, "answer_start": answer_start})
        answer_start = context_lower.find(value_lower,
                                          answer_start + len(value))
        if cased_value != value:
            logging.info("Use cased value: {} VS {}".format(cased_value, value))
    return answers


def covert_features_to_ids(feature_dimension,
                           feature_to_id,
                           raw_features,
                           min_count=20):
    feat_ids = [0 for _ in range(feature_dimension)]
    for k, v in raw_features.items():
        feat_key = "{}#{}".format(k, v)
        if feat_key in feature_to_id:
            [idx, ct] = feature_to_id[feat_key]
            if idx < feature_dimension and ct >= min_count:
                feat_ids[idx] = 1
    return feat_ids


@click.command()
@click.option(
    "--input_file",
    default=".data/dstcslotall_final_cat/val.jsonl",
    help="input file")
@click.option(
    "--output_file",
    default=".data/xnli/xnli.dev.final.cat.feats.jsonl",
    help="output file")
@click.option(
    "--norm_num/--no_norm_num",
    default=False,
    help="norm English number into Arabic numbers")
@click.option("--feature_dimension", default=50, help="feature dimension")
@click.option("--min_count", default=20, help="feature pruning by count")
@click.option(
    "--feature_file",
    default=".data/dstcslotall_final_cat/feature.json",
    help="feature file")
@click.option(
    "--dontcare/--no_dontcare",
    default=False,
    help="only use dontcare example.")
@click.option(
    "--dontcare_file",
    default=".data/dstcslotall_final_cat/dontcare.val.jsonl",
    help="output file")
def dstc_to_xnli(input_file, output_file, norm_num, feature_dimension,
                 min_count, feature_file, dontcare, dontcare_file):
    '''
    input: 
        {"context": "User : I am interested in finding an apartment with 
        "question": "visits: Number of bed rooms , Number of bedrooms", 
        "answer": "two bedrooms", 
        "context_tok": "User :  number of the property ?", 
        "question_tok": " : Number of bed rooms , Number of bedrooms", 
        "answer_tok": "two bedrooms", 
        "answer_type": 0, 
        "answer_four_way": 0, 
        "answer_binary": 0, 
        "answer_span_start": 10, 
        "answer_span_end": 11,
        "task_type": [1, 0, 0], 
        "slot_type": "number", 
        "aux": "19_00080|4|Homes_1|number_of_beds|"}

    output:
        {"annotator_labels": ["cont", "cont", "cont", "cont", "cont"], 
        "genre": "verbatim", 
        "gold_label": "cont", 
        "language": "el", 
        "match": "True", 
        "pairID": "7474", 
        "promptID": "2492", 
        "sentence1": "This is a test.", 
        "sentence1_tokenized": "This is a test .", 
        "sentence2": "Test.", 
        "sentence2_tokenized": "Test ."}
    '''

    tot_xnli = 0
    tot_diff = 0
    features = {}
    if feature_file != "":
        with open(feature_file) as feat_f:
            features = json.load(feat_f)
    if dontcare:
        dontcare_output = open(dontcare_file, 'w')

    with open_all(input_file) as input:
        with open(output_file, "w") as output:
            for line in input:
                tot_xnli += 1
                dstc = json.loads(line)
                slot_type = dstc['slot_type']
                aux = dstc['aux']
                gold_label = ""

                any_str = ""
                if dontcare:  # only output dontcare
                    if slot_type == "noncategorical":
                        _, _, _, slot_name, _ = aux.split("|")
                        slot_name = slot_name.replace("_", " ")
                        any_str = f" . any {slot_name}"
                    elif (slot_type in ["categorical", "number"] and
                          DONTCARE not in aux) or (slot_type in ["boolean"]):
                        continue

                if slot_type == "boolean":
                    answer_four_way = dstc["answer_four_way"]
                    gold_label = MAP_FOUR_WAY[answer_four_way]
                elif slot_type in ["categorical", "number"]:
                    answer_binary = dstc["answer_binary"]
                    gold_label = MAP_BINARY[answer_binary]
                else:
                    if dontcare:  # non categorcial
                        aux += DONTCARE
                        gold_label = ("True" if DONTCARE in dstc["answer"] else
                                      "False")
                    else:
                        continue

                context, context_tok = dstc['context'], dstc['context_tok']
                question, question_tok = dstc['question'], dstc['question_tok']
                if norm_num:
                    context_tok, is_diff = norm_number(dstc["context_tok"],
                                                       dstc["context_pos"])
                    tot_diff += 1 if is_diff else 0
                    question_tok, _ = norm_number(dstc['question_tok'],
                                                  dstc["question_pos"])

                if len(features) > 0:
                    wide_ids = covert_features_to_ids(
                        feature_dimension,
                        features,
                        dstc['features'],
                        min_count=min_count)
                else:
                    wide_ids = [0]

                if dontcare:
                    # dump dontcare reference file
                    dc = {
                        "context": dstc["context"],
                        "question": dstc["question"],
                        "answer": gold_label,
                        "answer_tok": gold_label,
                        "answer_type": 2,
                        "answer_binary": 0 if gold_label == "False" else 1,
                        "task_type": [0, 0, 1],
                        "slot_type": "categorical",
                        "aux": aux,
                    }
                    dontcare_output.write(json.dumps(dc) + '\n')
                xnli = {
                    "gold_label": gold_label,
                    "pairID": aux,
                    "sentence1": context,
                    "sentence1_tokenized": context_tok,
                    "sentence2": question + any_str,
                    "sentence2_tokenized": question_tok + any_str,
                    "wide_ids": wide_ids,
                }
                output.write(json.dumps(xnli) + '\n')

    if dontcare:
        dontcare_output.close()
    logging.info("Total number of training instances: {}".format(tot_xnli))
    logging.info("Total number of difference {}".format(tot_diff))
    logging.info("Saving instances to {}".format(output_file))


def extract_orig_and_trans_description(description):
    """
    sample input: visits: Number of bed rooms , Number of bedrooms
    """
    service_des, orig_and_trans = description.split(":", maxsplit=1)
    orig, trans = orig_and_trans.split(",", maxsplit=1)
    return service_des.strip() + " : " + orig.strip(), \
        service_des.strip() + " : " + trans.strip()


@click.command()
@click.option(
    "--input_file",
    default=".data/dstcslotall_final_non/val.jsonl.gz",
    help="input file")
@click.option(
    "--output_file",
    default=".data/squad/dev.final.noncat.json",
    help="output file")
@click.option(
    "--positive/--no_positive",
    default=False,
    help="only use positive example.")
@click.option(
    "--orig/--no_orig",
    default=False,
    help="only original slot description without back translation.")
def dstc_to_squad(input_file, output_file, positive, orig):
    ''' 
    input: 
        {"context": "User : I am interested in finding an apartment with 
        "question": "visits: Number of bed rooms , Number of bedrooms", 
        "answer": "two bedrooms", 
        "context_tok": "User :  number of the property ?", 
        "question_tok": " : Number of bed rooms , Number of bedrooms", 
        "answer_tok": "two bedrooms", 
        "answer_type": 0, 
        "answer_four_way": 0, 
        "answer_binary": 0, 
        "answer_span_start": 10, 
        "answer_span_end": 11, 
        "task_type": [1, 0, 0], 
        "slot_type": "number", 
        "aux": "19_00080|4|Homes_1|number_of_beds|"}
    output:
        {"data": [ {
            "title": "Normans",
            "paragraphs": [ {
                "qas": [ {
                    "question": "In what country is Normandy located?",
                    "id": "56ddde6b9a695914005b9628",
                    "answers": [ {"text": "France", "answer_start": 159} ],
                    "is_impossible": false
                    }],
                    "question": "When did the Frankish identity emerge?",
                    "id": "5ad39d53604f3c001a3fe8d4",
                    "answers": [],
                    "is_impossible": true
                    }],
                "context": "The Normans (Norman: Nourmands; French: Normands;"
    '''
    data = []
    tot_squad, skip_num = 0, 0
    number_long, number_short = 0, 0

    with open_all(input_file) as input:
        for line in input:
            dstc = json.loads(line)
            if dstc['task_type'][0] == 0:
                continue

            # this is a span prediction instance
            (_, _, s_name, slot_name, slot_raw_value) = dstc['aux'].split("|")
            paragraphs = []
            answer = dstc['answer_tok']
            context = dstc["context_tok"]
            is_impossible = answer in ["None", "dontcare"]
            answer_state = "span"
            if answer == "None":
                answer_state = "none"
            if answer == "dontcare":
                answer_state = "dontcare"
            slot_type = dstc['slot_type']

            if (not positive and slot_type == "number" and answer in context):
                number_long += 1

            if (not positive and answer not in context and
                    slot_type == "number"):
                # we need to change the answer
                # "answer_tok": "two bedrooms",
                # the number is less than 10 for non-year type
                short_answer = answer.split(" ")[0]
                if short_answer in context:
                    logging.info("Cannot find {}, use short {}".format(
                        answer, short_answer))
                    answer = short_answer
                    number_short += 1

            if positive:
                if (answer == "True" and
                        slot_type in ["noncategorical", "number", "boolean"]):
                    # only output positive ones
                    answers = []
                    answer_type = ("Active" if slot_raw_value not in PREDICT
                                   else slot_raw_value)
                    is_impossible = answer_type in PREDICT
                    question, svs = dstc['question_tok'].split("VALUE :", 1)
                    question_orig, question_trans = extract_orig_and_trans_description(
                        question)
                    svs = svs.split(",")
                    slot_values = []
                    for sv in svs:
                        slot_values.append(" ".join(sv.strip().split()))
                    # slot raw value to english
                    atl_cands = []
                    if slot_raw_value.strip().isnumeric():
                        eng = int_to_english(int(slot_raw_value))
                        if eng is not None:
                            atl_cands = eng
                        atl_cands.append(slot_raw_value)
                    tot_squad += 1
                    find = True
                    if not is_impossible:
                        if slot_raw_value in ["True", "False"]:
                            answers = find_all(context, slot_raw_value)
                        else:
                            # check slot values first
                            for slot_value in slot_values:
                                lsv = slot_value.replace("star rating", "star")
                                if lsv.lower() in context.lower():
                                    answers = find_all(context, lsv)
                                    break
                            # check raw slot values
                            if len(answers) == 0:
                                for sv in atl_cands:
                                    if sv.lower() in context.lower():
                                        answers = find_all(context, sv)
                            # skip
                            if len(answers) == 0:
                                tot_squad -= 1
                                skip_num += 1
                                logging.info(
                                    "Cannot find '{}', '{}' for {} in {}"
                                    .format(slot_raw_value,
                                            "'".join(slot_values), dstc['aux'],
                                            context))
                                find = False

                    if find:
                        qas = [{
                            "question": question_orig if orig else question,
                            "question_orig": question_orig,
                            "question_trans": question_trans,
                            "id": dstc['aux'],
                            "is_impossible": is_impossible,
                            "answer_type": answer_type,
                            "answer_state": answer_state,
                            "answers": answers
                        }]
                        paragraphs.append({"context": context, "qas": qas})
                        squad = {
                            "title": "{}|{}".format(s_name, slot_name),
                            "paragraphs": paragraphs
                        }
                        data.append(squad)

            elif is_impossible or answer in context:
                tot_squad += 1
                answers = []

                if not is_impossible:
                    answers = find_all(context, answer)
                question_orig, question_trans = \
                    extract_orig_and_trans_description(dstc["question_tok"])
                qas = [{
                    "question": question_orig if orig else dstc["question_tok"],
                    "question_orig": question_orig,
                    "question_trans": question_trans,
                    "id": dstc['aux'],
                    "is_impossible": is_impossible,
                    "answer_state": answer_state,
                    "answers": answers
                }]

                paragraphs.append({"context": context, "qas": qas})

                squad = {
                    "title": "{}|{}".format(s_name, slot_name),
                    "paragraphs": paragraphs
                }
                data.append(squad)
            else:
                skip_num += 1
                logging.info("Cannot find {} in context: {} ".format(
                    answer, context))

    logging.info("Total number of instances: {}, skipped {}".format(
        tot_squad, skip_num))
    logging.info(
        "{} number with quantifier, {} use short number without any quantifiers"
        .format(number_long, number_short))

    logging.info("Saving instances to {}".format(output_file))

    with open(output_file, "w") as output:
        output.write(
            json.dumps({
                "data": data,
                "version": "2.0"
            }, indent=2) + '\n')


@click.command()
@click.option(
    "--train_schema_file",
    default=".data/dstc8-schema-guided-dialogue/train/schema.json",
    help="service schema for train set")
@click.option(
    "--dev_schema_file",
    default=".data/dstc8-schema-guided-dialogue/dev/schema.json",
    help="service schema for dev set")
@click.option(
    "--input_dstc_dir",
    default=".data/merge/pretrained_dev_30",
    help="input dialog states")
@click.option(
    "--output_dstc_dir",
    default=".data/merge/pretrained_dev_3_postrules",
    help="output dialog states")
@click.option(
    "--eval_type", default="all", help="evaluation type all/single/multi")
@click.option("--eval_set", default="dev", help="evaluation set dev/test")
@click.option(
    "--dstc_path",
    default=".data/dstc8-schema-guided-dialogue",
    help="original DSTC files")
@click.option(
    "--output_metric_file",
    default=".data/merge/spandev-postrules-result.json",
    help="output metric file")
def post_process(train_schema_file, dev_schema_file, input_dstc_dir,
                 output_dstc_dir, eval_type, eval_set, dstc_path,
                 output_metric_file):
    try:
        os.makedirs(output_dstc_dir)
    except:
        pass
    recovered_dont_care, _ = postprocess(train_schema_file, dev_schema_file,
                                         input_dstc_dir, output_dstc_dir)
    metrics = get_dstc_metrics(
        eval_type=eval_type,
        eval_set=eval_set,
        output_metric_file=output_metric_file,
        prediction_dir=output_dstc_dir,
        dstc8_data_dir=dstc_path,
        reconstruct_paths=False)
    logging.info(pp.pformat(metrics))
    logging.info("Recovered dontcare: {}".format(recovered_dont_care))


@click.command()
@click.option(
    "--input_file",
    default=".data/dstcslotall_final_cat/train.jsonl.gz",
    help="input")
@click.option(
    "--output_file",
    default=".data/dstcslotall_final_cat/feature.json",
    help="output")
def gen_features(input_file, output_file):
    with open_all(input_file) as f:
        feats = defaultdict(int)
        for _, line in enumerate(f):
            dstc = json.loads(line)
            for k, v in dstc["features"].items():
                feats[(k, v)] += 1

        sorted_feats = sorted([(k, ct) for (k, ct) in feats.items()],
                              key=lambda x: x[1],
                              reverse=True)
        logging.info("Total number of features: {}".format(len(sorted_feats)))
        feats_id_ct = {}
        for idx, ((k, v), ct) in enumerate(sorted_feats):
            feats_id_ct["{}#{}".format(k, v)] = [idx, ct]
        with open(output_file, 'w') as output:
            json.dump(feats_id_ct, output, indent=2)


@click.command()
@click.option(
    "--input_file",
    default=".data/dstcslotall_norm_phone_num_cat/train.jsonl",
    help="input")
@click.option(
    "--output_file",
    default=".data/dstcslotall_norm_phone_num_cat/train.jsonl.fix",
    help="output")
def fix_categorical_data(input_file, output_file):
    with open(input_file) as f:
        with open(output_file, 'w') as output:
            for _, line in enumerate(f):
                dstc = json.loads(line)
                answer_binary = dstc["answer_binary"]
                ans = "True" if answer_binary else "False"
                dstc["answer_tok"] = ans
                dstc["answer"] = ans
                output.write(json.dumps(dstc) + "\n")


@click.command()
@click.option(
    "--paraphrase_file",
    multiple=True,
    default=[
        ".data/ppdb/ppdb-2.0-xxl-lexical.gz",
    ],
    help="paraphrase file")
@click.option(
    '--schema_file',
    default=".data/dstc/data/all_pos_norm_phone/dev/schema.json",
    help="schema file")
@click.option(
    '--para_schema_file',
    default=".data/dstc/data/all_pos_norm_phone/dev/schema_para.json",
    help="schema paraphrase file")
def read_paraphrase_dict(paraphrase_file, schema_file, para_schema_file):
    paraphrases = defaultdict(list)
    # {source: [(prob, value)]}
    for psf in paraphrase_file:
        with gzip.open(psf) as input:
            for line in input:
                _, source, target, scores, _, _ = line.decode(
                    'utf8').strip().split(" ||| ")
                source = source.strip()
                target = target.strip()
                ppdb2score = float(
                    scores.split(" PPDB1.0", 1)[0].split("=", 1)[1])
                paraphrases[source].append((ppdb2score, target))
    tot_cands = 0
    for k, v in paraphrases.items():
        sv = sorted(v, key=lambda x: x[0], reverse=True)
        sv = [x for x in sv if x[0] > 3.0]
        paraphrases[k] = sv[:15]
        tot_cands += len(sv)
    logging.info("Total number of paraphrases {}".format(len(paraphrases)))
    logging.info("Total cands {}".format(tot_cands))

    if "film" in paraphrases:
        logging.info("Film paraphrases: {}".format(paraphrases["film"]))

    with open(schema_file) as example_file:
        with open(para_schema_file, 'w') as output_file:
            logging.info("Loading schema from {}".format(schema_file))
            entry = json.load(example_file)
            for schema_frame in entry:
                for slot in schema_frame["slots"]:
                    if not slot["is_categorical"]:
                        continue

                    for idx, value in enumerate(slot["possible_values"]):
                        if value.isnumeric():
                            continue  # skip numeric values e.g. 1, 2, 3
                        low_value = value.lower()
                        if low_value in paraphrases:
                            trans = [
                                x
                                for x in slot["possible_values_bak_trans"][idx]
                            ]
                            paras = paraphrases[low_value]
                            for (_, v) in paras:
                                trans.append(v)
                            slot["possible_values_bak_trans"][idx] = list(
                                set(trans))
                        else:
                            logging.info("Cannot find paraphrases '{}'".format(
                                low_value))

            json.dump(entry, output_file, indent=2)


@click.command()
@click.option(
    "--input_file",
    default="merge/roberta/roberta_norm_pretrained.nbest.json.gz",
    help="input")
@click.option('--dstc_path', default=".data/dstc/data/all/dev", help="ref path")
def result_ana(input_file, dstc_path):
    results = defaultdict(lambda: defaultdict(list))
    # {(dialog_id, turn_id, service_name): {slot_name: [(prob, value)]}}
    with gzip.open(input_file) as input:
        squad = json.load(input)
        for aux, res in squad.items():
            d_id, t_id, s_name, slot_name, _ = aux.split("|")
            best_res = res[0]
            text = best_res["text"] if best_res["text"] not in [
                'empty', 'none', 'None'
            ] else ''
            text = dstc_detok(text, slot_name=slot_name)
            prob = best_res["probability"]
            results[(d_id, t_id, s_name)][slot_name].append((prob, text))

    for _, _, files in os.walk(dstc_path):
        for f in files:
            if 'dialogues_0' not in f and 'dialogues_1' not in f:
                continue
            logging.info("Loading file {}".format(f))
            with open(os.path.join(dstc_path, f)) as example_file:
                entry = json.load(example_file)
                for dialogue in entry:
                    dialogue_id = dialogue["dialogue_id"]
                    turns = dialogue['turns']
                    for turn_id, t in enumerate(turns):
                        if t["speaker"] == "USER":
                            for frame in t["frames"]:
                                service_name = frame["service"]
                                state = frame["state"]
                                slot_values = state["slot_values"]

                                key = (dialogue_id, str(turn_id), service_name)
                                sys_slot_values = results.get(key, {})

                                for n, pv in sys_slot_values.items():
                                    p, v = pv[0]
                                    ref_slot_vales = slot_values.get(n, [""])
                                    if v not in ref_slot_vales:
                                        logging.info(
                                            "aux: {} res: '{}' ref: '{}' prob: {}"
                                            .format(
                                                "|".join([
                                                    dialogue_id,
                                                    str(turn_id), service_name,
                                                    n
                                                ]), v,
                                                "', '".join(ref_slot_vales), p))


@click.command()
@click.option(
    "--input_file",
    default="transformer_models/xnli_final_cat_roberta/pred_results.txt",
    help="prediction output")
@click.option(
    "--ref_file",
    default=".data/dstcslotall_final_cat/val.jsonl",
    help="reference")
@click.option(
    "--slot_type",
    default="categorical",
    help="slot type: noncategorical, number, boolean, categorical")
@click.option("--system", default="roberta", help="system: decanlp, roberta")
def compute_f1(input_file, ref_file, slot_type, system):
    '''
    input_file: 
      decnlp:
        Aux: 9_00000|0|Banks_2|recipient_name| Task_type: tensor([1, 0, 0]) 
        Four_way_res: tensor([-2.3068, -9.9429, -5.3456,  4.6653]) 
        Binary_res: tensor([-0.5684,  1.9268]) Generation_res: none
      roberta:
        9_00000|0|Events_1|number_of_seats|1	False	5.534853935241699
    ref_file:
        {"context": "ade", "answer": "None", "context_tok": "UsQ", 
        "answer_tok": "None", "answer_type": 2, "answer_four_way": 0, 
        "answer_binary": 0, "answer_span_start": 0, "answer_span_end": 0, 
        "task_type": [1, 0, 0], "slot_type": "noncategorical", 
        "aux": "9_00000|0|Banks_2|recipient_name|"}
    '''
    ref_, res_ = {}, {}
    tot_ext = 0
    logger.info(f"{input_file}, {ref_file}")
    tot_num_ref, tot_hasans_ref, tot_noans_ref, = 0, 0, 0
    assert system in ["decanlp", "roberta"], "--system: decanlp or roberta"

    logging.info("Reading reference from {}".format(ref_file))

    # categorical slots
    cat_ref_ = {}
    cat_res_ = defaultdict(list)

    with open_all(ref_file) as ref:
        for _, line in enumerate(ref):
            dstc = json.loads(line)

            if slot_type in ["noncategorical", "number"]:
                # make lower() optional
                ans = dstc['answer_tok'].strip().lower()
            elif slot_type in ["boolean"]:
                ans = MAP_FOUR_WAY[dstc['answer_four_way']]
            elif slot_type in ["categorical"]:
                ans = NONE_MAP_BINARY[dstc['answer_binary']]
                if ans == "True":
                    cat_slot, cat_ans = dstc['aux'].rsplit('|', 1)
                    cat_ref_[cat_slot] = cat_ans.lower()
            else:
                assert False, "NOT defined slot_type {}".format(slot_type)

            ref_[dstc['aux']] = ans
            tot_num_ref += 1
            if ans not in ["none", "None"]:
                tot_hasans_ref += 1
            else:
                tot_noans_ref += 1

    def get_max_score_idx(scores):
        # tensor([ -3.2042, -44.0950, -28.2944,  -0.1166])
        scores = eval(tmp_res.split('(', 1)[1].split(")", 1)[0])
        max_score = scores[0]
        max_id = 0
        for idx, score in enumerate(scores):
            if score > max_score:
                max_id = idx
                max_score = score
        return max_id

    tot_num_res, tot_hasans_res, tot_noans_res = 0, 0, 0
    tot_hasans_res_ext, tot_noans_res_ext = 0, 0
    logging.info("Reading prediction from {}".format(input_file))
    with open(input_file) as input:
        for _, line in enumerate(input):

            if system == "decanlp":
                aux = line.split("Task_type:", 1)[0].split("Aux:", 1)[1].strip()
                if slot_type in ["noncategorical", "number"]:
                    pred = line.rsplit("Generation_res:", 1)[1].strip().lower()
                elif slot_type in ["boolean"]:
                    tmp_res = line.split("Four_way_res: ",
                                         1)[1].split("Binary_res: ", 1)[0]
                    max_id = get_max_score_idx(tmp_res)
                    pred = MAP_FOUR_WAY[max_id]
                elif slot_type in ["categorical"]:
                    tmp_res = line.split("Binary_res: ",
                                         1)[1].split("Generation_res: ", 1)[0]
                    max_id = get_max_score_idx(tmp_res)
                    pred = NONE_MAP_BINARY[max_id]
                else:
                    logging.error("NOT defined slot_type {}".format(slot_type))
                    assert False
            else:
                if slot_type in ["noncategorical", "number"]:
                    assert False, "NOT IMPLEMENTED!"
                elif slot_type in ["boolean"]:
                    aux, pred, score = line.strip().split("\t")
                elif slot_type in ["categorical"]:
                    aux, pred, score = line.strip().split("\t")
                    cat_slot, cat_ans = aux.rsplit("|", 1)
                    true_score = eval(score)[0]
                    cat_res_[cat_slot].append((true_score, cat_ans.lower()))
                    # change False to None as no answer type
                    if pred == "False":
                        pred = "None"
                else:
                    logging.error("NOT defined slot_type {}".format(slot_type))
                    assert False

            res_[aux] = pred
            tot_num_res += 1
            if pred == ref_[aux]:
                tot_ext += 1
            if pred not in ["none", "None"]:
                tot_hasans_res += 1
                if pred == ref_[aux]:
                    tot_hasans_res_ext += 1
            else:
                tot_noans_res += 1
                if pred == ref_[aux]:
                    tot_noans_res_ext += 1

    # Compute categorical type F1 with cat_ref_, cat_res_
    tot_cat_hasans_ref, tot_cat_hasans_res = 0, 0
    tot_cat_hasans_ref_ext, tot_cat_hasans_res_ext = 0, 0
    tot_cat_ext = 0
    for k, v in cat_res_.items():
        sort_sv = sorted(v, key=lambda x: x[0], reverse=True)
        max_v = sort_sv[0][1]
        ref_v = cat_ref_[k] if k in cat_ref_ else "dontcare"
        if ref_v == max_v:
            tot_cat_ext += 1
        if max_v != 'none':
            tot_cat_hasans_res += 1
            if ref_v == max_v:
                tot_cat_hasans_res_ext += 1
        if ref_v != 'none':
            tot_cat_hasans_ref += 1
            if ref_v == max_v:
                tot_cat_hasans_ref_ext += 1
    cat_acc = (float(tot_cat_ext) / len(cat_ref_)) if len(cat_ref_) > 0 else 0
    cat_hasans_rec = ((float(tot_cat_hasans_ref_ext) /
                       tot_cat_hasans_ref) if tot_cat_hasans_ref > 0 else 0)
    cat_hasans_acc = ((float(tot_cat_hasans_res_ext) /
                       tot_cat_hasans_res) if tot_cat_hasans_res > 0 else 0)

    cat_hasans_f1 = (2 * cat_hasans_acc * cat_hasans_rec /
                     (cat_hasans_rec + cat_hasans_acc) if
                     (cat_hasans_acc + cat_hasans_rec) > 0 else 0)

    hasans_res_acc = (
        float(tot_hasans_res_ext) / tot_hasans_res if tot_hasans_res > 0 else 0)
    noans_res_acc = (
        float(tot_noans_res_ext) / tot_noans_res if tot_noans_res > 0 else 0)

    assert tot_num_ref == tot_num_res

    tot_f1_num, tot_f1_ext = 0, 0
    tot_hasans_ref_ext, tot_noans_ref_ext = 0, 0
    for k, v in ref_.items():
        r = res_[k]
        if len(v) > 0 or len(r) > 0:
            tot_f1_num += 1
            if r == v:
                tot_f1_ext += 1
        if r not in ["none", "None"]:
            if r == v:
                tot_hasans_ref_ext += 1
        else:
            if r == v:
                tot_noans_ref_ext += 1

    hasans_ref_rec = (
        float(tot_hasans_ref_ext) / tot_hasans_ref if tot_hasans_ref > 0 else 0)
    noans_ref_rec = (
        float(tot_noans_ref_ext) / tot_noans_ref if tot_noans_ref > 0 else 0)

    hasans_f1 = (2 * hasans_res_acc * hasans_ref_rec /
                 (hasans_res_acc + hasans_ref_rec) if
                 (hasans_res_acc + hasans_ref_rec) > 0 else 0)

    noans_f1 = (2 * noans_res_acc * noans_ref_rec /
                (noans_res_acc + noans_ref_rec) if
                (noans_res_acc + noans_ref_rec) > 0 else 0)

    eval_result = {
        "exact": 100 * float(tot_ext) / tot_num_ref if tot_num_ref > 0 else 0,
        "f1": 100 * float(tot_f1_ext) / tot_f1_num if tot_f1_num > 0 else 0,
        "total": tot_num_ref,
        'HasAns_exact': 100 * hasans_ref_rec,
        'HasAns_f1': 100 * hasans_f1,
        'HasAns_total_ref': tot_hasans_ref,
        'HasAns_total_res': tot_hasans_res,
        'NoAns_exact': 100 * noans_ref_rec,
        'NoAns_f1': 100 * noans_f1,
        'NoAns_total_ref': tot_num_ref - tot_hasans_ref,
        'NoAns_total_res': tot_num_res - tot_hasans_res,
        "Cat_acc": 100 * cat_acc,
        "Cat_hasAns_f1": 100 * cat_hasans_f1,
        "Cat_hasAns_acc": 100 * cat_hasans_acc,
        "Cat_hasAns_rec": 100 * cat_hasans_rec,
        "Cat_hasAns_ref_num": tot_cat_hasans_ref,
        "Cat_hasAns_res_num": tot_cat_hasans_res,
    }

    click.echo(eval_result)


def read_dialog_schema(dstc8_data_dir):
    service_dict = {}
    len_dict = {}
    for f in os.listdir(dstc8_data_dir):
        if 'dialogues' in f and 'metrics' not in f:
            with open(os.path.join(dstc8_data_dir, f)) as example_file:
                data = json.load(example_file)
                for datum in data:
                    service_dict[datum["dialogue_id"]] = datum["services"]
                    len_dict[datum["dialogue_id"]] = len(datum["turns"])
    return service_dict, len_dict


def merge_slots_in_history(collection, service_dict, len_dict, schema_dict):
    """
    Merge all slot values in history, currently results are negative on MRC

    collection: MRC results collection[dialogue_id, turn_id, service_name][slot_name] = [value]
    service_dict: dialogue_id -> List[services]
    len_dict: dialogue_id -> turn length
    schema_dict: service -> slots
    """
    extracted = {}
    for dialogue_id, turn_id, service_name in collection:
        if service_name in service_dict[dialogue_id]:
            if dialogue_id not in extracted:
                extracted[dialogue_id] = OrderedDict()
            if turn_id not in extracted[dialogue_id]:
                extracted[dialogue_id][turn_id] = {}
            if service_name not in extracted[dialogue_id][turn_id]:
                extracted[dialogue_id][turn_id][service_name] = {}
            for slot_name in collection[(dialogue_id, turn_id, service_name)]:
                extracted[dialogue_id][turn_id][service_name][slot_name] = \
                    collection[(dialogue_id, turn_id, service_name)][slot_name]

    for dialogue_id in extracted:
        for turn_id in range(len_dict[dialogue_id]):
            for service_name in service_dict[dialogue_id]:
                if turn_id not in extracted[dialogue_id]:
                    extracted[dialogue_id][turn_id] = {}
                if turn_id > 0:
                    logger.debug("{} {} extracted before: {}".format(
                        dialogue_id, turn_id, extracted[dialogue_id][turn_id]))
                    if service_name not in extracted[dialogue_id][turn_id] and \
                            service_name in extracted[dialogue_id][turn_id-1]:
                        logger.debug("extracted: {}".format(
                            extracted[dialogue_id][turn_id - 1][service_name]))
                        extracted[dialogue_id][turn_id][service_name] = {
                            k:
                            extracted[dialogue_id][turn_id - 1][service_name][k]
                            for k in extracted[dialogue_id][turn_id -
                                                            1][service_name]
                        }
                    if service_name in extracted[dialogue_id][turn_id]:
                        if service_name not in extracted[dialogue_id][turn_id -
                                                                      1]:
                            continue
                        for slot in schema_dict[service_name]["slots"]:
                            if slot["is_categorical"]:
                                continue
                            slot_name = slot["name"]
                            # merge value of the previous turn if possible
                            if slot_name in extracted[dialogue_id][turn_id-1][service_name] and \
                                    extracted[dialogue_id][turn_id-1][service_name][slot_name]:
                                if slot_name not in extracted[dialogue_id][
                                        turn_id][service_name]:
                                    extracted[dialogue_id][turn_id][
                                        service_name][slot_name] = [
                                            v for v in extracted[dialogue_id]
                                            [turn_id -
                                             1][service_name][slot_name]
                                        ]
                                else:
                                    for v in extracted[dialogue_id][
                                            turn_id -
                                            1][service_name][slot_name]:
                                        if v not in extracted[dialogue_id][
                                                turn_id][service_name][
                                                    slot_name]:
                                            extracted[dialogue_id][turn_id][
                                                service_name][slot_name].append(
                                                    v)
                    logger.debug("{} {} extracted after: {}".format(
                        dialogue_id, turn_id, extracted[dialogue_id][turn_id]))

    result = {}
    for dialogue_id in extracted:
        for turn_id in extracted[dialogue_id]:
            for service_name in extracted[dialogue_id][turn_id]:
                result[(dialogue_id, turn_id, service_name
                       )] = extracted[dialogue_id][turn_id][service_name]

    return result


@click.command()
@click.option(
    "--squad_input_file",
    default="dstc8-squad-norm/train-norm-20.json",
    help="squad input file")
@click.option(
    "--squad_output_file",
    default="dstc8-squad-norm/train-norm-20.dropout0.3.json",
    help="squad output file after dropout")
@click.option("--dropout_prob", default=0.3, help="dropout probability")
@click.option("--dropout_token", default="<blank>", help="dropout token")
def dropout_squad_input(squad_input_file, squad_output_file, dropout_prob,
                        dropout_token):
    with open(squad_input_file) as input_:
        data = json.load(input_)
        for item in tqdm(data["data"]):
            for paragraph in item["paragraphs"]:
                for qa in paragraph["qas"]:
                    question = qa["question"]
                    question_toks = question.split()
                    dropout_count = int(len(question_toks) * dropout_prob)
                    indices = list(range(len(question_toks)))
                    random.shuffle(indices)
                    dropout_indices = indices[:dropout_count]
                    for index in dropout_indices:
                        question_toks[index] = dropout_token
                    qa["question"] = " ".join(question_toks)
    with open(squad_output_file, "w") as output:
        json.dump(data, output, indent=2)


@click.command()
@click.option(
    "--cat_file_name",
    default="dstc-xnli/xnli/xnli.train.cat.jsonl",
    help="cat xnli input data")
@click.option(
    "--num_file_name",
    default="dstc-xnli/xnli.train.number.jsonl",
    help="squad prediction gzip file: num")
@click.option(
    "--bool_file_name",
    default="dstc-xnli/xnli/xnli.train.bool.jsonl",
    help="boolean slots tab separated prediction file")
@click.option(
    "--output_file_name",
    default="dstc8-squad/train.cat-squad.json.gz",
    help="combined data in json format")
def xnli_to_squad(cat_file_name, num_file_name, bool_file_name,
                  output_file_name):
    """
    Convert XNLI input to squad format

    Input XNLI format:
    {"annotator_labels": ["False", "False", "False", "False", "False"], "genre": "dstc", "gold_label": "False", "language": "en", "match
": "True", "pairID": "94_00000|2|Buses_2|fare_type|Economy extra", "promptID": "94_00000|2|Buses_2|fare_type|Economy extra", "senten
ce1": "User : I am looking for tickets on a bus to San Francisco. System : How many tickets? Do you know when you'd like to leave? U
ser : This is for 4 people. We want to leave on the 11th of March at 10:15 in the morning.", "sentence1_tokenized": "User : I am loo
king for tickets on a bus to San Francisco . System : How many tickets ? Do you know when you 'd like to leave ? User : This is for
4 people . We want to leave on the 11th of March at 10:15 in the morning .", "sentence2": "Find a bus to take you to the city you wa
nt: Type of fare for the booking , Type of fare booked  is Economy extra , Economic extra", "sentence2_tokenized": "Find a bus to ta
ke you to the city you want : Type of fare for the booking , Type of fare booked  is Economy extra , Economic extra"}
    Output SQUAD format:
    {
  "data": [
    {
      "title": "Dialog state: dialogues_001.json",
      "paragraphs": [
        {
          "context": "USER: I want to make a restaurant reservation for 2 people at half past 11 in the morning. ",
          "qas": [
            {
              "question": "Name of the restaurant",
              "is_impossible": true,
              "answers": [],
              "id": "dialogues_001.json_1_00000_0_Restaurants_2_slot_restaurant_name"
            }
          ]
        }
     }]
     }
    """

    def _split_question(question):
        logger.debug(question)
        sys_and_slots, values = question.split("  is ")
        service_desc, slots = sys_and_slots.split(" : ")
        ques_orig, ques_trans = slots.split(" , ", maxsplit=1)
        try:
            value_orig, value_trans = values.split(" , ", maxsplit=1)
        except:
            value_orig, value_trans = values, values
        return service_desc.strip(), ques_orig.strip(), ques_trans.strip(
        ), value_orig.strip(), value_trans.strip()

    def _xnli_cat_to_squad_data(cat_file_name, is_bool=False):
        cat_data = []
        all_labels = set()
        logger.info("Processing: {}".format(cat_file_name))
        with open(cat_file_name) as cat_file:
            for line in tqdm(cat_file):
                cat_datum = json.loads(line)
                logger.debug("{}".format(cat_datum))
                context = cat_datum["sentence1_tokenized"]
                enriched_question = cat_datum["sentence2_tokenized"]
                qid = cat_datum["pairID"]
                if is_bool:
                    question = enriched_question.rsplit(" , ", maxsplit=1)[0]
                else:
                    service_desc, ques_orig, ques_trans, value_orig, value_trans = _split_question(
                        enriched_question)
                    question = service_desc + " : " + ques_orig + " is " + value_orig
                class_label = cat_datum["gold_label"]
                all_labels.add(class_label)
                if is_bool:
                    qas = []
                    for label in ["True", "False", "None"]:
                        qa = {
                            "question":
                                question + " is {}".format(label.lower()),
                            # mask based on is_impossible
                            "is_impossible":
                                True,
                            "answers": [],
                            "id":
                                qid + label,
                            # class prediction based on class label
                            "class_label":
                                str(class_label == label)
                        }
                        qas.append(qa)
                else:
                    qas = [{
                        "question": question,
                        # mask based on is_impossible
                        "is_impossible": True,
                        "answers": [],
                        "id": qid,
                        # class prediction based on class label
                        "class_label": class_label
                    }]
                datum = {
                    "title": qid,
                    "paragraphs": [{
                        "context": context,
                        "qas": qas
                    }]
                }
                cat_data.append(datum)
        logger.info("File: {}\tInstances: {}\tLabels: {}".format(
            cat_file_name, len(cat_data), all_labels))
        return cat_data

    data = []
    data.extend(_xnli_cat_to_squad_data(cat_file_name))
    data.extend(_xnli_cat_to_squad_data(num_file_name))
    data.extend(_xnli_cat_to_squad_data(bool_file_name, is_bool=True))
    logger.info("Writing {}".format(output_file_name))
    with open_all(output_file_name, "wt") as output:
        json.dump({"data": data}, output, indent=2)


@click.command()
@click.option(
    "--input_file",
    default=".data/merge/pretrained_dev_3_postrules/dialogues_and_metrics.json.incorrect.json",
    help="json of hyp/ref pairs")
def top_errors(input_file):
    with open(input_file) as f:
        data = json.load(f)
    stats_val = {"fn": {}, "fp": {}, "incorrect": {}}
    stats_key = {"fn": {}, "fp": {}, "incorrect": {}}
    for datum in data:
        hyp = datum["hyp"]
        ref = datum["ref"]
        for k in hyp:
            v = ref[k][0] if k in ref else hyp[k][0]
            field = "incorrect" if k in ref else "fp"
            stats_val[field][v] = stats_val[field].setdefault(v, 0) + 1
            stats_key[field][k] = stats_key[field].setdefault(k, 0) + 1
        for k in ref:
            if k not in hyp:
                stats_val["fn"][v] = stats_val["fn"].setdefault(v, 0) + 1
                stats_key["fn"][k] = stats_key["fn"].setdefault(k, 0) + 1
    logger.info("Key False Positive")
    logger.info("\n{}".format(
        sorted([x for x in stats_key["fp"].items()], key=lambda x: -x[1])))
    logger.info("Key False Negative")
    logger.info("\n{}".format(
        sorted([x for x in stats_key["fn"].items()], key=lambda x: -x[1])))
    logger.info("Key Incorrect")
    logger.info("\n{}".format(
        sorted([x for x in stats_key["incorrect"].items()],
               key=lambda x: -x[1])))
    logger.info("Value False Positive")
    logger.info("\n{}".format(
        sorted([x for x in stats_val["fp"].items()], key=lambda x: -x[1])))
    logger.info("Value False Negative")
    logger.info("\n{}".format(
        sorted([x for x in stats_val["fn"].items()], key=lambda x: -x[1])))
    logger.info("Value Incorrect")
    logger.info("\n{}".format(
        sorted([x for x in stats_val["incorrect"].items()],
               key=lambda x: -x[1])))


if __name__ == "__main__":
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    cli.add_command(build_examples)
    cli.add_command(merge_slots)
    cli.add_command(down_sample)
    cli.add_command(build_generation_examples)
    cli.add_command(convert_seq_to_pred)
    cli.add_command(dstc_to_squad)
    cli.add_command(merge_slot_spans)
    cli.add_command(post_process)
    cli.add_command(reranker)
    cli.add_command(dstc_to_xnli)
    cli.add_command(compute_f1)
    cli.add_command(fix_categorical_data)
    cli.add_command(merge_pretrained)
    cli.add_command(gen_features)
    cli.add_command(result_ana)
    cli.add_command(read_paraphrase_dict)
    cli.add_command(dropout_squad_input)
    cli.add_command(xnli_to_squad)
    cli.add_command(top_errors)
    cli.add_command(validate)
    cli.add_command(merge_pretrained_mwoz)
    cli()
