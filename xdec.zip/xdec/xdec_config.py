import logging
import gzip


def get_logger(name):
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO,
    )
    return logging.getLogger(name)


def open_all(file_name, mode="rb"):
    is_gz = file_name.endswith(".gz")
    open_all = "gzip.open" if is_gz else "open"
    return eval(open_all)(file_name, mode=mode)


def is_english(s):
    try:
        s.encode(encoding='utf-8').decode('ascii')
    except:
        return False
    else:
        return True
