import os
import re
import sys
import json
import click
from wikisql.processors import WikiSQL, Query
from xdec_config import get_logger, is_english
from fuzzywuzzy import fuzz
from fuzzysearch import find_near_matches
from s2s_ft.utils import detokenize
from wikisql.dianli_processors import DIANLI_SQL_KEYWORD_MAP, process_dianli2, process_dianli3, process_gold, process_dianli5
from wikisql.zhuiyi_processors import SQL, read_tables, read_data
from wikisql.grammar import rule_extraction3

logger = get_logger(__name__)


@click.group()
def cli():
    pass


@click.command()
@click.option(
    "--dir_name",
    default=".data/WikiSQL/data/train.jsonl",
    help="location of the wikisql files")
@click.option(
    "--noneq_context_file",
    default=".data/WikiSQL/contexts.json",
    help="context stats for non equal conds")
def process(dir_name, noneq_context_file):
    wikisql = WikiSQL(dir_name)
    wikisql.dump_noneq_context(noneq_context_file)


@click.command()
@click.option(
    "--input_file_name",
    default=".data/WikiSQL/data/train.jsonl",
    help="location of the wikisql files")
@click.option(
    "--output_file_name",
    default=".data/WikiSQL/seq2seq_ac/train.ac.jsonl",
    help="context stats for non equal conds")
@click.option("--text/--no_text", default=False, help="output text file")
@click.option(
    "--all_columns/--no_all_columns",
    default=False,
    help="use all columns in target")
def dump_s2s(input_file_name, output_file_name, text, all_columns):
    logger.info("text: {}".format(text))
    dir_name = os.path.dirname(output_file_name)
    try:
        os.makedirs(dir_name)
    except:
        logger.warning("Dir already exists: {}".format(dir_name))
    WikiSQL.dump_pairs(
        input_file_name, output_file_name, text=text, all_columns=all_columns)


@click.command()
@click.option(
    "--gold_file_name",
    default=".data/WikiSQL/seq2seq/dev.txt",
    help="gold file")
@click.option(
    "--pred_file_name",
    default=".data/WikiSQL/seq2seq/dev.duplicate.txt",
    help="prediction file")
def str_eval(gold_file_name, pred_file_name):
    sep = "<endofcolumns>"
    with open(gold_file_name) as gold:
        gold = gold.readlines()
    with open(pred_file_name) as pred:
        pred = pred.readlines()
    correct = 0
    total = 0
    for g, p in zip(gold, pred):
        gs = g.split(sep)[-1].strip()
        ps = p.split(sep)[-1].strip()
        logger.debug(g)
        logger.debug(gs)
        if gs == ps:
            correct += 1
        else:
            logger.warn(f"Error - gold:{g}\tpred: {ps}")
        total += 1
    logger.info("Str Acc ({}/{}): {}".format(correct, total, correct / total))


@click.command()
@click.option(
    "--gold_file_name",
    default=".data/WikiSQL/seq2seq/dev.jsonl",
    help="gold file")
@click.option("--pred_file_name", default="", help="prediction file")
def jsonl_str_eval(gold_file_name,
                   pred_file_name,
                   remove_spaces=True,
                   lower=True):
    with open(gold_file_name) as gold:
        gold = gold.readlines()
    with open(pred_file_name) as pred:
        pred = pred.readlines()
    correct = 0
    total = 0
    for g, p in zip(gold, pred):
        gs = json.loads(g)["tgt"].strip()
        ps = p.strip()
        gs1 = re.sub(r"\s+", "", gs) if remove_spaces else gs
        ps1 = re.sub(r"\s+", "", ps) if remove_spaces else ps
        if lower:
            gs1 = gs1.lower()
            ps1 = ps1.lower()
        if gs1 == ps1:
            correct += 1
        else:
            logger.warn(f"Error - gold:{json.loads(g)}\tpred: {ps}")
        total += 1
    logger.info("Str Acc ({}/{}): {}".format(correct, total, correct / total))


def norm_zhuiyi_string(s):
    return s.replace("（", "(").replace("）",
                                       ")").replace("（",
                                                    "(").replace("）",
                                                                 ")").lower()


@click.command()
@click.option(
    "--gold_file_name", default=".data/zhuiyi/val.json", help="gold file")
@click.option(
    "--table_file_name",
    default=".data/zhuiyi/val.tables.json",
    help="gold table file")
@click.option(
    "--pred_file_name",
    default="transformer_models/zhuiyi_rbtl3_lr7e-5_ep50_b128/val.output.txt",
    help="prediction file")
def zhuiyi_eval(gold_file_name, table_file_name, pred_file_name):

    def best_in_header(header, val):
        idx = 0
        best_score = 0
        for i, h in enumerate(header):
            score = fuzz.ratio(
                norm_zhuiyi_string(val), norm_zhuiyi_string(h[0]))
            if score >= best_score:
                best_score = score
                idx = i
        return idx

    def best_in_column(table, col_id, val):
        best_val = val
        best_score = 0
        for row in table.rows:
            if isinstance(row[col_id], float) or isinstance(row[col_id], int):
                return val
            score = fuzz.ratio(
                norm_zhuiyi_string(row[col_id].lower()),
                norm_zhuiyi_string(val.lower()))
            if score > best_score:
                best_score = score
                best_val = row[col_id]
        return best_val

    tables = read_tables(table_file_name)
    gold_queries = read_data(gold_file_name, tables)
    correct = 0
    total = 0
    st_op_sql_dict = SQL.st_op_sql_dict
    st_agg_sql_dict = SQL.st_agg_sql_dict
    st_conn_sql_dict = SQL.st_conn_sql_dict
    inv_st_op_sql_dict = {st_op_sql_dict[k]: k for k in st_op_sql_dict}
    inv_st_agg_sql_dict = {st_agg_sql_dict[k]: k for k in st_agg_sql_dict}
    inv_st_conn_sql_dict = {st_conn_sql_dict[k]: k for k in st_conn_sql_dict}
    with open(pred_file_name) as pred_input:
        for i, line in enumerate(pred_input):
            line = line.replace(" ", "").strip()
            gold_sql = gold_queries[i].sql
            try:
                sel_part, where_part = line[len(SQL.st_sel[0]):].split(
                    SQL.st_where[0], maxsplit=1)
                if SQL.st_where[0] in where_part:
                    where_part = where_part[:where_part.find(SQL.st_where[0])]
            except:
                logger.error(f"Fail to parse: {line}")
                total += 1
                continue
            sel_parts = sel_part.split(SQL.st_sel_and[0])
            sel, agg = [], []
            for sel_part in sel_parts:
                agg_item, sel_item = sel_part.split(">")
                sel_idx = best_in_header(gold_queries[i].table.header, sel_item)
                if sel_idx in sel:
                    continue
                sel.append(sel_idx)
                agg_item += ">"
                agg.append(inv_st_agg_sql_dict[agg_item])
            cond_conn_op = 0
            cond_items = [where_part]
            conds = []
            if st_conn_sql_dict[1] in where_part:
                cond_items = where_part.split(st_conn_sql_dict[1])
                cond_conn_op = 1
            elif st_conn_sql_dict[2] in where_part:
                cond_items = where_part.split(st_conn_sql_dict[2])
                cond_conn_op = 2
            for cond_item in cond_items:
                for j in range(len(st_op_sql_dict)):
                    op = st_op_sql_dict[j]
                    if op in cond_item:
                        op_id = j
                        col_name, col_value = cond_item.split(op, maxsplit=1)
                        col_id = best_in_header(gold_queries[i].table.header,
                                                col_name)
                        col_val = best_in_column(gold_queries[i].table, col_id,
                                                 col_value)
                        if [col_id, op_id, col_val] not in conds:
                            conds.append([col_id, op_id, col_val])
                        break
            # less than two conditions do not need conn_op. Set to none
            if len(conds) < 2:
                cond_conn_op = 0
            pred_sql = SQL(cond_conn_op, agg, sel, conds)
            if gold_sql.equal_all_mode(pred_sql):
                correct += 1
            else:
                logger.info(f"\n[error] gold: {gold_sql.to_json()}")
                logger.info(f"[error] pred str: {line}")
                logger.info(f"[error] pred: {pred_sql.to_json()}")
                logger.info(f"[error] gold query:\n{gold_queries[i]}")
            total += 1

    logger.info(f"Accuracy: {correct}/{total} = {correct/total}")


def detok(s):
    return detokenize(s)


def recover_header(header, headers):
    max_ratio = -1
    idx = -1
    for i, cand in enumerate(headers):
        score = fuzz.ratio(header, cand)
        if score > max_ratio:
            max_ratio = score
            idx = i
    return idx


@click.command()
@click.option(
    "--query_file_name",
    default=".data/WikiSQL/data/dev.jsonl",
    help="input file")
@click.option(
    "--input_file_name",
    default="transformer_models/wikisql_unilm1.2_lr7e-5_ep5_b32/ckpt-8805/dev.output.txt",
    help="input file")
@click.option(
    "--output_file_name",
    default="transformer_models/wikisql_unilm1.2_lr7e-5_ep5_b32/ckpt-8805/dev.output.lf.jsonl",
    help="output file")
def str_to_lf(query_file_name, input_file_name, output_file_name, lower=True):
    special_tokens_inv = {
        Query.special_tokens[k]: k for k in Query.special_tokens
    }
    with open(query_file_name) as query_input, \
            open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        expanded_path = os.path.expanduser(query_file_name)
        table_path = os.path.splitext(expanded_path)
        table_path = table_path[0] + '.tables' + table_path[1]
        with open(table_path) as tables_file:
            tables = [json.loads(line) for line in tables_file]
            id_to_tables = {x['id']: x for x in tables}
        query_lines = list(query_input.readlines())
        input_lines = list(input_.readlines())
        sel_non_recover = 0
        col_val_non_recover = 0
        col_val_fuzzy_recover = 0
        op_errors = 0
        agg_errors = 0
        for query, line in zip(query_lines, input_lines):
            entry = json.loads(query)
            human_query = entry['question']
            if lower:
                human_query = human_query.lower()
            table = id_to_tables[entry['table_id']]
            header = table['header']
            if lower:
                header = [re.sub(r"\s+", "", x.lower()) for x in header]
            line = line.strip()
            line = re.sub(r">(\w)", r"> \1", line)
            # do more harm than good.
            # line = re.sub(r"(\w)<", r"\1 <", line)
            try:
                sel_section, cond_section = line.split("<fromtable>")
            except:
                sel_section = line.strip()
                cond_section = ""
                logger.warn("<fromtable> not found: {}".format(line))
            if cond_section.startswith("<where>"):
                cond_section = cond_section[len("<where>")]
            sel_toks = sel_section.split()
            agg = 0
            try:
                agg = int(special_tokens_inv[sel_toks[1]].split("_")[-1])
            except:
                logger.warning("Unable to recover agg: {}".format(sel_toks))
                agg_errors += 1
            sel_col = re.sub(r"\s+", "", "".join(sel_toks[2:]))
            sel = 0
            try:
                sel = header.index(sel_col)
            except:
                sel_non_recover += 1
                sel = recover_header(sel_col, header)
                logger.warning(
                    f"Sel not found: {line} in header {header}. Recover to: {header[sel]}"
                )
            conds = []
            cond_strs = cond_section.strip().split("<cond>")
            if cond_strs:
                cond_strs.pop(0)
            logger.debug(f"cond_strs: {cond_strs}")
            for cond_str in cond_strs:
                cond_str = cond_str.strip()
                if cond_str.endswith(" <and>"):
                    cond_str = cond_str[:-len(" <and>")]
                if "<none_val>" in cond_str:
                    continue
                logger.debug(f"{cond_str}")
                toks = cond_str.split()
                op_idx = -1
                for i, tok in enumerate(toks):
                    if tok.startswith("<cond") and tok.endswith(">"):
                        op_idx = i
                        break
                if op_idx < 0:
                    logger.warning(f"op_idx not found in: {cond_str}")
                col_name = re.sub(r"\s+", "", "".join(toks[:op_idx]))
                col_value = detok(" ".join(toks[op_idx + 1:]))
                op = 0
                try:
                    op = int(special_tokens_inv[toks[i]].split("_")[-1])
                except:
                    logger.warning(f"op error in: {cond_str}")
                    op_errors += 1
                col = 0
                try:
                    col = header[col_name]
                except:
                    col = recover_header(col_name, header)
                if col_value not in human_query:
                    col_val_non_recover += 1
                    logger.warning(
                        f"col_value of [{cond_str}] [{col_value}] not found in query: {human_query}"
                    )
                    matches = find_near_matches(
                        col_value, human_query, max_l_dist=3)
                    if matches:
                        m = matches[0].matched
                        if m.strip():
                            col_value = m.strip()
                            logger.warning(
                                f"col_value recovered to: {col_value}")
                            col_val_fuzzy_recover += 1
                conds.append([col, op, col_value])
            output.write(
                json.dumps({"query": {
                    "sel": sel,
                    "agg": agg,
                    "conds": conds
                }}) + "\n")
        logger.info(f"sel_non_recover: {sel_non_recover}")
        logger.info(f"col_val_non_recover: {col_val_non_recover}")
        logger.info(f"col_val_fuzzy_recover: {col_val_fuzzy_recover}")
        logger.info(f"op_errors: {op_errors}")
        logger.info(f"agg_errors: {agg_errors}")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/dianli/dianli-nl2sql/dataset/irnet/dev.json",
    help="input file")
@click.option(
    "--schema_file_name",
    default=".data/dianli/dianli-nl2sql/table2.json",
    help="input file")
@click.option(
    "--output_file_name",
    default=".data/dianli/dianli-nl2sql/dev.dianli.jsonl",
    help="output file")
def dianli_to_jsonl(input_file_name, schema_file_name, output_file_name):

    def _filter_between(toks):
        result = []
        in_between = False
        for tok in toks:
            if not in_between:
                if tok == "BETWEEN":
                    in_between = True
                    count = 1
                else:
                    result.append(tok)
            else:
                if count == 1:
                    count += 1
                    year, month, _ = tok.split("-")
                    if month[0] == "0":
                        month = month[1]
                    result.append("IN")
                    result.append(f"{year}年{month}月")
                elif count == 5:
                    count = 0
                    in_between = False
                else:
                    count += 1
        return result

    def _filter_duplicate_cols(toks):
        end = toks.index("FROM")
        cols = " ".join(toks[1:end]).split(",")
        col_list = []
        for col in cols:
            col = col.strip()
            if col not in col_list:
                col_list.append(col)
        return toks[0:1] + [" , ".join(col_list)] + toks[end:]

    def _find_table(toks):
        return toks[toks.index("FROM") + 1]

    def _read_schema(schema_file_name):
        table_name_map = {}
        column_name_map = {}
        with open(schema_file_name) as input_:
            schema = json.load(input_)
            table_name_map = schema["table_name_en2cn"]
            column_name_map = schema["column_name_en2cn"]
        return table_name_map, column_name_map

    def _table_and_column(table_name_map, column_name_map, table_name):
        result = "<tn>" + table_name_map[table_name]
        for column_name in column_name_map:
            if column_name.startswith(table_name + "."):
                col_name = column_name_map[column_name].split()[0].split(".")[1]
                result += "<col>" + col_name
        return result

    sql_keywords = set()
    table_name_map, column_name_map = _read_schema(schema_file_name)
    inverse_keyword_map = {
        DIANLI_SQL_KEYWORD_MAP[k]: k for k in DIANLI_SQL_KEYWORD_MAP
    }
    with open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        data = json.load(input_)
        for datum in data["samples"]:
            query = datum["query"]
            query = query.replace("(", " (").replace(")", " )").replace(
                "'", "").replace(",", " , ").replace(" and ", " AND ")
            query = re.sub(r"\s+", " ", query)
            query = re.sub(r"\sas\s\S+\s", " ", query)
            query = re.sub(r"FROM\s\S+\s", "FROM ", query)
            query_toks = query.split()
            query_toks = _filter_between(query_toks)
            query_toks = _filter_duplicate_cols(query_toks)
            query = " ".join(query_toks)
            question = "".join(datum["question"])
            # temporarily remove join
            if "JOIN" in query:
                continue
            table_name = _find_table(query_toks)
            question += _table_and_column(table_name_map, column_name_map,
                                          table_name)
            query_toks = query.split()
            for i in range(len(query_toks)):
                t = query_toks[i]
                if t in inverse_keyword_map:
                    query_toks[i] = inverse_keyword_map[t]
                if t in column_name_map:
                    query_toks[i] = column_name_map[t].split()[0].split(".")[1]
                if t in table_name_map:
                    query_toks[i] = table_name_map[t]
            query = "".join(query_toks)
            logger.info(
                f"source: {question}\tquery: {query}\ttable: {table_name}\tlen(q): {len(question)}"
            )
            output.write(
                json.dumps({
                    "src": question,
                    "tgt": query
                }, ensure_ascii=False) + "\n")
    with open(output_file_name + "speicial_tokens.json", "w") as output:
        json.dump(DIANLI_SQL_KEYWORD_MAP, output, indent=2)


@click.command()
@click.option(
    "--input_file_name",
    default=".data/dianli2/data0701.json",
    help="input file")
@click.option(
    "--output_file_name",
    default=".data/dianli2/processed.jsonl",
    help="output file")
def dianli2_to_jsonl(input_file_name, output_file_name):
    result = process_dianli2(input_file_name)
    with open(output_file_name, "w") as output:
        for datum in result:
            output.write(json.dumps(datum, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/dianli3/data0708.json",
    help="input file")
@click.option(
    "--output_file_name",
    default=".data/dianli3/processed_0727.jsonl",
    help="output file")
def dianli3_to_jsonl(input_file_name, output_file_name):
    result = process_dianli3(input_file_name)
    with open(output_file_name, "w") as output:
        for datum in result:
            output.write(json.dumps(datum, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/dianli5/dianli0825/new_train.json",
    help="input file")
@click.option(
    "--table_file_name",
    default=".data/dianli3/data0708.json",
    help="input file")
@click.option(
    "--output_file_name",
    default=".data/dianli5/processed0825.jsonl",
    help="output file")
def dianli5_to_jsonl(input_file_name, table_file_name, output_file_name):
    result = process_dianli5(input_file_name, table_file_name)
    with open(output_file_name, "w") as output:
        for datum in result:
            output.write(json.dumps(datum, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/dianli4/train_0716.json",
    help="input file")
@click.option(
    "--output_file_name",
    default=".data/dianli4/train_0716.processed.jsonl",
    help="output file")
def dianli4_to_jsonl(input_file_name, output_file_name):
    result = process_dianli3(input_file_name)
    with open(output_file_name, "w") as output:
        for datum in result:
            output.write(json.dumps(datum, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--data_file_name", default=".data/zhuiyi/train.json", help="input file")
@click.option(
    "--table_file_name",
    default=".data/zhuiyi/train.tables.json",
    help="input file")
@click.option(
    "--output_file_name",
    default=".data/zhuiyi/train.s2s.num_norm.json",
    help="output file")
def zhuiyi_to_jsonl(data_file_name, table_file_name, output_file_name):
    tables = read_tables(table_file_name)
    queries = read_data(data_file_name, tables)
    with open(output_file_name, "w") as output:
        for q in queries:
            output.write(
                json.dumps(
                    {
                        "src": norm_zhuiyi_string(q.source()),
                        "tgt": norm_zhuiyi_string(q.target())
                    },
                    ensure_ascii=False) + "\n")
    with open(output_file_name + ".special_tokens.json", "w") as output:
        st = {}
        dicts = [
            SQL.st_agg_sql_dict, SQL.st_col, SQL.st_cond, SQL.st_conn_sql_dict,
            SQL.st_op_sql_dict, SQL.st_sel, SQL.st_sel_and, SQL.st_where
        ]
        for d in dicts:
            for _, v in d.items():
                st[v] = v[1:-1].replace("_", " ")
        json.dump(st, output, indent=2)


@click.command()
@click.option(
    "--input_file_name",
    default=".data/dianli3/train_0720.jsonl",
    help="input file")
@click.option(
    "--output_file_name",
    default=".data/dianli3/train_0720.xxs.jsonl",
    help="output file")
def dianli_strip(input_file_name, output_file_name):
    with open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        for line in input_:
            datum = json.loads(line)
            datum["tgt"] = datum["tgt"][:datum["tgt"].index("<from>")]
            output.write(json.dumps(datum, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--gold_file_name",
    default=".data/dianli5/dianli_nl2sql_107.csv",
    help="input file")
@click.option(
    "--metadata_file_name",
    default=".data/dianli5/metadata.json",
    help="metadata output file")
@click.option(
    "--output_jsonl_file_name",
    default=".data/dianli5/dump.jsonl",
    help="jsonl output file")
def process_dianli_gold(gold_file_name, metadata_file_name,
                        output_jsonl_file_name):
    process_gold(gold_file_name, metadata_file_name, output_jsonl_file_name)


@click.command()
@click.option(
    "--data_file_name",
    default=".data/dianli3/data0708.json",
    help="table data file")
@click.option(
    "--country_file_name",
    default=".data/dianli_resource/countries.info.json",
    help="country file")
@click.option(
    "--input_file_name",
    default=".data/dianli5/dump.jsonl",
    help="jsonl input file")
def test_grammar(data_file_name, country_file_name, input_file_name):
    rule_extraction3(data_file_name, country_file_name, input_file_name)


if __name__ == "__main__":
    cli.add_command(process)
    cli.add_command(dump_s2s)
    cli.add_command(str_eval)
    cli.add_command(jsonl_str_eval)
    cli.add_command(str_to_lf)
    cli.add_command(dianli_to_jsonl)
    cli.add_command(dianli2_to_jsonl)
    cli.add_command(dianli3_to_jsonl)
    cli.add_command(dianli4_to_jsonl)
    cli.add_command(zhuiyi_to_jsonl)
    cli.add_command(zhuiyi_eval)
    cli.add_command(dianli_strip)
    cli.add_command(process_dianli_gold)
    cli.add_command(test_grammar)
    cli.add_command(dianli5_to_jsonl)
    cli()
