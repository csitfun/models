import re
import json
import numpy as np
import pandas as pd
import chinese2digits as c2d
from xdec_config import get_logger

logger = get_logger(__name__)


class Header:

    def __init__(self, names: list, types: list):
        self.names = names
        self.types = types

    def __getitem__(self, idx):
        return self.names[idx], self.types[idx]

    def __len__(self):
        return len(self.names)

    def __repr__(self):
        return ' | '.join(
            ['{}({})'.format(n, t) for n, t in zip(self.names, self.types)])


class Table:

    def __init__(self, id, name, title, header: Header, rows, **kwargs):
        self.id = id
        self.name = name
        self.title = title
        self.header = header
        self.rows = rows
        self._df = None

    @property
    def df(self):
        if self._df is None:
            self._df = pd.DataFrame(
                data=self.rows, columns=self.header.names, dtype=str)
        return self._df

    def _repr_html_(self):
        return self.df._repr_html_()


class Tables:
    table_dict = None

    def __init__(self, table_list: list = None, table_dict: dict = None):
        self.table_dict = {}
        if isinstance(table_list, list):
            for table in table_list:
                self.table_dict[table.id] = table
        if isinstance(table_dict, dict):
            self.table_dict.update(table_dict)

    def push(self, table):
        self.table_dict[table.id] = table

    def __len__(self):
        return len(self.table_dict)

    def __add__(self, other):
        return Tables(
            table_list=list(self.table_dict.values()) +
            list(other.table_dict.values()))

    def __getitem__(self, id):
        return self.table_dict[id]

    def __iter__(self):
        for table_id, table in self.table_dict.items():
            yield table_id, table


def set_sql_compare_mode(mode):
    available_modes = {'all', 'agg', 'no_val', 'conn_and_agg'}
    if mode not in available_modes:
        raise ValueError('mode should be one of {}'.format(available_modes))
    cmp_func = getattr(SQL, 'equal_{}_mode'.format(mode))
    SQL.__eq__ = cmp_func


class SQL:
    op_sql_dict = {0: ">", 1: "<", 2: "==", 3: "!="}
    agg_sql_dict = {0: "", 1: "AVG", 2: "MAX", 3: "MIN", 4: "COUNT", 5: "SUM"}
    conn_sql_dict = {0: "", 1: "and", 2: "or"}

    st_op_sql_dict = {0: "<gt>", 1: "<lt>", 2: "<==>", 3: "<!=>"}
    st_agg_sql_dict = {
        0: "<no_agg>",
        1: "<avg>",
        2: "<max>",
        3: "<min>",
        4: "<count>",
        5: "<sum>"
    }
    st_conn_sql_dict = {0: "<no_conn>", 1: "<and>", 2: "<or>"}
    st_sel = {0: "<sel>"}
    st_sel_and = {0: "<sel_and>"}
    st_col = {0: "<col>"}
    st_cond = {0: "<cond>"}
    st_where = {0: "<where>"}

    def __init__(self, cond_conn_op: int, agg: list, sel: list, conds: list,
                 **kwargs):
        self.cond_conn_op = cond_conn_op
        self.sel = []
        self.agg = []
        sel_agg_pairs = zip(sel, agg)
        sel_agg_pairs = sorted(sel_agg_pairs, key=lambda x: (x[0], x[1]))
        for col_id, agg_op in sel_agg_pairs:
            self.sel.append(col_id)
            self.agg.append(agg_op)
        self.conds = sorted(conds, key=lambda x: (x[0], x[1], x[2]))

    @classmethod
    def from_dict(cls, data: dict):
        return cls(**data)

    def keys(self):
        return ['cond_conn_op', 'sel', 'agg', 'conds']

    def __getitem__(self, key):
        return getattr(self, key)

    def to_json(self):
        return json.dumps(dict(self), ensure_ascii=False, sort_keys=True)

    def equal_all_mode(self, other):
        return self.to_json() == other.to_json()

    def equal_agg_mode(self, other):
        self_sql = SQL(cond_conn_op=0, agg=self.agg, sel=self.sel, conds=[])
        other_sql = SQL(cond_conn_op=0, agg=other.agg, sel=other.sel, conds=[])
        return self_sql.to_json() == other_sql.to_json()

    def equal_conn_and_agg_mode(self, other):
        self_sql = SQL(
            cond_conn_op=self.cond_conn_op,
            agg=self.agg,
            sel=self.sel,
            conds=[])
        other_sql = SQL(
            cond_conn_op=other.cond_conn_op,
            agg=other.agg,
            sel=other.sel,
            conds=[])
        return self_sql.to_json() == other_sql.to_json()

    def equal_no_val_mode(self, other):
        self_sql = SQL(
            cond_conn_op=self.cond_conn_op,
            agg=self.agg,
            sel=self.sel,
            conds=[cond[:2] for cond in self.conds])
        other_sql = SQL(
            cond_conn_op=other.cond_conn_op,
            agg=other.agg,
            sel=other.sel,
            conds=[cond[:2] for cond in other.conds])
        return self_sql.to_json() == other_sql.to_json()

    def __eq__(self, other):
        raise NotImplementedError('compare mode not set')

    def __repr__(self):
        repr_str = ''
        repr_str += "sel: {}\n".format(self.sel)
        repr_str += "agg: {}\n".format([self.agg_sql_dict[a] for a in self.agg])
        repr_str += "cond_conn_op: '{}'\n".format(
            self.conn_sql_dict[self.cond_conn_op])
        repr_str += "conds: {}".format([
            [cond[0], self.op_sql_dict[cond[1]], cond[2]] for cond in self.conds
        ])

        return repr_str

    def _repr_html_(self):
        return self.__repr__().replace('\n', '<br>')


class Question:

    def __init__(self, text):
        self.text = text

    def __repr__(self):
        return self.text

    def __getitem__(self, idx):
        return self.text[idx]

    def __len__(self):
        return len(self.text)


class Query:

    def __init__(self, question: Question, table: Table, sql: SQL = None):
        self.question = question
        self.table = table
        self.sql = sql

    def _repr_html_(self):
        repr_str = '{}<br>{}<br>{}'.format(
            self.table._repr_html_(), self.question.__repr__(),
            self.sql._repr_html_() if self.sql is not None else '')
        return repr_str

    def __repr__(self):
        return f"SOURCE: {self.source()}\n" \
            + f"TARGET: {self.target()}\n" \
            + f"TABLE: {self.table._repr_html_()}\n" \
            + f"SQL: {self.sql._repr_html_() if self.sql else ''}"

    def source(self):
        source = norm_number(self.question.text)
        for header in self.table.header:
            source += f"{SQL.st_col[0]}{header[0]}"
        return source

    def target(self):
        target = f"{SQL.st_sel[0]}"
        sels = []
        for agg, sel in zip(self.sql.agg, self.sql.sel):
            sels.append(
                f"{SQL.st_agg_sql_dict[agg]}{self.table.header[sel][0]}")
        target += SQL.st_sel_and[0].join(sels)
        conds = []
        if self.sql.conds:
            target += SQL.st_where[0]
        for col, op, val in self.sql.conds:
            conds.append(
                f"{self.table.header[col][0]}{SQL.st_op_sql_dict[op]}{val}")
        target += SQL.st_conn_sql_dict[self.sql.cond_conn_op].join(conds)
        return target


def read_tables(table_file):
    tables = Tables()
    with open(table_file, encoding='utf-8') as f:
        for line in f:
            tb = json.loads(line)
            header = Header(tb.pop('header'), tb.pop('types'))
            table = Table(header=header, **tb)
            tables.push(table)
    return tables


def read_data(data_file, tables: Tables):
    queries = []
    with open(data_file, encoding='utf-8') as f:
        for line in f:
            data = json.loads(line)
            question = Question(text=data['question'])
            table = tables[data['table_id']]
            if 'sql' in data:
                sql = SQL.from_dict(data['sql'])
            else:
                sql = None
            query = Query(question=question, table=table, sql=sql)
            queries.append(query)
    return queries


def check_acc(pred_queries, gt_queries):
    tot_err = sel_num_err = agg_err = sel_err = 0.0
    cond_num_err = cond_col_err = cond_op_err = cond_val_err = cond_rela_err = 0.0
    bad_sample_idxs = []
    for b, (pred_qry, gt_qry) in enumerate(zip(pred_queries, gt_queries)):
        good = True
        sel_pred, agg_pred, where_rela_pred = pred_qry['sel'], pred_qry[
            'agg'], pred_qry['cond_conn_op']
        sel_gt, agg_gt, where_rela_gt = gt_qry['sel'], gt_qry['agg'], gt_qry[
            'cond_conn_op']

        if where_rela_gt != where_rela_pred:
            good = False
            cond_rela_err += 1

        if len(sel_pred) != len(sel_gt):
            good = False
            sel_num_err += 1

        pred_sel_dict = {k: v for k, v in zip(list(sel_pred), list(agg_pred))}
        gt_sel_dict = {k: v for k, v in zip(sel_gt, agg_gt)}
        if set(sel_pred) != set(sel_gt):
            good = False
            sel_err += 1
        agg_pred = [pred_sel_dict[x] for x in sorted(pred_sel_dict.keys())]
        agg_gt = [gt_sel_dict[x] for x in sorted(gt_sel_dict.keys())]
        if agg_pred != agg_gt:
            good = False
            agg_err += 1

        cond_pred = list(
            sorted(pred_qry['conds'], key=lambda x: (x[0], x[1], x[2])))
        cond_gt = list(
            sorted(gt_qry['conds'], key=lambda x: (x[0], x[1], x[2])))
        if len(cond_pred) != len(cond_gt):
            good = False
            cond_num_err += 1
        else:
            cond_op_pred, cond_op_gt = {}, {}
            cond_val_pred, cond_val_gt = {}, {}
            for p, g in zip(cond_pred, cond_gt):
                cond_op_pred[p[0]] = p[1]
                cond_val_pred[p[0]] = p[2]
                cond_op_gt[g[0]] = g[1]
                cond_val_gt[g[0]] = g[2]

            if set(cond_op_pred.keys()) != set(cond_op_gt.keys()):
                cond_col_err += 1
                good = False

            where_op_pred = [
                cond_op_pred[x] for x in sorted(cond_op_pred.keys())
            ]
            where_op_gt = [cond_op_gt[x] for x in sorted(cond_op_gt.keys())]
            if where_op_pred != where_op_gt:
                cond_op_err += 1
                good = False

            where_val_pred = [
                cond_val_pred[x] for x in sorted(cond_val_pred.keys())
            ]
            where_val_gt = [cond_val_gt[x] for x in sorted(cond_val_gt.keys())]
            if where_val_pred != where_val_gt:
                cond_val_err += 1
                good = False

        if not good:
            tot_err += 1
            bad_sample_idxs.append(b)
    return np.array(
        (sel_num_err, sel_err, agg_err, cond_num_err, cond_col_err, cond_op_err,
         cond_val_err, cond_rela_err)), tot_err, bad_sample_idxs


def norm_number(s):
    """
    >>> c2d.takeNumberFromString("百分之三十二的23%")
{'inputText': '百分之三十二的23%', 
 'replacedText': '0.32的0.23', 
 'CHNumberStringList': ['百分之三十二', '23%'], 
 'digitsStringList': ['0.32', '0.23']}
    """
    try:
        datum = c2d.takeNumberFromString(s)
    except:
        ss = re.sub(r"百分之(\d+)", r"\1%", s)
        ss = re.sub(r"(\d+)个百分点", r"\1%", ss)
        logger.warn(f"Unable to run c2d: {s}, recovered to: {ss}")
        return ss
    result = datum["replacedText"]
    for chn, dig in zip(datum["CHNumberStringList"], datum["digitsStringList"]):
        # if dig.endswith("0000"):
        #     result = result.replace(dig, dig[:-4] + "万")
        #     continue
        # logger.info(f"chn: {chn}\tdig: {dig}")
        if "分之" in chn or "%" in chn:
            result = result.replace(dig, f"{float(dig)*100}%")
        elif "." not in chn and dig.endswith(".0"):
            result = result.replace(dig, dig[:-2])
    return result
