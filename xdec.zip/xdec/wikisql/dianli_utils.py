import re
import sys
import json
import math
import logging
from collections import defaultdict, OrderedDict
from ahocorasick import Automaton
from xdec_utils.time import TimeProcessor
import chinese2digits as c2d

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


def get_alias(select):
    as_pattern = r"as\s([^\s,]+)"
    m = re.search(as_pattern, select)
    aliases = {}
    select = select.strip()
    new_select = ""
    use_as = False
    while m:
        use_as = True
        start = m.start()
        end = m.end()
        col = select[:start].strip()
        if new_select:
            new_select += " , "
        new_select += col
        alias = m.group(1)
        if col.startswith("DISTINCT"):
            col = col[len("DISTINCT "):]
        aliases[alias] = col
        select = select[end:].strip()
        if select.startswith(","):
            select = select[1:]
        m = re.search(as_pattern, select)
    if not use_as:
        new_select = select
    return new_select, aliases


def clean_sql(sql):
    sql_tokens = sql.split()
    index_from = sql_tokens.index("FROM")
    index_where = sql_tokens.index("WHERE") if "WHERE" in sql_tokens else len(
        sql_tokens)
    index_where_end = len(sql_tokens)
    if "GROUP" in sql_tokens or "ORDER" in sql_tokens:
        if "GROUP" in sql_tokens:
            index_where_end = sql_tokens.index("GROUP")
        if "ORDER" in sql_tokens:
            index_where_end = min(index_where_end, sql_tokens.index("ORDER"))
    select = sql_tokens[1:index_from]
    mid = " ".join(sql_tokens[index_from + 1:index_where_end])
    where = sql_tokens[index_where + 1:index_where_end]
    tail = " ".join(sql_tokens[index_where_end:])
    tail = tail.replace("(",
                        " ( ").replace(")", " ) ").replace(",", " , ").replace(
                            ">", " > ").replace("<", " < ").replace("=", " = ")
    tail = re.sub(r"\s+", " ", tail)
    tail = tail.strip().split()
    logger.debug(f"sql: {sql}\nselect: {select}\twhere: {where}\ttail: {tail}")
    select = " ".join(select)
    new_select, aliases = get_alias(select)
    logger.debug(f"new_select: {new_select}\taliases: {aliases}")
    if tail:
        logger.debug(f"has tail: {tail}")
        for i in range(len(tail)):
            if tail[i] in aliases:
                tail[i] = aliases[tail[i]]
        logger.debug(f"new tail: {tail}")
    tail = " ".join(tail)
    new_sql = "SELECT " + new_select + " FROM " + mid + " " + tail
    new_sql = re.sub(r"\s+", " ", new_sql).strip()
    new_sql = re.sub(r"(and|AND)\stq_epidemic_data\.areaType='\d'", "", new_sql)
    new_sql = re.sub(r"tq_epidemic_data\.areaType='\d'\s(and|AND)", "", new_sql)
    logger.debug(f"new_sql: {new_sql}")
    return new_sql


def main(input_file_name):
    with open(input_file_name) as input_file:
        data = json.load(input_file)
        for nl, sql, ts in data["query&sql"]:
            clean_sql(sql)


def build_column_map(column_name_en2cn, column_types):
    result = {}
    logger.debug(f"{column_types} {len(column_name_en2cn)} {len(column_types)}")
    for k, t in zip(column_name_en2cn, column_types[1:]):
        logger.debug(f"k: {k} t: {t}")
        v = column_name_en2cn[k]
        table_name = k.split(".")[0]
        en_name = k.split(".")[-1]
        cn_name = v.split(".")[-1]
        if table_name not in result:
            result[table_name] = OrderedDict()
        result[table_name][cn_name] = (k, t)
        if cn_name == "省份":
            result[table_name]["省"] = (k, t)
        if cn_name == "城市":
            result[table_name]["市"] = (k, t)
    result["tq_epidemic_data"]["累计确认"] = ("tq_epidemic_data.confirmedCount",
                                          "number")
    result["tq_epidemic_data"]["死亡人数"] = ("tq_epidemic_data.deadCount",
                                          "number")
    return result


def build_value_map(column_name_en2cn, table2values, column_types):
    result = {}  # table_name -> value -> col_name
    cols_buf = []
    table_id = -1
    prev_table_name = ""
    table_col_index = {}
    for k, t in zip(column_name_en2cn, column_types[1:]):
        logger.debug(f"k: {k} t: {t}")
        table_name = k.split(".")[0]
        logger.debug(f"table_name: {table_name}")
        if table_name != prev_table_name:
            logger.debug(
                f"prev: {prev_table_name} tn: {table_name} cols_buf: {cols_buf}"
            )
            if len(cols_buf) > 0:
                table_col_index[str(table_id)] = (prev_table_name, cols_buf)
                cols_buf = []
            prev_table_name = table_name
            table_id += 1
        cols_buf.append((k, t))
    if cols_buf:
        table_col_index[str(table_id)] = (prev_table_name, cols_buf)
    logger.debug(f"table_col_index: {table_col_index}")
    for t2v_key in table2values:
        rows = table2values[t2v_key]
        table_name, col_types = table_col_index[t2v_key]
        if table_name not in result:
            result[table_name] = {}
            for row in rows:
                for (col_name, col_type), value in zip(col_types, row):
                    if col_type == "string" and \
                        ".id" not in col_name and \
                        ".code" not in col_name and value:
                        if value not in result[table_name]:
                            result[table_name][value] = col_name
    return result


def build_output(input_name, output_name):
    result = {}
    with open(input_name) as input_:
        data = json.load(input_)
    table_data = data["table"]
    column_map = build_column_map(table_data["column_name_en2cn"],
                                  table_data["column_types"])
    result = {}  # table_name -> value -> col_name
    cols_buf = []
    table_id = -1
    prev_table_name = ""
    table_col_index = {}
    column_name_en2cn = table_data["column_name_en2cn"]
    table2values = table_data["table2values"]
    column_types = table_data["column_types"]
    for k, t in zip(column_name_en2cn, column_types[1:]):
        logger.debug(f"k: {k} c: {column_name_en2cn[k]} t: {t}")
        table_name = k.split(".")[0]
        logger.debug(f"table_name: {table_name}")
        if table_name != prev_table_name:
            logger.debug(
                f"prev: {prev_table_name} tn: {table_name} cols_buf: {cols_buf}"
            )
            if len(cols_buf) > 0:
                table_col_index[str(table_id)] = (prev_table_name, cols_buf)
                cols_buf = []
            prev_table_name = table_name
            table_id += 1
        cols_buf.append((k, column_name_en2cn[k], t))
    if cols_buf:
        table_col_index[str(table_id)] = (prev_table_name, cols_buf)
    logger.debug(f"table_col_index: {table_col_index}")
    for t2v_key in table2values:
        rows = table2values[t2v_key]
        table_name, col_types = table_col_index[t2v_key]
        result[table_name] = {"cols": col_types, "rows": rows}
    with open(output_name, "w") as output:
        json.dump(result, output, ensure_ascii=False, indent=2)


def load_gold_and_table(input_file):
    with open(input_file) as input_:
        data = json.load(input_)
        table_data = data["table"]
        gold_data = {}
        continent_name_count = 0
        sum_if_count = 0
        for nl, sql, ts in data["query&sql"]:
            if "continentName" in sql:
                continent_name_count += 1
                continue
            if "SUM(IF" in sql:
                sql_if_count += 1
                continue
            if nl not in gold_data:
                gold_data[nl] = {"sql": sql, "ts": ts}
        logger.debug(f"len(gold_data): {len(gold_data)}" +
                     f" continentName: {continent_name_count}" +
                     f" SUM(IF: {sum_if_count}")
    return gold_data, table_data


def rule_extraction(data_file, input_file):
    correct = 0
    total = 0
    time_processor = TimeProcessor()
    gold_data, table_data = load_gold_and_table(data_file)
    logger.debug(f"{table_data.keys()}")
    column_map = build_column_map(table_data["column_name_en2cn"],
                                  table_data["column_types"])
    value_map = build_value_map(table_data["column_name_en2cn"],
                                table_data["table2values"],
                                table_data["column_types"])
    logger.debug(f"value_map: {value_map}")
    all_table_names = {
        'shenghui_table', 'business_bulletin', 'tq_epidemic_data', 'city_table',
        'taiqu'
    }
    count_patterns = {}
    cond_patterns = {}
    desc_patterns = {}
    asc_patterns = {}
    str_col_patterns = {}
    logger.debug(f"{column_map.keys()}")
    for table_name in column_map:
        string_names = []
        number_names = []
        for cn_name in column_map[table_name]:
            _, t = column_map[table_name][cn_name]
            if t == "string" and cn_name not in string_names:
                string_names.append(cn_name)
            if t == "number" and cn_name not in number_names:
                number_names.append(cn_name.replace("(", "（").replace(")", ")"))
        string_names.sort(key=lambda s: -len(s))
        number_names.sort(key=lambda s: -len(s))

        # count patterns
        p = r"(多少|几个)个?" + "(" + "|".join(string_names) + ")"
        count_patterns[table_name] = re.compile(p)
        eq_clauses = [
            "(" + f"({x})(是|为|等于)" + r"([+-]?\d+(?:\.\d+)?)" + ")"
            for x in number_names
            if "(" not in x and ")" not in x
        ]
        lt_clauses = [
            "(" + f"({x})(小于|低于|不到)" + r"([+-]?\d+(?:\.\d+)?)" + ")"
            for x in number_names
            if "(" not in x and ")" not in x
        ]
        gt_clauses = [
            "(" + f"({x})(大于|高于|超过)" + r"([+-]?\d+(?:\.\d+)?)" + ")"
            for x in number_names
            if "(" not in x and ")" not in x
        ]
        logger.debug(f"eq_clauses: {eq_clauses}")
        p = "|".join(eq_clauses + lt_clauses + gt_clauses)
        cond_patterns[table_name] = re.compile(p)
        filtered_number_names = [
            x for x in number_names if "(" not in x and ")" not in x
        ]
        # str col pattern
        str_col_patterns[table_name] = re.compile(
            "|".join(string_names + filtered_number_names))
        # asc
        num_names_p = "|".join(
            [x for x in number_names if "(" not in x and ")" not in x])
        asc_patterns[table_name] = [
            re.compile(r"最小(\d+)?个?" + "(" + num_names_p + ")"),
            re.compile("(" + num_names_p + ")" + r"最小(\d+)?个?")
        ]
        desc_patterns[table_name] = [
            re.compile(r"最大(\d+)?个?" + "(" + num_names_p + ")"),
            re.compile("(" + num_names_p + ")" + r"最大(\d+)?个?")
        ]

    with open(input_file) as input_:
        data = json.load(input_)["query&sql"]
        count = 0
        correct = 0
        logger.debug(f"total len: {len(data)}")
        for datum in data:
            logger.debug(f"count: {count}")
            count += 1
            sql_head = ""
            nl, gold_sql, ts = datum
            orig_nl = nl
            nl = nl.replace("(", "（").replace(")", ")")
            gold_toks = gold_sql.split()
            table_name = gold_toks[gold_toks.index("FROM") + 1]
            logger.debug(f"nl: {nl}")
            if table_name == "t_epidemic_data":
                table_name = "tq_epidemic_data"
            m = count_patterns[table_name].search(nl)
            rest = nl
            count_col = ""
            if m:
                cn_name = m.group(2)
                count_col = f"count({column_map[table_name][cn_name][0]})"
                sql_head += f"SELECT count({column_map[table_name][cn_name][0]}) FROM {table_name} "
                logger.debug(f"nl: {nl} sql: {sql_head}")
                rest = nl[:m.start()] + nl[m.end():]
                # logger.info(f"rest: {rest}")
            else:
                if "count(" in gold_sql:
                    logger.warning(
                        f"count missing: {nl} schema: {column_map[table_name]}")
            m = cond_patterns[table_name].search(rest)
            conds = []
            cond = ""
            while m:
                content = m.group(0)
                logger.debug(f"cond m: {content}")
                # op eq
                mm = re.search(r"是|为|等于", content)
                if mm:
                    conds.append(
                        f"{column_map[table_name][content[:mm.start()]][0]} = {content[mm.end():]}"
                    )
                # op lt
                mm = re.search(r"小于|低于|不到", content)
                if mm:
                    conds.append(
                        f"{column_map[table_name][content[:mm.start()]][0]} < {content[mm.end():]}"
                    )
                # op gt
                mm = re.search(r"大于|高于|超过", content)
                if mm:
                    conds.append(
                        f"{column_map[table_name][content[:mm.start()]][0]} > {content[mm.end():]}"
                    )
                rest = rest[:m.start()] + rest[m.end():]
                logger.debug(f"rest: {rest}")
                m = cond_patterns[table_name].search(rest)
            if conds:
                cond = "WHERE " + " AND ".join(conds)
            logger.debug(f"cond: {cond}")
            # clean rest
            rest = rest.replace("的", "").replace("得", "")
            rest = rest.replace("最多", "最大").replace("最高", "最大")
            rest = rest.replace("最少", "最小").replace("最低", "最小")
            rest = re.sub(r"排名前(\d)", r"最大\1", rest)
            rest = re.sub(r"前(\d)", r"最大\1", rest)
            rest = re.sub(r"排名后(\d)", r"最小\1", rest)
            rest = re.sub(r"后(\d)", r"最小\1", rest)
            rest = rest.replace("排名", "")
            found_max = False

            # asc_patterns[table_name] = [
            #     re.compile(r"最小(\d+)?个?" + "(" + num_names_p + ")"),
            #     re.compile("(" + num_names_p + ")" + r"最小(\d+)?个?")
            # ]

            # desc
            order_col = ""
            order_clause = ""
            for i, pat in enumerate(desc_patterns[table_name]):
                m = pat.search(rest)
                if m:
                    found_max = True
                    if i == 0:
                        num = m.group(1)
                        num = int(num) if num else 1
                        col = m.group(2)
                    elif i == 1:
                        num = m.group(2)
                        num = int(num) if num else 1
                        col = m.group(1)
                    rest = rest[:m.start()] + rest[m.end():]
                    order_col = column_map[table_name][col][0]
                    order_clause = f"ORDER BY {column_map[table_name][col][0]} DESC LIMIT {num}"
                    break
            # asc
            for i, pat in enumerate(asc_patterns[table_name]):
                m = pat.search(rest)
                if m:
                    found_max = True
                    if i == 0:
                        num = m.group(1)
                        num = int(num) if num else 1
                        col = m.group(2)
                    elif i == 1:
                        num = m.group(2)
                        num = int(num) if num else 1
                        col = m.group(1)
                    rest = rest[:m.start()] + rest[m.end():]
                    order_col = column_map[table_name][col][0]
                    order_clause = f"ORDER BY {column_map[table_name][col][0]} ASC LIMIT {num}"
                    break
            logger.debug(f"order_clause: {order_clause}")
            logger.debug(f"after order rest: {rest}")
            if not found_max and "最" in nl:
                logger.warning(f"Missing most: {nl} rest: {rest}")

            # cols
            sel_cols = []
            m = str_col_patterns[table_name].search(rest)
            while m:
                sel_cols.append(column_map[table_name][m.group(0)][0])
                rest = rest[:m.start()] + rest[m.end():]
                m = str_col_patterns[table_name].search(rest)

            if not sel_cols and order_col:
                sel_cols = [order_col]

            if count_col:
                sel_cols = [count_col]

            # final cond
            time_exps = time_processor.extract_exps(rest)
            for time_exp in time_exps:
                rest = rest.replace(time_exp, "")

            # start comment out
            old_rest = rest
            stopwords = [x for x in "和有多少与总数量是什么，"]
            for sw in stopwords:
                rest = rest.replace(sw, "")

            if table_name in value_map and rest in value_map[table_name]:
                conds = [f"{value_map[table_name][rest]} = {rest}"] + conds
                conds_details = [(value_map[table_name][rest], "=", rest)
                                ] + conds
            # end comment out

            sel_clause = " , ".join(sel_cols)
            if conds:
                cond = "WHERE " + " AND ".join(conds)
            pred_sql = f"SELECT {sel_clause} FROM {table_name} {cond} {order_clause}"
            norm_pred_sql = re.sub(r"\s+", "", pred_sql.lower())
            norm_gold_sql = re.sub(r"\s+", "", gold_sql.lower())
            norm_gold_sql = norm_gold_sql.replace("t_epidemic_data",
                                                  "tq_epidemic_data")
            if norm_gold_sql == norm_pred_sql:
                correct += 1
            else:
                logger.warning(
                    f"Incorrect: {nl} Rest: {rest} Pred: {pred_sql} Gold: {gold_sql}"
                )

        logger.debug(
            f"Correct: {correct} Total: {count} Ratio: {correct/count}")


def rule_extraction2(data_file, country_data_file, input_file):
    extractor = GrammarExtractor(data_file, country_data_file)
    with open(input_file) as input_:
        data = json.load(input_)["query&sql"]
        count = 0
        correct = 0
        logger.debug(f"total len: {len(data)}")
        for datum in data:
            logger.debug(f"count: {count}")
            count += 1
            nl, gold_sql, ts = datum
            orig_nl = nl
            nl = nl.replace("(", "（").replace(")", ")")
            gold_toks = gold_sql.split()
            table_name = gold_toks[gold_toks.index("FROM") + 1]
            logger.debug(f"nl: {nl}")
            if table_name == "t_epidemic_data":
                table_name = "tq_epidemic_data"
            pred = extractor.extract(nl, table_name)
            pred_sql = pred["sql"]
            rest = pred["rest"]
            norm_pred_sql = re.sub(r"\s+", "", pred_sql.lower())
            norm_gold_sql = re.sub(r"\s+", "", gold_sql.lower())
            norm_gold_sql = norm_gold_sql.replace("t_epidemic_data",
                                                  "tq_epidemic_data")
            if norm_gold_sql == norm_pred_sql:
                correct += 1
            else:
                logger.warning(
                    f"Incorrect: {nl} Rest: {rest} Pred: {pred_sql} Gold: {gold_sql}"
                )
    logger.debug(f"Correct: {correct} Total: {count} Ratio: {correct/count}")


def table_extraction(data_file, country_data_file, input_file):
    extractor = GrammarExtractor(data_file, country_data_file)
    total = 0
    correct = 0
    with open(input_file) as input_:
        data = json.load(input_)["query&sql"]
        count = 0
        correct = 0
        logger.debug(f"total len: {len(data)}")
        for datum in data:
            logger.debug(f"count: {count}")
            count += 1
            nl, gold_sql, ts = datum
            orig_nl = nl
            nl = nl.replace("(", "（").replace(")", ")")
            gold_toks = gold_sql.split()
            table_name = gold_toks[gold_toks.index("FROM") + 1]
            s_table_name, scores = extractor.select_table(nl)
            if table_name == "tq_epidemic_data":
                table_name = "t_epidemic_data"
            if s_table_name == table_name:
                correct += 1
            else:
                logger.warning(
                    f"table error pred: {s_table_name} gold: {table_name} nl: {nl} scores: {scores}"
                )
            total += 1
    logger.debug(f"correct: {correct} total: {total}")


class GrammarExtractor:

    def __init__(self, data_file, country_data_file):
        self.time_processor = TimeProcessor()
        gold_data, table_data = load_gold_and_table(data_file)
        logger.debug(f"{table_data.keys()}")
        with open(country_data_file) as country_data_file:
            country_data = json.load(country_data_file)
        self.column_map = build_column_map(table_data["column_name_en2cn"],
                                           table_data["column_types"])
        self.value_map = build_value_map(table_data["column_name_en2cn"],
                                         table_data["table2values"],
                                         table_data["column_types"])
        self.capital_map = self._enrich_epidemic_countries(
            self.value_map["tq_epidemic_data"], country_data)
        logger.debug(f"value_map: {self.value_map}")
        logger.debug(f"capital_map: {self.capital_map}")
        all_table_names = {
            'shenghui_table', 'business_bulletin', 'tq_epidemic_data',
            'city_table', 'taiqu'
        }
        self.count_patterns = {}
        self.cond_patterns = {}
        self.desc_patterns = {}
        self.asc_patterns = {}
        self.str_col_patterns = {}
        self.automata = {}
        column_map = self.column_map
        count_patterns = self.count_patterns
        cond_patterns = self.cond_patterns
        logger.debug(f"{column_map.keys()}")
        for table_name in column_map:
            string_names = []
            number_names = []
            for cn_name in column_map[table_name]:
                _, t = column_map[table_name][cn_name]
                if t == "string" and cn_name not in string_names:
                    string_names.append(cn_name)
                if t == "number" and cn_name not in number_names:
                    number_names.append(
                        cn_name.replace("(", "（").replace(")", ")"))
            string_names.sort(key=lambda s: -len(s))
            number_names.sort(key=lambda s: -len(s))

            # count patterns
            p = r"(多少|几个)个?" + "(" + "|".join(string_names) + ")"
            count_patterns[table_name] = re.compile(p)
            eq_clauses = [
                "(" + f"({x})(是|为|等于)" + r"([+-]?\d+(?:\.\d+)?)" + ")"
                for x in number_names
                if "(" not in x and ")" not in x
            ]
            lt_clauses = [
                "(" + f"({x})(小于|低于|不到)" + r"([+-]?\d+(?:\.\d+)?)" + ")"
                for x in number_names
                if "(" not in x and ")" not in x
            ]
            gt_clauses = [
                "(" + f"({x})(大于|高于|超过)" + r"([+-]?\d+(?:\.\d+)?)" + ")"
                for x in number_names
                if "(" not in x and ")" not in x
            ]
            logger.debug(f"eq_clauses: {eq_clauses}")
            p = "|".join(eq_clauses + lt_clauses + gt_clauses)
            cond_patterns[table_name] = re.compile(p)
            filtered_number_names = [
                x for x in number_names if "(" not in x and ")" not in x
            ]
            # str col pattern
            self.str_col_patterns[table_name] = re.compile(
                "|".join(string_names + filtered_number_names))
            # asc
            num_names_p = "|".join(
                [x for x in number_names if "(" not in x and ")" not in x])
            self.asc_patterns[table_name] = [
                re.compile(r"最小([\d一二三四五六七八九十百千万]+)?个?" + "(" + num_names_p +
                           ")"),
                re.compile("(" + num_names_p + ")" +
                           r"最小([\d一二三四五六七八九十百千万]+)?个?")
            ]
            self.desc_patterns[table_name] = [
                re.compile(r"最大([\d一二三四五六七八九十百千万]+)?个?" + "(" + num_names_p +
                           ")"),
                re.compile("(" + num_names_p + ")" +
                           r"最大([\d一二三四五六七八九十百千万]+)?个?")
            ]
            self.automata[table_name] = self._build_automaton(
                self.value_map[table_name])

    def select_table(self, nl):
        scores = []
        for table_name in self.str_col_patterns:
            found_cols = self.str_col_patterns[table_name].findall(nl)
            score = len(found_cols)
            if table_name == "tq_epidemic_data" and "疫情" in nl:
                score += 100
            if table_name == "tq_epidemic_data" and re.search(
                    r"确诊|治愈|疑似|病例", nl):
                score += 1.2
            if table_name == "shenghui_table" and re.search(r"变压|变电|电器", nl):
                score += 0.75
            if table_name == "business_bulletin":
                score *= 1.6
                score += 0.5
            automaton = self.automata[table_name]
            score += 0.1 * len([entry for _, entry in automaton.iter(nl)])
            scores.append((score, table_name))
        scores.sort(reverse=True)
        tot = 0
        new_scores = []
        for score, table_name in scores:
            score = math.exp(score)
            tot += score
            table_name = "t_epidemic_data" if table_name == "tq_epidemic_data" else table_name
            new_scores.append([score, table_name])
        for new_score in new_scores:
            new_score[0] /= tot
        return new_scores[0][1], new_scores

    def _enrich_epidemic_countries(self, value_map, country_data):
        capital_map = {}
        for country_datum in country_data:
            country_name = country_datum["country_name_chinese_short"]
            capital_name = country_datum["capital_name_chinese"]
            capital_map[f"{country_name}首都"] = f"{country_name}{capital_name}"
            capital_map[f"{country_name}的首都"] = f"{country_name}{capital_name}"
            if country_name not in value_map:
                value_map[country_name] = "tq_epidemic_data.areaName"
            if capital_name not in value_map:
                value_map[capital_name] = "tq_epidemic_data.cityName"
        return capital_map

    def _build_automaton(self, value_map):
        A = Automaton()
        for val in value_map:
            A.add_word(val, (val, value_map[val]))
        A.make_automaton()
        return A

    def extract(self, nl, table_name):
        logger.debug(f"nl: {nl}")
        sql_head = ""
        count_patterns = self.count_patterns
        column_map = self.column_map
        cond_patterns = self.cond_patterns
        desc_patterns = self.desc_patterns
        asc_patterns = self.asc_patterns
        str_col_patterns = self.str_col_patterns
        time_processor = self.time_processor
        value_map = self.value_map
        if table_name == "t_epidemic_data":
            table_name = "tq_epidemic_data"
        m = count_patterns[table_name].search(nl)
        rest = nl
        count_col = ""
        if m:
            cn_name = m.group(2)
            count_col = f"count({column_map[table_name][cn_name][0]})"
            sql_head += f"SELECT count({column_map[table_name][cn_name][0]}) FROM {table_name} "
            logger.debug(f"nl: {nl} sql: {sql_head}")
            rest = nl[:m.start()] + nl[m.end():]
            # logger.info(f"rest: {rest}")
        m = cond_patterns[table_name].search(rest)
        conds = []
        conds_details = []
        cond = ""
        while m:
            content = m.group(0)
            logger.debug(f"cond m: {content}")
            # op eq
            mm = re.search(r"是|为|等于", content)
            if mm:
                conds.append(
                    f"{column_map[table_name][content[:mm.start()]][0]} = {content[mm.end():]}"
                )
                conds_details.append(
                    (column_map[table_name][content[:mm.start()]][0], "=",
                     content[mm.end():]))
            # op lt
            mm = re.search(r"小于|低于|不到", content)
            if mm:
                conds.append(
                    f"{column_map[table_name][content[:mm.start()]][0]} < {content[mm.end():]}"
                )
                conds_details.append(
                    (column_map[table_name][content[:mm.start()]][0], "<",
                     content[mm.end():]))
            # op gt
            mm = re.search(r"大于|高于|超过", content)
            if mm:
                conds.append(
                    f"{column_map[table_name][content[:mm.start()]][0]} > {content[mm.end():]}"
                )
                conds_details.append(
                    (column_map[table_name][content[:mm.start()]][0], ">",
                     content[mm.end():]))
            rest = rest[:m.start()] + rest[m.end():]
            logger.debug(f"rest: {rest}")
            m = cond_patterns[table_name].search(rest)
        if conds:
            cond = "WHERE " + " AND ".join(conds)
        logger.debug(f"cond: {cond}")
        # clean rest
        rest = rest.replace("的", "").replace("得", "")
        rest = rest.replace("最多", "最大").replace("最高", "最大")
        rest = rest.replace("最少", "最小").replace("最低", "最小")
        rest = re.sub(r"最[高大]的?是?哪几?个?", r"最大", rest)
        rest = re.sub(r"最[低小]的?是?哪几?个?", r"最小", rest)
        rest = re.sub(r"排名前([\d一二三四五六七八九十百千万]+)", r"最大\1", rest)
        rest = re.sub(r"从大到小取前([\d一二三四五六七八九十百千万]+)", r"最大\1", rest)
        rest = re.sub(r"从小到大取前([\d一二三四五六七八九十百千万]+)", r"最小\1", rest)
        rest = re.sub(r"前([\d一二三四五六七八九十百千万]+)", r"最大\1", rest)
        rest = re.sub(r"排名后([\d一二三四五六七八九十百千万]+)", r"最小\1", rest)
        rest = re.sub(r"后([\d一二三四五六七八九十百千万]+)", r"最小\1", rest)
        rest = rest.replace("排名", "")
        found_max = False

        # asc_patterns[table_name] = [
        #     re.compile(r"最小(\d+)?个?" + "(" + num_names_p + ")"),
        #     re.compile("(" + num_names_p + ")" + r"最小(\d+)?个?")
        # ]

        # desc
        order_col = ""
        order_clause = ""
        for i, pat in enumerate(desc_patterns[table_name]):
            m = pat.search(rest)
            if m:
                found_max = True
                if i == 0:
                    # num = m.group(1)
                    try:
                        num = c2d.takeNumberFromString(
                            m.group(1))["replacedText"].replace(".0", "")
                    except:
                        num = None
                    num = int(num) if num else 1
                    col = m.group(2)
                elif i == 1:
                    # num = m.group(2)
                    try:
                        num = c2d.takeNumberFromString(
                            m.group(2))["replacedText"].replace(".0", "")
                    except:
                        num = None
                    num = int(num) if num else 1
                    col = m.group(1)
                rest = rest[:m.start()] + rest[m.end():]
                order_col = column_map[table_name][col][0]
                order_clause = f"ORDER BY {column_map[table_name][col][0]} DESC LIMIT {num}"
                break
        # asc
        for i, pat in enumerate(asc_patterns[table_name]):
            m = pat.search(rest)
            if m:
                found_max = True
                if i == 0:
                    # num = m.group(1)
                    try:
                        num = c2d.takeNumberFromString(
                            m.group(1))["replacedText"].replace(".0", "")
                    except:
                        num = None
                    num = int(num) if num else 1
                    col = m.group(2)
                elif i == 1:
                    # num = m.group(2)
                    try:
                        num = c2d.takeNumberFromString(
                            m.group(2))["replacedText"].replace(".0", "")
                    except:
                        num = None
                    num = int(num) if num else 1
                    col = m.group(1)
                rest = rest[:m.start()] + rest[m.end():]
                order_col = column_map[table_name][col][0]
                order_clause = f"ORDER BY {column_map[table_name][col][0]} ASC LIMIT {num}"
                break
        logger.debug(f"order_clause: {order_clause}")
        logger.debug(f"after order rest: {rest}")
        if not found_max and "最" in nl:
            logger.warning(f"Missing most: {nl} rest: {rest}")

        # cols
        sel_cols = []
        sel_details = []

        m = str_col_patterns[table_name].search(rest)
        while m:
            sel_cols.append(column_map[table_name][m.group(0)][0])
            rest = rest[:m.start()] + rest[m.end():]
            m = str_col_patterns[table_name].search(rest)

        if not sel_cols and order_col:
            sel_cols = [order_col]

        if count_col:
            sel_cols = [count_col]

        for sc in sel_cols:
            if sc.startswith("count(") and sc.endswith(")"):
                sel_details.append((sc[6:-1], sc))
            else:
                sel_details.append((sc, sc))

        # final cond
        old_rest = rest
        time_exps = time_processor.extract_exps(rest)
        for time_exp in time_exps:
            rest = rest.replace(time_exp, "")
        # old rest processing
        # stopwords = [x for x in "和有多少与总数量是什么，"]
        # for sw in stopwords:
        #     rest = rest.replace(sw, "")

        # if table_name in value_map and rest in value_map[table_name]:
        #     conds = [f"{value_map[table_name][rest]} = {rest}"] + conds
        # old rest processing ends

        # use automaton on rest
        automaton = self.automata[table_name]
        conds_buf = []
        auto_rest = old_rest
        for k in self.capital_map:
            auto_rest = auto_rest.replace(k, self.capital_map[k])
        logger.debug(f"auto_rest: {auto_rest}")
        for _, entry in automaton.iter(auto_rest):
            val, entity_type = entry
            conds_buf.append((entity_type, val))
            logger.debug(f"Detected by automaton: {entity_type} {val}")
            if val in rest:
                rest = rest[:rest.index(val)] + rest[rest.index(val) +
                                                     len(val):]
        for cond_buf in conds_buf:
            conds = [f"{cond_buf[0]} = {cond_buf[1]}"] + conds
            conds_details.append((cond_buf[0], "=", cond_buf[1]))

        sel_clause = " , ".join(sel_cols)
        if conds:
            cond = "WHERE " + " AND ".join(conds)
        pred_sql = f"SELECT {sel_clause} FROM {table_name} {cond} {order_clause}"
        return {
            "sql": pred_sql,
            "rest": rest,
            "sel": sel_details,
            "conds": conds_details,
            "order": order_clause
        }


if __name__ == "__main__":
    # rule_extraction(".data/dianli3/data0708.json",
    #     ".data/dianli3/first4pat_test.json")
    # rule_extraction2(".data/dianli3/data0708.json",
    #     ".data/dianli_resource/countries.info.json",
    #     ".data/dianli3/first4pat_test.json")
    # table_extraction(".data/dianli3/data0708.json",
    #     ".data/dianli_resource/countries.info.json",
    #     ".data/dianli3/data0708.json")
    build_output(".data/dianli3/data0708.json", ".data/dianli3/table_data.json")
