import os
import json
from collections import defaultdict
from tqdm import tqdm
from xdec_config import get_logger
import sys

logger = get_logger(__name__)


class Query:
    #https://github.com/salesforce/WikiSQL/blob/c2ed4f9b22db1cc2721805d53e6e76e07e2ccbdc/lib/query.py#L10

    agg_ops = ['', 'MAX', 'MIN', 'COUNT', 'SUM', 'AVG']
    cond_ops = ['=', '>', '<', 'OP']
    syms = [
        'SELECT', 'WHERE', 'AND', 'COL', 'TABLE', 'CAPTION', 'PAGE', 'SECTION',
        'OP', 'COND', 'QUESTION', 'AGG', 'AGGOPS', 'CONDOPS'
    ]
    special_tokens = {
        "select": "<select>",
        "from table": "<fromtable>",
        "where": "<where>",
        "and": "<and>",
        "condition": "<cond>",
        "columns": "<columns>",
        "column": "<col>",
        "endofcolumns": "<endofcolumns>"
    }
    none_token = "<none_val>"
    for i, agg_op in enumerate(agg_ops):
        special_tokens[f"agg_op_{i}"] = f"<agg_{agg_op}>".lower()
    for i, cond_op in enumerate(cond_ops):
        special_tokens[f"cond_op_{i}"] = f"<cond_{cond_op}>".lower()
    special_tokens["none_token"] = none_token

    def __init__(self, sel_index, agg_index, columns, conditions=tuple()):
        self.sel_index = sel_index
        self.agg_index = agg_index
        self.columns = columns
        self.conditions = list(conditions)

    def __repr__(self):
        rep = 'SELECT {agg} {sel} FROM table'.format(
            agg=self.agg_ops[self.agg_index],
            sel= self.columns[self.sel_index] \
                if self.columns is not None else 'col{}'.format(self.sel_index),
        )
        if self.conditions:
            rep += ' WHERE ' + ' AND '.join([
                '{} {} {}'.format(self.columns[i], self.cond_ops[o], v)
                for i, o, v in self.conditions
            ])
        return ' '.join(rep.split())

    def target_str(self, lower=True, all_columns=False):
        st = self.special_tokens
        rep = '{select} {agg} {sel} {fromtable}'.format(
            select=st["select"],
            agg=st[f"agg_op_{self.agg_index}"],
            sel=(self.columns[self.sel_index].lower() if lower else self.columns[self.sel_index]) \
                if self.columns is not None else 'col{}'.format(self.sel_index),
            fromtable=st["from table"]
        )
        if all_columns:
            condition = f' {st["where"]} '
            conds = []
            cond_indices = {i for i, _, _ in self.conditions} \
                if self.conditions \
                else set()
            for i in range(len(self.columns)):
                if i in cond_indices:
                    ii, o, v = None, None, None
                    for item in self.conditions:
                        ii, o, v = item
                        if ii == i:
                            break
                    if o is None or v is None:
                        logger.error(
                            "Unable to find column: {}, {}, {}, o:{}, v:{}"
                            .format(self, i, self.conditions, o, v))
                        sys.exit(-1)
                    conds.append("{} {} {} {}".format(
                        st["condition"],
                        self.columns[i].lower() if lower else self.columns[i],
                        st[f"cond_op_{o}"],
                        str(v).lower() if lower else v))
                else:
                    o = len(self.cond_ops) - 1
                    conds.append("{} {} {} {}".format(
                        st["condition"],
                        self.columns[i].lower() if lower else self.columns[i],
                        st[f"cond_op_{o}"], self.none_token))
            rep += f' {st["where"]} ' + f' {st["and"]} '.join(conds)
        else:
            if self.conditions:
                rep += f' {st["where"]} ' + f' {st["and"]} '.join([
                    '{} {} {} {}'.format(
                        st["condition"], self.columns[i].lower()
                        if lower else self.columns[i], st[f"cond_op_{o}"],
                        str(v).lower() if lower else v)
                    for i, o, v in self.conditions
                ])
        return ' '.join(rep.split())

    def source_columns(self, lower=True):
        st = self.special_tokens
        result = st["columns"]
        for column in self.columns:
            if lower:
                column = column.lower()
            result += f' {st["column"]} {column}'
        result += " " + st["endofcolumns"]
        return result

    @classmethod
    def from_dict(cls, d, t):
        return cls(
            sel_index=d['sel'],
            agg_index=d['agg'],
            columns=t,
            conditions=d['conds'])


class WikiSQL:

    def __init__(self, path):
        self.context_counter = defaultdict(int)

        expanded_path = os.path.expanduser(path)
        table_path = os.path.splitext(expanded_path)
        table_path = table_path[0] + '.tables' + table_path[1]

        with open(table_path) as tables_file:
            tables = [json.loads(line) for line in tables_file]
            id_to_tables = {x['id']: x for x in tables}

        all_answers = []
        examples = []
        tot_conds = 0
        non_eq_conds = 0
        num_conds = 0
        agg_count = 0
        agg_count_count = 0
        with open(expanded_path) as example_file:
            for idx, line in enumerate(example_file):
                entry = json.loads(line)
                human_query = entry['question']
                human_query_toks = human_query.split()
                table = id_to_tables[entry['table_id']]
                sql = entry['sql']
                header = table['header']
                answer = repr(Query.from_dict(sql, header))
                query = Query.from_dict(sql, header)
                for cond in query.conditions:
                    if query.agg_index != 0:
                        agg_count += 1
                        if query.agg_index == 3:
                            agg_count_count += 1
                        logger.debug("agg: {}\ncontext: {}".format(
                            query.agg_ops[query.agg_index], human_query_toks))
                    if cond[1] != 0:
                        logger.debug("{} {} {}".format(query.columns[cond[0]],
                                                       query.cond_ops[cond[1]],
                                                       cond[2]))
                        try:
                            idx = human_query_toks.index(str(cond[2]))
                            logger.debug("context: {}".format(
                                human_query_toks[idx - 3:idx + 3]))
                            context = " ".join(human_query_toks[idx - 2:idx])
                            self.context_counter[context] += 1
                        except:
                            pass
                        non_eq_conds += 1
                    try:
                        _ = int(cond[2])
                        num_conds += 1
                    except:
                        try:
                            _ = float(conds[2])
                            num_conds += 1
                        except:
                            pass
                    tot_conds += 1

        sorted_context = sorted(
            [(self.context_counter[k], k) for k in self.context_counter],
            reverse=True)
        logger.info(
            "agg_count/agg_count_count/non_eq_conds/num_conds/tot_conds: {}/{}/{}/{}/{}"
            .format(agg_count, agg_count_count, non_eq_conds, num_conds,
                    tot_conds))
        logger.info("sorted context: {}".format(sorted_context))

    def dump_noneq_context(self, output_file, threshold=5):
        with open(output_file, "w") as output:
            data = {
                k: self.context_counter[k]
                for k in self.context_counter
                if self.context_counter[k] > threshold
            }
            json.dump(data, output, indent=2)

    @classmethod
    def dump_pairs(cls,
                   input_file_name,
                   output_file_name,
                   text=False,
                   lower=True,
                   all_columns=False):
        expanded_path = os.path.expanduser(input_file_name)
        table_path = os.path.splitext(expanded_path)
        table_path = table_path[0] + '.tables' + table_path[1]

        parts = output_file_name.rsplit(".", maxsplit=1)
        output_special_tokens_file_path = parts[0] + ".special_tokens.json"
        part1, part2 = output_file_name.rsplit(".", maxsplit=1)
        source_output_file_name = part1 + ".source." + part2

        with open(output_special_tokens_file_path, "w") as output:
            inv_d = {Query.special_tokens[k]: k for k in Query.special_tokens}
            json.dump(inv_d, output, indent=2)

        with open(table_path) as tables_file:
            tables = [json.loads(line) for line in tables_file]
            id_to_tables = {x['id']: x for x in tables}

        with open(expanded_path) as example_file, \
                open(output_file_name, "w") as output, \
                open(source_output_file_name, "w") as source_output:
            for line in tqdm(list(example_file.readlines())):
                entry = json.loads(line)
                human_query = entry['question']
                table = id_to_tables[entry['table_id']]
                sql = entry['sql']
                header = table['header']
                query = Query.from_dict(sql, header)
                target = query.target_str(lower=lower, all_columns=all_columns)
                source = human_query.lower() if lower else human_query
                source += " " + query.source_columns(lower=lower)
                if text:
                    output.write(source + " " + target + "\n")
                    source_output.write(source + "\n")
                else:
                    output.write(
                        json.dumps({
                            "src": source,
                            "tgt": target
                        }) + "\n")
