import re
import sys
import json
from tqdm import tqdm
from fuzzywuzzy import fuzz
import chinese2digits as c2d
from xdec_utils.time import TimeProcessor
from wikisql.dianli_utils import clean_sql, GrammarExtractor
from xdec_config import get_logger
from server.s2s_predictor import TOKENIZER_CLASSES, S2SPredictor
from server.run import load_args
import pandas as pd
import traceback

logger = get_logger(__name__)

rule_extractor = GrammarExtractor(".data/dianli3/data0708.json",
                                  ".data/dianli_resource/countries.info.json")

DIANLI_SQL_KEYWORD_MAP = {
    "<from>": "FROM",
    "<and>": "AND",
    "<distinct>": "DISTINCT",
    "<join>": "JOIN",
    "<sum>": "SUM",
    "<between>": "BETWEEN",
    "<asc>": "ASC",
    "<on>": "ON",
    "<select>": "SELECT",
    "<limit>": "LIMIT",
    "<max>": "MAX",
    "<desc>": "DESC",
    "<count>": "COUNT",
    "<avg>": "AVG",
    "<groupby>": "GROUP BY",
    "<min>": "MIN",
    "<orderby>": "ORDER BY",
    "<where>": "WHERE",
    "<in>": "IN",
    "<tn>": "TABLE_NAME",
    "<col>": "COLUMN_NAME",
    "<eq>": "=",
    "<lrb>": "(",
    "<rrb>": ")",
    "<comma>": ",",
    "<having>": "HAVING",
    "<neq>": "!=",
    "<lt>": "<",
    "<gt>": ">"
}

COMPARE_OPS_SET = {"<eq>", "<neq>", "<lt>", "<gt>"}

DIANLI2_PARAPHRASES = {
    "STR_TO_DATE(concat(tq_epidemic_data.countYear,-,tq_epidemic_data.countMonth,-,tq_epidemic_data.countDay),%Y-%m-%d)":
        "tq_epidemic_data.format_date",
    "STR_TO_DATE(concat(tq_epidemic_data.countYear,'-',tq_epidemic_data.countMonth,'-',tq_epidemic_data.countDay),'%Y-%m-%d')":
        "tq_epidemic_data.format_date",
    "SUM( tq_epidemic_data.confirmedCount) as confirmedCount,SUM( tq_epidemic_data.suspectedCount) as suspectedCount,SUM( tq_epidemic_data.curedCount) as curedCount,SUM( tq_epidemic_data.deadCount) as deadCount,SUM( tq_epidemic_data.seriousCount) as seriousCount,SUM( tq_epidemic_data.currentConfirmedCount) as currentConfirmedCount":
        "tq_epidemic_data.overview",
    "tq_epidemic_data.confirmedCount as confirmedCount,tq_epidemic_data.suspectedCount as suspectedCount,SUM( tq_epidemic_data.curedCount) as curedCount,SUM( tq_epidemic_data.deadCount) as deadCount,SUM( tq_epidemic_data.seriousCount) as seriousCount,SUM( tq_epidemic_data.currentConfirmedCount) as currentConfirmedCount":
        "tq_epidemic_data.overview",
    "(tq_epidemic_data.areaName=中国 or tq_epidemic_data.areaName=全国)":
        "tq_epidemic_data.areaName=全国",
    "(tq_epidemic_data.areaName=全国 or tq_epidemic_data.areaName=中国)":
        "tq_epidemic_data.areaName=全国",
    "(tq_epidemic_data.areaName='中国' or tq_epidemic_data.areaName='全国')":
        "tq_epidemic_data.areaName=全国",
    "DATE_FORMAT( business_bulletin.date, %Y-%m)":
        "business_bulletin.format_month",
    "DATE_FORMAT( tq_epidemic_data.format_date, %Y-%m-%d)":
        "tq_epidemic_data.format_date",
    "STR_TO_DATE(concat(kanban_month.A01,-,kanban_month.A02,-,01),%Y-%m-%d)":
        "kanban_month.format_date",
    "(business_bulletin.company=国家电网 or business_bulletin.company=国家电网)":
        "business_bulletin.company=国家电网",
    "(select MAX(tq_epidemic_data.format_date) from tq_epidemic_data)":
        "今天",
    "(select MIN(tq_epidemic_data.format_date) from tq_epidemic_data)":
        "最早",
    "YEAR(business_bulletin.date)":
        "business_bulletin.this_year",
    # TODO: use pattern matching
    "(select AVG(shangwangdianjia) from business_bulletin WHERE (business_bulletin.date BETWEEN 2019-05-01 00:00:00.000 AND 2019-05-31 23:59:59.999) )":
        "电价平均值",
    "(select AVG(shoudianliang) from business_bulletin WHERE (business_bulletin.date BETWEEN 2019-03-01 00:00:00.000 AND 2019-03-31 23:59:59.999) )":
        "售电量平均值",
    "(select MAX(tq_epidemic_data.format_date) from tq_epidemic_data where tq_epidemic_data.format_date between 2020-04-20 00:00:00.000 and 2020-04-26 23:59:59.999)":
        "上周",
    "(select MAX(tq_epidemic_data.format_date) from tq_epidemic_data where tq_epidemic_data.format_date between 2020-04-28 00:00:00.000 and 2020-04-28 23:59:59.999)":
        "今天",
    "SUM(IF((business_bulletin.date BETWEEN 2019-03-01 00:00:00.000 AND 2019-03-31 23:59:59.999),business_bulletin.shoudianliang,0))":
        "business_bulletin.calc_cur_AC_YOY_shoudianliang",
    "SUM(IF((business_bulletin.date BETWEEN 2018-03-01 00:00:00.000 AND 2018-03-31 23:59:59.999),business_bulletin.shoudianliang,0))":
        "business_bulletin.calc_pre_AC_YOY_shoudianliang",
    "SUM(IF((business_bulletin.date BETWEEN 2019-04-01 00:00:00.000 AND 2019-04-30 23:59:59.999),business_bulletin.shoudianliang,0))":
        "business_bulletin.calc_cur_AC_YOY_shoudianliang",
    "SUM(IF((business_bulletin.date BETWEEN 2018-04-01 00:00:00.000 AND 2018-04-30 23:59:59.999),business_bulletin.shoudianliang,0))":
        "business_bulletin.calc_pre_AC_YOY_shoudianliang",
    "SUM(IF((business_bulletin.date BETWEEN 2019-03-01 00:00:00.000 AND 2019-03-31 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_cur_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2018-03-01 00:00:00.000 AND 2018-03-31 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_pre_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2019-03-01 00:00:00.000 AND 2019-03-30 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_cur_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2018-03-01 00:00:00.000 AND 2018-03-30 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_pre_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2019-04-01 00:00:00.000 AND 2019-04-30 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_cur_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2018-04-01 00:00:00.000 AND 2018-04-30 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_pre_AC_YOY_eva"
}

DIANLI2_USER_COLUMNS = {
    "tq_epidemic_data.overview": "疫情",
    "tq_epidemic_data.format_date": "日期",
    "business_bulletin.format_month": "月份",
    "kanban_month.format_date": "日期",
    "business_bulletin.this_year": "今年",
    "business_bulletin.calc_cur_AC_YOY_shoudianliang": "本期售电量",
    "business_bulletin.calc_pre_AC_YOY_shoudianliang": "上期售电量",
    "business_bulletin.calc_cur_AC_YOY_eva": "本期EVA",
    "business_bulletin.calc_pre_AC_YOY_eva": "上期EVA",
    "business_bulletin.calc_tongbi_AC_YOY_eva": "EVA同比",
    "business_bulletin.calc_huanbi_AC_YOY_eva": "EVA环比",
    "business_bulletin.calc_tongbi_AC_YOY_shoudianliang": "售电量同比"
}

DIANLI3_PARAPHRASES = {
    "STR_TO_DATE(concat(tq_epidemic_data.countYear,-,tq_epidemic_data.countMonth,-,tq_epidemic_data.countDay),%Y-%m-%d)":
        "tq_epidemic_data.format_date",
    "STR_TO_DATE(concat(tq_epidemic_data.countYear,'-',tq_epidemic_data.countMonth,'-',tq_epidemic_data.countDay),'%Y-%m-%d')":
        "tq_epidemic_data.format_date",
    "SUM( tq_epidemic_data.confirmedCount) as confirmedCount,SUM( tq_epidemic_data.suspectedCount) as suspectedCount,SUM( tq_epidemic_data.curedCount) as curedCount,SUM( tq_epidemic_data.deadCount) as deadCount,SUM( tq_epidemic_data.seriousCount) as seriousCount,SUM( tq_epidemic_data.currentConfirmedCount) as currentConfirmedCount":
        "tq_epidemic_data.overview",
    "tq_epidemic_data.confirmedCount as confirmedCount,tq_epidemic_data.suspectedCount as suspectedCount,SUM( tq_epidemic_data.curedCount) as curedCount,SUM( tq_epidemic_data.deadCount) as deadCount,SUM( tq_epidemic_data.seriousCount) as seriousCount,SUM( tq_epidemic_data.currentConfirmedCount) as currentConfirmedCount":
        "tq_epidemic_data.overview",
    "(tq_epidemic_data.areaName=中国 or tq_epidemic_data.areaName=全国)":
        "tq_epidemic_data.areaName=全国",
    "(tq_epidemic_data.areaName=全国 or tq_epidemic_data.areaName=中国)":
        "tq_epidemic_data.areaName=全国",
    "(tq_epidemic_data.areaName='中国' or tq_epidemic_data.areaName='全国')":
        "tq_epidemic_data.areaName=全国",
    "DATE_FORMAT( business_bulletin.date, %Y-%m)":
        "business_bulletin.format_month",
    "DATE_FORMAT(business_bulletin.date, '%Y-%m')":
        "business_bulletin.format_month",
    "DATE_FORMAT( tq_epidemic_data.format_date, %Y-%m-%d)":
        "tq_epidemic_data.format_date",
    "DATE_FORMAT( tq_epidemic_data.format_date, '%Y-%m-%d')":
        "tq_epidemic_data.format_date",
    "STR_TO_DATE(concat(kanban_month.A01,-,kanban_month.A02,-,01),%Y-%m-%d)":
        "kanban_month.format_date",
    "(business_bulletin.company=国家电网 or business_bulletin.company=国家电网)":
        "business_bulletin.company=国家电网",
    "(select MAX(tq_epidemic_data.format_date) from tq_epidemic_data)":
        "当前",
    "(select MIN(tq_epidemic_data.format_date) from tq_epidemic_data)":
        "最早",
    "(select MAX(date) from business_bulletin)":
        "当前",
    "YEAR(business_bulletin.date)":
        "business_bulletin.this_year",
    # TODO: use pattern matching
    "(select AVG(shangwangdianjia) from business_bulletin WHERE (business_bulletin.date BETWEEN 2019-05-01 00:00:00.000 AND 2019-05-31 23:59:59.999) )":
        "电价平均值",
    "(select AVG(shoudianliang) from business_bulletin WHERE (business_bulletin.date BETWEEN 2019-03-01 00:00:00.000 AND 2019-03-31 23:59:59.999) )":
        "售电量平均值",
    "(select MAX(tq_epidemic_data.format_date) from tq_epidemic_data where tq_epidemic_data.format_date between 2020-04-20 00:00:00.000 and 2020-04-26 23:59:59.999)":
        "上周",
    "(select MAX(tq_epidemic_data.format_date) from tq_epidemic_data where tq_epidemic_data.format_date between 2020-04-28 00:00:00.000 and 2020-04-28 23:59:59.999)":
        "今天",
    "SUM(IF((business_bulletin.date BETWEEN 2019-03-01 00:00:00.000 AND 2019-03-31 23:59:59.999),business_bulletin.shoudianliang,0))":
        "business_bulletin.calc_cur_AC_YOY_shoudianliang",
    "SUM(IF((business_bulletin.date BETWEEN 2018-03-01 00:00:00.000 AND 2018-03-31 23:59:59.999),business_bulletin.shoudianliang,0))":
        "business_bulletin.calc_pre_AC_YOY_shoudianliang",
    "SUM(IF((business_bulletin.date BETWEEN 2019-04-01 00:00:00.000 AND 2019-04-30 23:59:59.999),business_bulletin.shoudianliang,0))":
        "business_bulletin.calc_cur_AC_YOY_shoudianliang",
    "SUM(IF((business_bulletin.date BETWEEN 2018-04-01 00:00:00.000 AND 2018-04-30 23:59:59.999),business_bulletin.shoudianliang,0))":
        "business_bulletin.calc_pre_AC_YOY_shoudianliang",
    "SUM(IF((business_bulletin.date BETWEEN 2019-03-01 00:00:00.000 AND 2019-03-31 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_cur_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2018-03-01 00:00:00.000 AND 2018-03-31 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_pre_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2019-03-01 00:00:00.000 AND 2019-03-30 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_cur_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2018-03-01 00:00:00.000 AND 2018-03-30 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_pre_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2019-04-01 00:00:00.000 AND 2019-04-30 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_cur_AC_YOY_eva",
    "SUM(IF((business_bulletin.date BETWEEN 2018-04-01 00:00:00.000 AND 2018-04-30 23:59:59.999),business_bulletin.eva,0))":
        "business_bulletin.calc_pre_AC_YOY_eva",
}

DIANLI3_PARAPHRASES_INVERSABLE = {
    "STR_TO_DATE(concat(tq_epidemic_data.countYear,-,tq_epidemic_data.countMonth,-,tq_epidemic_data.countDay),%Y-%m-%d)":
        "tq_epidemic_data.format_date",
    "STR_TO_DATE(concat(tq_epidemic_data.countYear,'-',tq_epidemic_data.countMonth,'-',tq_epidemic_data.countDay),'%Y-%m-%d')":
        "tq_epidemic_data.format_date",
    "SUM( tq_epidemic_data.confirmedCount) as confirmedCount,SUM( tq_epidemic_data.suspectedCount) as suspectedCount,SUM( tq_epidemic_data.curedCount) as curedCount,SUM( tq_epidemic_data.deadCount) as deadCount,SUM( tq_epidemic_data.seriousCount) as seriousCount,SUM( tq_epidemic_data.currentConfirmedCount) as currentConfirmedCount":
        "tq_epidemic_data.overview",
    "tq_epidemic_data.confirmedCount as confirmedCount,tq_epidemic_data.suspectedCount as suspectedCount,SUM( tq_epidemic_data.curedCount) as curedCount,SUM( tq_epidemic_data.deadCount) as deadCount,SUM( tq_epidemic_data.seriousCount) as seriousCount,SUM( tq_epidemic_data.currentConfirmedCount) as currentConfirmedCount":
        "tq_epidemic_data.overview",
    "(tq_epidemic_data.areaName=中国 or tq_epidemic_data.areaName=全国)":
        "tq_epidemic_data.areaName=全国",
    "(tq_epidemic_data.areaName=全国 or tq_epidemic_data.areaName=中国)":
        "tq_epidemic_data.areaName=全国",
    "(tq_epidemic_data.areaName='中国' or tq_epidemic_data.areaName='全国')":
        "tq_epidemic_data.areaName=全国",
    "STR_TO_DATE(concat(kanban_month.A01,-,kanban_month.A02,-,01),%Y-%m-%d)":
        "kanban_month.format_date",
    "(business_bulletin.company=国家电网 or business_bulletin.company=国家电网)":
        "business_bulletin.company=国家电网",
    "(select MAX(tq_epidemic_data.format_date) from tq_epidemic_data)":
        "tq_epidemic_data|当前",
    "(select MIN(tq_epidemic_data.format_date) from tq_epidemic_data)":
        "tq_epidemic_data|最早",
    "(select MAX(date) from business_bulletin)":
        "business_bulletin|当前",
    "YEAR(business_bulletin.date)":
        "business_bulletin.this_year"
}

DIANLI3_PARAPHRASES_SELECT_INVERSABLE = {
    "DATE_FORMAT( business_bulletin.date, %Y-%m)":
        "business_bulletin.format_month",
    "DATE_FORMAT(business_bulletin.date, '%Y-%m')":
        "business_bulletin.format_month",
    "DATE_FORMAT( tq_epidemic_data.format_date, %Y-%m-%d)":
        "tq_epidemic_data.format_date",
    "DATE_FORMAT( tq_epidemic_data.format_date, '%Y-%m-%d')":
        "tq_epidemic_data.format_date",
}

DIANLI3_USER_COLUMNS = {
    "tq_epidemic_data.overview": "疫情",
    "tq_epidemic_data.format_date": "日期",
    "business_bulletin.format_month": "月份",
    "kanban_month.format_date": "日期",
    "business_bulletin.this_year": "今年",
    # "business_bulletin.calc_cur_AC_YOY_shoudianliang": "本期售电量",
    # "business_bulletin.calc_pre_AC_YOY_shoudianliang": "上期售电量",
    # "business_bulletin.calc_cur_AC_YOY_eva": "本期EVA",
    # "business_bulletin.calc_pre_AC_YOY_eva": "上期EVA",
    # "business_bulletin.calc_tongbi_AC_YOY_eva": "EVA同比",
    # "business_bulletin.calc_huanbi_AC_YOY_eva": "EVA环比",
    # "business_bulletin.calc_tongbi_AC_YOY_shoudianliang": "售电量同比"
}

DIANLI3_BLOCK = {"continentName", "SUM(IF"}

FILTER_WHERE = {"_date", ".date", ".areaType=", "全国"}

FILTER_WHERE3 = {".areaType=", "全国"}


def filter_where(where_clause, nl):
    where_parts = where_clause.split(" and ")
    result = []
    for part in where_parts:
        valid = True
        for k in FILTER_WHERE:
            if k in part:
                valid = False
                break
        if valid:
            result.append(part)
    return result


def filter_where3(where_clause, nl):
    where_parts = where_clause.split(" and ")
    result = []
    for part in where_parts:
        valid = True
        for k in FILTER_WHERE3:
            if k in part:
                valid = False
                break
        if valid:
            result.append(part)
    return result


def filter_where5(where_clause, nl):
    where_clause = where_clause.replace(" AND ", " and ")
    where_parts = where_clause.split(" and ")
    result = []
    for part in where_parts:
        valid = True
        if valid:
            result.append(part)
    return result


def fix_sql(sql):
    for k in DIANLI3_PARAPHRASES:
        sql = sql.replace(k, DIANLI3_PARAPHRASES[k])
    for k in DIANLI3_PARAPHRASES:
        sql = sql.replace(k, DIANLI3_PARAPHRASES[k])
    return sql


def get_val(column_name_en2cn, col_name):
    distinct = col_name.lower().startswith("distinct")
    col_name = col_name[len("distinct") + 1:].strip() if distinct else col_name
    if col_name in DIANLI2_USER_COLUMNS:
        val = DIANLI2_USER_COLUMNS[col_name]
        return f"<distinct>{val}" if distinct else val
    elif col_name in column_name_en2cn:
        val = column_name_en2cn[col_name]
        return f"<distinct>{val}" if distinct else val
    else:
        return None


def convert_col(col_name, column_name_en2cn):
    aggs = ["SUM", "COUNT", "AVG", "MIN", "MAX"]
    for agg in aggs:
        if col_name.startswith(agg + "("):
            val = get_val(column_name_en2cn, col_name[len(agg) + 1:-1])
            if val:
                return f"<{agg}>".lower() + "<lrb>" + val.split(
                    ".")[-1] + "<rrb>"
            else:
                return None
    val = get_val(column_name_en2cn, col_name)
    if val:
        return val.split(".")[-1]
    else:
        return None


def convert_col5(col_name, column_name_en2cn):
    aggs = ["SUM", "COUNT", "AVG", "MIN", "MAX"]
    for agg in aggs:
        if col_name.upper().startswith(agg + "("):
            val = get_val(column_name_en2cn, col_name[len(agg) + 1:-1])
            if val:
                return f"<{agg}>".lower() + "<lrb>" + val.split(
                    ".")[-1] + "<rrb>"
            else:
                return None
    val = get_val(column_name_en2cn, col_name)
    if val:
        return val.split(".")[-1]
    else:
        return None


def build_select(select_tokens, column_name_en2cn):
    result = ""
    if select_tokens[0] == "DISTINCT":
        result += "<distinct>"
        select_tokens = select_tokens[1:]
    select_string = " ".join(select_tokens)
    select_parts = select_string.split(",")
    aliases = {}
    cols = []
    for select_part in select_parts:
        logger.info(f"{select_parts}")
        try:
            name, alias = select_part.split(" as ")
        except:
            name, alias = select_part, "_"
        if alias != "_":
            aliases[alias] = name
        col = convert_col(name, column_name_en2cn)
        if col:
            cols.append(col)
        else:
            logger.warning(f"Missing column: {name}")
            logger.warning(f"Corresponding SQL: {select_string}")
    return result + "<comma>".join(cols), aliases


def build_select5(select_tokens, column_name_en2cn):
    result = ""
    if select_tokens[0] == "DISTINCT":
        result += "<distinct>"
        select_tokens = select_tokens[1:]
    select_string = " ".join(select_tokens)
    select_parts = select_string.split(",")
    aliases = {}
    cols = []
    logger.info(f"select_parts: {select_parts}")
    for select_part in select_parts:
        name = select_part
        col = convert_col5(name, column_name_en2cn)
        if col:
            cols.append(col)
        else:
            logger.warning(f"Missing column: {name}")
            logger.warning(f"Corresponding SQL: {select_string}")
    return result + "<comma>".join(cols), aliases


def build_cond(cond, column_name_en2cn):

    def _build_cond(cond, op):
        op_map = {"!=": "<neq>", "=": "<eq>", ">": "<gt>", "<": "<lt>"}
        col_name, val = cond.split(op)
        col_name = col_name.strip()
        val = val.strip()
        if val.startswith("'"):
            val = val[1:-1]
        cn_col = get_val(column_name_en2cn, col_name)
        return cn_col.split(".")[-1] + op_map[op] + val if cn_col else None

    logger.info(f"!cond: {cond}")
    if "!=" in cond:
        return _build_cond(cond, "!=")
    elif "<" in cond:
        return _build_cond(cond, "<")
    elif ">" in cond:
        return _build_cond(cond, ">")
    elif "=" in cond:
        return _build_cond(cond, "=")
    return None


def build_where(wheres, column_name_en2cn):
    result = []
    has_paren = False
    for w in wheres:
        if w.startswith("("):
            w = w[1:-1]
            has_paren = True
        if " or " in w:
            or_wheres = w.split(" or ")
            or_results = [
                build_cond(or_where, column_name_en2cn)
                for or_where in or_wheres
            ]
            r = "<or>".join(or_results)
            if has_paren:
                r = "<lrb>" + r + "<rrb>"
            result.append(r)
        else:
            cond_val = build_cond(w, column_name_en2cn)
            if cond_val:
                result.append(cond_val)
    return "<and>".join(result)


def build_where5(wheres, column_name_en2cn):
    result = []
    has_paren = False
    for w in wheres:
        w = w.replace(" OR ", " or ")
        if w.startswith("("):
            w = w[1:-1]
            has_paren = True
        if " or " in w:
            or_wheres = w.split(" or ")
            or_results = [
                build_cond(or_where, column_name_en2cn)
                for or_where in or_wheres
            ]
            r = "<or>".join(or_results)
            if has_paren:
                r = "<lrb>" + r + "<rrb>"
            result.append(r)
        else:
            cond_val = build_cond(w, column_name_en2cn)
            if cond_val:
                result.append(cond_val)
    return "<and>".join(result)


def build_table_column(table_name, table_name_en2cn, column_name_en2cn):
    result = "<tn>" + table_name_en2cn[table_name]
    for k in DIANLI2_USER_COLUMNS:
        if k.startswith(table_name + "."):
            result += "<col>" + DIANLI2_USER_COLUMNS[k].split(".")[-1]
    for k in column_name_en2cn:
        if k.startswith(table_name + "."):
            result += "<col>" + column_name_en2cn[k].split(".")[-1]
    return result, table_name_en2cn[table_name]


def build_tail(tail, column_name_en2cn, aliases):

    def _build_groupby(text, column_name_en2cn, aliases):
        cols = text.split(",")
        result = "<groupby>"
        cn_cols = []
        for col in cols:
            col = col.strip()
            if col in aliases:
                col = aliases[col]
            cn_cols.append(convert_col(col, column_name_en2cn))
        return result + "<comma>".join(cn_cols)

    def _build_having(text, column_name_en2cn, aliases):
        items = text.split(" and ")
        result = "<having>"
        cn_items = []
        for item in items:
            if ">" in item:
                head = item[:item.index(">")]
                tail = item[item.index(">") + 1:]
                cn_items.append(
                    convert_col(head, column_name_en2cn) + "<gt>" + tail)
            elif "<" in item:
                head = item[:item.index("<")]
                tail = item[item.index("<") + 1:]
                cn_items.append(
                    convert_col(head, column_name_en2cn) + "<lt>" + tail)
            elif "=" in item:
                head = item[:item.index("=")]
                tail = item[item.index("=") + 1:]
                cn_items.append(
                    convert_col(head, column_name_en2cn) + "<eq>" + tail)
        return result + "<and>".join(cn_items)

    def _build_orderby(text, column_name_en2cn, aliases):
        order_dict = {"ASC": "<asc>", "DESC": "<desc>"}
        items = text.split(",")
        result = "<orderby>"
        cn_items = []
        for item in items:
            col, order = item.split()
            if col in aliases:
                col = aliases[col]
            cn_items.append(
                convert_col(col, column_name_en2cn) + order_dict[order])
        return result + "<comma>".join(cn_items)

    def _build_limit(text, column_name_en2cn, aliases):
        text = text.strip()
        return "<limit>" + text[2:]

    delimiters = ["GROUP_BY", "HAVING", "ORDER_BY", "LIMIT"]
    tail = tail.replace(" limit ", " LIMIT ")
    toks = tail.split()
    buf = []
    state = ""
    result = ""
    for tok in toks:
        if tok in delimiters:
            if buf:
                if state == "GROUP_BY":
                    result += _build_groupby(" ".join(buf), column_name_en2cn,
                                             aliases)
                elif state == "HAVING":
                    result += _build_having(" ".join(buf), column_name_en2cn,
                                            aliases)
                elif state == "ORDER_BY":
                    result += _build_orderby(" ".join(buf), column_name_en2cn,
                                             aliases)
                elif state == "LIMIT":
                    result += _build_limit(" ".join(buf), column_name_en2cn,
                                           aliases)
            state = tok
            buf = []
        else:
            buf.append(tok)
    if buf:
        if state == "GROUP_BY":
            result += _build_groupby(" ".join(buf), column_name_en2cn, aliases)
        elif state == "HAVING":
            result += _build_having(" ".join(buf), column_name_en2cn, aliases)
        elif state == "ORDER_BY":
            result += _build_orderby(" ".join(buf), column_name_en2cn, aliases)
        elif state == "LIMIT":
            result += _build_limit(" ".join(buf), column_name_en2cn, aliases)
    return result


def build_tail5(tail, column_name_en2cn, aliases):

    def _build_groupby(text, column_name_en2cn, aliases):
        cols = text.split(",")
        result = "<groupby>"
        cn_cols = []
        for col in cols:
            col = col.strip()
            if col in aliases:
                col = aliases[col]
            cn_cols.append(convert_col(col, column_name_en2cn))
        return result + "<comma>".join(cn_cols)

    def _build_having(text, column_name_en2cn, aliases):
        items = text.split(" and ")
        result = "<having>"
        cn_items = []
        for item in items:
            if ">" in item:
                head = item[:item.index(">")]
                tail = item[item.index(">") + 1:]
                cn_items.append(
                    convert_col(head, column_name_en2cn) + "<gt>" + tail)
            elif "<" in item:
                head = item[:item.index("<")]
                tail = item[item.index("<") + 1:]
                cn_items.append(
                    convert_col(head, column_name_en2cn) + "<lt>" + tail)
            elif "=" in item:
                head = item[:item.index("=")]
                tail = item[item.index("=") + 1:]
                cn_items.append(
                    convert_col(head, column_name_en2cn) + "<eq>" + tail)
        return result + "<and>".join(cn_items)

    def _build_orderby(text, column_name_en2cn, aliases):
        order_dict = {"ASC": "<asc>", "DESC": "<desc>"}
        items = text.split(",")
        result = "<orderby>"
        cn_items = []
        for item in items:
            col, order = item.split()
            if col in aliases:
                col = aliases[col]
            cn_items.append(
                convert_col(col, column_name_en2cn) + order_dict[order])
        return result + "<comma>".join(cn_items)

    def _build_limit(text, column_name_en2cn, aliases):
        text = text.strip()
        return "<limit>" + text

    delimiters = ["GROUP_BY", "HAVING", "ORDER_BY", "LIMIT"]
    tail = tail.replace(" limit ", " LIMIT ")
    toks = tail.split()
    buf = []
    state = ""
    result = ""
    for tok in toks:
        if tok in delimiters:
            if buf:
                if state == "GROUP_BY":
                    result += _build_groupby(" ".join(buf), column_name_en2cn,
                                             aliases)
                elif state == "HAVING":
                    result += _build_having(" ".join(buf), column_name_en2cn,
                                            aliases)
                elif state == "ORDER_BY":
                    result += _build_orderby(" ".join(buf), column_name_en2cn,
                                             aliases)
                elif state == "LIMIT":
                    result += _build_limit(" ".join(buf), column_name_en2cn,
                                           aliases)
            state = tok
            buf = []
        else:
            buf.append(tok)
    if buf:
        if state == "GROUP_BY":
            result += _build_groupby(" ".join(buf), column_name_en2cn, aliases)
        elif state == "HAVING":
            result += _build_having(" ".join(buf), column_name_en2cn, aliases)
        elif state == "ORDER_BY":
            result += _build_orderby(" ".join(buf), column_name_en2cn, aliases)
        elif state == "LIMIT":
            result += _build_limit(" ".join(buf), column_name_en2cn, aliases)
    return result


def process_dianli2(input_file_name):
    result = []
    with open(input_file_name) as input_file:
        data = json.load(input_file)
        table_data = data["table"]
        table_name_en2cn = table_data["table_name_en2cn"]
        column_name_en2cn = table_data["column_name_en2cn"]
        logger.info(f"sql count: {len(data['query&sql'])}")
        has_tail = 0
        for nl, sql in tqdm(data["query&sql"]):
            sql = fix_sql(sql)
            sql = sql.replace("&gt;", ">")
            sql = sql.replace("( ", "(").replace(" )", ")")
            sql = re.sub(r"\s+", " ", sql)
            sql = fix_sql(sql)
            sql_tokens = sql.split()
            index_from = sql_tokens.index("FROM")
            index_where = sql_tokens.index(
                "WHERE") if "WHERE" in sql_tokens else len(sql_tokens)
            index_where_end = len(sql_tokens)
            if "GROUP" in sql_tokens or "ORDER" in sql_tokens:
                if "GROUP" in sql_tokens:
                    index_where_end = sql_tokens.index("GROUP")
                if "ORDER" in sql_tokens:
                    index_where_end = min(index_where_end,
                                          sql_tokens.index("ORDER"))
            table = sql_tokens[index_from + 1]
            select, aliases = build_select(sql_tokens[1:index_from],
                                           column_name_en2cn)
            select = select.replace("本期EVA,本期EVA,上期EVA,上期EVA", "EVA同比,EVA环比")
            select = select.replace("本期售电量,上期售电量", "售电量同比")
            select = select.replace("本期EVA,上期EVA", "EVA同比")
            where = " ".join(sql_tokens[index_where + 1:index_where_end])
            where = filter_where(where, nl)
            logger.info(f"Filtered where: {where}")
            where = build_where(where, column_name_en2cn)
            tail = sql_tokens[index_where_end:]
            tc_info, table_name = build_table_column(table, table_name_en2cn,
                                                     column_name_en2cn)
            source = nl + tc_info
            target = "<select>" + select + "<from>" + table_name + "<where>" + where
            if not tail:
                result.append({"src": source, "tgt": target})
            else:
                has_tail += 1
            if "DATE_FORMAT" in sql or "STR_TO_DATE" in sql or "(select" in sql or True:
                logger.info(f"NL: {nl}\nSQL: {sql}")
                logger.info(f"SOURCE: {source}")
                logger.info(f"SELECT: {select}")
                logger.info(f"WHERE: {where}")
                logger.info(f"TAIL: {tail}\n")
        logger.info(f"Has TAIL: {has_tail}")
    return result


def process_dianli3(input_file_name):
    time_processor = TimeProcessor()
    result = []
    with open(input_file_name) as input_file,\
            open(".data/dianli3/nl2sql.clean.json", "w") as clean_output:
        clean_data = {"query&sql": []}
        data = json.load(input_file)
        table_data = data["table"]
        table_name_en2cn = table_data["table_name_en2cn"]
        logger.info(f"table_name_en2cn: {table_name_en2cn}")
        column_name_en2cn = table_data["column_name_en2cn"]
        logger.info(f"sql count: {len(data['query&sql'])}")
        has_tail = 0
        blocked = 0
        skip_table = 0
        for nl, sql, ts in tqdm(data["query&sql"]):
            ts_str = ts
            ts = time_processor.parse_ts(ts_str)
            block = False
            logger.info(f"RAW NL: {nl}\nRAW SQL: {sql}")
            sql = fix_sql(sql)
            sql = sql.replace("&gt;", ">")
            sql = sql.replace("( ", "(").replace(" )", ")")
            sql = re.sub(r"\s+", " ", sql)
            logger.info(f"Pre-fix SQL: {sql}")
            sql = fix_sql(sql)
            logger.info(f"Fixed SQL: {sql}")
            for b in DIANLI3_BLOCK:
                if b.lower() in sql.lower():
                    block = True
            if block:
                logger.info(f"Blocked SQL: {sql}")
                blocked += 1
                continue
            m = re.search(r"\((\S+?)\s+BETWEEN\s'(.+?)'\sAND\s'(.+?)'\)", sql)
            if m:
                logger.info(
                    f"Time in SQL: {m.group(1)} {m.group(2)} {m.group(3)}")
                nl_start, nl_end = time_processor.extract(nl, ts)
                try:
                    start = time_processor.parse_sql_ts(m.group(2))
                    end = time_processor.parse_sql_ts(m.group(3))
                except:
                    logger.warning(f"Error processing time: {nl} {sql}")
                    blocked += 1
                    continue
                if nl_start == start and nl_end == end:
                    time_exp = time_processor.extract_exp(nl)
                    sql = sql.replace(m.group(0), f"{m.group(1)}={time_exp}")
                    logger.info(f"Time replaced SQL: {sql}")
                else:
                    logger.warning(f"Unable to align time: {nl} {sql}")
                    blocked += 1
                    continue
            clean_data["query&sql"].append([nl, sql, ts_str])
            sql_tokens = sql.split()
            index_from = sql_tokens.index("FROM")
            index_where = sql_tokens.index(
                "WHERE") if "WHERE" in sql_tokens else len(sql_tokens)
            index_where_end = len(sql_tokens)
            if "GROUP" in sql_tokens or "ORDER" in sql_tokens:
                if "GROUP" in sql_tokens:
                    index_where_end = sql_tokens.index("GROUP")
                if "ORDER" in sql_tokens:
                    index_where_end = min(index_where_end,
                                          sql_tokens.index("ORDER"))
            table = sql_tokens[index_from + 1]
            logger.debug(f"Table: {table}")
            if "(select" in table.lower():
                logger.warning(f"Skip table: {table}")
                logger.warning(f"RAW SQL: {sql}")
                skip_table += 1
                continue
            try:
                select, aliases = build_select(sql_tokens[1:index_from],
                                               column_name_en2cn)
                select = select.replace("本期EVA,本期EVA,上期EVA,上期EVA",
                                        "EVA同比,EVA环比")
                select = select.replace("本期售电量,上期售电量", "售电量同比")
                select = select.replace("本期EVA,上期EVA", "EVA同比")
                where = " ".join(sql_tokens[index_where + 1:index_where_end])
                where = filter_where3(where, nl)
                where = build_where(where, column_name_en2cn)
                tail = sql_tokens[index_where_end:]
                tc_info, table_name = build_table_column(
                    table, table_name_en2cn, column_name_en2cn)
                source = nl + tc_info
                target = "<select>" + select + "<from>" + table_name + "<where>" + where
                tail = " ".join(tail).replace("GROUP BY", "GROUP_BY").replace(
                    "ORDER BY", "ORDER_BY")
                if tail:
                    converted_tail = build_tail(tail, column_name_en2cn,
                                                aliases)
                    logger.info(f"CONVERTED TAIL: {converted_tail}")
                    target = target + converted_tail
            except:
                logger.warning(f"Error processing: NL: {nl} SQL:{sql}")
                blocked += 1
                continue
            result.append({"src": source, "tgt": target})
            if not tail:
                pass
            else:
                has_tail += 1
            if "DATE_FORMAT" in sql or "STR_TO_DATE" in sql or "(select" in sql or True:
                logger.info(f"NL: {nl}\nSQL: {sql}")
                logger.info(f"SOURCE: {source}")
                logger.info(f"SELECT: {select}")
                logger.info(f"WHERE: {where}")
                if tail:
                    logger.info(f"TAIL: {tail}")
                logger.info("\n")
        json.dump(clean_data, clean_output, indent=2, ensure_ascii=False)
    logger.info(f"Has TAIL: {has_tail}")
    logger.info(f"Blocked: {blocked}")
    logger.info(f"Skip table: {skip_table}")
    return result


def process_dianli5(input_file_name, table_file_name):
    time_processor = TimeProcessor()
    result = []
    with open(input_file_name) as input_file, \
            open(table_file_name) as table_file:
        clean_data = {"query&sql": []}
        data = json.load(input_file)
        table_data = json.load(table_file)
        table_data = table_data["table"]
        table_name_en2cn = table_data["table_name_en2cn"]
        logger.info(f"table_name_en2cn: {table_name_en2cn}")
        column_name_en2cn = table_data["column_name_en2cn"]
        logger.info(f"sql count: {len(data['query&sql'])}")
        has_tail = 0
        blocked = 0
        skip_table = 0
        for nl, sql, ts in tqdm(data["query&sql"]):
            block = False
            sql = sql.replace("t_epidemic_data", "tq_epidemic_data")
            logger.info(f"RAW NL: {nl}\nRAW SQL: {sql}")
            sql = fix_sql(sql)
            sql = sql.replace("&gt;", ">")
            sql = sql.replace("( ", "(").replace(" )", ")")
            sql = re.sub(r"\s+", " ", sql)
            logger.info(f"Pre-fix SQL: {sql}")
            sql = fix_sql(sql)
            logger.info(f"Fixed SQL: {sql}")
            for b in DIANLI3_BLOCK:
                if b.lower() in sql.lower():
                    block = True
            if block:
                logger.info(f"Blocked SQL: {sql}")
                blocked += 1
                continue
            time_exp = time_processor.extract_exp(nl)
            if time_exp:
                nl = nl.replace(time_exp, "")
            sql_tokens = sql.split()
            index_from = sql_tokens.index("FROM")
            index_where = sql_tokens.index(
                "WHERE") if "WHERE" in sql_tokens else len(sql_tokens)
            index_where_end = len(sql_tokens)
            if "GROUP" in sql_tokens or "ORDER" in sql_tokens:
                if "GROUP" in sql_tokens:
                    index_where_end = sql_tokens.index("GROUP")
                if "ORDER" in sql_tokens:
                    index_where_end = min(index_where_end,
                                          sql_tokens.index("ORDER"))
            table = sql_tokens[index_from + 1]
            logger.debug(f"Table: {table}")
            if "(select" in table.lower():
                logger.warning(f"Skip table: {table}")
                logger.warning(f"RAW SQL: {sql}")
                skip_table += 1
                continue
            try:
                select, aliases = build_select5(sql_tokens[1:index_from],
                                                column_name_en2cn)
                select = select.replace("本期EVA,本期EVA,上期EVA,上期EVA",
                                        "EVA同比,EVA环比")
                select = select.replace("本期售电量,上期售电量", "售电量同比")
                select = select.replace("本期EVA,上期EVA", "EVA同比")
                where = " ".join(sql_tokens[index_where + 1:index_where_end])
                where = filter_where5(where, nl)
                logger.info(f"where: {where}")
                where = build_where5(where, column_name_en2cn)
                logger.info(f"processed where: {where}")
                tail = sql_tokens[index_where_end:]
                tc_info, table_name = build_table_column(
                    table, table_name_en2cn, column_name_en2cn)
                source = nl + tc_info
                target = "<select>" + select + "<from>" + table_name + "<where>" + where
                tail = " ".join(tail).replace("GROUP BY", "GROUP_BY").replace(
                    "ORDER BY", "ORDER_BY")
                if tail:
                    converted_tail = build_tail5(tail, column_name_en2cn,
                                                 aliases)
                    logger.info(f"CONVERTED TAIL: {converted_tail}")
                    target = target + converted_tail
            except:
                traceback.print_exc()
                logger.warning(f"Error processing: NL: {nl} SQL:{sql}")
                blocked += 1
                continue
            result.append({"src": source, "tgt": target})
            if not tail:
                pass
            else:
                has_tail += 1
    logger.info(f"Has TAIL: {has_tail}")
    logger.info(f"Blocked: {blocked}")
    logger.info(f"Skip table: {skip_table}")
    return result


def build_column_map(column_name_en2cn):
    result = {}
    for k in column_name_en2cn:
        v = column_name_en2cn[k]
        table_name = k.split(".")[0]
        en_name = k.split(".")[-1]
        cn_name = v.split(".")[-1].lower()
        if table_name not in result:
            result[table_name] = {}
        result[table_name][cn_name] = k

    for k in DIANLI3_USER_COLUMNS:
        v = DIANLI3_USER_COLUMNS[k]
        table_name, _ = k.split(".")
        if table_name not in result:
            result[table_name] = {}
        result[table_name][v] = k
    logger.info(result)
    return result


def build_paraphrases(inversable_paraphrases):
    result = {}
    for k in inversable_paraphrases:
        v = inversable_paraphrases[k]
        if "|" in v:
            table_name, v = v.split("|")
        else:
            table_name, _ = v.split(".", maxsplit=1)
        if (table_name, v) not in result:
            result[(table_name, v)] = k
        else:
            kk = result[(table_name, v)]
            if len(k) > len(kk):
                result[(table_name, v)] = k
    logger.info(f"built paraphrases: {result}")
    return result


def parse_output(s):
    toks = s.strip().split()
    buf = ""
    result = []
    logger.debug(f"toks: {toks}")
    for tok in toks:
        if re.match(r"^<.+>$", tok):
            if buf:
                result.append(buf)
                buf = ""
            result.append(tok)
        else:
            buf = buf + tok
    if buf:
        result.append(buf)
    return result


def token_deparaphrase(target_tok,
                       table_name,
                       paraphrases,
                       select_paraphrases,
                       is_select=True):
    old_target_tok = ""
    if is_select and (table_name, target_tok) in select_paraphrases:
        old_target_tok = target_tok
        target_tok = select_paraphrases[(table_name, target_tok)]
    if (table_name, target_tok) in paraphrases:
        target_tok = paraphrases[(table_name, target_tok)]
    else:
        if old_target_tok in target_tok and (table_name,
                                             old_target_tok) in paraphrases:
            v = paraphrases[(table_name, old_target_tok)]
            target_tok = target_tok.replace(old_target_tok, v)
    return target_tok


def is_number(s):
    result = False
    try:
        _ = float(s)
        result = True
    except:
        pass
    return result


def norm_ts(ts_str):
    if ts_str.endswith(".999000"):
        return ts_str[:-3]
    if "." not in ts_str:
        return ts_str + ".000"
    return ts_str


def process_where_tq_epidemic_data(where, paraphrases):
    # add area if no province and city
    no_location = True
    location_type = ""
    result = [x for x in where]
    for item in where:
        if ".areaName" in item or ".provinceName" in item or ".cityName" in item:
            no_location = False
            if ".areaName" in item:
                location_type = "'1'"
            if ".provinceName" in item:
                location_type = "'2'"
            if ".cityName" in item:
                location_type = "'3'"
    if no_location:
        result += [
            "AND",
            "(tq_epidemic_data.areaName='中国' or tq_epidemic_data.areaName='全国')",
            "AND", "tq_epidemic_data.areaType='1'"
        ]
    else:
        if location_type:
            result += ["AND", f"tq_epidemic_data.areaType={location_type}"]
    for i in range(len(result)):
        if "tq_epidemic_data.format_date" in result[i]:
            result[i] = result[i].replace(
                "tq_epidemic_data.format_date",
                paraphrases[("tq_epidemic_data",
                             "tq_epidemic_data.format_date")])
    return result


def post_process(sql_output, table_name, ts, column_map, paraphrases,
                 select_paraphrases):
    if table_name == "t_epidemic_data":
        table_name = "tq_epidemic_data"
    final_replaces = {"9江": "九江"}
    time_processor = TimeProcessor()
    ts = time_processor.parse_ts(ts)
    index_from = sql_output.index("<from>")
    index_where = index_from + 2
    index_tail = len(sql_output)
    result = []
    if "<groupby>" in sql_output or "<orderby>" in sql_output:
        if "<groupby>" in sql_output:
            index_tail = sql_output.index("<groupby>")
        if "<orderby>" in sql_output:
            index_tail = min(index_tail, sql_output.index("<orderby>"))
    select = sql_output[:index_from]
    table = sql_output[index_from + 1]
    where = sql_output[index_where + 1:index_tail]
    tail = sql_output[index_tail:]
    logger.info(f"{select} ... FROM {table} ... WHERE {where} ... {tail}")
    select_result = []
    for tok in select:
        if re.match(r"^<.+>$", tok):
            select_result.append(DIANLI_SQL_KEYWORD_MAP[tok] if tok in
                                 DIANLI_SQL_KEYWORD_MAP else "")
        else:
            if tok in column_map[table_name]:
                target_tok = column_map[table_name][tok]
                target_tok = token_deparaphrase(target_tok, table_name,
                                                paraphrases, select_paraphrases)
                select_result.append(target_tok)
            else:
                logger.warning(f"COL NOT FOUND in SELECT: {tok}")
    result += select_result
    logger.info(f"where: {where}")
    i = 0
    result += ["FROM", table_name, table_name]
    where_result = ["WHERE"]
    while i < len(where):
        if i < len(where) - 2 and where[i + 1] in COMPARE_OPS_SET:
            # process col
            if where[i] == "日期":
                target_tok = column_map[table_name][where[i]]
                target_col = token_deparaphrase(
                    target_tok,
                    table_name,
                    paraphrases,
                    select_paraphrases,
                    is_select=False)
                op = where[i + 1]
                val = where[i + 2]
                if val in ["本日"]:
                    val = "当前"
                if val in ["当前", "最早"]:
                    target_val = token_deparaphrase(
                        val,
                        table_name,
                        paraphrases,
                        select_paraphrases,
                        is_select=False)
                    if target_val != val:
                        where_result.append(
                            f"{target_col} {DIANLI_SQL_KEYWORD_MAP[op]} {target_val}"
                        )
                        i += 3
                        continue
                    else:
                        val = "今天"
                ts_start, ts_end = time_processor.ground_time([val],
                                                              basetime=ts)
                ts_start = norm_ts(str(ts_start))
                ts_end = norm_ts(str(ts_end))
                where_result.append(
                    f"({target_col} BETWEEN '{ts_start}' AND '{ts_end}')")
            else:
                target_tok = column_map[table_name][where[i]]
                target_col = token_deparaphrase(
                    target_tok,
                    table_name,
                    paraphrases,
                    select_paraphrases,
                    is_select=False)
                op = DIANLI_SQL_KEYWORD_MAP[where[i + 1]]
                val = where[i + 2]
                target_val = token_deparaphrase(
                    val,
                    table_name,
                    paraphrases,
                    select_paraphrases,
                    is_select=False)
                if not is_number(target_val):
                    target_val = f"'{target_val}'"
                where_result.append(f"{target_col} {op} {target_val}")
            i += 2
        else:
            if where[i] in DIANLI_SQL_KEYWORD_MAP:
                where_result.append(DIANLI_SQL_KEYWORD_MAP[where[i]])
            else:
                where_result.append(where[i])
        i += 1
    if len(where_result) > 1:
        if table_name == "tq_epidemic_data":
            where_result = process_where_tq_epidemic_data(
                where_result, paraphrases)
        result += where_result
    tail_result = []
    i = 0
    while i < len(tail):
        if tail[i] in DIANLI_SQL_KEYWORD_MAP:
            tail_result.append(DIANLI_SQL_KEYWORD_MAP[tail[i]])
        elif i > 0 and tail[i - 1] == "<limit>":
            tail_result.append("0," + tail[i])
        elif i > 0 and tail[i - 1] not in COMPARE_OPS_SET:
            target_tok = column_map[table_name][tail[i]]
            target_col = token_deparaphrase(
                target_tok,
                table_name,
                paraphrases,
                select_paraphrases,
                is_select=True)
            logger.debug(f"target_col: {target_col}")
            tail_result.append(target_col)
        else:
            target_val = tail[i]
            if not is_number(target_val):
                target_val = f"'{target_val}'"
            tail_result.append(target_val)
        i += 1
    result += tail_result
    result = " ".join(result)
    for k, v in final_replaces.items():
        result = result.replace(k, v)
    result = result.replace("tq_epidemic_data", "t_epidemic_data")
    return result


def fuzzy_col_recall(col_name, col_map):
    max_ratio = -1
    best_key = ""
    logger.debug(f"col_name: {col_name}")
    for cand in col_map.keys():
        logger.debug(f"cand: {cand}")
        score = fuzz.token_sort_ratio(col_name, cand)
        if cand.startswith(col_name):
            score = 90
        logger.debug(f"score: {score}")
        if score > max_ratio:
            max_ratio = score
            best_key = cand
    return best_key, max_ratio


def post_process2(nl, sql_output, table_name, ts, column_map, paraphrases,
                  select_paraphrases):
    if table_name == "t_epidemic_data":
        table_name = "tq_epidemic_data"
    final_replaces = {"9江": "九江"}
    time_processor = TimeProcessor()
    ts = time_processor.parse_ts(ts)
    index_from = sql_output.index("<from>")
    index_where = index_from + 2
    index_tail = len(sql_output)
    rule_result = rule_extractor.extract(nl, table_name)
    rule_sel, rule_conds, rule_order, rule_rest = \
        rule_result["sel"], rule_result["conds"], rule_result["order"], rule_result["rest"]
    logger.info(f"rule_result: {rule_result}")
    result = []
    if "<groupby>" in sql_output or "<orderby>" in sql_output:
        if "<groupby>" in sql_output:
            index_tail = sql_output.index("<groupby>")
        if "<orderby>" in sql_output:
            index_tail = min(index_tail, sql_output.index("<orderby>"))
    select = sql_output[:index_from]
    table = sql_output[index_from + 1]
    where = sql_output[index_where + 1:index_tail]
    tail = sql_output[index_tail:]
    logger.info(f"{select} ... FROM {table} ... WHERE {where} ... {tail}")
    select_result = []
    for tok in select:
        if re.match(r"^<.+>$", tok):
            select_result.append(DIANLI_SQL_KEYWORD_MAP[tok] if tok in
                                 DIANLI_SQL_KEYWORD_MAP else "")
        else:
            if tok in column_map[table_name]:
                target_tok = column_map[table_name][tok]
            else:
                _best_key, _best_score = fuzzy_col_recall(
                    tok, column_map[table_name])
                logger.warning(
                    f"857 COL NOT FOUND in SELECT: {tok} recovered to: {_best_key}"
                )
                target_tok = column_map[table_name][_best_key]
            target_tok = token_deparaphrase(target_tok, table_name, paraphrases,
                                            select_paraphrases)
            select_result.append(target_tok)
    # expand select
    is_sum = len(select_result) > 1 and select_result[1].lower() == "sum"
    logger.info(f"select_result: {select_result}")
    for col_key, col_value in rule_sel:
        if table_name in ["business_bulletin"]:
            break
        found = False
        ck = col_key.split(".")[-1]
        for sr in select_result:
            if ck in sr:
                found = True
                break
        if not found:
            if len(select_result) > 0:
                select_result.append(",")
            if is_sum and "(" not in col_value:
                select_result.append(f"SUM ( {col_value} )")
            else:
                select_result.append(col_value)
            logger.info(f"Expand SEL with col: (sum: {is_sum}) {col_value}")
    # end expand select
    result += select_result
    logger.info(f"where: {where}")
    i = 0
    result += ["FROM", table_name, table_name]
    values_by_rule = set()
    cols_by_rule = set()
    for col_name, _, col_value in rule_conds:
        values_by_rule.add(col_value)
        cols_by_rule.add(col_name)
    new_select_result = []
    for s_item in select_result:
        valid = True
        for cr in cols_by_rule:
            if cr in s_item:
                valid = False
                break
        if valid:
            new_select_result.append(s_item)
    select_result = new_select_result
    logger.info(f"processed select_result: {select_result}")

    where_result = ["WHERE"]
    while i < len(where):
        if i < len(where) - 2 and where[i + 1] in COMPARE_OPS_SET:
            # process col
            if where[i] == "日期":
                target_tok = column_map[table_name][where[i]]
                target_col = token_deparaphrase(
                    target_tok,
                    table_name,
                    paraphrases,
                    select_paraphrases,
                    is_select=False)
                op = where[i + 1]
                val = where[i + 2]
                cand_val = time_processor.extract_exp(nl)
                if (cand_val is None or
                        not cand_val) and val not in ["本日", "当前", "最早"]:
                    # date not valid
                    logger.info(f"Skip date in {nl}")
                    i += 3
                    if len(where_result) > 0 and where_result[-1] == "AND":
                        where_result.pop()
                    continue
                if val not in ["本日", "当前", "最早"] and val not in nl:
                    val = cand_val
                if val in ["本日"]:
                    val = "当前"
                if val in ["当前", "最早"]:
                    target_val = token_deparaphrase(
                        val,
                        table_name,
                        paraphrases,
                        select_paraphrases,
                        is_select=False)
                    if target_val != val:
                        where_result.append(
                            f"{target_col} {DIANLI_SQL_KEYWORD_MAP[op]} {target_val}"
                        )
                        i += 3
                        continue
                    else:
                        val = "今天"
                ts_start, ts_end = time_processor.ground_time([val],
                                                              basetime=ts)
                ts_start = norm_ts(str(ts_start))
                ts_end = norm_ts(str(ts_end))
                where_result.append(
                    f"({target_col} BETWEEN '{ts_start}' AND '{ts_end}')")
            else:
                logger.warning(
                    f"923 column_map[table_name]: {column_map[table_name]}")
                if where[i] in column_map[table_name]:
                    target_tok = column_map[table_name][where[i]]
                else:
                    _best_key, _best_score = fuzzy_col_recall(
                        where[i], column_map[table_name])
                    logger.warning(
                        f"928 COL NOT FOUND in SELECT: {where[i]} recovered to: {_best_key}"
                    )
                    target_tok = column_map[table_name][_best_key]
                target_col = token_deparaphrase(
                    target_tok,
                    table_name,
                    paraphrases,
                    select_paraphrases,
                    is_select=False)
                op = DIANLI_SQL_KEYWORD_MAP[where[i + 1]]
                val = where[i + 2]
                _search_val = val[:-1] if val.endswith("省") or val.endswith(
                    "市") or val.endswith("区") else val
                logger.info(f"_search_val: {_search_val}")
                if (_search_val in nl or op == "!=") and not is_number(
                        _search_val) and not val in values_by_rule:
                    target_val = token_deparaphrase(
                        val,
                        table_name,
                        paraphrases,
                        select_paraphrases,
                        is_select=False)
                    if not is_number(target_val):
                        target_val = f"'{target_val}'"
                    # where_result.append(f"{target_col} {op} {target_val}")
                    where_result.append((target_col, op, target_val))
                elif len(where_result) > 0 and where_result[-1] == "AND":
                    where_result.pop()
            i += 2
        else:
            if where[i] in DIANLI_SQL_KEYWORD_MAP:
                _val = DIANLI_SQL_KEYWORD_MAP[where[i]]
                if _val.lower() != "and" or len(where_result) > 1:
                    where_result.append(_val)
            else:
                where_result.append(where[i])
        i += 1
    logger.info(f"where before expansion: {where_result}")
    # expand where
    logger.info(f"where_result : {where_result}")
    for col_key, op, col_value in rule_conds:
        if col_value in ["全国"]:
            continue
        ck = col_key.split(".")[-1]
        found = False
        for wr in where_result:
            if isinstance(wr, tuple):
                wr_value = wr[2][1:-1] \
                    if wr[2].startswith("'") and wr[2].endswith("'") else wr[2]
                if col_value in wr_value or wr_value in col_value:
                    found = True
                    break
            else:
                if ck in wr:
                    found = True
                    break
        if not found:
            if is_number(col_value):
                wh_exp = (col_key, op, col_value)
            else:
                wh_exp = (col_key, op, f"'{col_value}'")
            logger.info(f"Expand wh_exp: {wh_exp}")
            if len(where_result) > 1:
                where_result.append("AND")
            where_result.append(wh_exp)
    # merge where
    new_where_result = []
    for wr in where_result:
        if isinstance(wr, tuple):
            found = False
            for nwr in new_where_result:
                if isinstance(nwr, list) and wr[1] == "=" and \
                        nwr[0][0] in wr[0] and nwr[0][1] == wr[1]:
                    nwr.append(wr)
                    found = True
                    break
            if not found:
                new_where_result.append([wr])
        else:
            new_where_result.append(wr)

    def _process_item(item):
        if isinstance(item, str):
            return item
        else:
            statements = [f"{x[0]} {x[1]} {x[2]}" for x in item]
            result = " OR ".join(statements)
            if len(statements) > 1:
                result = "(" + result + ")"
            return result

    new_where_result = [_process_item(x) for x in new_where_result]
    while new_where_result and new_where_result[-1] == "AND":
        new_where_result.pop()
    where_result = new_where_result
    # end expand where
    if len(where_result) > 1:
        if table_name == "tq_epidemic_data":
            where_result = process_where_tq_epidemic_data(
                where_result, paraphrases)
        result += where_result
    tail_result = []
    i = 0
    while i < len(tail):
        if tail[i] in DIANLI_SQL_KEYWORD_MAP:
            tail_result.append(DIANLI_SQL_KEYWORD_MAP[tail[i]])
        elif i > 0 and tail[i - 1] == "<limit>":
            tail_result.append("0," + tail[i])
        elif i > 0 and tail[i - 1] not in COMPARE_OPS_SET:
            if tail[i] in column_map[table_name]:
                target_tok = column_map[table_name][tail[i]]
            else:
                _best_key, _best_score = fuzzy_col_recall(
                    tail[i], column_map[table_name])
                logger.warning(
                    f"1026 COL NOT FOUND in SELECT: {tail[i]} recovered to: {_best_key}"
                )
                target_tok = column_map[table_name][_best_key]
            target_col = token_deparaphrase(
                target_tok,
                table_name,
                paraphrases,
                select_paraphrases,
                is_select=True)
            logger.debug(f"target_col: {target_col}")
            tail_result.append(target_col)
        else:
            target_val = tail[i]
            if not is_number(target_val):
                target_val = f"'{target_val}'"
            tail_result.append(target_val)
        i += 1
    logger.info(f"tail result: {tail_result}")
    if "ORDER BY" not in tail_result and rule_order:
        logger.info(f"Expand rule_order: {rule_order}")
        tail_result.append(rule_order)
    elif rule_order and len(
            tail_result
    ) > 0 and "LIMIT" not in tail_result and "LIMIT" in rule_order:
        rule_limit = rule_order[rule_order.index("LIMIT"):]
        logger.info(f"Expand limit: {rule_limit}")
        tail_result.append(rule_limit)
    result += tail_result
    result = " ".join(result)
    for k, v in final_replaces.items():
        result = result.replace(k, v)
    result = result.replace("tq_epidemic_data", "t_epidemic_data")
    select_output = " ".join(select_result[1:]).replace("tq_epidemic_data",
                                                        "t_epidemic_data")
    where_output = " ".join(where_result).replace("tq_epidemic_data",
                                                  "t_epidemic_data")
    group_order_output = " ".join(tail_result).replace("tq_epidemic_data",
                                                       "t_epidemic_data")
    detail_output = {
        "select": {
            "stmt": select_output,
            "score": 1.0
        },
        "where": {
            "stmt": where_output,
            "score": 0.8 if len(rule_rest) < 5 else 0.2
        },
        "grouporder": {
            "stmt": group_order_output,
            "score": 0.8 if group_order_output else 0.2
        }
    }
    return result, detail_output


def load_gold_and_table(input_file):
    with open(input_file) as input_:
        data = json.load(input_)
        table_data = data["table"]
        gold_data = {}
        continent_name_count = 0
        sum_if_count = 0
        for nl, sql, ts in data["query&sql"]:
            if "continentName" in sql:
                continent_name_count += 1
                continue
            if "SUM(IF" in sql:
                sql_if_count += 1
                continue
            if nl not in gold_data:
                gold_data[nl] = {"sql": sql, "ts": ts}
        logger.info(f"len(gold_data): {len(gold_data)}" +
                    f" continentName: {continent_name_count}" +
                    f" SUM(IF: {sum_if_count}")
    return gold_data, table_data


def fix_and_compare():
    logger.info(
        fix_sql(
            "SELECT DISTINCT DATE_FORMAT(business_bulletin.date, '%Y-%m') as date,business_bulletin.mechanism as mechanism,business_bulletin.company as company,business_bulletin.lirunzhanbi_dianwang as lirunzhanbi_dianwang FROM business_bulletin business_bulletin WHERE (business_bulletin.date BETWEEN '2018-07-01 00:00:00.000' AND '2018-07-31 23:59:59.999') and business_bulletin.mechanism='四川' and business_bulletin.mechanism!='国家电网有限公司'"
        ))
    gold_data, table_data = load_gold_and_table(".data/dianli3/data0708.json")
    predictions, test_data = [], []
    # best model
    with open(
            "transformer_models/dianli3_0720_large_890_196_lr1e-4_ep500_b64/ckpt-6000/test.output.txt"
    ) as predictions_input:
        for pred in predictions_input:
            predictions.append(pred)
    with open(".data/dianli3/test_0720.jsonl") as test_input:
        test_data = []
        for line in test_input:
            test_data.append(json.loads(line))
    logger.info(f"{predictions[0]}")
    logger.info(f"{test_data[0]}")
    column_map = build_column_map(table_data["column_name_en2cn"])
    paraphrases = build_paraphrases(DIANLI3_PARAPHRASES_INVERSABLE)
    select_paraphrases = build_paraphrases(
        DIANLI3_PARAPHRASES_SELECT_INVERSABLE)
    total = 0
    correct = 0
    for test_datum, pred in zip(test_data, predictions):
        line = pred.strip()
        sql_output = parse_output(line)
        src = test_datum["src"][:test_datum["src"].index("<tn>")]
        test_sql, test_ts = gold_data[src]["sql"], gold_data[src]["ts"]
        sql_toks = test_sql.split()
        table_name = sql_toks[sql_toks.index("FROM") + 1]
        logger.info(f"{src}\t{test_sql}\t{test_ts}\t{line}\t{sql_output}")
        result = post_process(sql_output, table_name, test_ts, column_map,
                              paraphrases, select_paraphrases)
        norm_gold = clean_sql(test_sql)
        norm_gold = norm_gold.replace("tq_epidemic_data", "t_epidemic_data")
        clean_gold = norm_gold.replace("'", "").replace(" ", "").lower()
        result = re.sub(r"AND tq_epidemic_data\.areaType='\d'", "", result)
        result = re.sub(r"AND t_epidemic_data\.areaType='\d'", "", result)
        clean_result = result.replace("'", "").replace(" ", "").lower()
        if clean_result == clean_gold:
            correct += 1
        else:
            logger.info(f"DIFF: pred: {result} gold: {norm_gold}")
        total += 1
    logger.info(f"Correct: {correct} Total: {total}")


def fix_and_compare2():
    logger.info(
        fix_sql(
            "SELECT DISTINCT DATE_FORMAT(business_bulletin.date, '%Y-%m') as date,business_bulletin.mechanism as mechanism,business_bulletin.company as company,business_bulletin.lirunzhanbi_dianwang as lirunzhanbi_dianwang FROM business_bulletin business_bulletin WHERE (business_bulletin.date BETWEEN '2018-07-01 00:00:00.000' AND '2018-07-31 23:59:59.999') and business_bulletin.mechanism='四川' and business_bulletin.mechanism!='国家电网有限公司'"
        ))
    gold_data, table_data = load_gold_and_table(".data/dianli3/data0708.json")
    predictions, test_data = [], []
    with open(
            "transformer_models/dianli3_0720_384_128_lr1e-4_ep100_b64/test.output.txt"
    ) as predictions_input:
        for pred in predictions_input:
            predictions.append(pred)
    with open(".data/dianli3/test_0720.jsonl") as test_input:
        test_data = []
        for line in test_input:
            test_data.append(json.loads(line))
    logger.info(f"{predictions[0]}")
    logger.info(f"{test_data[0]}")
    column_map = build_column_map(table_data["column_name_en2cn"])
    paraphrases = build_paraphrases(DIANLI3_PARAPHRASES_INVERSABLE)
    select_paraphrases = build_paraphrases(
        DIANLI3_PARAPHRASES_SELECT_INVERSABLE)
    total = 0
    correct = 0
    for test_datum, pred in zip(test_data, predictions):
        line = pred.strip()
        sql_output = parse_output(line)
        src = test_datum["src"][:test_datum["src"].index("<tn>")]
        test_sql, test_ts = gold_data[src]["sql"], gold_data[src]["ts"]
        sql_toks = test_sql.split()
        table_name = sql_toks[sql_toks.index("FROM") + 1]
        logger.info(f"{src}\t{test_sql}\t{test_ts}\t{line}\t{sql_output}")
        result, detail_result = post_process2(src, sql_output, table_name,
                                              test_ts, column_map, paraphrases,
                                              select_paraphrases)
        logger.info(f"Result: {result} Detail result: {detail_result}")
        norm_gold = clean_sql(test_sql)
        norm_gold = norm_gold.replace("tq_epidemic_data", "t_epidemic_data")
        clean_gold = norm_gold.replace("'", "").replace(" ", "").lower()
        clean_gold = clean_gold.replace(
            "andbusiness_bulletin.mechanism!=国家电网有限公司", "")
        clean_gold = clean_gold.replace("business_bulletin.mechanism!=国家电网有限公司",
                                        "")

        result = re.sub(r"AND tq_epidemic_data\.areaType='\d'", "", result)
        result = re.sub(r"AND t_epidemic_data\.areaType='\d'", "", result)
        clean_result = result.replace("'", "").replace(" ", "").lower()
        clean_result = clean_result.replace(
            "andbusiness_bulletin.mechanism!=国家电网有限公司", "")
        clean_result = clean_result.replace(
            "business_bulletin.mechanism!=国家电网有限公司", "")

        if clean_result == clean_gold:
            correct += 1
        else:
            logger.info(f"DIFF: pred: {result} gold: {norm_gold}")
        total += 1
    logger.info(f"Correct: {correct} Total: {total}")


def matched_parathesis(s):
    count = 0
    for i in s:
        if i == "(":
            count += 1
        elif i == ")":
            count -= 1
        if count < 0:
            return False
    return count == 0


def process3(nl,
             table_name,
             model,
             ts,
             column_map,
             table_name_en2cn,
             column_name_en2cn,
             paraphrases,
             select_paraphrases,
             use_model1=True):
    if table_name == "t_epidemic_data":
        table_name = "tq_epidemic_data"
    logger.info(f"Process NL: {nl}")
    # final_replaces = {"9江": "九江"}
    final_replaces = {}
    time_processor = TimeProcessor()
    ts = time_processor.parse_ts(ts)
    rule_result = rule_extractor.extract(nl, table_name)
    rule_sel, rule_conds, rule_order, rule_rest = \
        rule_result["sel"], rule_result["conds"], rule_result["order"], rule_result["rest"]
    logger.info(f"model0 result: {rule_result}")

    result = []
    sql_output = ""
    select = ["<select>"]
    table = table_name_en2cn[
        table_name] if table_name in table_name_en2cn else "NOTABLE"  # sql_output[index_from+1]
    where = []  # sql_output[index_where+1:index_tail]
    tail = []  # sql_output[index_tail:]
    # use_model1 = False
    if use_model1:
        tc_info, _ = build_table_column(table_name, table_name_en2cn,
                                        column_name_en2cn)
        final_query = nl + tc_info
        model_output = model.predict(final_query)
        logger.info(f"model_output: {model_output}")
        sql_output = parse_output(model_output)
        logger.debug(f"sql_output: {sql_output}")
        if "<from>" in sql_output:
            index_from = sql_output.index("<from>")
            index_where = index_from + 2
            index_tail = len(sql_output)
            if "<groupby>" in sql_output or "<orderby>" in sql_output:
                if "<groupby>" in sql_output:
                    index_tail = sql_output.index("<groupby>")
                if "<orderby>" in sql_output:
                    index_tail = min(index_tail, sql_output.index("<orderby>"))
            select = sql_output[:index_from]
            table = sql_output[index_from + 1]
            where = sql_output[index_where + 1:index_tail]
            tail = sql_output[index_tail:]
            logger.info(f"sql_output: {sql_output} tail: {tail}")
            where_in_tail = tail.index("<where>") if "<where>" in tail else -1
            from_in_tail = tail.index("<from>") if "<from>" in tail else -1
            last_in_tail = -1
            if where_in_tail > -1:
                last_in_tail = where_in_tail
            if from_in_tail > -1 and (last_in_tail == -1 or
                                      from_in_tail < last_in_tail):
                last_in_tail = from_in_tail
            if last_in_tail > -1:
                tail = tail[:last_in_tail]
        else:
            select = sql_output
    else:
        if "疫情" in nl:
            if len(select) > 1:
                select.append("<comma>")
            select.append("疫情")
    _time_exp = time_processor.extract_exp(nl)
    if _time_exp and "日期" in column_map[table_name] and "日期" not in where:
        if len(where) > 0:
            where.append("<and>")
        where.extend(["日期", "<eq>", _time_exp])
    logger.info(
        f"SELECT {select} ... FROM {table} ... WHERE {where} ... TAIL {tail}")
    select_result = []
    select_map = {}
    for tok in select:
        if re.match(r"^<.+>$", tok):
            select_result.append(DIANLI_SQL_KEYWORD_MAP[tok] if tok in
                                 DIANLI_SQL_KEYWORD_MAP else "")
        else:
            if tok in column_map[table_name]:
                target_tok = column_map[table_name][tok]
            else:
                _best_key, _best_score = fuzzy_col_recall(
                    tok, column_map[table_name])
                logger.warning(
                    f"857 COL NOT FOUND in SELECT: {tok} recovered to: {_best_key}"
                )
                target_tok = column_map[table_name][_best_key]
            new_target_tok = token_deparaphrase(target_tok, table_name,
                                                paraphrases, select_paraphrases)
            if new_target_tok != target_tok:
                select_map[target_tok] = new_target_tok
            select_result.append(target_tok)
    select_string = " ".join(select_result[1:]).strip()
    _select_result = select_string.split(",")
    if _select_result == [""]:
        _select_result = []
    logger.info(f"_select_result: {select_result}")
    select_result = []
    for item in _select_result:
        valid = matched_parathesis(item)
        if item in ["SELECT"]:
            valid = False
        for cond in rule_conds:
            if cond[0] in item:
                valid = False
                break
        if valid:
            if len(select_result) > 0:
                select_result.append(",")
            select_result.append(item)
    logger.info(f"select_result 0: {select_result}")
    is_sum = len(select_result) > 1
    for item in select_result:
        if not item.lower().startswith("sum"):
            is_sum = False

    for i in range(len(select_result)):
        item = select_result[i]
        for k in select_map:
            if k in item:
                select_result[i] = item.replace(k, select_map[k])
                break
    select_result = ["SELECT"] + select_result
    # expand select
    logger.info(f"select_result: {select_result}")
    for col_key, col_value in rule_sel:
        # if table_name in ["business_bulletin"]:
        #     break
        found = False
        ck = col_key.split(".")[-1]
        for sr in select_result:
            if ck in sr:
                found = True
                break
        if not found:
            if len(select_result) > 1:
                select_result.append(",")
            if is_sum and "(" not in col_value:
                select_result.append(f"SUM ( {col_value} )")
            else:
                select_result.append(col_value)
            logger.info(f"Expand SEL with col: (sum: {is_sum}) {col_value}")
    # end expand select
    result += select_result
    logger.info(f"where: {where}")
    i = 0
    result += ["FROM", table_name, table_name]
    values_by_rule = set()
    cols_by_rule = set()
    for col_name, _, col_value in rule_conds:
        values_by_rule.add(col_value)
        cols_by_rule.add(col_name)
    new_select_result = []
    for s_item in select_result:
        valid = True
        for cr in cols_by_rule:
            if cr in s_item:
                valid = False
                break
        if valid:
            new_select_result.append(s_item)
    select_reuslt = new_select_result
    logger.info(f"processed select_result: {select_result}")

    where_result = ["WHERE"]
    # clean where
    logger.info(f"Original where: {where}")
    _where_str = " ".join(where)
    sections = _where_str.split("<and>")
    new_sections = []
    for section in sections:
        section = section.strip()
        section_parts = section.split()
        if len(section_parts) == 3 and section_parts[1] in [
                "<eq>", "<neq>", "<lt>", "<gt>"
        ]:
            new_sections.append(section)
    where = " <and> ".join(new_sections).split()
    logger.info(f"New where: {where}")

    while i < len(where):
        if i < len(where) - 2 and where[i + 1] in COMPARE_OPS_SET:
            # process col
            if where[i] == "日期":
                target_tok = column_map[table_name][where[i]]
                target_col = token_deparaphrase(
                    target_tok,
                    table_name,
                    paraphrases,
                    select_paraphrases,
                    is_select=False)
                op = where[i + 1]
                val = where[i + 2]
                cand_val = time_processor.extract_exp(nl)
                if (cand_val is None or
                        not cand_val) and val not in ["本日", "当前", "最早"]:
                    # date not valid
                    logger.info(f"Skip date in {nl}")
                    i += 3
                    if len(where_result) > 0 and where_result[-1] == "AND":
                        where_result.pop()
                    continue
                if val not in ["本日", "当前", "最早"] and val not in nl:
                    val = cand_val
                if val in ["本日"]:
                    val = "当前"
                if val in ["当前", "最早"]:
                    target_val = token_deparaphrase(
                        val,
                        table_name,
                        paraphrases,
                        select_paraphrases,
                        is_select=False)
                    if target_val != val:
                        where_result.append(
                            f"{target_col} {DIANLI_SQL_KEYWORD_MAP[op]} {target_val}"
                        )
                        i += 3
                        continue
                    else:
                        val = "今天"
                ts_start, ts_end = time_processor.ground_time([val],
                                                              basetime=ts)
                ts_start = norm_ts(str(ts_start))
                ts_end = norm_ts(str(ts_end))
                where_result.append(
                    f"({target_col} BETWEEN '{ts_start}' AND '{ts_end}')")
            else:
                # logger.warning(f"923 column_map[table_name]: {column_map[table_name]}")
                if where[i] in column_map[table_name]:
                    target_tok = column_map[table_name][where[i]]
                else:
                    _best_key, _best_score = fuzzy_col_recall(
                        where[i], column_map[table_name])
                    logger.warning(
                        f"928 COL NOT FOUND in SELECT: {where[i]} recovered to: {_best_key}"
                    )
                    target_tok = column_map[table_name][_best_key]
                target_col = token_deparaphrase(
                    target_tok,
                    table_name,
                    paraphrases,
                    select_paraphrases,
                    is_select=False)
                op = DIANLI_SQL_KEYWORD_MAP[where[i + 1]]
                val = where[i + 2]
                _search_val = val[:-1] if val.endswith("省") or val.endswith(
                    "市") or val.endswith("区") else val
                logger.info(f"_search_val: {_search_val}")
                if (_search_val in nl or op == "!=") and not is_number(
                        _search_val) and not val in values_by_rule:
                    target_val = token_deparaphrase(
                        val,
                        table_name,
                        paraphrases,
                        select_paraphrases,
                        is_select=False)
                    if not is_number(target_val):
                        target_val = f"'{target_val}'"
                    # where_result.append(f"{target_col} {op} {target_val}")
                    where_result.append((target_col, op, target_val))
                elif len(where_result) > 0 and where_result[-1] == "AND":
                    where_result.pop()
            i += 2
        else:
            if where[i] in DIANLI_SQL_KEYWORD_MAP:
                _val = DIANLI_SQL_KEYWORD_MAP[where[i]]
                if _val.lower() != "and" or len(where_result) > 1:
                    where_result.append(_val)
            else:
                where_result.append(where[i])
        i += 1
    logger.info(f"where before expansion: {where_result}")
    # expand where
    logger.info(f"where_result : {where_result}")
    for col_key, op, col_value in rule_conds:
        if col_value in ["全国"]:
            continue
        ck = col_key.split(".")[-1]
        found = False
        for wr in where_result:
            if isinstance(wr, tuple):
                wr_value = wr[2][1:-1] \
                    if wr[2].startswith("'") and wr[2].endswith("'") else wr[2]
                if col_value in wr_value or wr_value in col_value:
                    found = True
                    break
            else:
                if ck in wr:
                    found = True
                    break
        if not found:
            if is_number(col_value):
                wh_exp = (col_key, op, col_value)
            else:
                wh_exp = (col_key, op, f"'{col_value}'")
            logger.info(f"Expand wh_exp: {wh_exp}")
            if len(where_result) > 1:
                where_result.append("AND")
            where_result.append(wh_exp)
    # merge where
    new_where_result = []
    for wr in where_result:
        if isinstance(wr, tuple):
            found = False
            for nwr in new_where_result:
                if isinstance(nwr, list) and wr[1] == "=" and \
                        nwr[0][0] in wr[0] and nwr[0][1] == wr[1]:
                    nwr.append(wr)
                    found = True
                    break
            if not found:
                new_where_result.append([wr])
        else:
            new_where_result.append(wr)

    def _process_item(item):
        if isinstance(item, str):
            return item
        else:
            statements = [f"{x[0]} {x[1]} {x[2]}" for x in item]
            result = " OR ".join(statements)
            if len(statements) > 1:
                result = "(" + result + ")"
            return result

    new_where_result = [_process_item(x) for x in new_where_result]
    while new_where_result and new_where_result[-1] == "AND":
        new_where_result.pop()
    where_result = new_where_result
    # end expand where
    if len(where_result) > 1:
        if table_name == "tq_epidemic_data":
            where_result = process_where_tq_epidemic_data(
                where_result, paraphrases)
        result += where_result
    tail_result = []
    i = 0
    while i < len(tail):
        if tail[i] in DIANLI_SQL_KEYWORD_MAP:
            tail_result.append(DIANLI_SQL_KEYWORD_MAP[tail[i]])
        elif i > 0 and tail[i - 1] == "<limit>":
            tail_result.append("0," + tail[i])
        elif i > 0 and tail[i - 1] not in COMPARE_OPS_SET:
            if tail[i] in column_map[table_name]:
                target_tok = column_map[table_name][tail[i]]
            else:
                _best_key, _best_score = fuzzy_col_recall(
                    tail[i], column_map[table_name])
                logger.warning(
                    f"1026 COL NOT FOUND in SELECT: {tail[i]} recovered to: {_best_key}"
                )
                target_tok = column_map[table_name][_best_key]
            target_col = token_deparaphrase(
                target_tok,
                table_name,
                paraphrases,
                select_paraphrases,
                is_select=True)
            logger.debug(f"target_col: {target_col}")
            tail_result.append(target_col)
        else:
            target_val = tail[i]
            if not is_number(target_val):
                target_val = f"'{target_val}'"
            tail_result.append(target_val)
        i += 1
    logger.info(f"tail result: {tail_result}")
    if table_name == "tq_epidemic" and "疫情" in nl and not tail_result:
        tail_result = "GROUP BY t_epidemic_data.confirmedCount , t_epidemic_data.suspectedCount , t_epidemic_data.provinceName"
    if "ORDER BY" not in tail_result and rule_order:
        logger.info(f"Expand rule_order: {rule_order}")
        tail_result.append(rule_order)
    elif rule_order and len(
            tail_result
    ) > 0 and "LIMIT" not in tail_result and "LIMIT" in rule_order:
        rule_limit = rule_order[rule_order.index("LIMIT"):]
        logger.info(f"Expand limit: {rule_limit}")
        tail_result.append(rule_limit)
    result += tail_result
    result = " ".join(result)
    for k, v in final_replaces.items():
        result = result.replace(k, v)
    result = result.replace("tq_epidemic_data", "t_epidemic_data")
    select_output = " ".join(select_result[1:]).replace("tq_epidemic_data",
                                                        "t_epidemic_data")
    where_output = " ".join(where_result).replace("tq_epidemic_data",
                                                  "t_epidemic_data")
    group_order_output = " ".join(tail_result).replace("tq_epidemic_data",
                                                       "t_epidemic_data")
    detail_output = {
        "select": {
            "stmt": select_output,
            "score": 1.0
        },
        "where": {
            "stmt": where_output,
            "score": 0.8 if len(rule_rest) < 5 else 0.2
        },
        "grouporder": {
            "stmt": group_order_output,
            "score": 0.8 if group_order_output else 0.2
        }
    }
    return result, detail_output


def fix_and_compare3():
    user_args = {
        "model_type": "unilm",
        "do_lower_case": True,
        "model_path": "",
        "max_seq_length": 384,
        "max_tgt_length": 128,
        "batch_size": 1,
        "beam_size": 1,
        "length_penalty": 0,
        "mode": "s2s",
        "forbid_duplicate_ngrams": False
    }
    # model_path = "transformer_models/dianli3_0720_384_128_lr1e-4_ep100_b64"
    # transformer_models/dianli3_0720_96_32_lr1e-4_ep500_b64_xxs
    model_path = "transformer_models/dianli3_0720_96_32_lr1e-4_ep500_b64_xxs"
    user_args["model_path"] = model_path
    args = load_args(user_args=user_args)
    model = S2SPredictor(args)
    gold_data, table_data = load_gold_and_table(".data/dianli3/data0708.json")
    table_name_en2cn = table_data["table_name_en2cn"]
    column_name_en2cn = table_data["column_name_en2cn"]
    predictions, test_data = [], []
    with open(f"{model_path}/test.output.txt") as predictions_input:
        for pred in predictions_input:
            predictions.append(pred)
    with open(".data/dianli3/test_0720.jsonl") as test_input:
        test_data = []
        for line in test_input:
            test_data.append(json.loads(line))
    logger.info(f"{predictions[0]}")
    logger.info(f"{test_data[0]}")
    column_map = build_column_map(table_data["column_name_en2cn"])
    paraphrases = build_paraphrases(DIANLI3_PARAPHRASES_INVERSABLE)
    select_paraphrases = build_paraphrases(
        DIANLI3_PARAPHRASES_SELECT_INVERSABLE)
    total = 0
    correct = 0
    for test_datum, pred in zip(test_data, predictions):
        line = pred.strip()
        # sql_output = parse_output(line)
        src = test_datum["src"][:test_datum["src"].index("<tn>")]
        test_sql, test_ts = gold_data[src]["sql"], gold_data[src]["ts"]
        sql_toks = test_sql.split()
        table_name = sql_toks[sql_toks.index("FROM") + 1]
        # logger.info(f"{src}\t{test_sql}\t{test_ts}\t{line}\t{sql_output}")
        result, detail_result = process3(src, table_name, model, test_ts,
                                         column_map, table_name_en2cn,
                                         column_name_en2cn, paraphrases,
                                         select_paraphrases)
        logger.info(f"Result: {result} Detail result: {detail_result}")
        norm_gold = clean_sql(test_sql)
        norm_gold = norm_gold.replace("tq_epidemic_data", "t_epidemic_data")
        clean_gold = norm_gold.replace("'", "").replace(" ", "").lower()
        clean_gold = clean_gold.replace(
            "andbusiness_bulletin.mechanism!=国家电网有限公司", "")
        clean_gold = clean_gold.replace("business_bulletin.mechanism!=国家电网有限公司",
                                        "")

        result = re.sub(r"AND tq_epidemic_data\.areaType='\d'", "", result)
        result = re.sub(r"AND t_epidemic_data\.areaType='\d'", "", result)
        clean_result = result.replace("'", "").replace(" ", "").lower()
        clean_result = clean_result.replace(
            "andbusiness_bulletin.mechanism!=国家电网有限公司", "")
        clean_result = clean_result.replace(
            "business_bulletin.mechanism!=国家电网有限公司", "")

        if clean_result == clean_gold:
            correct += 1
        else:
            logger.info(f"DIFF: pred: {result} gold: {norm_gold}")
        total += 1
    logger.info(f"Correct: {correct} Total: {total}")


def process_gold(gold_file_name, metadata_file_name, output_jsonl_file_name):
    df = pd.read_csv(gold_file_name)
    sum_fields = set()
    with open(output_jsonl_file_name, "w") as output:
        for _, row in df.iterrows():
            # logger.info(f"{row['query']} {row['table']} {row['correct']}")
            query = row["query"]
            try:
                sql = clean_sql(row["correct"])
                logger.info(f"query: {query} sql: {sql}")
                select = sql[7:sql.index("FROM")]
                parts = select.split(",")
                logger.info(f"parts: {parts}")
                for part in parts:
                    part = part.strip()
                    if part.startswith("SUM(") and part.endswith(")") and \
                            not part.startswith("IF"):
                        sum_fields.add(part[4:-1].strip())
                output.write(
                    json.dumps(
                        {
                            "query": query,
                            "table": row["table"],
                            "timestamp": "2020-07-08 13:23:00",
                            "sql": sql
                        },
                        ensure_ascii=False) + "\n")
            except:
                logger.warning(f"Unable to parse SQL: {row['correct']}")
    with open(metadata_file_name, "w") as metadata:
        json.dump({"sumfields": list(sum_fields)}, metadata, indent=2)


if __name__ == "__main__":
    # load from decoded results and post process
    fix_and_compare3()
