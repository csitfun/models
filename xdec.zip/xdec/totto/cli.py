import re
import json
import click
import random
from tqdm import tqdm
from xdec_config import open_all, get_logger
from wikisql.processors import WikiSQL, Query

logger = get_logger(__name__)


@click.group()
def cli():
    pass


@click.command()
@click.option(
    "--input_file_name",
    default=".data/totto/totto_data/totto_dev_data.jsonl",
    help="location of the wikisql files")
@click.option(
    "--output_file_name",
    default=".data/totto/totto_dev_pretty.jsonl",
    help="context stats for non equal conds")
def dump_json(input_file_name, output_file_name):
    with open(input_file_name) as input_, open(output_file_name, "w") as output:
        for line in input_:
            datum = json.loads(line)
            output.write(json.dumps(datum, indent=2) + "\n\n")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/totto/totto_data/totto_train_data.jsonl",
    help="location of the wikisql files")
@click.option(
    "--output_file_name",
    default=".data/totto/totto_context_values.train.jsonl",
    help="context stats for non equal conds")
def extract_data(input_file_name, output_file_name):
    with open(input_file_name) as input_, open(output_file_name, "w") as output:
        for line in input_:
            datum = json.loads(line)
            context = datum["sentence_annotations"][-1]["final_sentence"]
            table = datum["table"]
            header_row = table[0]
            if len([x for x in header_row if x["column_span"] == 1
                   ]) != len(header_row):
                logger.warn("Skip complex header: {}".format(header_row))
                continue
            rows = {x[0] for x in datum["highlighted_cells"]}
            if len(rows) != 1:
                continue
            for cell in datum["highlighted_cells"]:
                sel_name = table[0][cell[1]]["value"]
                sel_value = table[cell[0]][cell[1]]["value"]
                conds_sketch = []
                for other_cell in datum["highlighted_cells"]:
                    if other_cell == cell:
                        continue
                    cond_name = table[0][other_cell[1]]["value"]
                    cond_value = table[other_cell[0]][other_cell[1]]["value"]
                    conds_sketch.append(
                        (other_cell, remove_non_latin(cond_name),
                         remove_non_latin(cond_value)))
                valid_conds = [
                    x for x in conds_sketch if x[2].lower() in context.lower()
                ]
                if len(valid_conds) != len(conds_sketch):
                    continue
                if sel_value.lower() in context.lower():
                    new_datum = {
                        "context": remove_non_latin(context),
                        "sel_value": remove_non_latin(sel_value),
                        "sel_name": sel_name,
                        "sel": cell,
                        "conds_sketch": conds_sketch,
                        "example_id": datum["example_id"]
                    }
                    output.write(json.dumps(new_datum) + "\n")


@click.command()
@click.option(
    "--train_file_name",
    default=".data/totto/totto_data/totto_train_data.jsonl",
    help="location of the wikisql files")
@click.option(
    "--input_file_name",
    default=".data/totto/totto_context_values.train.jsonl",
    help="location of the wikisql files")
@click.option(
    "--question_file_name",
    default=".data/totto/totto_questions.jsonl",
    help="location of the wikisql files")
@click.option(
    "--output_file_name",
    default=".data/totto/totto_pretrain_v1.jsonl",
    help="context stats for non equal conds")
def extract_gen_questions(train_file_name, input_file_name, question_file_name,
                          output_file_name):
    lower = True
    example_headers = {}
    logger.info("Loading head_rows...")
    with open(train_file_name) as input_:
        for line in input_:
            datum = json.loads(line)
            table = datum["table"]
            header_row = table[0]
            if len([x for x in header_row if x["column_span"] == 1
                   ]) != len(header_row):
                logger.debug("Skip complex header: {}".format(header_row))
                continue
            example_headers[datum["example_id"]] = header_row
    logger.info(f"Done. {len(example_headers)} head rows loaded.")

    logger.info("Processing questions...")
    with open(input_file_name) as answers, \
            open(question_file_name) as questions, \
            open(output_file_name, "w") as output:
        question_lines = list(questions.readlines())
        answer_lines = list(answers.readlines())
        for question_datum, answer_datum in tqdm(
                zip(question_lines, answer_lines)):
            question_datum = json.loads(question_datum)
            answer_datum = json.loads(answer_datum)
            header_row = example_headers[answer_datum["example_id"]]
            # generate source side
            question = question_datum["answers"][0]
            if lower:
                question = question.lower()
            st = Query.special_tokens
            columns_str = st["columns"]
            logger.debug(f"header_row: {header_row}")
            for column_dict in header_row:
                column = column_dict["value"]
                if lower:
                    column = column.lower()
                columns_str += f' {st["column"]} {column}'
            columns_str += " " + st["endofcolumns"]
            source = question + " " + columns_str
            # generate target side
            sel_index = answer_datum["sel"][1]
            sel_name = answer_datum["sel_name"]
            target = "{select} {agg} {sel} {fromtable}".format(
                select=st["select"],
                agg=st[f"agg_op_0"],
                sel=(sel_name.lower() if lower else sel_name) \
                    if header_row is not None else 'col{}'.format(sel_index),
                fromtable=st["from table"]
            )
            conds = []
            for cond in answer_datum["conds_sketch"]:
                col_name = cond[1].lower() if lower else cond[1]
                col_value = cond[2].lower() if lower else cond[2]
                if col_value in question:
                    conds.append("{} {} {} {}".format(st["condition"], col_name,
                                                      st[f"cond_op_0"],
                                                      col_value))
            target += f' {st["where"]} ' + f' {st["and"]} '.join(conds)
            output.write(json.dumps({"src": source, "tgt": target}) + "\n")


@click.command()
@click.option(
    "--train_file_name",
    default=".data/totto/totto_data/totto_train_data.jsonl",
    help="location of the wikisql files")
@click.option(
    "--input_file_name",
    default=".data/totto/totto_context_values.train.jsonl",
    help="location of the wikisql files")
@click.option(
    "--question_file_name",
    default=".data/totto/totto_questions.jsonl",
    help="location of the wikisql files")
@click.option(
    "--num_sample_file_name",
    default=".data/WikiSQL/num_contexts.json",
    help="num sample file")
@click.option(
    "--time_sample_file_name",
    default=".data/WikiSQL/time_contexts.json",
    help="time sample file")
@click.option(
    "--output_file_name",
    default=".data/totto/totto_pretrain_v2_sample.jsonl",
    help="context stats for non equal conds")
def extract_gen_questions_sample(train_file_name, input_file_name,
                                 question_file_name, num_sample_file_name,
                                 time_sample_file_name, output_file_name):
    lower = True
    example_headers = {}
    logger.info("Loading head_rows...")
    with open(train_file_name) as input_:
        for line in input_:
            datum = json.loads(line)
            table = datum["table"]
            header_row = table[0]
            if len([x for x in header_row if x["column_span"] == 1
                   ]) != len(header_row):
                logger.debug("Skip complex header: {}".format(header_row))
                continue
            example_headers[datum["example_id"]] = header_row
    logger.info(f"Done. {len(example_headers)} head rows loaded.")

    logger.info("Loading sample skeletons")

    def _read_from_sample_file(sample_file_name):
        with open(sample_file_name) as sample_file:
            samples = json.load(sample_file)
            gt_tot = sum([samples[">"][k] for k in samples[">"]])
            samples[">"] = {k: samples[">"][k] / gt_tot for k in samples[">"]}
            lt_tot = sum([samples["<"][k] for k in samples["<"]])
            samples["<"] = {k: samples["<"][k] / gt_tot for k in samples["<"]}
        return samples

    def _sample_op_id(value, num_samples, time_samples):
        result = 0
        phrase = ""
        if len(value) == 4 and "." not in value:
            try:
                _ = int(value)
                r = random.random()
            except:
                r = 1.0
            if r < 0.4:  # lt
                d = time_samples["<"]
                result = 2
            elif r < 0.8:  # gt
                d = time_samples[">"]
                result = 1
            if r < 0.8:
                choices, probs = [], []
                for k in d:
                    choices.append(k)
                    probs.append(d[k])
                phrase = random.choices(choices, weights=probs)[0]
            return result, phrase
        else:
            try:
                _ = float(value)
                r = random.random()
            except:
                r = 1.0
            if r < 0.4:  # lt
                d = num_samples["<"]
                result = 2
            elif r < 0.8:  # gt
                d = num_samples[">"]
                result = 1
            if r < 0.8:
                choices, probs = [], []
                for k in d:
                    choices.append(k)
                    probs.append(d[k])
                phrase = random.choices(choices, weights=probs)[0]
            return result, phrase

        return result, phrase

    def _sample_agg_id(value):
        r = random.random()
        result = 0
        phrase = ""
        if r < 0.1:  # count
            result = 3
            choices = ["number of", "count of"]
            phrase = random.choice(choices)
        else:
            try:
                _ = float(value)
            except:
                r = 1.0
            if r < 0.1:  # max 1
                result = 1
                choices = [
                    "max", "maximum", "largest", "highest", "the max",
                    "the maximum", "the largest", "the highest"
                ]
                phrase = random.choice(choices)
            elif r < 0.2:  # min 2
                result = 2
                choices = [
                    "min", "minimum", "smallest", "lowest", "the min",
                    "the minimum", "the smallest", "the lowest"
                ]
                phrase = random.choice(choices)
            elif r < 0.3:  # sum 4
                result = 4
                choices = ["sum", "total", "the sum", "the total"]
                phrase = random.choice(choices)
            elif r < 0.4:  # avg 5
                result = 5
                choices = ["average", "mean", "the average", "the mean"]
                phrase = random.choice(choices)
        return result, phrase

    def _detect_agg(question):
        d = {
            1: {"max", "maximum", "largest", "highest"},
            2: {"min", "minimum", "smallest", "lowest"},
            3: {"number", "count", "how many"},
            4: {"sum", "total"},
            5: {"average", "mean"}
        }
        question_toks = question.split()
        for k in d:
            for kk in d[k]:
                if kk in question_toks:
                    return k
        return 0

    num_samples = _read_from_sample_file(num_sample_file_name)
    time_samples = _read_from_sample_file(time_sample_file_name)
    logger.info("num_samples: {}".format(num_samples))
    logger.info("time_samples: {}".format(time_samples))

    logger.info("Processing questions...")
    with open(input_file_name) as answers, \
            open(question_file_name) as questions, \
            open(output_file_name, "w") as output:
        question_lines = list(questions.readlines())
        answer_lines = list(answers.readlines())
        for question_datum, answer_datum in tqdm(
                zip(question_lines, answer_lines)):
            question_datum = json.loads(question_datum)
            answer_datum = json.loads(answer_datum)
            header_row = example_headers[answer_datum["example_id"]]
            # generate source side
            question = question_datum["answers"][0]
            question = re.sub(r"\s+", " ", question)
            if lower:
                question = question.lower()
            agg_id = _detect_agg(question)
            st = Query.special_tokens
            columns_str = st["columns"]
            logger.debug(f"header_row: {header_row}")
            for column_dict in header_row:
                column = column_dict["value"]
                if lower:
                    column = column.lower()
                columns_str += f' {st["column"]} {column}'
            columns_str += " " + st["endofcolumns"]
            source = question + " " + columns_str
            # generate target side
            sel_index = answer_datum["sel"][1]
            sel_name = answer_datum["sel_name"]
            sel_name = sel_name.lower() if lower else sel_name
            if agg_id == 0:
                sample_agg_id, sample_agg_phrase = _sample_agg_id(sel_name)
                if sample_agg_id != 0 and " " + sel_name + " " in question:
                    agg_id = sample_agg_id
                    source = source.replace(
                        f" {sel_name} ", f" {sample_agg_phrase} {sel_name} ", 1)

            target = "{select} {agg} {sel} {fromtable}".format(
                select=st["select"],
                agg=st[f"agg_op_{agg_id}"],
                sel=(sel_name.lower() if lower else sel_name) \
                    if header_row is not None else 'col{}'.format(sel_index),
                fromtable=st["from table"]
            )
            cond_indices = {x[0][1]: x for x in answer_datum["conds_sketch"]} \
                if answer_datum["conds_sketch"] \
                else {}
            conds = []
            visited = set()
            for i in range(len(header_row)):
                if i in cond_indices:
                    cond = cond_indices[i]
                    col_name = cond[1].lower() if lower else cond[1]
                    col_value = cond[2].lower() if lower else cond[2]
                    op_id = 0
                    sample_op_id, sample_op_phrase = _sample_op_id(
                        col_value, num_samples, time_samples)
                    question_toks = question.split()
                    if col_value in question_toks:

                        if sample_op_id != 0 and col_value not in visited:
                            logger.debug(
                                "sample_op_phrase: {}".format(sample_op_phrase))
                            logger.debug("col_value: {}".format(col_value))
                            op_id = sample_op_id
                            visited.add(col_value)
                            if f"in {col_value}" in source:
                                source = source.replace(f"in {col_value}",
                                                        col_value, 1)
                            source = source.replace(
                                col_value, sample_op_phrase + " " + col_value,
                                1)
                        conds.append("{} {} {} {}".format(
                            st["condition"], col_name, st[f"cond_op_{op_id}"],
                            col_value))
                else:
                    o = len(Query.cond_ops) - 1
                    conds.append("{} {} {} {}".format(
                        st["condition"], header_row[i]["value"].lower()
                        if lower else header_row[i]["value"],
                        st[f"cond_op_{o}"], Query.none_token))

            target += f' {st["where"]} ' + f' {st["and"]} '.join(conds)
            output.write(json.dumps({"src": source, "tgt": target}) + "\n")


def remove_non_latin(text):
    """
    Replace non-latin characters in Document with spaces.

    Note that the followings are Latin unicode blocks:

    \p{InBasic_Latin}: U+0000–U+007F
    \p{InLatin-1_Supplement}: U+0080–U+00FF
    \p{InLatin_Extended-A}: U+0100–U+017F
    \p{InLatin_Extended-B}: U+0180–U+024F
    \p{InLatin_Extended_Additional}: U+1E00–U+1EFF

    """
    return re.sub(
        r'[^\x00-\x7F\x80-\xFF\u0100-\u017F\u0180-\u024F\u1E00-\u1EFF]', '',
        text)


if __name__ == "__main__":
    cli.add_command(dump_json)
    cli.add_command(extract_data)
    cli.add_command(extract_gen_questions)
    cli.add_command(extract_gen_questions_sample)
    cli()
