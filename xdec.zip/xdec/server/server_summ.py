from uuid import uuid4
from bottle import route, run, template, post, request, response
from server.s2s_predictor import TOKENIZER_CLASSES, S2SPredictor
from server.run import load_args
import logging
import time

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

user_args = {
    "model_type": "unilm",
    "do_lower_case": True,
    "model_path": "summ_model/ckpt-11562",
    "max_seq_length": 512,
    "max_tgt_length": 96,
    "batch_size": 1,
    "beam_size": 1,
    "length_penalty": 0,
    "mode": "s2s"
}
args = load_args(user_args=user_args)
model = S2SPredictor(args)


@route('/status')
def status():
    return "ok"


@post('/summ')
def summ_handler():
    debug = "OK"
    query = ""
    qid = uuid4()
    try:
        data = request.json
        query = data["text"]
        time1 = time.time()
        output = model.predict(query)
        time2 = time.time()
        logger.info(f"Predict time [{qid}]: {time2-time1}")
    except:
        debug = "Error"
    result = {"input": query, "summ": output, "debug": debug}
    return result


if __name__ == "__main__":
    logger.info("Starting server...")
    run(host="0.0.0.0", port=18280)
