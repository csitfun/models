import re
import json
import logging
import requests
import unittest

query, gold_sql_, timestamp, table = [
    "哪个城市的综合线损率最高？",
    "SELECT taiqu.city as city,SUM( taiqu.wire_lose) as wire_lose FROM taiqu taiqu GROUP BY taiqu.city ORDER BY wire_lose DESC  LIMIT 0,1",
    "2020-07-08 13:23:00", "taiqu"
]

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


def get_alias(select):
    as_pattern = r"as\s([^\s,]+)"
    m = re.search(as_pattern, select)
    aliases = {}
    select = select.strip()
    new_select = ""
    while m:
        start = m.start()
        end = m.end()
        col = select[:start].strip()
        new_select += col
        alias = m.group(1)
        if col.startswith("DISTINCT"):
            col = col[len("DISTINCT "):]
        aliases[alias] = col
        select = select[end:].strip()
        if select.startswith(","):
            select = select[1:]
            new_select += " , "
        m = re.search(as_pattern, select)
    return new_select, aliases


def clean_sql(sql):
    sql_tokens = sql.split()
    index_from = sql_tokens.index("FROM")
    index_where = sql_tokens.index("WHERE") if "WHERE" in sql_tokens else len(
        sql_tokens)
    index_where_end = len(sql_tokens)
    if "GROUP" in sql_tokens or "ORDER" in sql_tokens:
        if "GROUP" in sql_tokens:
            index_where_end = sql_tokens.index("GROUP")
        if "ORDER" in sql_tokens:
            index_where_end = min(index_where_end, sql_tokens.index("ORDER"))
    select = sql_tokens[1:index_from]
    mid = " ".join(sql_tokens[index_from + 1:index_where_end])
    where = sql_tokens[index_where + 1:index_where_end]
    tail = " ".join(sql_tokens[index_where_end:])
    tail = tail.replace("(",
                        " ( ").replace(")", " ) ").replace(",", " , ").replace(
                            ">", " > ").replace("<", " < ").replace("=", " = ")
    tail = re.sub(r"\s+", " ", tail)
    tail = tail.strip().split()
    select = " ".join(select)
    new_select, aliases = get_alias(select)
    if tail:
        for i in range(len(tail)):
            if tail[i] in aliases:
                tail[i] = aliases[tail[i]]
    tail = " ".join(tail)
    new_sql = "SELECT " + new_select + " FROM " + mid + " " + tail
    new_sql = re.sub(r"\s+", " ", new_sql).strip()
    new_sql = re.sub(r"(and|AND)\stq_epidemic_data\.areaType='\d'", "", new_sql)
    new_sql = re.sub(r"tq_epidemic_data\.areaType='\d'\s(and|AND)", "", new_sql)
    return new_sql


class TestService(unittest.TestCase):

    def test_service(self):
        global table
        if table == "t_epidemic_data":
            table = "tq_epidemic_data"
        # http://33.17.233.246:18187/nl2sql
        result = requests.post(
            "http://pre-mit-ai.alibaba-inc.com/dianli-nl2sql/v2958/nl2sql",
            json={
                "query": query,
                "table": table,
                "timestamp": timestamp
            })
        # !!! Read result from the data field !!!
        output = result.json()["data"]
        status = output["debug"]
        self.assertEqual(status, "OK")
        predict_sql = output["sql"]
        gold_sql = clean_sql(gold_sql_)
        clean_gold = gold_sql.replace("'", "").replace(" ", "").lower()
        clean_predict = re.sub(r"AND tq_epidemic_data\.areaType='\d'", "",
                               predict_sql)
        clean_predict = clean_predict.replace("'", "").replace(" ", "").lower()
        self.assertEqual(clean_predict, clean_gold)


if __name__ == '__main__':
    unittest.main()
