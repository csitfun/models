import os
import time
import argparse
import logging
import json
import torch
import numpy as np
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler, TensorDataset
from dstc.processors import (DSTCClassificationProcessor,
                             DSTCClassificationInputExample,
                             dstc_convert_examples_to_features,
                             dstc_convert_examples_to_features_with_pos,
                             dstc_convert_pair_examples_to_features)
from transformers import (
    WEIGHTS_NAME,
    AdamW,
    BertConfig,
    BertForSequenceClassification,
    BertTokenizer,
    RobertaConfig,
    RobertaForSequenceClassification,
    RobertaTokenizer,
    DistilBertConfig,
    DistilBertForSequenceClassification,
    DistilBertTokenizer,
    XLMConfig,
    XLMForSequenceClassification,
    XLMTokenizer,
    get_linear_schedule_with_warmup,
)
from transformers import xnli_output_modes as output_modes


logger = logging.getLogger(__name__)
dstc_processor = DSTCClassificationProcessor(
        "cat",
        use_tok=False,
        use_wide=False,
        label_file=None)


def _build_example(datum, guid=None):
    guid = datum["pairID"] if not guid else guid
    text_a = datum["sentence1"]
    text_b = datum["sentence2"]
    label = datum["gold_label"]
    return DSTCClassificationInputExample(
        guid=guid,
        text_a=text_a,
        text_b=text_b,
        wide_ids=None,
        label=label)


def load_and_cache_examples(args,
                            pred_data,
                            tokenizer=None):
    """
    args: argparse object
    pred_data: [each datum is a dict, with pairID, sentence1, sentence2, gold_label as keys]
    """
    # NOTE: make sure to set DSTCClassificationProcessor in main()!
    output_mode = "classification"
    label_list = dstc_processor.get_labels()

    examples = [_build_example(datum) for datum in pred_data]

    features = dstc_convert_examples_to_features(
        examples,
        tokenizer,
        label_list=label_list,
        max_length=args.max_seq_length,
        output_mode=output_mode,
        pad_on_left=False,
        pad_token=tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0],
        pad_token_segment_id=0,
        use_wide=args.use_wide,
        trunk_left=args.trunk_left,
    )

    # Convert to Tensors and build dataset
    all_input_ids = torch.tensor([f.input_ids for f in features],
                                 dtype=torch.long)
    all_attention_mask = torch.tensor([f.attention_mask for f in features],
                                      dtype=torch.long)
    all_token_type_ids = torch.tensor([f.token_type_ids for f in features],
                                      dtype=torch.long)
    if args.use_wide:
        all_wide_ids = torch.tensor([f.wide_ids for f in features],
                                    dtype=torch.float)
    if output_mode == "classification":
        all_labels = torch.tensor([f.label for f in features], dtype=torch.long)
    else:
        raise ValueError("No other `output_mode` for XNLI.")

    if args.use_wide:
        dataset = TensorDataset(all_input_ids, all_attention_mask,
                                all_token_type_ids, all_labels, all_wide_ids)
    else:
        dataset = TensorDataset(all_input_ids, all_attention_mask,
                                all_token_type_ids, all_labels)

    return dataset


def prepare_args(user_args, device="cpu"):
    parser = argparse.ArgumentParser()

    # Required parameters
    parser.add_argument(
        "--data_dir",
        default=None,
        type=str,
        help="The input data dir. Should contain the .tsv files (or other data files) for the task.",
    )
    parser.add_argument(
        "--train_file",
        default=None,
        type=str,
        help="The input training file. If a data dir is specified, will look for the file there"
        +
        "If no data dir or train/predict files are specified, will run with tensorflow_datasets.",
    )
    parser.add_argument(
        "--predict_file",
        default=None,
        type=str,
        help="The input evaluation file. If a data dir is specified, will look for the file there"
        +
        "If no data dir or train/predict files are specified, will run with tensorflow_datasets.",
    )
    parser.add_argument(
        "--output_prefix",
        default="",
        type=str,
        help="Prefix to pred_results.txt and eval_results.txt")
    parser.add_argument(
        "--model_type",
        default=None,
        type=str,
        help="Model type selected in the list: "
    )
    parser.add_argument(
        "--task_type",
        default="bool",
        type=str,
    )
    parser.add_argument(
        "--use_tok",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--model_name_or_path",
        default=None,
        type=str,
        help="Path to pre-trained model or shortcut name selected in the list: "
    )
    parser.add_argument(
        "--output_dir",
        default=None,
        type=str,
        help="The output directory where the model predictions and checkpoints will be written.",
    )

    # Other parameters
    parser.add_argument(
        "--use_layers",
        default=[],
        nargs="*",
        help="which layers to use for the classification task, [1, 11]")
    parser.add_argument(
        "--use_avg",
        default=False,
        action='store_true',
        help="use_avg for hidden states over all positions")
    parser.add_argument(
        "--output_hidden_states",
        default=False,
        action="store_true",
        help="output_hidden_states")
    parser.add_argument(
        "--output_attentions",
        default=False,
        action="store_true",
        help="output_attentions")
    parser.add_argument(
        "--config_name",
        default="",
        type=str,
        help="Pretrained config name or path if not the same as model_name")
    parser.add_argument(
        "--tokenizer_name",
        default="",
        type=str,
        help="Pretrained tokenizer name or path if not the same as model_name",
    )
    parser.add_argument(
        "--cache_dir",
        default="",
        type=str,
        help="Where do you want to store the pre-trained models downloaded from s3",
    )
    parser.add_argument(
        "--max_seq_length",
        default=128,
        type=int,
        help="The maximum total input sequence length after tokenization. Sequences longer "
        "than this will be truncated, sequences shorter will be padded.",
    )
    parser.add_argument(
        "--do_train", action="store_true", help="Whether to run training.")
    parser.add_argument(
        "--do_eval",
        action="store_true",
        help="Whether to run eval on the test set.")
    parser.add_argument(
        "--evaluate_during_training",
        action="store_true",
        help="Rul evaluation during training at each logging step.")
    parser.add_argument(
        "--do_lower_case",
        action="store_true",
        help="Set this flag if you are using an uncased model.")

    parser.add_argument(
        "--per_gpu_train_batch_size",
        default=8,
        type=int,
        help="Batch size per GPU/CPU for training.")
    parser.add_argument(
        "--per_gpu_eval_batch_size",
        default=8,
        type=int,
        help="Batch size per GPU/CPU for evaluation.")
    parser.add_argument(
        "--gradient_accumulation_steps",
        type=int,
        default=1,
        help="Number of updates steps to accumulate before performing a backward/update pass.",
    )
    parser.add_argument(
        "--wide_dimension", type=int, default=50, help="Wide feature size")
    parser.add_argument(
        "--use_wide",
        default=False,
        action="store_true",
        help="Whether use wide features")
    parser.add_argument(
        "--wide_weight",
        default=0.25,
        type=float,
        help="Weight of wide feature loss")
    parser.add_argument(
        "--wide_lr",
        default=1e-3,
        type=float,
        help="The initial learning rate for wide and deep classififer.")
    parser.add_argument(
        "--learning_rate",
        default=5e-5,
        type=float,
        help="The initial learning rate for Adam.")
    parser.add_argument(
        "--weight_decay",
        default=0.0,
        type=float,
        help="Weight decay if we apply some.")
    parser.add_argument(
        "--adam_epsilon",
        default=1e-8,
        type=float,
        help="Epsilon for Adam optimizer.")
    parser.add_argument(
        "--max_grad_norm", default=1.0, type=float, help="Max gradient norm.")
    parser.add_argument(
        "--num_train_epochs",
        default=3.0,
        type=float,
        help="Total number of training epochs to perform.")
    parser.add_argument(
        "--max_steps",
        default=-1,
        type=int,
        help="If > 0: set total number of training steps to perform. Override num_train_epochs.",
    )
    parser.add_argument(
        "--warmup_steps",
        default=0,
        type=int,
        help="Linear warmup over warmup_steps.")

    parser.add_argument(
        "--logging_steps",
        type=int,
        default=500,
        help="Log every X updates steps.")
    parser.add_argument(
        "--save_steps",
        type=int,
        default=500,
        help="Save checkpoint every X updates steps.")
    parser.add_argument(
        "--eval_all_checkpoints",
        action="store_true",
        help="Evaluate all checkpoints starting with the same prefix as model_name ending and ending with step number",
    )
    parser.add_argument(
        "--no_cuda",
        action="store_true",
        help="Avoid using CUDA when available")
    parser.add_argument(
        "--overwrite_output_dir",
        action="store_true",
        help="Overwrite the content of the output directory")
    parser.add_argument(
        "--overwrite_cache",
        action="store_true",
        help="Overwrite the cached training and evaluation sets")
    parser.add_argument(
        "--seed", type=int, default=42, help="random seed for initialization")

    parser.add_argument(
        "--fp16",
        action="store_true",
        help="Whether to use 16-bit (mixed) precision (through NVIDIA apex) instead of 32-bit",
    )
    parser.add_argument(
        "--fp16_opt_level",
        type=str,
        default="O1",
        help="For fp16: Apex AMP optimization level selected in ['O0', 'O1', 'O2', and 'O3']."
        "See details at https://nvidia.github.io/apex/amp.html",
    )
    parser.add_argument(
        "--local_rank",
        type=int,
        default=-1,
        help="For distributed training: local_rank")
    parser.add_argument(
        "--label_file",
        default="",
        type=str,
        help="Load labels for classification from this text file",
    )
    parser.add_argument(
        "--exp_name",
        default="run_{}".format(time.time()),
        type=str,
        help="Determines where the TF events file is saved",
    )
    parser.add_argument(
        "--max_query_seq_length",
        default=128,
        type=int,
        help="The max length of the query string.",
    )
    parser.add_argument(
        "--trunk_left",
        default=False,
        action='store_true',
        help="Trunk left part of strings, default is right")
    parser.add_argument(
        "--server_ip", type=str, default="", help="For distant debugging.")
    parser.add_argument(
        "--server_port", type=str, default="", help="For distant debugging.")
    args = parser.parse_args()
    for k in user_args:
        args.__setattr__(k, user_args[k])
    args.device = torch.device(device)
    return args


class ClassPredictor:
    def __init__(self, args):
        self.args = args
        self.labels = dstc_processor.get_labels()
        config_class = BertConfig
        model_class = BertForSequenceClassification
        tokenizer_class = BertTokenizer
        config = config_class.from_pretrained(
            args.model_name_or_path,
            num_labels=2
        )
        self.tokenizer = tokenizer_class.from_pretrained(
            args.model_name_or_path,
            do_lower_case=args.do_lower_case,
            cache_dir=None
        )
        self.model = model_class.from_pretrained(
            args.model_name_or_path,
            from_tf=False,
            config=config,
            cache_dir=None,
        )
        self.model.to(args.device)
        
    def predict(self, pred_data, batch_size=20):
        pred_dataset = load_and_cache_examples(self.args, pred_data, tokenizer=self.tokenizer)
        eval_sampler = SequentialSampler(pred_dataset)
        eval_dataloader = DataLoader(
            pred_dataset, sampler=eval_sampler, batch_size=batch_size)
        preds = None
        for batch in eval_dataloader:
            self.model.eval()
            batch = tuple(t.to(self.args.device) for t in batch)

            with torch.no_grad():
                inputs = {
                    "input_ids": batch[0],
                    "attention_mask": batch[1],
                    "labels": batch[3]
                }
                if self.args.model_type != "distilbert":
                    inputs["token_type_ids"] = (
                        batch[2] if self.args.model_type in ["bert"] else None
                    )  # XLM and DistilBERT don't use segment_ids
                outputs = self.model(**inputs)
                _, logits = outputs[:2]

            if preds is None:
                preds = logits.detach().cpu().numpy()
                out_label_ids = inputs["labels"].detach().cpu().numpy()
            else:
                preds = np.append(preds, logits.detach().cpu().numpy(), axis=0)
                out_label_ids = np.append(
                    out_label_ids,
                    inputs["labels"].detach().cpu().numpy(),
                    axis=0)
            
        probs = preds
        max_preds = np.argmax(preds, axis=1)
        labels = [self.labels[pred] for pred in max_preds.tolist()]
        return labels, probs            


class ZZHotProcessor:
    @staticmethod
    def preprocess(datum, max_size=20):
        """
        Expected input:
        {
            "text": [{"客服": "XXX"}, {"客户": "XXX"} ...]
        }
        Expected output:
        [each datum is a dict, with pairID, sentence1, sentence2, gold_label as keys]
        """
        sources = []
        result = []
        for item in datum["text"]:
            for k in item:
                sources.append(item[k])
        if max_size > 0:
            sources = sources[:max_size]
        for sent_id, sent in enumerate(sources):
            pairID = f"sent_{sent_id}"
            gold_label = "False"
            sent1 = "" if sent_id == 0 else sources[sent_id-1]
            sent2 = sent
            out_datum = {
                "gold_label": gold_label,
                "pairID": pairID,
                "sentence1": sent1,
                "sentence1_tokenized": sent1,
                "sentence2": sent2,
                "sentence2_tokenized": sent2
            }
            result.append(out_datum)
        return result

    @staticmethod
    def postprocess(datum, labels, probs, max_size=20):
        sources = []
        result = []
        for item in datum["text"]:
            for k in item:
                sources.append(item[k])
        if max_size > 0:
            sources = sources[:max_size]
        for label, utterance in zip(labels, sources):
            if label == "True":
                result.append(utterance)
        if not result and len(sources) > 1:
            result.append(sources[1])
        return {
            "input": datum["text"],
            "summ": result,
            "debug": "OK"
        }


def load_zzhot_args():
    user_args = {
        "model_name_or_path": "transformer_models/zzhot_xnli_zzhot_s48",
        "model_type": "bert",
        "task_type": "cat",
        "max_seq_length": 48
    }
    return prepare_args(user_args)


def run_zzhot():
    args = load_zzhot_args()
    predictor = ClassPredictor(args)
    test_file = ".data/zzhot/zz_summ_processed/test.jsonl"

    def jsonl_to_datum(jsonl_datum):
        text_data = [{"A": x} for x in jsonl_datum["src"]][:20]
        return {"text": text_data}

    with open(test_file) as input_:
        for line in input_:
            jsonl_datum = json.loads(line)
            input_datum = jsonl_to_datum(jsonl_datum)
            input_data = ZZHotProcessor.preprocess(input_datum)
            labels, probs = predictor.predict(input_data)
            result = ZZHotProcessor.postprocess(input_datum, labels, probs)
            logger.info(f"Prediction: {result}")


if __name__ == "__main__":
    run_zzhot()
