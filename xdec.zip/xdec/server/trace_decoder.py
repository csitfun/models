import torch
import random
import os
import numpy as np
from server.run import load_args
from s2s_ft.modeling_decoding import BertForSeq2SeqDecoder, BertConfig
from transformers.tokenization_bert import whitespace_tokenize
import s2s_ft.s2s_loader as seq2seq_loader
from server.s2s_predictor import TOKENIZER_CLASSES, S2SPredictor
from xdec_config import get_logger


logger = get_logger(__name__)


if __name__ == "__main__":
    user_args = {
        "model_type": "unilm",
        "do_lower_case": True,
        "model_path": "transformer_models/gsum_rbt3_200_50_lr1e-4_ep10_b192",
        "max_seq_length": 128,
        "max_tgt_length": 24,
        "batch_size": 1,
        "beam_size": 2,
        "length_penalty": 0,
        "mode": "s2s"
    }
    args = load_args(user_args=user_args)

    if args.need_score_traces and args.beam_size <= 1:
        raise ValueError(
            "Score trace is only available for beam search with beam size > 1."
        )
    if args.max_tgt_length >= args.max_seq_length - 2:
        raise ValueError("Maximum tgt length exceeds max seq length - 2.")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    n_gpu = torch.cuda.device_count()

    if args.seed > 0:
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        if n_gpu > 0:
            torch.cuda.manual_seed_all(args.seed)
    else:
        random_seed = random.randint(0, 10000)
        logger.info("Set random seed as: {}".format(random_seed))
        random.seed(random_seed)
        np.random.seed(random_seed)
        torch.manual_seed(random_seed)
        if n_gpu > 0:
            torch.cuda.manual_seed_all(args.seed)

    tokenizer = TOKENIZER_CLASSES[args.model_type].from_pretrained(
        args.model_path.strip(),
        do_lower_case=args.do_lower_case,
        cache_dir=args.cache_dir if args.cache_dir else None)

    if args.model_type == "roberta":
        vocab = tokenizer.encoder
    else:
        vocab = tokenizer.vocab

    logger.info("added_tokens_encoder = {}".format(
        tokenizer.added_tokens_encoder))

    tokenizer.max_len = args.max_seq_length

    config_file = args.config_path if args.config_path else os.path.join(
        args.model_path, "config.json")
    logger.info("Read decoding config from: %s" % config_file)
    config = BertConfig.from_json_file(config_file)

    bi_uni_pipeline = []
    vocab_words = list(vocab.keys())
    added_toks = sorted([(tokenizer.added_tokens_encoder[k], k)
                            for k in tokenizer.added_tokens_encoder])
    for _, added_tok in added_toks:
        vocab_words.append(added_tok)
    bi_uni_pipeline.append(
        seq2seq_loader.Preprocess4Seq2seqDecoder(
            vocab_words,  # old: list(vocab.keys()),
            tokenizer.convert_tokens_to_ids,
            args.max_seq_length,
            max_tgt_length=args.max_tgt_length,
            pos_shift=args.pos_shift,
            source_type_id=config.source_type_id,
            target_type_id=config.target_type_id,
            cls_token=tokenizer.cls_token,
            sep_token=tokenizer.sep_token,
            pad_token=tokenizer.pad_token))

    mask_word_id, eos_word_ids, sos_word_id = tokenizer.convert_tokens_to_ids(
        [tokenizer.mask_token, tokenizer.sep_token, tokenizer.sep_token])
    forbid_ignore_set = None
    if args.forbid_ignore_word:
        w_list = []
        for w in args.forbid_ignore_word.split('|'):
            if w.startswith('[') and w.endswith(']'):
                w_list.append(w.upper())
            else:
                w_list.append(w)
        forbid_ignore_set = set(tokenizer.convert_tokens_to_ids(w_list))
    logger.info(args.model_path)
    found_checkpoint_flag = False
    model_recover_path = args.model_path.strip()
    logger.info("***** Recover model: %s *****", model_recover_path)
    found_checkpoint_flag = True
    model = BertForSeq2SeqDecoder.from_pretrained(
        model_recover_path,
        config=config,
        mask_word_id=mask_word_id,
        search_beam_size=args.beam_size,
        length_penalty=args.length_penalty,
        eos_id=eos_word_ids,
        sos_id=sos_word_id,
        forbid_duplicate_ngrams=args.forbid_duplicate_ngrams,
        forbid_ignore_set=forbid_ignore_set,
        ngram_size=args.ngram_size,
        min_len=args.min_len,
        mode=args.mode,
        max_position_embeddings=args.max_seq_length,
        pos_shift=args.pos_shift,
    )

    scripted_module = torch.jit.script(model)

