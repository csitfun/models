from uuid import uuid4
from bottle import route, run, template, post, request, response
from wikisql.dianli_processors import (load_gold_and_table, build_table_column,
                                       build_column_map, build_paraphrases,
                                       parse_output, post_process2, process3,
                                       DIANLI3_PARAPHRASES_INVERSABLE,
                                       DIANLI3_PARAPHRASES_SELECT_INVERSABLE)
from wikisql.dianli_utils import GrammarExtractor
from server.s2s_predictor import TOKENIZER_CLASSES, S2SPredictor
from server.run import load_args
import traceback
import logging
import time

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

user_args = {
    "model_type": "unilm",
    "do_lower_case": True,
    # "model_path": "transformer_models/dianli3_0720_large_384_128_lr1e-4_ep500_b64/",
    # "model_path": "transformer_models/dianli3_0720_384_128_lr1e-4_ep100_b64/",
    # "model_path": "transformer_models/dianli3_0720_256_128_lr1e-4_ep500_b64_sm",
    # "model_path": "transformer_models/dianli3_0720_256_128_lr1e-4_ep500_b64_sm",
    "model_path": "transformer_models/dianli3_0720_96_32_lr1e-4_ep500_b64_xxs",
    "max_seq_length": 96,  # 384
    "max_tgt_length": 32,
    "batch_size": 1,
    "beam_size": 1,
    "length_penalty": 0,
    "mode": "s2s",
    "forbid_duplicate_ngrams": False
}
args = load_args(user_args=user_args)
model = S2SPredictor(args)
gold_data, table_data = load_gold_and_table(".data/dianli3/data0708.json")
column_map = build_column_map(table_data["column_name_en2cn"])
paraphrases = build_paraphrases(DIANLI3_PARAPHRASES_INVERSABLE)
select_paraphrases = build_paraphrases(DIANLI3_PARAPHRASES_SELECT_INVERSABLE)
extractor = GrammarExtractor(".data/dianli3/data0708.json",
                             ".data/dianli_resource/countries.info.json")


@route('/status')
def index(name):
    return "ok"


@post('/nl2sql')
def nl2sql_handler():
    debug = "OK"
    query = ""
    qid = uuid4()
    try:
        data = request.json
        query = data["query"]
        table_name = data["table"] if "table" in data else None
        table_details = {}
        if not table_name:
            table_name, table_details = extractor.select_table(query)
        time_stamp = data["timestamp"]
        if table_name == "t_epidemic_data":
            table_name = "tq_epidemic_data"
        table_name_en2cn = table_data["table_name_en2cn"]
        column_name_en2cn = table_data["column_name_en2cn"]
        final_sql, final_detail = process3(query, table_name, model, time_stamp,
                                           column_map, table_name_en2cn,
                                           column_name_en2cn, paraphrases,
                                           select_paraphrases)
        # tc_info, _ = build_table_column(table_name, table_name_en2cn, column_name_en2cn)
        # logger.info(f"Query [{qid}]: {query}")
        # final_query = query + tc_info
        # logger.info(f"Final query [{qid}]: {final_query}")
        # time1 = time.time()
        # sql_output = model.predict(final_query)
        # time2 = time.time()
        # logger.info(f"Predict time [{qid}]: {time2-time1}")
        # logger.info(f"SQL output [{qid}]: {sql_output}")
        # sql_output = parse_output(sql_output)
        # final_sql, final_detail = post_process2(query, sql_output, table_name, time_stamp,
        #     column_map, paraphrases, select_paraphrases)
        final_detail["tables"] = table_details
    except:
        traceback.print_exc()
        final_sql = ""
        final_detail = {}
        debug = "Error"
    result = {
        "question": query,
        "sql": final_sql,
        "detail": final_detail,
        "debug": debug
    }
    logger.info(f"Final result [{qid}]: {result}")
    return result


with open("ip.txt") as ip_file:
    hostname = ip_file.read().strip()
logger.info(f"Hostname: {hostname}")
run(host=hostname, port=18187)
