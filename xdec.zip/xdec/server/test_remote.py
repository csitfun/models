import requests
import json
from time import time
from tqdm import tqdm

# host = 'http://11.139.204.86:18280/summ'
host = 'http://localhost:18280/summ'
input_file = ".data/zj/test.clean.jsonl"
with open(input_file) as input_:
    lines = input_.readlines()[:200]
    for line in tqdm(lines):
        datum = json.loads(line)
        source = datum["src"]
        time1 = time()
        response = requests.post(host, json={"text": source})
        time2 = time()
        print(time2 - time1)
        print(response.json())
