import requests
import json
from time import time

host = 'http://11.139.204.86:18280/summ'
# host = 'http://localhost:18280/summ'

time1 = time()
response = requests.post(host, json={"text": "房子没有了，还侵占了我土地，我今年25岁，身份证号是：4293827305874382430283，我想要要回我的房子"})
time2 = time()
print(time2 - time1)
print(response.json())
