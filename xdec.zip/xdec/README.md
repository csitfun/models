# xdec2

**xdec2** is a set of NLP models/decoders and util functions based on the transformer family of models.

The original **xdec** is here: http://gitlab.alibaba-inc.com/alinli/xdec It currently focuses on dialogue tasks and is shared among Alibaba and Alipay colleagues.


## Dialogue tasks


## SQL generation



## Summarization

### Abstractive Summarization

Abstractive summrization modules are based on UniLM.

### Extractive Summarization



## Server


