# path of the fine-tuned checkpoint
MODEL_PATH=transformer_models/wikisql_unilm1.2_lr7e-5_ep5_b32_on_transformer_models/totto_pretrain_unilm1.2_lr2e-5_ep10_b32
# input file that you would like to decode
INPUT_JSON=.data/WikiSQL/seq2seq/dev.jsonl

python predict_seq2seq.py \
  --model_type unilm \
  --input_file ${INPUT_JSON} \
  --output_file ${MODEL_PATH}/dev.output.txt \
  --do_lower_case \
  --model_path ${MODEL_PATH} \
  --max_seq_length 512 \
  --max_tgt_length 256 \
  --batch_size 4 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s \
  --trunk_left
