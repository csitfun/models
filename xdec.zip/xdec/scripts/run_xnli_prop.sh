XNLI_DIR=.data/proptc
python -m xnli \
    --model_type roberta \
    --model_name_or_path roberta-base \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file train.jsonl \
    --predict_file dev.jsonl \
    --task_type proptc \
    --learning_rate 3e-5 \
    --num_train_epochs 5 \
    --max_seq_length 512 \
    --output_dir transformer_models/xnli_proptc_roberta \
    --label_file ${XNLI_DIR}/labels.txt \
    --per_gpu_eval_batch_size=8   \
    --per_gpu_train_batch_size=8   \
    --save_steps 5000

