SQUAD_DIR=.data/dstcslotall_dstc_20_non/
python -m squad \
    --model_type roberta \
    --model_name_or_path transformer_models/squad_final_noncat_roberta/ \
    --cache_dir .transformers_cache \
    --do_eval \
    --data_dir ${SQUAD_DIR} \
    --train_file squad.train.dstc.json \
    --predict_file squad.dev.dstc.json \
    --learning_rate 3e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --doc_stride 128 \
    --output_dir transformer_models/squad_final_noncat_roberta/ \
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 8 \
    --version_2_with_negative \
    --save_steps 10000 \
    --threads 8
