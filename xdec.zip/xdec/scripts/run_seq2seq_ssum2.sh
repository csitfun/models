# path of training data
TRAIN_FILE=.data/ssum/abstract200716.short.train.jsonl
TEST_FILE=.data/ssum/abstract200716.short.test.jsonl
# folder used to save fine-tuned checkpoints
PRE_EXP_NAME=gsum_base_ext_512_256_lr1e-4_ep10_b256
MODEL_DIR=transformer_models/${PRE_EXP_NAME}
OUTPUT_DIR=transformer_models/ssum2_short_b64_ep100_on_${PRE_EXP_NAME}
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3

python -m seq2seq \
  --train_file ${TRAIN_FILE} \
  --output_dir ${OUTPUT_DIR} \
  --model_type unilm \
  --model_name_or_path ${MODEL_DIR} \
  --do_lower_case \
  --max_source_seq_length 512 \
  --max_target_seq_length 256 \
  --per_gpu_train_batch_size 4 \
  --gradient_accumulation_steps 4 \
  --learning_rate 1e-4 \
  --num_warmup_steps 1000 \
  --num_training_epochs 100 \
  --save_steps 5000 \
  --cache_dir ${CACHE_DIR}

python predict_seq2seq.py \
  --model_type unilm \
  --input_file ${TEST_FILE} \
  --output_file ${OUTPUT_DIR}/test.output.txt \
  --do_lower_case \
  --model_path ${OUTPUT_DIR} \
  --max_seq_length 512 \
  --max_tgt_length 256 \
  --batch_size 16 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s \
  --forbid_duplicate_ngrams \
  --ngram_size 4

python -m summ.cli rouge_eval \
  --gold_file_name ${TEST_FILE} \
  --pred_file_name ${OUTPUT_DIR}/test.output.txt 2>&1 | tee ${OUTPUT_DIR}/eval.log
