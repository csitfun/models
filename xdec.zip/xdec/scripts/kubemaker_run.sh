set -x
BASE=/kubemaker/code
SRC=xdec
STORE='oss://csrobotmng-oss-dev/public_area/alipay-search-service/antassistant/haitao.mi/transformer_models'
OSS='/kubemaker/code/tools/ossutil64 --config-file=/kubemaker/code/tools/.ossutilconfig'
SCRIPT=$1
DIR=$2

export LC_ALL=C.UTF-8
export LANG=C.UTF-8

cd ${BASE}
DEPS='install.tgz'
${OSS} cp ${STORE}/${DEPS} ${DEPS}
tar -xzf ${DEPS}
ls install

cli=click-6.7-py2.py3-none-any.whl
regex=regex-2020.4.4-cp36-cp36m-manylinux1_x86_64.whl
sacremoses=sacremoses-0.0.41.tar.gz
sentpic=sentencepiece-0.1.86-cp36-cp36m-manylinux1_x86_64.whl
tok=tokenizers-0.0.11-cp36-cp36m-manylinux1_x86_64.whl
joblib=joblib-0.14.1-py2.py3-none-any.whl
transformers=transformers-2.4.1-py3-none-any.whl
nltk=nltk-3.5.zip
tensorboardX=tensorboardX-2.0-py2.py3-none-any.whl
truecase=truecase-0.0.8-py3-none-any.whl
fuzzywuzzy=fuzzywuzzy-0.18.0-py2.py3-none-any.whl
pylen=python-Levenshtein-0.12.0.tar.gz
proto=protobuf-3.11.3-cp36-cp36m-manylinux1_x86_64.whl
word2number=word2number-1.1.zip
for dep in ${cli} ${regex} ${joblib} ${sacremoses} ${sentpic} ${tok} ${transformers} ${nltk} ${proto} ${tensorboardX} ${truecase} ${fuzzywuzzy} ${pylen} ${word2number}
do
    pip install ${BASE}/install/${dep}
done

ALIYUN='-i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com'
pip install pyspellchecker $ALIYUN

cd $BASE/${SRC}
echo "######################################################"
# download data from oss
for d in transformers_cache.tgz data.tgz
do
    ${OSS} cp ${STORE}/${d} ${d}
    tar -xzf ${d}
done 

echo "######################################################"
nvcc --version
nvidia-smi
python --version
python -c "import torch; print(torch.__version__)"
python -c "import torch; print(torch.cuda.is_available())"
python -c 'import tensorflow as tf; print(tf.__version__)'
echo "######################################################"

echo "-----START TRAININT-----"
bash $SCRIPT
echo "-----TRAININT DONE------"
cd transformer_models
for ck in 40000 80000
do
    rm -rf ${DIR}/checkpoint-${ck}
done
tar -czf ${DIR}.tgz ${DIR}
# copy output to oss
${OSS} cp -f ${DIR}.tgz ${STORE}/${DIR}.tgz
echo "------DONE-----"
