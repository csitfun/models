# path of training data
TRAIN_FILE=.data/dianli/dianli-nl2sql/train.dianli.jsonl
SPECIAL_TOKEN_FILE=.data/dianli/dianli-nl2sql/train.dianli.jsonlspeicial_tokens.json
# folder used to save fine-tuned checkpoints
OUTPUT_DIR=transformer_models/dianli_rbtl3_890_128_lr1e-4_ep100_b64
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3

python -m seq2seq \
  --train_file ${TRAIN_FILE} \
  --output_dir ${OUTPUT_DIR} \
  --model_type unilm \
  --model_name_or_path hfl/rbtl3 \
  --do_lower_case \
  --max_source_seq_length 890 \
  --max_target_seq_length 128 \
  --per_gpu_train_batch_size 4 \
  --gradient_accumulation_steps 4 \
  --learning_rate 1e-4 \
  --num_warmup_steps 1000 \
  --num_training_epochs 100 \
  --save_steps 5000 \
  --special_token_file ${SPECIAL_TOKEN_FILE} \
  --cache_dir ${CACHE_DIR}
