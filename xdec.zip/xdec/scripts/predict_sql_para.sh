# path of the fine-tuned checkpoint
MODEL_PATH=transformer_models/seq_qgen_sql_para_simple/ckpt-64000
# input file that you would like to decode
INPUT_FILE=parasql/dev.jsonl
OUTPUT_FILE=parasql/dev.output.jsonl

python predict_seq2seq.py \
  --fp16 --model_type unilm --tokenizer_name unilm1.2-base-uncased --input_file ${INPUT_FILE} \
  --output_file ${OUTPUT_FILE} --do_lower_case \
  --model_path ${MODEL_PATH} --max_seq_length 384 --max_tgt_length 128 --batch_size 4 --beam_size 5 \
  --length_penalty 0 --forbid_duplicate_ngrams --mode s2s --forbid_ignore_word "."
