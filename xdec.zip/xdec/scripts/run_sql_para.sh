# path of training data
TRAIN_FILE=parasql/train.jsonl
# folder used to save fine-tuned checkpoints
OUTPUT_DIR=transformer_models/seq_qgen_sql_para_simple
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3
# python -m torch.distributed.launch --nproc_per_node=4 run_seq2seq.py \
python -m seq2seq \
  --train_file ${TRAIN_FILE} --output_dir ${OUTPUT_DIR} \
  --model_type unilm --model_name_or_path unilm1.2-base-uncased \
  --do_lower_case --max_source_seq_length 196 --max_target_seq_length 196 \
  --per_gpu_train_batch_size 8 --gradient_accumulation_steps 2 \
  --learning_rate 7e-5 --num_warmup_steps 500 --num_training_steps 64000 --cache_dir ${CACHE_DIR}
