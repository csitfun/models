XNLI_DIR=dstc-xnli
python -m xnli \
    --model_type roberta_wd \
    --model_name_or_path transformer_models/xnli_final_num_norm_feats_roberta \
    --cache_dir .transformers_cache \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file xnli.train.final.num.norm.feats.jsonl.gz \
    --predict_file xnli.dev.final.num.norm.feats.jsonl.gz \
    --task_type cat \
    --learning_rate 2e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --use_wide \
    --use_tok \
    --wide_dimension 30 \
    --wide_weight 0.5 \
    --wide_lr 2e-5 \
    --output_dir transformer_models/xnli_final_num_norm_feats_roberta \
    --per_gpu_eval_batch_size=8   \
    --per_gpu_train_batch_size=8   \
    --eval_all_checkpoints \
    --save_steps 20000

python -m dstc.cli compute_f1 --slot_type categorical \
     --input_file transformer_models/xnli_final_num_norm_feats_roberta/pred_results.txt \
     --ref_file .data/dstcslotall_final_num/val.jsonl.gz
