#!/usr/bin/env bash

STANFORD_NLP_DIR="${HOME}/work"
PUNKT_DIR="${HOME}/nltk_data/tokenizers"

mkdir -p ${STANFORD_NLP_DIR}
mkdir -p ${PUNKT_DIR}

cd ${STANFORD_NLP_DIR}
wget http://nlp.stanford.edu/software/stanford-corenlp-full-2018-10-05.zip
unzip stanford-corenlp-full-2018-10-05.zip
cd -

cd ${PUNKT_DIR}
wget https://raw.githubusercontent.com/nltk/nltk_data/gh-pages/packages/tokenizers/punkt.zip
unzip punkt.zip
cd -
