SQUAD_DIR=mwoz-squad
python -m squad \
    --model_type roberta \
    --model_name_or_path transformer_models/dialog_mlm_all_roberta \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${SQUAD_DIR} \
    --train_file squad.train.multiwozonly.json \
    --predict_file squad.dev.multiwozonly.json \
    --learning_rate 3e-5 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --doc_stride 128 \
    --output_dir transformer_models/roberta_after_pretrain_mwoz_0408 \
    --per_gpu_eval_batch_size=8   \
    --per_gpu_train_batch_size=8   \
    --version_2_with_negative \
    --save_steps 10000 \
    --threads 8
