# path of training data
TRAIN_FILE=.data/WikiSQL/seq2seq/train.jsonl
SPECIAL_TOKEN_FILE=.data/WikiSQL/seq2seq/train.special_tokens.json
# folder used to save fine-tuned checkpoints
OUTPUT_DIR=transformer_models/wikisql_unilm1.2_lr7e-5_ep10_b32
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3

python -m seq2seq \
  --train_file ${TRAIN_FILE} \
  --output_dir ${OUTPUT_DIR} \
  --model_type unilm \
  --model_name_or_path unilm1.2-base-uncased \
  --do_lower_case \
  --max_source_seq_length 256 \
  --max_target_seq_length 256 \
  --per_gpu_train_batch_size 4 \
  --gradient_accumulation_steps 4 \
  --learning_rate 7e-5 \
  --num_warmup_steps 1000 \
  --num_training_epochs 10 \
  --save_steps 5000 \
  --special_token_file ${SPECIAL_TOKEN_FILE} \
  --trunk_left \
  --cache_dir ${CACHE_DIR}
