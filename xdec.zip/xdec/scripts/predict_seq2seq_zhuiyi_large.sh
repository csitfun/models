# path of the fine-tuned checkpoint
MODEL_PATH=transformer_models/zhuiyi_num_norm2_bertext_lr7e-5_s384_t128_ep50_b64
# input file that you would like to decode
INPUT_JSON=.data/zhuiyi/val.s2s.num_norm.json

python predict_seq2seq.py \
  --model_type unilm \
  --input_file ${INPUT_JSON} \
  --output_file ${MODEL_PATH}/val.output.txt \
  --do_lower_case \
  --model_path ${MODEL_PATH} \
  --max_seq_length 384 \
  --max_tgt_length 128 \
  --batch_size 32 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s

python -m wikisql.cli zhuiyi_eval \
  --pred_file_name ${MODEL_PATH}/val.output.txt
