DATASET=val
# path of training data
INPUT_JSON=.data/chip20/${DATASET}_processed.jsonl
SPECIAL_TOKEN_FILE=.data/chip20/special_tokens.json
# folder used to save fine-tuned checkpoints
MODEL_DIR=transformer_models/chip20_large_lr7e-5_s512_t128_ep50_b96
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3

python predict_seq2seq.py \
  --input_file ${INPUT_JSON} \
  --output_file ${MODEL_DIR}/${DATASET}.output.txt \
  --model_type unilm \
  --model_path ${MODEL_DIR} \
  --do_lower_case \
  --max_seq_length 512 \
  --max_tgt_length 256 \
  --batch_size 16 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s
