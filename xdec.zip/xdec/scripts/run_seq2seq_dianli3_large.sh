# path of training data
TRAIN_FILE=.data/dianli3/train_0720.jsonl
TEST_FILE=.data/dianli3/test_0720.jsonl
SPECIAL_TOKEN_FILE=.data/dianli/dianli-nl2sql/train.dianli2.special_tokens.json
# folder used to save fine-tuned checkpoints
OUTPUT_DIR=transformer_models/dianli3_0720_large_890_196_lr1e-4_ep1000_b64
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3
# trained model name: transformer_models/dianli2_rbtl3_890_128_lr1e-4_ep100_b64 \

# python -m seq2seq \
#   --train_file ${TRAIN_FILE} \
#   --output_dir ${OUTPUT_DIR} \
#   --model_type unilm \
#   --model_name_or_path hfl/chinese-bert-wwm-ext \
#   --do_lower_case \
#   --max_source_seq_length 890 \
#   --max_target_seq_length 196 \
#   --per_gpu_train_batch_size 2 \
#   --gradient_accumulation_steps 8 \
#   --learning_rate 1e-4 \
#   --num_warmup_steps 1000 \
#   --num_training_epochs 1000 \
#   --save_steps 1000 \
#   --special_token_file ${SPECIAL_TOKEN_FILE} \
#   --cache_dir ${CACHE_DIR}

# python predict_seq2seq.py \
#   --model_type unilm \
#   --input_file ${TEST_FILE} \
#   --output_file ${OUTPUT_DIR}/test.output.txt \
#   --do_lower_case \
#   --model_path ${OUTPUT_DIR} \
#   --max_seq_length 890 \
#   --max_tgt_length 196 \
#   --batch_size 8 \
#   --beam_size 5 \
#   --length_penalty 0 \
#   --mode s2s 

# python -m wikisql.cli jsonl_str_eval \
#   --gold_file_name ${TEST_FILE} \
#   --pred_file_name ${OUTPUT_DIR}/test.output.txt

for step in 1000 2000 3000 4000 5000 6000 7000 8000 9000 10000 11000 12000
do
    STEP_DIR=${OUTPUT_DIR}/ckpt-${step}
    echo ${STEP_DIR}
    python predict_seq2seq.py \
      --model_type unilm \
      --input_file ${TEST_FILE} \
      --output_file ${STEP_DIR}/test.output.txt \
      --do_lower_case \
      --model_path ${STEP_DIR} \
      --max_seq_length 890 \
      --max_tgt_length 196 \
      --batch_size 8 \
      --beam_size 5 \
      --length_penalty 0 \
      --mode s2s 
      # --forbid_duplicate_ngrams \
      # --ngram_size 6

    python -m wikisql.cli jsonl_str_eval \
      --gold_file_name ${TEST_FILE} \
      --pred_file_name ${STEP_DIR}/test.output.txt
done