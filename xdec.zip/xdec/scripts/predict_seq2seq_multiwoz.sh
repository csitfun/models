# path of the fine-tuned checkpoint
MODEL_PATH=transformer_models/seq_gen_multiwoz
# input file that you would like to decode
INPUT_JSON=.data/gen_multiwoz/gen_test.jsonl
OUTPUT_FILE=transformer_models/seq_gen_multiwoz


for i in 51000 48000 45000 42000 39000 36000 33000 30000 27000 21000
do 
  python predict_seq2seq.py \
    --fp16 --model_type unilm \
    --tokenizer_name unilm1.2-base-uncased \
    --input_file ${INPUT_JSON} \
    --output_file ${OUTPUT_FILE}/ckpt-${i}/test.output.txt \
    --do_lower_case \
    --model_path ${MODEL_PATH}/ckpt-${i} \
    --max_seq_length 640 \
    --max_tgt_length 128 \
    --batch_size 6 \
    --beam_size 5 \
    --length_penalty 0 \
    --forbid_duplicate_ngrams \
    --mode s2s \
    --trunk_left \
    --forbid_ignore_word "."
done