# path of training data
TRAIN_FILE=.data/dianli5/train.jsonl
TEST_FILE=.data/dianli5/test.jsonl
SPECIAL_TOKEN_FILE=.data/dianli/dianli-nl2sql/train.dianli2.special_tokens.json
# folder used to save fine-tuned checkpoints
OUTPUT_DIR=transformer_models/dianli5_0826_large_384_128_lr1e-4_ep10_b64
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3
# trained model name: transformer_models/dianli2_rbtl_890_128_lr1e-4_ep100_b64 \

python -m seq2seq \
  --train_file ${TRAIN_FILE} \
  --output_dir ${OUTPUT_DIR} \
  --model_type unilm \
  --model_name_or_path hfl/chinese-bert-wwm-ext \
  --do_lower_case \
  --max_source_seq_length 384 \
  --max_target_seq_length 128 \
  --per_gpu_train_batch_size 2 \
  --gradient_accumulation_steps 8 \
  --learning_rate 1e-4 \
  --num_warmup_steps 500 \
  --num_training_epochs 10 \
  --save_steps 5000 \
  --special_token_file ${SPECIAL_TOKEN_FILE} \
  --cache_dir ${CACHE_DIR}

python predict_seq2seq.py \
  --model_type unilm \
  --input_file ${TEST_FILE} \
  --output_file ${OUTPUT_DIR}/test.output.txt \
  --do_lower_case \
  --model_path ${OUTPUT_DIR} \
  --max_seq_length 384 \
  --max_tgt_length 128 \
  --batch_size 8 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s 

python -m wikisql.cli jsonl_str_eval \
  --gold_file_name ${TEST_FILE} \
  --pred_file_name ${OUTPUT_DIR}/test.output.txt

# for step in 1000 2000 3000 4000 5000
# do
#     STEP_DIR=${OUTPUT_DIR}/ckpt-${step}
#     echo ${STEP_DIR}
#     python predict_seq2seq.py \
#       --model_type unilm \
#       --input_file ${TEST_FILE} \
#       --output_file ${STEP_DIR}/test.output.txt \
#       --do_lower_case \
#       --model_path ${STEP_DIR} \
#       --max_seq_length 890 \
#       --max_tgt_length 196 \
#       --batch_size 8 \
#       --beam_size 5 \
#       --length_penalty 0 \
#       --mode s2s 
#       # --forbid_duplicate_ngrams \
#       # --ngram_size 6

#     python -m wikisql.cli jsonl_str_eval \
#       --gold_file_name ${TEST_FILE} \
#       --pred_file_name ${STEP_DIR}/test.output.txt
# done
