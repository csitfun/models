LM_DIR=.data/WikiSQL/seq2seq
EXP_NAME=wikisql_gpt2_7e-5_ep10_b32
python -m lm \
    --model_type gpt2 \
    --model_name_or_path gpt2 \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --train_data_file ${LM_DIR}/train.txt \
    --eval_data_file ${LM_DIR}/dev.txt \
    --learning_rate 7e-5 \
    --num_train_epochs 10 \
    --output_dir transformer_models/${EXP_NAME} \
    --per_gpu_eval_batch_size=4   \
    --per_gpu_train_batch_size=4   \
    --gradient_accumulation_steps 2 \
    --line_by_line \
    --special_token_file ${LM_DIR}/train.special_tokens.json \
    --block_size 512 \
    --save_steps 5000

bash scripts/predict_lm_gpt.sh ${EXP_NAME}
python -m wikisql.cli str_eval --pred_file_name transformer_models/${EXP_NAME}/output/dev.output.txt
