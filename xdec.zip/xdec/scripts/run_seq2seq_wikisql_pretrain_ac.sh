# path of training data
TRAIN_FILE=.data/totto/totto_pretrain_v2_sample.jsonl
SPECIAL_TOKEN_FILE=.data/WikiSQL/seq2seq_ac/train.ac.special_tokens.json
# folder used to save fine-tuned checkpoints
OUTPUT_DIR=transformer_models/totto_v2_ac_unilm1.2_lr2e-5_ep1_b64
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3

echo "PROGRESS TRAINING"

python -m seq2seq \
  --train_file ${TRAIN_FILE} \
  --output_dir ${OUTPUT_DIR} \
  --model_type unilm \
  --model_name_or_path unilm1.2-base-uncased \
  --do_lower_case \
  --max_source_seq_length 512 \
  --max_target_seq_length 256 \
  --per_gpu_train_batch_size 4 \
  --gradient_accumulation_steps 2 \
  --learning_rate 7e-5 \
  --num_warmup_steps 1000 \
  --num_training_epochs 5 \
  --save_steps 5000 \
  --special_token_file ${SPECIAL_TOKEN_FILE} \
  --cache_dir ${CACHE_DIR}

MODEL_PATH=${OUTPUT_DIR}
INPUT_JSON=.data/WikiSQL/seq2seq_ac/dev.ac.jsonl

echo "PROGRESS PREDICTION"

python predict_seq2seq.py \
  --model_type unilm \
  --input_file ${INPUT_JSON} \
  --output_file ${MODEL_PATH}/dev.output.txt \
  --do_lower_case \
  --model_path ${MODEL_PATH} \
  --max_seq_length 512 \
  --max_tgt_length 256 \
  --batch_size 36 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s

echo "PROGRESS STRING TO LOGICAL FORM"

python -m wikisql.cli str_to_lf \
    --query_file_name .data/WikiSQL/data/dev.jsonl \
    --input_file_name ${MODEL_PATH}/dev.output.txt \
    --output_file_name ${MODEL_PATH}/dev.output.lf.jsonl

echo "PROGRESS EVALUATION"

python -m wikisql.evaluate \
    .data/WikiSQL/data/dev.jsonl \
    .data/WikiSQL/data/dev.db \
    ${MODEL_PATH}/dev.output.lf.jsonl &> ${MODEL_PATH}/eval.log
