XNLI_DIR=dstc-xnli/multiwoz_act/dstcslotall_multiwozonly_act_20_cat
EXP_NAME=xnli_mwoz_roberta_nonone_ep1
echo "Logging ${EXP_NAME}"
python -m xnli \
    --model_type roberta \
    --model_name_or_path roberta-base \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file xnli.train.multiwozonly_act.nonone.jsonl \
    --predict_file xnli.dev.multiwozonly_act.nonone.jsonl \
    --task_type cat \
    --learning_rate 2e-5 \
    --exp_name ${EXP_NAME} \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --output_dir transformer_models/${EXP_NAME} \
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 8 \
    --gradient_accumulation_steps 2 \
    --save_steps 5000
