EXP_NAME=xnli_mwoz_roberta_poscls_b64
XNLI_DIR=dstc-xnli/multiwoz_act/dstcslotall_multiwozonly_act_20_cat
echo "Logging ${EXP_NAME}"
python -m xnli \
    --model_type roberta_pos \
    --model_name_or_path roberta-base \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --exp_name ${EXP_NAME} \
    --train_file xnli.train.multiwozonly_act.jsonl.gz \
    --predict_file xnli.test.multiwozonly_act.jsonl.gz \
    --task_type cat \
    --learning_rate 2e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --output_dir transformer_models/${EXP_NAME} \
    --per_gpu_eval_batch_size 16 \
    --per_gpu_train_batch_size 16 \
    --seed 42 \
    --save_steps 10000
