# path of training data
TRAIN_FILE=.data/sogou/s2s.maxlen190.jsonl
# folder used to save fine-tuned checkpoints
OUTPUT_DIR=transformer_models/gsum_rbtl3_196_128_lr2e-5_ep1_b128_500k_complete
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3

python -m seq2seq \
  --train_file ${TRAIN_FILE} \
  --output_dir ${OUTPUT_DIR} \
  --model_type unilm \
  --model_name_or_path hfl/rbtl3 \
  --do_lower_case \
  --max_source_seq_length 196 \
  --max_target_seq_length 128 \
  --per_gpu_train_batch_size 8 \
  --gradient_accumulation_steps 4 \
  --learning_rate 2e-5 \
  --num_warmup_steps 1000 \
  --num_training_epochs 1 \
  --save_steps 5000 \
  --cache_dir ${CACHE_DIR}
