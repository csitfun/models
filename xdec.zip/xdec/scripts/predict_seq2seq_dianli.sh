# input file that you would like to decode
INPUT_JSON=.data/dianli/dianli-nl2sql/test.dianli.jsonl
# folder used to save fine-tuned checkpoints
MODEL_PATH=transformer_models/dianli2_rbtl3_890_128_lr1e-4_ep100_b64

python predict_seq2seq.py \
  --model_type unilm \
  --input_file ${INPUT_JSON} \
  --output_file ${MODEL_PATH}/test.output.txt \
  --do_lower_case \
  --model_path ${MODEL_PATH} \
  --max_seq_length 890 \
  --max_tgt_length 128 \
  --batch_size 16 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s \
  --forbid_duplicate_ngrams \
  --ngram_size 6

python -m wikisql.cli jsonl_str_eval \
  --gold_file_name .data/dianli/dianli-nl2sql/test.dianli.jsonl \ 
  --pred_file_name ${MODEL_PATH}/test.output.txt
