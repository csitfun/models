python -m schema_guided_dst.evaluate \
    --prediction_dir .data/merge_multiwoz/multiwozonly_base_test \
    --dstc8_data_dir  .data/merge_source/multiwoz2.1_dontcare/data/all_multiwoz_only_cat/ \
    --eval_set test \
    --eval_type test \
    --output_metric_file log_output_metrics.json