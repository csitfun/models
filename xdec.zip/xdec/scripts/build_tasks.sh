#!/bin/bash
set -e

exp_name=$1

TURN_ROUNDS=20
INPUT_DIR=".data/dstc/data/all_pos_norm_phone"
OUTPUT_DIR=".data/dstcslotall_${exp_name}_${TURN_ROUNDS}"
PY_MAIN="dstc.cli"
echo "Input dir: ${INPUT_DIR}"

DUMP_DONTCARE="" # "--dontcare" will dump dontcare class for cat and num slots
dir=$(pwd)
    
mkdir -p ${OUTPUT_DIR}
mkdir -p ${OUTPUT_DIR}_non
mkdir -p ${OUTPUT_DIR}_num
mkdir -p ${OUTPUT_DIR}_bool
mkdir -p ${OUTPUT_DIR}_cat

if [[ ${DUMP_DONTCARE} == '--dontcare' ]]
then
    mkdir -p ${OUTPUT_DIR}_dont
fi

for d in train dev test
do 
    python -m ${PY_MAIN} build_examples --turn_rounds ${TURN_ROUNDS} \
        --input_path ${INPUT_DIR}/${d} \
        --output ${OUTPUT_DIR}/${d}.jsonl \
        --add_back_trans --service_des ${DUMP_DONTCARE} \
        >& logs/log.${exp_name}.buildexamples.${d} 
    gzip -f ${OUTPUT_DIR}/${d}.jsonl

    # non categorical slots
    zcat ${OUTPUT_DIR}/${d}.jsonl.gz | grep "slot_type\": \"noncategorical" \
        | gzip >${OUTPUT_DIR}_non/${d}.jsonl.gz
    python -m ${PY_MAIN} dstc_to_squad \
        --input_file ${OUTPUT_DIR}_non/${d}.jsonl.gz \
        --output_file ${OUTPUT_DIR}_non/squad.${d}.${exp_name}.json \
        >& logs/log.${exp_name}.dstc_to_squad_${d}
    gzip -f ${OUTPUT_DIR}_non/squad.${d}.${exp_name}.json

    # numerical slots
    zcat ${OUTPUT_DIR}/${d}.jsonl.gz | grep "slot_type\": \"number" \
        | sed "s/task_type\": \[0, 0, 1\]/task_type\": \[1, 0, 1\]/g" \
        | gzip >${OUTPUT_DIR}_num/${d}.jsonl.gz
    if [[ ${d} == 'train' ]]
    then
        python -m ${PY_MAIN} gen_features \
            --input_file ${OUTPUT_DIR}_num/${d}.jsonl.gz \
            --output_file ${OUTPUT_DIR}_num/feature.json 

        python -m ${PY_MAIN} down_sample \
            --input_jsonl_file ${OUTPUT_DIR}_num/${d}.jsonl.gz \
            --output_jsonl_file ${OUTPUT_DIR}_num/${d}.ds.jsonl \
            --use_false
        gzip -f ${OUTPUT_DIR}_num/${d}.ds.jsonl

        python -m ${PY_MAIN} dstc_to_xnli --norm_num \
            --input_file ${OUTPUT_DIR}_num/${d}.ds.jsonl.gz \
            --output_file ${OUTPUT_DIR}_num/xnli.${d}.ds.${exp_name}.jsonl \
            --feature_file ${OUTPUT_DIR}_num/feature.json \
            --feature_dimension 30 --min_count 20
        gzip -f ${OUTPUT_DIR}_num/xnli.${d}.ds.${exp_name}.jsonl

    fi
    python -m ${PY_MAIN} dstc_to_xnli --norm_num \
        --input_file ${OUTPUT_DIR}_num/${d}.jsonl.gz \
        --output_file ${OUTPUT_DIR}_num/xnli.${d}.${exp_name}.jsonl \
        --feature_file ${OUTPUT_DIR}_num/feature.json \
        --feature_dimension 30 --min_count 20
    gzip -f ${OUTPUT_DIR}_num/xnli.${d}.${exp_name}.jsonl

    # categorical slots
    zcat ${OUTPUT_DIR}/${d}.jsonl.gz | grep "slot_type\": \"categorical" \
        | sed "s/task_type\": \[0, 0, 1\]/task_type\": \[1, 0, 1\]/g" \
        | gzip >${OUTPUT_DIR}_cat/${d}.jsonl.gz
    if [[ ${d} == 'train' ]]
    then
        python -m ${PY_MAIN} gen_features \
            --input_file ${OUTPUT_DIR}_cat/${d}.jsonl.gz \
            --output_file ${OUTPUT_DIR}_cat/feature.json 

        python -m ${PY_MAIN} down_sample \
            --input_jsonl_file ${OUTPUT_DIR}_cat/${d}.jsonl.gz \
            --output_jsonl_file ${OUTPUT_DIR}_cat/${d}.ds.jsonl \
            --use_false
        gzip -f ${OUTPUT_DIR}_cat/${d}.ds.jsonl

        python -m ${PY_MAIN} dstc_to_xnli \
            --input_file ${OUTPUT_DIR}_cat/${d}.ds.jsonl.gz \
            --output_file ${OUTPUT_DIR}_cat/xnli.${d}.ds.${exp_name}.jsonl \
            --feature_file ${OUTPUT_DIR}_cat/feature.json \
            --feature_dimension 30 --min_count 20
        gzip -f ${OUTPUT_DIR}_cat/xnli.${d}.ds.${exp_name}.jsonl

    fi
    python -m ${PY_MAIN} dstc_to_xnli \
        --input_file ${OUTPUT_DIR}_cat/${d}.jsonl.gz \
        --output_file ${OUTPUT_DIR}_cat/xnli.${d}.${exp_name}.jsonl \
        --feature_file ${OUTPUT_DIR}_cat/feature.json \
        --feature_dimension 30 --min_count 20
    gzip -f ${OUTPUT_DIR}_cat/xnli.${d}.${exp_name}.jsonl

    # boolean slots
    zcat ${OUTPUT_DIR}/${d}.jsonl.gz | grep "slot_type\": \"boolean" \
        | sed "s/task_type\": \[0, 1, 0\]/task_type\": \[1, 1, 0\]/g" \
        | gzip >${OUTPUT_DIR}_bool/${d}.jsonl.gz
    python -m ${PY_MAIN} dstc_to_xnli \
        --input_file ${OUTPUT_DIR}_bool/${d}.jsonl.gz \
        --output_file ${OUTPUT_DIR}_bool/xnli.${d}.${exp_name}.jsonl
    gzip -f ${OUTPUT_DIR}_bool/xnli.${d}.${exp_name}.jsonl

    # dontcare class
    if [[ ${DUMP_DONTCARE} == '--dontcare' ]]
    then
        python -m ${PY_MAIN} dstc_to_xnli \
            --input_file ${OUTPUT_DIR}/${d}.jsonl.gz \
            --output_file ${OUTPUT_DIR}_dont/xnli.${d}.${exp_name}.jsonl \
            --dontcare \
            --dontcare_file ${OUTPUT_DIR}_dont/${d}.jsonl \
            --feature_file ""
        gzip -f ${OUTPUT_DIR}_dont/xnli.${d}.${exp_name}.jsonl
        gzip -f ${OUTPUT_DIR}_dont/${d}.jsonl
    fi
done


