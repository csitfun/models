XNLI_DIR=.data/dstcslotall_multiwozonly_care_20_dont/
python -m xnli \
    --model_type roberta \
    --model_name_or_path roberta-base \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file xnli.train.dontcare.jsonl.gz \
    --predict_file xnli.test.dontcare.jsonl.gz \
    --task_type cat \
    --learning_rate 2e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --gradient_accumulation_steps 2 \
    --output_dir transformer_models/xnli_multiwozonly_dontcare_roberta \
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 8 \
    --overwrite_output_dir \
    --save_steps 2500

python -m dstc.cli compute_f1 --slot_type categorical \
     --input_file transformer_models/xnli_multiwozonly_dontcare_roberta/pred_results.txt \
     --ref_file .data/dstcslotall_multiwozonly_care_20_dont/test.jsonl.gz
