# path of the fine-tuned checkpoint
MODEL_PATH=transformer_models/gsum_rbtl3_512_128_lr1e-4_ep5_b128
# input file that you would like to decode
INPUT_JSON=.data/asrsum/live.test.jsonl

python predict_seq2seq.py \
  --model_type unilm \
  --input_file ${INPUT_JSON} \
  --output_file ${MODEL_PATH}/test.gsum_live.output.txt \
  --do_lower_case \
  --model_path ${MODEL_PATH} \
  --max_seq_length 512 \
  --max_tgt_length 128 \
  --batch_size 64 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s \
  --forbid_duplicate_ngrams \
  --ngram_size 4

