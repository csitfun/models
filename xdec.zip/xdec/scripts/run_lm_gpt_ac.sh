LM_DIR=.data/WikiSQL/seq2seq
EXP_NAME=wikisql_ac_gpt2_2e-4_ep20_b32
python -m lm \
    --model_type gpt2 \
    --model_name_or_path gpt2 \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --train_data_file ${LM_DIR}/train.ac.txt \
    --eval_data_file ${LM_DIR}/dev.ac.txt \
    --learning_rate 2e-4 \
    --num_train_epochs 20 \
    --output_dir transformer_models/${EXP_NAME} \
    --per_gpu_eval_batch_size=4   \
    --per_gpu_train_batch_size=4   \
    --gradient_accumulation_steps 2 \
    --line_by_line \
    --special_token_file ${LM_DIR}/train.ac.special_tokens.json \
    --block_size 512 \
    --save_steps 5000

bash scripts/predict_lm_gpt_ac.sh ${EXP_NAME}
python -m wikisql.cli str_eval \
    --gold_file_name .data/WikiSQL/seq2seq/dev.ac.txt \
    --pred_file_name transformer_models/${EXP_NAME}/output/dev.ac.output.txt
