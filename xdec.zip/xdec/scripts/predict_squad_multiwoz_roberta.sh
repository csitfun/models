SQUAD_DIR=.data/dstcslotall_multiwozonly_care_20_non/
python -m squad \
    --model_type roberta \
    --model_name_or_path transformer_models/squad_multiwoz_noncat_roberta/ \
    --cache_dir .transformers_cache \
    --do_eval \
    --data_dir ${SQUAD_DIR} \
    --train_file squad.train.multiwozonly_care.json \
    --predict_file squad.test.multiwozonly_care.json \
    --learning_rate 3e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --doc_stride 128 \
    --output_dir transformer_models/squad_multiwoz_noncat_roberta/ \
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 8 \
    --version_2_with_negative \
    --save_steps 10000 \
    --threads 8
