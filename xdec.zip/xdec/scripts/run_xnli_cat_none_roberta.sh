XNLI_DIR=.data/dstcslotall_dstc_20_cat/
python -m xnli \
    --model_type roberta \
    --model_name_or_path roberta-base \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file xnli.train.none.dstc.jsonl.gz \
    --predict_file xnli.dev.none.dstc.jsonl.gz \
    --task_type cat \
    --learning_rate 2e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --output_dir transformer_models/xnli_dstc_cat_none_roberta \
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 8 \
    --save_steps 20000

python -m dstc.cli compute_f1 --slot_type categorical \
    --input_file transformer_models/xnli_dstc_cat_none_roberta/pred_results.txt \
    --ref_file .data/dstcslotall_dstc_20_cat/dev.none.jsonl.gz
