XNLI_DIR=.data/rel/CDR_Data/CDR.Corpus.v010516/processed/
OUTPUT_DIR=transformer_models/xnli_rel_causes_roberta_pair_ai2bio_b32_lr5e-5_ep20
python -m xnli \
    --model_type roberta_pair \
    --model_name_or_path allenai/biomed_roberta_base \
    --cache_dir transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file train.causes.jsonl \
    --predict_file dev.causes.jsonl \
    --task_type cat \
    --learning_rate 5e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 20 \
    --max_seq_length 512 \
    --gradient_accumulation_steps 2 \
    --output_dir ${OUTPUT_DIR}\
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 8 \
    --seed 42 \
    --save_steps 10000
