XNLI_DIR=.data/dstcslotall_unittest_5_cat/
python -m xnli \
    --model_type roberta_wd \
    --model_name_or_path transformer_models/xnli_unittest_wd \
    --cache_dir .transformers_cache \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file xnli.train.unittest.jsonl.gz \
    --predict_file xnli.train.unittest.jsonl.gz \
    --task_type cat \
    --learning_rate 2e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 64 \
    --output_dir transformer_models/xnli_unittest_wd \
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 8 \
    --gradient_accumulation_steps 2 \
    --use_wide \
    --wide_dimension 30 \
    --wide_weight 0.1 \
    --wide_lr 2e-5 \
    --use_avg \
    --use_layers 5 8 \
    --output_hidden_states \
    --save_steps 1000

python -m dstc.cli compute_f1 --slot_type categorical \
    --input_file transformer_models/xnli_unittest_wd/pred_results.txt \
    --ref_file .data/dstcslotall_unittest_5_cat/train.jsonl.gz
