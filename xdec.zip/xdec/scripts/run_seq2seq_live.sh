# path of training data
TRAIN_FILE=.data/asrsum/live.shuf.train.jsonl
TEST_FILE=.data/asrsum/live.shuf.test.jsonl
EPOCH=$1
# folder used to save fine-tuned checkpoints
PRE_EXP_NAME=ssum_long_lr1e-4_ep60_b64_on_gsum_rbtl3_512_128_lr1e-4_ep5_b128
SOURCE_LEN=512
TARGET_LEN=256
# Original: 1e-4
LR=1e-4
MODEL_DIR=transformer_models/${PRE_EXP_NAME}
OUTPUT_DIR=transformer_models/liveshuf_lr${LR}_warm1000_ep${EPOCH}_b16_bm5_sl${SOURCE_LEN}_tl${TARGET_LEN}_on_${PRE_EXP_NAME}
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3

# python -m seq2seq \
#   --train_file ${TRAIN_FILE} \
#   --output_dir ${OUTPUT_DIR} \
#   --model_type unilm \
#   --model_name_or_path ${MODEL_DIR} \
#   --do_lower_case \
#   --max_source_seq_length ${SOURCE_LEN} \
#   --max_target_seq_length ${TARGET_LEN} \
#   --per_gpu_train_batch_size 4 \
#   --gradient_accumulation_steps 1 \
#   --learning_rate ${LR} \
#   --num_warmup_steps 1000 \
#   --num_training_epochs ${EPOCH} \
#   --save_steps 5000 \
#   --cache_dir ${CACHE_DIR}

python predict_seq2seq.py \
  --model_type unilm \
  --input_file ${TEST_FILE} \
  --output_file ${OUTPUT_DIR}/test.output.txt \
  --do_lower_case \
  --model_path ${OUTPUT_DIR} \
  --max_seq_length ${SOURCE_LEN} \
  --max_tgt_length ${TARGET_LEN} \
  --batch_size 4 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s \
  --forbid_duplicate_ngrams \
  --ngram_size 4

echo ${OUTPUT_DIR}

python -m summ.cli rouge_eval \
  --gold_file_name ${TEST_FILE} \
  --pred_file_name ${OUTPUT_DIR}/test.output.txt 2>&1 | tee ${OUTPUT_DIR}/eval.log
