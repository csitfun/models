LM_DIR=dialog_data
python -m lm \
    --model_type roberta \
    --model_name_or_path roberta-base \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --train_data_file ${LM_DIR}/all_datasets.txt \
    --eval_data_file ${LM_DIR}/dstc_dev.txt \
    --learning_rate 3e-5 \
    --num_train_epochs 1 \
    --output_dir transformer_models/dialog_mlm_all_roberta \
    --per_gpu_eval_batch_size=4   \
    --per_gpu_train_batch_size=4   \
    --gradient_accumulation_steps 4 \
    --mlm \
    --line_by_line \
    --save_steps 5000
