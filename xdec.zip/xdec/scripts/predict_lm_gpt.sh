LM_DIR=.data/WikiSQL/seq2seq
FINE_TUNED_MODEL=$1
python -m lm_generate \
    --model_type gpt2 \
    --model_name_or_path transformer_models/${FINE_TUNED_MODEL} \
    --length 512 \
    --input_file_name ${LM_DIR}/dev.source.txt \
    --output_file_name transformer_models/${FINE_TUNED_MODEL}/output/dev.output.txt

