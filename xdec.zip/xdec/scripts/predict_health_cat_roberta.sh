XNLI_DIR=.data/health
python -m xnli \
    --model_type bert \
    --model_name_or_path transformer_models/health_cat_roberta_2e-5_b128 \
    --cache_dir .transformers_cache \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --predict_file test.200609.jsonl \
    --task_type cat \
    --learning_rate 2e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --gradient_accumulation_steps 4 \
    --output_dir transformer_models/health_cat_roberta_2e-5_b128 \
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 8 \
    --seed 42 \
    --save_steps 10000
