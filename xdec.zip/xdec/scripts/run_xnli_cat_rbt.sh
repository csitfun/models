XNLI_DIR=.data/zzhot/zz_summ_processed/
python -m xnli \
    --model_type bert \
    --model_name_or_path hfl/rbt3 \
    --cache_dir .transformer_cache_unilm \
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file train_xnli.jsonl \
    --predict_file test_xnli.jsonl \
    --task_type cat \
    --learning_rate 1e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 48 \
    --gradient_accumulation_steps 4 \
    --output_dir transformer_models/zzhot_xnli_zzhot_s48 \
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 4 \
    --overwrite_output_dir \
    --seed 42 \
    --save_steps 10000

