for i in 10 20 30 40 50
do
    bash scripts/run_seq2seq_ssum.sh $i
done
