# path of training data
TRAIN_FILE=.data/zhuiyi/train.s2s.json
SPECIAL_TOKEN_FILE=.data/zhuiyi/train.s2s.json.special_tokens.json
# folder used to save fine-tuned checkpoints
OUTPUT_DIR=transformer_models/zhuiyi_rbtl3_lr7e-5_s512_t128_ep50_b128
# folder used to cache package dependencies
CACHE_DIR=.transformer_cache_unilm

# export CUDA_VISIBLE_DEVICES=0,1,2,3

python -m seq2seq \
  --train_file ${TRAIN_FILE} \
  --output_dir ${OUTPUT_DIR} \
  --model_type unilm \
  --model_name_or_path hfl/rbtl3 \
  --do_lower_case \
  --max_source_seq_length 512 \
  --max_target_seq_length 128 \
  --per_gpu_train_batch_size 16 \
  --gradient_accumulation_steps 2 \
  --learning_rate 7e-5 \
  --num_warmup_steps 1000 \
  --num_training_epochs 50 \
  --save_steps 5000 \
  --special_token_file ${SPECIAL_TOKEN_FILE} \
  --trunk_left \
  --cache_dir ${CACHE_DIR}
