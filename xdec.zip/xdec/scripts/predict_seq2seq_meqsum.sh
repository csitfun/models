# path of the fine-tuned checkpoint
MODEL_PATH=transformer_models/medqsum_lr7e-5_ep20_b64
# input file that you would like to decode
INPUT_JSON=.data/meqsum/tail.jsonl


python predict_seq2seq.py \
    --model_type unilm \
    --input_file ${INPUT_JSON} \
    --output_file ${MODEL_PATH}/test.output.txt \
    --do_lower_case \
    --model_path ${MODEL_PATH} \
    --max_seq_length 512 \
    --max_tgt_length 64 \
    --batch_size 64 \
    --beam_size 5 \
    --length_penalty 0 \
    --forbid_duplicate_ngrams \
    --mode s2s \
    --forbid_ignore_word "."


python -m summ.cli rouge-eval-en \
    --gold_file_name ${INPUT_JSON} \
    --pred_file_name ${MODEL_PATH}/test.output.txt
