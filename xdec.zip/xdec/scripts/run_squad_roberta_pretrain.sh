SQUAD_DIR=dstc8-squad-30
python -m squad \
    --model_type roberta \
    --model_name_or_path transformer_models/dialog_mlm_all_roberta \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${SQUAD_DIR} \
    --train_file train.json \
    --predict_file dev.json \
    --learning_rate 3e-5 \
    --num_train_epochs 2 \
    --max_seq_length 512 \
    --doc_stride 128 \
    --output_dir transformer_models/roberta_base_norm_30_pretrain_e2 \
    --per_gpu_eval_batch_size=8   \
    --per_gpu_train_batch_size=8   \
    --version_2_with_negative \
    --save_steps 10000 \
    --threads 8
