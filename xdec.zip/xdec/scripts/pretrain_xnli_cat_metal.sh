XNLI_DIR=dstc-xnli
python -m xnli \
    --model_type roberta \
    --model_name_or_path roberta-base \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file pretrain-metal.train.jsonl \
    --predict_file pretrain-metal.dev.jsonl \
    --task_type cat \
    --learning_rate 2e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --output_dir transformer_models/xnli_cat_roberta_pretrain_2 \
    --per_gpu_eval_batch_size=8   \
    --per_gpu_train_batch_size=8   \
    --save_steps 5000

