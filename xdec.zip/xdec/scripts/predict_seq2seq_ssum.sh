# path of the fine-tuned checkpoint
MODEL_PATH=transformer_models/ssum_lr1e-4_ep20_b32_on_gsum_rbtl3_lr2e-5_ep1_b32
# input file that you would like to decode
INPUT_JSON=.data/ssum/s2s.test.jsonl

python predict_seq2seq.py \
  --model_type unilm \
  --input_file ${INPUT_JSON} \
  --output_file ${MODEL_PATH}/test.output.txt \
  --do_lower_case \
  --model_path ${MODEL_PATH} \
  --max_seq_length 256 \
  --max_tgt_length 128 \
  --batch_size 4 \
  --beam_size 5 \
  --length_penalty 0 \
  --mode s2s \
  --forbid_duplicate_ngrams \
  --ngram_size 4

python -m summ.cli rouge_eval \
  --gold_file_name ${INPUT_JSON} \
  --pred_file_name ${MODEL_PATH}/test.output.txt 2>&1 | tee ${OUTPUT_DIR}/eval.log
