import re
import time
import json
import calendar
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil.parser import parse
from copy import deepcopy
import chinese2digits as c2d
from xdec_config import get_logger
import unittest

logger = get_logger(__name__)


class TimeProcessor:

    def __init__(self):
        # supported patterns: longest first according to p.findall()
        # remove "去年N月", "前年N月", "上月N日" -> 546
        patterns = [
            "N年N月N日", "N年N月N号", "N年N月", "N月N日", "N月N号", "去年N月", "前年N月", "上月N日",
            "本月N日", "N年第N季度", "N年前N季度", "N年N季度", "第N季度", "N季度", "最?近N天",
            "最?近N日", "过去N天", "过去N日", "N年", "最?近N个?月", "N月", "N日", "N号", "前年",
            "去年", "今年", "本月", "上月", "本周", "上周", "昨天", "前天", "昨日", "前日", "今日",
            "今天", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "以来"
        ]
        self.p = self.__build_synonym_pattern(patterns)

    def __build_synonym_pattern(self, synonyms):
        replacements = {
            'N': r'[\d一二三四五六七八九十百千万]+',
            'yyyy': r'\d{4}',
            'mm': r'\d{1,2}',
            'dd': r'\d{1,2}',
            'YYYY': r'\d{4}',
            'MM': r'\d{1,2}',
            'DD': r'\d{1,2}',
            '-': r'\-'
        }

        def __replace(s):
            for r in replacements:
                s = s.replace(r, replacements[r])
            return s.lower()

        candidates = synonyms
        p = '|'.join(
            map(__replace, filter(lambda x: len(x.strip()) > 0, candidates)))
        logger.debug("pattern: {}".format(p))
        return re.compile(p)

    def ground_time(self, time_exps, basetime=None):

        def _process_year(time_exp, this_year):
            logger.debug(f"In process year: {time_exp}")
            if time_exp.endswith("年"):
                time_exp = time_exp[:-1]
            try:
                year = int(time_exp)
            except:
                logger.debug(f"Year except: {time_exp}")
                if time_exp == "去":
                    year = this_year - 1
                elif time_exp == "前":
                    year = this_year - 2
                else:
                    year = this_year
            if year < 1900:
                year += 2000
            return datetime(year, 1, 1), datetime(year, 12, 31) + timedelta(
                days=1, microseconds=-1000)

        def _process_season(time_exp, this_year):
            smap = {1: 1, 2: 4, 3: 7, 4: 10}
            if "年" in time_exp:
                year = _process_year(time_exp[:time_exp.index("年") + 1],
                                     this_year)[0].year
                time_exp = time_exp[time_exp.index("年") + 1:-2]
            else:
                year = this_year
                time_exp = time_exp[:-2]
            if time_exp.startswith("第"):
                time_exp = time_exp[1:]
            start_season = 0
            if time_exp.startswith("前"):
                time_exp = time_exp[1:]
                start_season = 1
            try:
                season = int(time_exp)
            except:
                season = 1
            start_month = smap[season]
            end_year = year if start_month != 10 else year + 1
            end_month = start_month + 3 if start_month != 10 else 1
            if start_season == 1:
                start_month = 1
            return datetime(year, start_month, 1), datetime(end_year, end_month, 1) + \
                timedelta(microseconds=-1000)

        def _process_month(time_exp, this_year, this_month):
            if "年" in time_exp:
                year = _process_year(time_exp[:time_exp.index("年") + 1],
                                     this_year)[0].year
                time_exp = time_exp[time_exp.index("年") + 1:-1]
            else:
                year = this_year
                time_exp = time_exp[:-1]
            try:
                month = int(time_exp)
            except:
                if time_exp == "本":
                    month = this_month
                elif time_exp == "上":
                    if this_month == 1:
                        month = 12
                        year -= 1
                    else:
                        month = this_month - 1
                else:
                    month = 1
            last_day = calendar.monthrange(year, month)[1]
            start = datetime(year, month, 1)
            end = datetime(year, month, last_day) + timedelta(
                days=1, microseconds=-1000)
            return start, end

        def _process_date(time_exp, this_year, this_month, this_date):

            def _process_only_date(date_exp, year, month, this_date):
                if date_exp in ["昨天", "前天", "今天", "昨日", "前日", "今日"]:
                    base_date = datetime(year, month, this_date)
                    if date_exp.startswith("前"):
                        base_date += timedelta(days=-2)
                    elif date_exp.startswith("昨"):
                        base_date += timedelta(days=-1)
                    return base_date.year, base_date.month, base_date.day
                else:
                    if "月" in time_exp:
                        try:
                            day = int(time_exp[time_exp.index("月") + 1:-1])
                        except:
                            day = 1
                    elif re.match(r"\d+[日号]", time_exp):
                        day = int(time_exp[:-1])
                    else:
                        day = 1
                    return year, month, day

            if "月" in time_exp:
                month_range = _process_month(time_exp[:time_exp.index("月") + 1],
                                             this_year, this_month)
                year = month_range[0].year
                month = month_range[0].month
                date_exp = time_exp[time_exp.index("月") + 1:]
                year, month, day = _process_only_date(date_exp, year, month,
                                                      this_date)
            else:
                year = this_year
                month = this_month
                date_exp = time_exp
                year, month, day = _process_only_date(date_exp, year, month,
                                                      this_date)
            start = datetime(year, month, day)
            end = datetime(year, month, day) + timedelta(
                days=1, microseconds=-1000)
            return start, end

        def _ground_single(time_exps, basetime=None):
            today = datetime.today()
            this_year = basetime.year if basetime else today.year
            this_month = basetime.month if basetime else today.month
            this_day = basetime.day if basetime else today.day

            time_exp = time_exps[0]
            logger.debug(f"Old time_exp: {time_exp}")
            time_exp = c2d.takeNumberFromString(
                time_exp)["replacedText"].replace(".0", "")
            if time_exp in [
                    "2017", "2018", "2019", "2020", "2021", "2022", "2023"
            ]:
                time_exp = time_exp + "年"
            logger.debug(f"New time_exp: {time_exp}")
            if re.match(r"最?近(\d+)[天日]", time_exp):
                days = int(re.match(r"最?近(\d+)[天日]", time_exp).group(1))
                return basetime + timedelta(days=-days), basetime
            if re.match(r"最?近(\d+)个?月", time_exp):
                months = int(re.match(r"最?近(\d+)个?月", time_exp).group(1))
                logger.info(f"months: {months}")
                new_month = basetime.month - months
                new_year = basetime.year
                if new_month <= 0:
                    new_month = -new_month
                    delta_y = new_month // 12 + 1
                    delta_m = new_month % 12
                    new_year = new_year - delta_y
                    new_month = 12 - delta_m
                newbase = basetime + timedelta(days=0)
                newbase = newbase.replace(year=new_year, month=new_month)
                return newbase, basetime
            elif re.match(r"过去(\d+)[天日]", time_exp):
                days = int(re.match(r"过去(\d+)[天日]", time_exp).group(1))
                return basetime + timedelta(days=-days), basetime
            elif time_exp in ["本周", "上周"]:
                current_day = datetime(this_year, this_month, this_day)
                if time_exp == "上周":
                    start = current_day - timedelta(days=current_day.weekday() +
                                                    7)
                else:
                    start = current_day - timedelta(days=current_day.weekday())
                end = start + timedelta(days=7, microseconds=-1000)
                return start, end
            elif time_exp.endswith("年"):
                time_range = _process_year(time_exp, this_year)
            elif time_exp.endswith("季度"):
                time_range = _process_season(time_exp, this_year)
            elif time_exp.endswith("月"):
                logger.debug("endswith month: " + time_exp)
                time_range = _process_month(time_exp, this_year, this_month)
            else:
                time_range = _process_date(time_exp, this_year, this_month,
                                           this_day)
            return time_range

        def _ground_multi(time_exps, basetime=None):
            if len(time_exps) == 2:
                if time_exps[0].endswith("年") and \
                    (time_exps[1].endswith("月") or
                        time_exps[1].endswith("季度")):
                    return _ground_single([time_exps[0] + time_exps[1]],
                                          basetime=basetime)
                if time_exps[1] == "以来":
                    start, _ = _ground_single([time_exps[0]], basetime=basetime)
                    end = basetime if basetime else datetime.today()
                    return start, end
                if time_exps[0][-1] == time_exps[1][-1]:
                    start, _ = _ground_single([time_exps[0]])
                    _, end = _ground_single([time_exps[1]], basetime=start)
                    return start, end
            return None, None

        if basetime is None:
            basetime = datetime.now()
        if len(time_exps) == 0:
            return None, None
        elif len(time_exps) == 1:
            return _ground_single(time_exps, basetime=basetime)
        else:
            return _ground_multi(time_exps, basetime=basetime)

    def extract(self, text, ts=None):
        time_exps = self.extract_exps(text)
        return self.ground_time(time_exps, basetime=ts)

    def extract_exps(self, text):
        return self.p.findall(text)

    def extract_exp(self, text):
        time_exps = self.p.findall(text)
        if len(time_exps) == 2:
            if time_exps[0].endswith("年") and \
                    (time_exps[1].endswith("月") or
                    time_exps[1].endswith("季度")):
                return time_exps[0] + time_exps[1]
            if time_exps[1] == "以来":
                return time_exps[0] + time_exps[1]
            if time_exps[0][-1] == time_exps[1][-1]:
                start = text.index(time_exps[0])
                end = text.index(time_exps[1]) + len(time_exps[1])
                return text[start:end]
        return time_exps[0] if len(time_exps) > 0 else None

    def parse_sql_ts(self, text):
        return datetime.strptime(text, '%Y-%m-%d %H:%M:%S.%f')

    def parse_ts(self, text):
        logger.debug(f"ts: {text}")
        return datetime.strptime(text, '%Y-%m-%d %H:%M:%S')

    def date_equals(self, dt1, dt2):
        if not dt1 and not dt2:
            return True
        if not dt1 or not dt2:
            return False
        return dt1.year == dt2.year and dt1.month == dt2.month and \
            dt1.day == dt2.day


class TestTime(unittest.TestCase):

    def test_extract(self):
        time_processor = TimeProcessor()
        logger.info(time_processor.extract("2018年9月黑龙江的售电量-一般工商业"))

    def test_validate_on_dianli(self):
        time_processor = TimeProcessor()
        with open(".data/dianli3/nl2sql.clean_copy.json") as input_:
            data = json.load(input_)
        total = 0
        correct = 0
        for nl, sql, ts in data["query&sql"]:
            ts = time_processor.parse_ts(ts)
            logger.debug(f"Orig NL:\t{nl}")
            logger.debug(f"Orig SQL:\t{sql}")
            m = re.search(r"\s\(.+?BETWEEN\s'(.+?)'\sAND\s'(.+?)'\)", sql)
            if m:
                total += 1
                try:
                    start = time_processor.parse_sql_ts(m.group(1))
                    end = time_processor.parse_sql_ts(m.group(2))
                except:
                    logger.warning(f"\nError\nNL: {nl}\nSQL: {sql}")
                    continue
                nl_start, nl_end = time_processor.extract(nl, ts)
                if time_processor.date_equals(nl_start, start) and \
                        time_processor.date_equals(nl_end, end):
                    correct += 1
                else:
                    logger.warning(f"Missing\nNL: {nl}\nSQL: {sql}")
                    logger.warning(f"\tNL: {nl_start} {nl_end}")
                    logger.warning(
                        f"\ttime_exps: {time_processor.extract_exps(nl)}")
                    logger.warning(f"\tSQL: {start} {end}")
        logger.info(f"Correct: {correct} Total: {total}")


if __name__ == "__main__":
    time_processor = TimeProcessor()
    time_exps = time_processor.extract_exps("最近5个月湖北死亡人数")
    logger.info(f"time_exps: {time_exps}")
    logger.info(f"ts: {time_processor.ground_time(time_exps)}")
