import re


def sent_split(sent, keep_last=False):
    if not sent:
        return []
    else:
        result = []
        m = re.search(r"[。？！]+", sent)
        while m:
            if m.end() > 0:
                content = sent[:m.end()].strip()
                if content:
                    result.append(content)
            sent = sent[m.end():]    
            m = re.search(r"[。？！]+", sent)
        if sent and keep_last:
            sent = sent.strip()
            if sent:
                result.append(sent)
        return result
