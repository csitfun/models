import os
import json
import copy
import logging
from argparse import ArgumentParser

EXPERIMENT_DOMAINS = ["hotel", "train", "restaurant", "attraction", "taxi"]


def fix_general_label_error(labels, type, slots):
    label_dict = dict([(l[0], l[1]) for l in labels]) if type else dict(
        [(l["slots"][0][0], l["slots"][0][1]) for l in labels])

    old_label_dict = copy.deepcopy(label_dict)

    GENERAL_TYPO = {
        # type
        "guesthouse": "guest house",
        "guesthouses": "guest house",
        "guest": "guest house",
        "mutiple sports": "multiple sports",
        "sports": "multiple sports",
        "mutliple sports": "multiple sports",
        "swimmingpool": "swimming pool",
        "concerthall": "concert hall",
        "concert": "concert hall",
        "pool": "swimming pool",
        "night club": "nightclub",
        "mus": "museum",
        "ol": "architecture",
        "colleges": "college",
        "coll": "college",
        "architectural": "architecture",
        "musuem": "museum",
        "churches": "church",
        # area
        "center": "centre",
        "center of town": "centre",
        "near city center": "centre",
        "in the north": "north",
        "cen": "centre",
        "east side": "east",
        "east area": "east",
        "west part of town": "west",
        "ce": "centre",
        "town center": "centre",
        "centre of cambridge": "centre",
        "city center": "centre",
        "the south": "south",
        "scentre": "centre",
        "town centre": "centre",
        "in town": "centre",
        "north part of town": "north",
        "centre of town": "centre",
        "cb30aq": "none",
        # price
        "mode": "moderate",
        "moderate -ly": "moderate",
        "mo": "moderate",
        # day
        "next friday": "friday",
        "monda": "monday",
        # parking
        "free parking": "free",
        # internet
        "free internet": "yes",
        # star
        "4 star": "4",
        "4 stars": "4",
        "0 star rarting": "none",
        # others
        "y": "yes",
        "any": "dontcare",
        "n": "no",
        "does not care": "dontcare",
        "not men": "none",
        "not": "none",
        "not mentioned": "none",
        '': "none",
        "not mendtioned": "none",
        "3 .": "3",
        "does not": "no",
        "fun": "none",
        "art": "none",
    }

    for slot in slots:
        if slot in label_dict.keys():
            # general typos
            if label_dict[slot] in GENERAL_TYPO.keys():
                label_dict[slot] = label_dict[slot].replace(
                    label_dict[slot], GENERAL_TYPO[label_dict[slot]])

            # miss match slot and value
            if ((slot == "hotel-type" and label_dict[slot] in [
                    "nigh", "moderate -ly priced", "bed and breakfast",
                    "centre", "venetian", "intern", "a cheap -er hotel"
            ]) or slot == "hotel-internet" and label_dict[slot] == "4" or
                    slot == "hotel-pricerange" and label_dict[slot] == "2" or
                    slot == "attraction-type" and label_dict[slot] in [
                        "gastropub", "la raza", "galleria", "gallery",
                        "science", "m"
                    ] or "area" in slot and label_dict[slot] in ["moderate"] or
                    "day" in slot and label_dict[slot] == "t"):
                label_dict[slot] = "none"
            elif slot == "hotel-type" and label_dict[slot] in [
                    "hotel with free parking and free wifi", "4", "3 star hotel"
            ]:
                label_dict[slot] = "hotel"
            elif slot == "hotel-star" and label_dict[slot] == "3 star hotel":
                label_dict[slot] = "3"
            elif "area" in slot:
                if label_dict[slot] == "no":
                    label_dict[slot] = "north"
                elif label_dict[slot] == "we":
                    label_dict[slot] = "west"
                elif label_dict[slot] == "cent":
                    label_dict[slot] = "centre"
            elif "day" in slot:
                if label_dict[slot] == "we":
                    label_dict[slot] = "wednesday"
                elif label_dict[slot] == "no":
                    label_dict[slot] = "none"
            elif "price" in slot and label_dict[slot] == "ch":
                label_dict[slot] = "cheap"
            elif "internet" in slot and label_dict[slot] == "free":
                label_dict[slot] = "yes"

            # some out-of-define classification slot values
            if (slot == "restaurant-area" and label_dict[slot]
                    in ["stansted airport", "cambridge", "silver street"] or
                    slot == "attraction-area" and label_dict[slot]
                    in ["norwich", "ely", "museum", "same area as hotel"]):
                label_dict[slot] = "none"

    for k, v in old_label_dict.items():
        if v != label_dict[k]:
            logging.info("DIFF: {} VS. {}".format(v, label_dict[k]))
    return label_dict


def get_slot_information(ontology):
    ontology_domains = dict([(k.replace("-semi-", "-"), v)
                             for k, v in ontology.items()
                             if k.split("-")[0] in EXPERIMENT_DOMAINS])
    SLOTS = [
        k.replace(" ", "").lower() if ("book" not in k) else k.lower()
        for k in ontology_domains.keys()
    ]
    return SLOTS


class DstEvaluate(object):

    def __init__(self,
                 pred_file,
                 ref_file,
                 ontology_file="data/MultiWOZ_2.1/ontology.json"):
        self.ref_file = ref_file
        self.pred_file = pred_file
        ontology = json.load(open(ontology_file, 'r'))
        self.slot_list = get_slot_information(ontology)

    def load(self, input_file, all_prediction, is_ref=True, run_fix=False):
        with open(input_file) as ifile:
            data = json.load(ifile)
        for dialogue in data:
            dialogue_idx = dialogue["dialogue_idx"]
            if dialogue_idx not in all_prediction:
                all_prediction[dialogue_idx] = {}
            dlg = dialogue["dialogue"]

            curr_pred = all_prediction[dialogue_idx]
            for turn in dlg:
                turn_idx = turn["turn_idx"]

                if run_fix:
                    # NOTE: fixes from TRADE system for early MultiWOZ <2.1
                    #  https://github.com/jasonwu0731/trade-dst
                    belief_state = fix_general_label_error(
                        turn["belief_state"], False, self.slot_list)

                    domain_slot_values = [
                        "{}-{}".format(k, v) for (k, v) in belief_state.items()
                    ]
                else:
                    domain_slot_values = []
                    for bs in turn["belief_state"]:
                        slot = bs["slots"]
                        domain_slot_values.append("-".join(slot[0]))

                if is_ref:
                    curr_pred[turn_idx] = {"turn_belief": domain_slot_values}
                else:
                    curr_pred[turn_idx]["pred_bs_ptr"] = domain_slot_values

    def evaluate(self):

        all_prediction = {}
        self.load(self.ref_file, all_prediction)
        self.load(self.pred_file, all_prediction, is_ref=False)

        (joint_acc_score_ptr, F1_score_ptr,
         turn_acc_score_ptr) = self.evaluate_metrics(all_prediction,
                                                     "pred_bs_ptr",
                                                     self.slot_list)

        evaluation_metrics = {
            "Joint Acc": joint_acc_score_ptr,
            "Turn Acc": turn_acc_score_ptr,
            "Joint F1": F1_score_ptr
        }
        logging.info(evaluation_metrics)

    def evaluate_metrics(self, all_prediction, from_which, slot_temp):
        total, turn_acc, joint_acc, F1_pred, F1_count = 0, 0, 0, 0, 0
        for d, v in all_prediction.items():
            for t in range(len(v)):
                cv = v[t]
                if set(cv["turn_belief"]) == set(cv[from_which]):
                    joint_acc += 1
                total += 1

                # Compute prediction slot accuracy
                temp_acc = self.compute_acc(
                    set(cv["turn_belief"]), set(cv[from_which]), slot_temp)
                turn_acc += temp_acc

                # Compute prediction joint F1 score
                temp_f1, temp_r, temp_p, count = self.compute_prf(
                    set(cv["turn_belief"]), set(cv[from_which]))
                F1_pred += temp_f1
                F1_count += count

        joint_acc_score = joint_acc / float(total) if total != 0 else 0
        turn_acc_score = turn_acc / float(total) if total != 0 else 0
        F1_score = F1_pred / float(F1_count) if F1_count != 0 else 0
        return joint_acc_score, F1_score, turn_acc_score

    def compute_acc(self, gold, pred, slot_temp):
        miss_gold = 0
        miss_slot = []
        for g in gold:
            if g not in pred:
                miss_gold += 1
                miss_slot.append(g.rsplit("-", 1)[0])
        wrong_pred = 0
        for p in pred:
            if p not in gold and p.rsplit("-", 1)[0] not in miss_slot:
                wrong_pred += 1
        ACC_TOTAL = len(slot_temp)
        ACC = len(slot_temp) - miss_gold - wrong_pred
        ACC = ACC / float(ACC_TOTAL)
        return ACC

    def compute_prf(self, gold, pred):
        TP, FP, FN = 0, 0, 0
        if len(gold) != 0:
            count = 1
            for g in gold:
                if g in pred:
                    TP += 1
                else:
                    FN += 1
            for p in pred:
                if p not in gold:
                    FP += 1
            precision = TP / float(TP + FP) if (TP + FP) != 0 else 0
            recall = TP / float(TP + FN) if (TP + FN) != 0 else 0
            F1 = 2 * precision * recall / float(precision + recall) if (
                precision + recall) != 0 else 0
        else:
            if len(pred) == 0:
                precision, recall, F1, count = 1, 1, 1, 1
            else:
                precision, recall, F1, count = 0, 0, 0, 1
        return F1, recall, precision, count


def parse():
    """
    Returns the arguments from the command line.
    """
    parser = ArgumentParser()
    parser.add_argument(
        '--pred_file',
        default='data/dev_dials.json',
        type=str,
        help='prediction file')
    parser.add_argument(
        '--ref_file',
        default='data/dev_dials.json',
        type=str,
        help='reference file')
    parser.add_argument(
        "--ontology_file",
        default="data/MultiWOZ_2.1/ontology.json",
        type=str,
        help="ontology data")
    args = parser.parse_args()

    return args


def main():
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    args = parse()

    dst_eval = DstEvaluate(
        args.pred_file, args.ref_file, ontology_file=args.ontology_file)
    dst_eval.evaluate()


if __name__ == "__main__":
    main()
