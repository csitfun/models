# -*- coding: utf-8 -*-
import copy
import json
import os
import re
from collections import defaultdict
from argparse import ArgumentParser
import logging

from spellchecker import SpellChecker

from multiwoz.create_dst_data import get_summary_bstate, normalize
from multiwoz.create_dst_data import getDomain as get_domain
from multiwoz.utils.util import find_sim

spell = SpellChecker(distance=1)
NUMERICAL_SLOTS = ["people", 'stars']
CAT_CANDS_SIZE = 50  # categorical slots: slot value cands less than this num
IGNORE_KEYS_IN_GOAL = ['eod', 'topic', 'messageLen', 'message']
SLOT_NAME_MAP = {
    "pricerange": "price range",
    "price": "price range",
    "arriveby": "arrive by",
    "leaveat": "leave at",
    "dest": "destination",
}
DONTCARE = "dontcare"
ACT_MAP = {
    "inform": "INFORM",  # this action is useless, won't go into state
    "recommend": "OFFER",
    "offerbooked": "CONFIRM",  # this is good, already in state
    "book": "CONFIRM",
    "nobook": "CONFIRM",
    "NoOffer": "INFORM",
}
# Other actions: OfferBook, Select
# INGORE_SLOTS: do not print logging, use in user/sys actions, not state
IGNORE_SLOTS = ['post', 'addr', 'phone', 'time', 'name']
# SKIP_SLOTS: do not use in user/sys actions
SKIP_SLOTS = ["choice", "none", "ref", 'car', 'fee', 'id', 'ticket']
SKIP_DOMAINS = ['police']
SKIP_SYS_ACTIONS = [
    "general-reqmore",
    "general-bye",
    "general-greet",
    "general-welcome",
]
KEEP_SYS_ACTIONS = [
    "booking-request",
    "booking-inform",
    "booking-book",
    "booking-nobook",
]
ACT_DOMAINS = ["booking"]
# in user/system acts, slot values are actually the surface strings, not the
# normed values in ontology, thus, if we want to use MRC, we have to reverse
# this table to find the "True" answer!
TOK_FIX = {
    'modrate': "moderate",
    'gueshouses': "guesthouse",
    'guesthose': "guesthouse",
    'guesthuse': "guesthouse",
    'guestshouses': "guesthouse",
    "gueshouses": "guesthouse",
    'espensive': "expensive",
    'fiday': "friday",
    'Sat': "saturday",
    'entre': "centre",
    'epensive': "expensive",
    "musuem": 'museum',
    "nighclubs": "nightclubs",
    "architectural": "architecture",
    "architechture": "architecture",
    "Anatoilia": "anatolia",
    "wandlbury": "wandlebury",
    "caffe": "cafe",
    "petersborough": "peterborough",
    "archaelogy": "archaeology",
    "caimbridge": "cambridge",
    "steveage": "stevenage",
    "brazliian": "brazilian",
}
SLOT_VALUE_MAP = {
    "moderately": "moderate",
    "musuem": 'museum',
    "moderately priced": "moderate",
    'modrate': "moderate",
    "hotels": "hotel",
    "guesthouses": "guesthouse",
    "guest houses": "guesthouse",
    "Guesthouses": "guesthouse",
    "guest house": "guesthouse",
    'gueshouses': "guesthouse",
    'guesthose': "guesthouse",
    'guesthuse': "guesthouse",
    "guest": "guesthouse",
    'guestshouses': "guesthouse",
    'guesthouse hotel': "guesthouse",
    "gueshouses": "guesthouse",
    'espensive': "expensive",
    'high - end': "expensive",
    'moderate to cheap': 'cheap>moderate',
    'lower end': "cheap",
    "the city centre": "centre",
    'centrally located': "centre",
    'the center of town': "centre",
    'center of the city': "centre",
    'Center': "centre",
    'fiday': "friday",
    "zero": "0",
    "one": "1",
    "two": "2",
    "three": "3",
    "four": "4",
    'four stars': "4",
    'four star': "4",
    'four - star': "4",
    "five": "5",
    "six": "6",
    "seven": "7",
    'Seven': "7",
    "eight": "8",
    "nine": "9",
    'Sat': "saturday",
    'entre': "centre",
    'epensive': "expensive",
    "the south side of town": "south",
    "the south": "south",
    "inexpensively - priced": "cheap",
    "inexpensive": "cheap",
    "town centre": "centre",
    "centre of town": "centre",
    "center of town": "centre",
    "Centre of town": "centre",
    "central district": "centre",
    'Center of town': "centre",
    'cetre': "centre",
    'town center': "centre",
    "city centre": "centre",
    "city centre": "centre",
    'cetnre of town': "centre",
    "center": "centre",
    'centre of the city': 'centre',
    "city 's center": "centre",
    'the centre': "centre",
    "North Area": "north",
    "Cambridge": "north",
    'east of town': 'east',
    'city center': 'centre',
    'centre area': 'centre',
    "in town": "centre",
    'cheapmoderate': 'cheap>moderate',
    "Same area as hotel": "centre",  # found in user act
    'y': "yes",
    "n": "no",
    "cent": "centre",
    "restaurant 2 two": "restaurant two two",
    "restaurant 17": "restaurant one seven",
    'gallery at 12 a high street': 'gallery at twelve a high street',
    "16,15": "16:15",
    "the gallery at 12": "the gallery at twelve",
    '2 two and cote': 'two two and cote',
    '2 two': 'two two',
    "17": "one seven",
    "sundaymonday": 'sunday>monday',
    "mondaythursday": 'monday<thursday',
    "fridaytuesday": 'friday>tuesday',
    "multiple sports attraction": "multiple sports",
    "nighclubs": "nightclubs",
    "architectural": "architecture",
    "architechture": "architecture",
}
PUNS = set([".", ",", "?", ":", "'", '"', "!", "@", "$", "&", "-"])


def has_puns(word):
    for pun in PUNS:
        if pun in word:
            return True
    return False


def has_num(word):
    return bool(re.search(r'\d', word))


def is_numeric_slot(cands):
    for c in cands:
        if not c.isnumeric():
            return False
    return True


def norm_text(text, do_correction=False):
    text = " " + text + " "
    for k, v in TOK_FIX.items():
        k = " " + k + " "
        if k in text:
            text = text.replace(k, f" {v} ")
    corr_text = " ".join(text.split())
    if do_correction:
        c_words = []
        for word in text.split():
            if not has_puns(word) and not has_num(word):
                c_word = spell.correction(word)
                if c_word != word:
                    logging.info(f"Spell correction: {word} to {c_word}")
                c_words.append(c_word)
            else:
                c_words.append(word)
        corr_text = " ".join(c_words)
    return corr_text


def norm_slot_name(slot_name, slot_cands=set(), return_none_name=False):
    """
    lower case, replace blank by _
    """
    slot_name = slot_name.lower().replace("book ", "").replace("book-", "")
    slot_name = SLOT_NAME_MAP.get(slot_name, slot_name)
    slot_name = slot_name.strip().replace(" ", "_")
    if (len(slot_cands) > 0 and slot_name not in slot_cands and
            slot_name not in ["choice", "ref", "none"]):
        # a short name we need to find the correct one
        find_num, correct_name = 0, ""
        for cand in slot_cands:
            if slot_name in cand:
                find_num += 1
                correct_name = cand
        if find_num > 0:
            if find_num > 1:
                logging.warning("More names: {} in {}".format(
                    slot_name, slot_cands))
            slot_name = correct_name
        else:
            if return_none_name:
                return "none"
            if slot_name not in (IGNORE_SLOTS + SKIP_SLOTS):
                logging.warning("Cannot find slot name '{}' in {}".format(
                    slot_name, slot_cands))
                return "none"

    return slot_name


def split_domain_slot(domain_slot):
    domain_slot = domain_slot.replace("-book ", "-")
    domain_name, slot_name = domain_slot.strip().split("-", 1)
    slot_name = norm_slot_name(slot_name)
    return domain_name, slot_name


def norm_slot_value(val, cands={}):
    if len(cands) > 0 and is_numeric_slot(cands):
        norm_value = val.split("|", 1)[0]
    else:
        norm_value = val.replace("|", " or ")
    norm_value = norm_value.replace("<", " to ").replace(">", " to ")

    norm_value = norm_value.replace("do nt care", DONTCARE)
    norm_value = norm_value.replace("do n't care", DONTCARE)
    if norm_value in ["not mentioned"]:
        norm_value = "none"
    if (len(cands) > 0 and norm_value.lower() not in cands and
            norm_value.lower() not in [DONTCARE, "?", "none"]):
        # categorical slots, must show in cands
        if norm_value in SLOT_VALUE_MAP and SLOT_VALUE_MAP[norm_value] in cands:
            norm_value = SLOT_VALUE_MAP[norm_value]
            logging.debug(f"change slot value from {val} to {norm_value}")
        else:
            # use similarity to find the best one
            sim_value = "None"
            if not has_num(norm_value):
                sim_value = find_sim(norm_value, cands, threshold=0.8)
            if sim_value != "None":
                norm_value = sim_value
                logging.debug(f"change slot value from {val} to {norm_value}")
            else:
                logging.error(
                    f"Cannot find slot value '{norm_value}' in {cands}")
    return norm_value


def norm_slot_values(values, slot_name):
    is_categorical = False

    norm_values = []
    for val in values:
        if val == DONTCARE:
            continue
        norm_v = norm_slot_value(val)
        norm_values.append(norm_v)

    norm_values = [x for x in set(norm_values) if x != ""]

    if slot_name in NUMERICAL_SLOTS:
        # remove non numerical
        norm_values = [val for val in norm_values if val.isnumeric()]

    is_numeric = True
    for sv in norm_values:
        if not sv.isnumeric():
            is_numeric = False
    if is_numeric:
        is_categorical = True
    elif len(norm_values) < CAT_CANDS_SIZE and slot_name not in [
            "leave_at", 'departure', 'destination'
    ]:
        is_categorical = True

    return norm_values, is_categorical


def check_slots(cur_domain,
                slot_name,
                slot_value,
                domain_slots_check={},
                domainslot_values_check={},
                name=""):
    if slot_name not in domain_slots_check[cur_domain]:
        if "Sys dialog act" in name and slot_name in IGNORE_SLOTS:
            return (True, True)
        if cur_domain not in ["police"]:
            logging.warning(f"{name}: Invalid slot name: " +
                            f"domain {cur_domain}, slot {slot_name}")
        return (False, False)
    elif slot_value != DONTCARE:
        ds_key = f"{cur_domain}-{slot_name}"
        cands = domainslot_values_check[ds_key]["possible_values"]
        if (len(cands) > 0 and slot_value.lower() not in cands and
                slot_value not in cands):
            logging.warning(f"{name}: Invalid slot value: " +
                            f"domain-slot: {ds_key}, " +
                            f"'{slot_value}' not in {cands}")
            return (True, False)
    return (True, True)


def update_sys_actions(frames,
                       dialog_act,
                       cur_domain,
                       domain_slots_check={},
                       domainslot_values_check={}):
    for act_info, slot_value_pairs in dialog_act.items():
        if act_info in SKIP_SYS_ACTIONS:
            continue
        act_domain, act_name = act_info.lower().split("-")

        if act_info.lower() in KEEP_SYS_ACTIONS:
            act_domain = cur_domain
        assert (act_domain
                in domain_slots_check), f"Invalid act domain: {act_domain}"

        if act_domain not in frames:
            frames[act_domain] = {
                "service": act_domain,
                "slots": [],
                "actions": []
            }

        actions = frames[act_domain]["actions"]

        for (slot_name, slot_value) in slot_value_pairs:
            return_none_name = act_name in ["offerbooked"]
            slot_name = norm_slot_name(
                slot_name,
                domain_slots_check[act_domain],
                return_none_name=return_none_name)
            ds_ = f"{act_domain}-{slot_name}"
            if ds_ in domainslot_values_check:
                cands = domainslot_values_check[ds_]["possible_values"]
            else:
                cands = {}
            slot_value = norm_slot_value(slot_value, cands)
            if slot_value == "none" or slot_name in SKIP_SLOTS:
                # e.g. "Police-Inform": [["none", "none"]]
                # "Train-Inform": [["Choice", "a number"]]
                # "Train-OfferBooked": [["Ref", "xxxxxxx"]]
                continue

            one_act = {}
            if act_name in ACT_MAP:
                sg_act_name = ACT_MAP[act_name]
                (name_val, value_val) = check_slots(
                    act_domain,
                    slot_name,
                    slot_value,
                    domain_slots_check=domain_slots_check,
                    domainslot_values_check=domainslot_values_check,
                    name="Sys dialog act")
                if name_val and value_val:
                    # only output value slot name and value pair
                    one_act = {
                        "act": sg_act_name,
                        "slot": slot_name,
                        "values": [slot_value]
                    }
            elif act_name == "request":
                one_act = {"act": "REQUEST", "slot": slot_name, "values": []}

            if len(one_act) > 0:
                actions.append(one_act)


def update_user_actions(frames,
                        turn_domains,
                        dialog_act,
                        is_single_domain=True,
                        active_domains=[],
                        domain_slots_check={},
                        domainslot_values_check={},
                        text=""):
    cur_turn_domains = set()
    for act_info, slot_value_pairs in dialog_act.items():
        if "general-" in act_info:
            continue
        act_domain, act_name = act_info.lower().split("-")
        assert (act_domain in domain_slots_check
               ), f"Invalid domain {act_domain} in user action"

        if is_single_domain and act_domain not in active_domains:
            continue

        cur_turn_domains.add(act_domain)

        slot_values = {}
        requested_slots = []
        # we can put span_info latter to "slots" part
        for (slot_name, slot_value) in slot_value_pairs:
            # NOTE: for user turn, slot names must be legal
            slot_name = norm_slot_name(
                slot_name,
                domain_slots_check.get(act_domain, set()),
                return_none_name=True)

            ds_ = f"{act_domain}-{slot_name}"
            if ds_ in domainslot_values_check:
                cands = domainslot_values_check[ds_]["possible_values"]
            else:
                cands = {}
            slot_value = norm_slot_value(slot_value, cands)
            if (slot_value == "none" or slot_name in SKIP_SLOTS):
                # e.g. "Police-Inform": [["none", "none"]]
                # "Train-Inform": [["Choice", "a number"]]
                # "Train-OfferBooked": [["Ref", "xxxxxxx"]]
                continue

            # add to the previous state
            if act_name in ["inform", "recommend"]:
                (name_val, value_val) = check_slots(
                    act_domain,
                    slot_name,
                    slot_value,
                    domain_slots_check=domain_slots_check,
                    domainslot_values_check=domainslot_values_check,
                    name="User dialog act")
                if (name_val and value_val) and False:
                    # skip update slot values from user turns
                    # the next belief state always contains this info if valid
                    # NOTE: system belief will do value vaidation, if not valid
                    #       won't put this value in state!
                    # e.g. "Please find a restaurant called Nusha.",
                    #      "name": "Nusha" won't show in state as it's invalid
                    slot_values[slot_name] = [slot_value]

            elif act_name == "request":
                requested_slots.append(slot_name)

        if act_domain not in active_domains:
            active_domains.append(act_domain)

        if act_domain not in frames:
            frames[act_domain] = {
                "service": act_domain,
                "slots": [],
                "state": {
                    "active_intent": act_domain,
                    "requested_slots": requested_slots,
                    "slot_values": slot_values
                }
            }
        else:
            # update existing results
            ex_frame = frames[act_domain]
            if len(requested_slots) > 0:
                ex_frame["state"]["requested_slots"] = requested_slots
            for k, v in slot_values.items():
                ex_frame["state"]["slot_values"][k] = v

    turn_domains.append(cur_turn_domains)
    if len(cur_turn_domains) > 1:
        logging.info("Multi domains in user acts: {}, text: {}".format(
            dialog_act, text))


def update_belief(beliefs,
                  pre_turn,
                  pre_update_domains,
                  domain_slots_check={},
                  domainslot_values_check={}):
    for bkv in beliefs:
        assert len(bkv) == 2, "Wrong slot value: {}".format(bkv)
        b_domain_slot, b_value = bkv
        b_domain, b_slot = split_domain_slot(b_domain_slot)

        ds_ = f"{b_domain}-{b_slot}"
        cands = domainslot_values_check[ds_]["possible_values"]
        b_value = norm_slot_value(b_value, cands)

        if b_value in ["None", "none"] or b_domain in SKIP_DOMAINS:
            continue

        (name_val, value_val) = check_slots(
            b_domain,
            b_slot,
            b_value,
            domain_slots_check=domain_slots_check,
            domainslot_values_check=domainslot_values_check,
            name="Sys belief")

        assert name_val and value_val, f"Invalid belief: {bkv}"

        if b_domain in pre_update_domains:
            # only update domains shown in pre_update_domains
            is_new = True
            for fe in pre_turn["frames"]:
                if fe["service"] == b_domain:
                    fe["state"]["slot_values"][b_slot] = [b_value]
                    is_new = False
            if is_new:
                pre_turn["frames"].append({
                    "service": b_domain,
                    "slots": [],
                    "state": {
                        "active_intent": b_domain,
                        "requested_slots": [],
                        "slot_values": {
                            b_slot: [b_value]
                        }
                    }
                })


def create_data(data_json="data/multi-woz/data.json",
                sys_acts_json="data/multi-woz/dialogue_acts.json",
                schema=None,
                domain_slots_check={},
                domainslot_values_check={}):
    '''
    Convert MultiWOZ data into Schema Guided Data format, but there are some 
    differentces in converting.
    1: all slot values from different domains are accumulated in MultiWOZ, 
       but not in Schema Guided Data. SGD only have two domains in the switch 
       turn, after the switch turn, we only have the current active domain.
    2: for evaluation: MultiWOZ compares all the slot value pairs in all domains
       SGD compute joint goal acc. one domain by one domain. Thus, the scores in
       SGD should be higher than MultiWOZ eval scripts.
    '''
    with open(data_json, 'r') as example:
        data = json.load(example)

    sg_dialogues = []
    tot_empty_acts_user_turn = 0
    tot_empty_acts_sys_turn = 0
    for dialogue_name, dialogue in data.items():
        is_single_domain = "MUL" not in dialogue_name
        sg_dialogue = {"dialogue_id": dialogue_name, "turns": []}
        active_domains = []
        domains = []
        for dom_k, dom_v in dialogue['goal'].items():
            if dom_v and dom_k not in IGNORE_KEYS_IN_GOAL:
                # check whether contains some goal entities
                assert dom_k in domain_slots_check, f"Invalid domain {dom_k}"
                domains.append(dom_k)

        if is_single_domain:
            assert len(
                domains
            ) == 1, f"Single domain dialog found more domains {domains}"
            active_domains = [domains[0]]

        last_domain = ""

        turn_domains = []
        turns = sg_dialogue["turns"]
        for idx, turn in enumerate(dialogue['log']):
            utterance = " ".join(turn['text'].strip().split())
            fix_utterance = norm_text(utterance)
            if utterance != fix_utterance:
                logging.info(f"Fix:\nraw: {utterance}\nfix: {fix_utterance}")
            norm_utterance = normalize(
                fix_utterance, lower=False, use_stem_replace=False)
            cur_turn = {"utterance": norm_utterance, "frames": []}

            frames = {}
            if idx % 2 == 1:  # system turn
                cur_turn["speaker"] = "SYSTEM"
                cur_domain = get_domain(idx, dialogue['log'], domains,
                                        last_domain)
                if is_single_domain:
                    cur_domain = active_domains[0]

                turn_domains.append(set([cur_domain]))
                pre_turn = turns[-1]

                # decide which domain(s) to update in the previous user turn
                # 1. current system domain.
                pre_update_domains = set([cur_domain])
                # 2. previous use domains is not stable, let's skip it
                pre_user_domains = turn_domains[-2]
                if False and len(
                        pre_user_domains.difference(pre_update_domains)) > 0:
                    logging.info(f"{dialogue_name} turn {idx}: " +
                                 f" user domains: {pre_user_domains}" +
                                 f" sys domains: {pre_update_domains}")
                    pre_update_domains |= pre_user_domains
                # 3. previous sys domain
                if len(turn_domains) > 2:
                    pre_sys_domains = turn_domains[-3]
                    if pre_sys_domains != set([cur_domain]):
                        # this is the first switch turn, update both domains
                        logging.info(
                            f"{dialogue_name} turn {idx}: " +
                            f"Switch turn: {pre_sys_domains} to {cur_domain}")
                        pre_update_domains |= pre_sys_domains

                # update pre_turn domain
                if len(pre_turn["frames"]) == 0:
                    pre_turn["frames"].append({
                        "service": cur_domain,
                        "slots": [],
                        "state": {
                            "active_intent": cur_domain,
                            "requested_slots": [],
                            "slot_values": {}
                        }
                    })

                # get beliefs and update previous user turn states
                _, beliefs = get_summary_bstate(
                    turn['metadata'], lower_slot_value=False)
                update_belief(
                    beliefs,
                    pre_turn,
                    pre_update_domains,
                    domain_slots_check=domain_slots_check,
                    domainslot_values_check=domainslot_values_check)

                # update current system frames
                last_domain = [cur_domain]
                if cur_domain not in active_domains:
                    active_domains.append(cur_domain)

                ## update system actions
                if "dialog_act" not in turn:
                    tot_empty_acts_sys_turn += 1
                    logging.warning(
                        f"Empty sys act: {dialogue_name} in turn {idx}")

                else:
                    dialog_act = turn["dialog_act"]
                    # In DSTC, we only have one domain for each system turn
                    # but, we have multi domains in MultiWOZ a system turn
                    update_sys_actions(
                        frames,
                        dialog_act,
                        cur_domain,
                        domain_slots_check=domain_slots_check,
                        domainslot_values_check=domainslot_values_check)
                # empty frame
                if cur_domain not in frames:
                    frames[cur_domain] = {
                        "service": cur_domain,
                        "slots": [],
                        "actions": []
                    }

            else:  # user turn
                cur_turn["speaker"] = "USER"
                # only process dialog acts
                if "dialog_act" not in turn:
                    tot_empty_acts_user_turn += 1
                    turn_domains.append(set())
                    logging.warning(
                        f"Empty user act: {dialogue_name} in turn {idx}")
                else:
                    # update the current turn slots from dialog_act
                    dialog_act = turn["dialog_act"]
                    update_user_actions(
                        frames,
                        turn_domains,
                        dialog_act,
                        is_single_domain=is_single_domain,
                        active_domains=active_domains,
                        domain_slots_check=domain_slots_check,
                        domainslot_values_check=domainslot_values_check,
                        text=turn["text"])

            # copy to frames
            for _, f_v in frames.items():
                cur_turn["frames"].append(f_v)
            turns.append(cur_turn)

        sg_dialogue["services"] = active_domains
        sg_dialogues.append(sg_dialogue)
    logging.info(
        "tot_empty_acts_user_turn: {}, tot_empty_acts_sys_turn: {}".format(
            tot_empty_acts_user_turn, tot_empty_acts_sys_turn))
    return sg_dialogues


def divide_data(data,
                schema,
                dev_file='data/MultiWOZ_2.1/valListFile.txt',
                test_file='data/MultiWOZ_2.1/testListFile.txt',
                output_dir='data'):
    """Given test and validation sets, divide data into three different sets"""

    output_dir = "." if len(output_dir.strip()) == 0 else output_dir
    test_list_file = set()
    with open(test_file, 'r') as test_fin:
        for line in test_fin:
            test_list_file.add(line.strip())

    val_list_file = set()
    with open(dev_file, 'r') as dev_fin:
        for line in dev_fin:
            val_list_file.add(line.strip())

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    test_dials = []
    val_dials = []
    train_dials = []

    count_train, count_val, count_test = 0, 0, 0
    turn_train, turn_val, turn_test = 0, 0, 0
    test_services, val_services, train_services = set(), set(), set()
    for dialogue in data:
        dialogue_name = dialogue["dialogue_id"]
        services = set(dialogue["services"])
        if dialogue_name in test_list_file:
            test_dials.append(dialogue)
            count_test += 1
            turn_test += len(dialogue["turns"])
            test_services |= services
        elif dialogue_name in val_list_file:
            val_dials.append(dialogue)
            count_val += 1
            turn_val += len(dialogue["turns"])
            val_services |= services
        else:
            train_dials.append(dialogue)
            count_train += 1
            turn_train += len(dialogue["turns"])
            train_services |= services

    logging.info(
        "# of dialogues: Train {} ({}), Val {} ({}), Test {} ({})".format(
            count_train, turn_train, count_val, turn_val, count_test,
            turn_test))

    base_id = 130
    num_diag = 200

    def dump_dialog(dials, base_id, name, services):
        output_path = output_dir + "/" + name
        try:
            os.mkdir(output_path)
        except OSError as error:
            logging.warning("Dir exists: {}".format(error))
        for idx in range(len(dials) // num_diag + 1):
            if len(dials) > num_diag * idx:
                of_name = '{}/dialogues_{:03d}.json'.format(
                    output_path, base_id + idx)
                with open(of_name, 'w') as f:
                    json.dump(
                        dials[idx * num_diag:(idx + 1) * num_diag], f, indent=2)
        with open(f"{output_path}/schema.json", 'w') as schema_file:
            schemas = [schema[ser] for ser in services]
            json.dump(schemas, schema_file, indent=2)

    # save all dialogues
    dump_dialog(train_dials, base_id, 'train', train_services)
    base_id += (len(train_dials) // num_diag + 1)

    dump_dialog(val_dials, base_id, 'dev', val_services)
    base_id += (len(val_dials) // num_diag + 1)

    dump_dialog(test_dials, base_id, 'test', test_services)


def create_schema(ontology_file, slot_des_file, output_file):
    with open(ontology_file) as onto_file:
        ontology = json.load(onto_file)
    with open(slot_des_file) as sdes_file:
        slot_des = json.load(sdes_file)

    slot_value = {}
    ontology_values = {}
    for domain_slot, values in ontology.items():
        split_s = "-semi-" if "-semi-" in domain_slot else "-book-"
        domain, slot_name = domain_slot.strip().split(split_s, 1)
        slot_name = norm_slot_name(slot_name)

        # norm values
        norm_values, is_cat = norm_slot_values(values, slot_name)

        possible_values = [] if not is_cat else copy.deepcopy(norm_values)
        ds_key = "{}-{}".format(domain, slot_name)
        slot_value[ds_key] = {
            "is_categorical": is_cat,
            "possible_values": possible_values
        }
        ontology_values[ds_key] = {
            "is_categorical": is_cat,
            "possible_values": copy.deepcopy(norm_values)
        }

    schema = []
    domains = {}

    domain_slots_check = defaultdict(set)

    # add police domain  w/o slots
    p_domain_name = "police"
    domain_slots_check[p_domain_name] = set()
    domains[p_domain_name] = {
        "service_name":
            p_domain_name,
        "description":
            p_domain_name,
        "slots": [],
        "intents": [{
            "name": p_domain_name,
            "description": p_domain_name,
            "is_transactional": False,
            "required_slots": [],
            "optional_slots": {}
        }]
    }

    for domain_slot, des in slot_des.items():
        # NOTE: 'book' in domain is only used for booking, let's remove it
        domain_slot = domain_slot.replace("-book ", "-")
        domain_name, slot_name = domain_slot.strip().split("-", 1)
        slot_name = norm_slot_name(slot_name)
        domain_slots_check[domain_name].add(slot_name)

        if domain_name not in domains:
            domains[domain_name] = {
                "service_name":
                    domain_name,
                "description":
                    domain_name,
                "slots": [],
                "intents": [{
                    "name": domain_name,
                    "description": domain_name,
                    "is_transactional": False,
                    "required_slots": [],
                    "optional_slots": {}
                }]
            }
        # append slot
        slots = domains[domain_name]["slots"]
        sv_key = "{}-{}".format(domain_name, slot_name)
        if sv_key not in slot_value:
            logging.warning("Cannot find domain-slot key: {}!".format(sv_key))
            continue
        sv_info = slot_value[sv_key]
        slots.append({
            "name": slot_name,
            "description": ", ".join(des),
            "is_categorical": sv_info["is_categorical"],
            "possible_values": sv_info["possible_values"]
        })
    for _, v in domains.items():
        schema.append(v)
    with open(output_file, 'w') as o_file:
        json.dump(schema, o_file, indent=2)

    return domains, domain_slots_check, ontology_values


def parse():
    """
    Returns the arguments from the command line.
    """
    parser = ArgumentParser()
    parser.add_argument(
        "--output_dir", default='data', type=str, help="the output data dir")
    parser.add_argument(
        "--load",
        default=False,
        action="store_true",
        help="load raw data from web")
    parser.add_argument(
        '--data_json',
        default='data/MultiWOZ_2.1/data.json',
        type=str,
        help='raw data json file')
    parser.add_argument(
        '--sys_acts_json',
        default='data/MultiWOZ_2.1/system_acts.json',
        type=str,
        help='system actions json file')
    parser.add_argument(
        '--dev_file',
        default='data/MultiWOZ_2.1/valListFile.txt',
        type=str,
        help='dev file')
    parser.add_argument(
        '--test_file',
        default='data/MultiWOZ_2.1/testListFile.txt',
        type=str,
        help='test file')
    parser.add_argument(
        '--slot_des',
        default='data/MultiWOZ_2.1/slot_descriptions.json',
        type=str,
        help='slot description file')
    parser.add_argument(
        '--ontology',
        default='data/MultiWOZ_2.1/ontology.json',
        type=str,
        help='ontology file')
    args = parser.parse_args()

    return args


def main():
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    args = parse()
    logging.info('Create Schema-Guided schema file...')
    schema, domain_slots_check, domainslot_values_check = create_schema(
        args.ontology, args.slot_des, "{}/schema.json".format(args.output_dir))

    logging.info('Create Schema-Guided dialogues...')
    data = create_data(
        data_json=args.data_json,
        sys_acts_json=args.sys_acts_json,
        schema=schema,
        domain_slots_check=domain_slots_check,
        domainslot_values_check=domainslot_values_check)
    logging.info('Divide dialogues...')
    divide_data(
        data,
        schema=schema,
        dev_file=args.dev_file,
        test_file=args.test_file,
        output_dir=args.output_dir)


if __name__ == "__main__":
    main()
