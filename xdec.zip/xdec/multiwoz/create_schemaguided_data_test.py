import unittest
from multiwoz.create_schemaguided_data import create_data
import logging
import json

logger = logging.getLogger(__name__)

domain_slots_check = {
    "hotel":
        set([
            "area", "parking", "stars", "internet", "people", "day", "stay",
            "name", "price_range"
        ]),
    "train":
        set([
            "destination", "departure", "arrive_by", "leaveat", "people", "day"
        ]),
    "restaurant":
        set(["price_range", "name", "food", "time", "day", "area"])
}
domainslot_values_check = {
    "restaurant-price_range": {
        "is_categorical": True,
        "possible_values": ["expensive", "cheap", "moderate"]
    },
    "restaurant-name": {
        "is_categorical": False,
        "possible_values": []
    },
    "restaurant-food": {
        "is_categorical": False,
        "possible_values": []
    },
    "restaurant-time": {
        "is_categorical": False,
        "possible_values": []
    },
    "restaurant-area": {
        "is_categorical": True,
        "possible_values": ["north", "east", "south", "centre", "west"]
    },
    "train-destination": {
        "is_categorical": False,
        "possible_values": []
    },
    "train-departure": {
        "is_categorical": False,
        "possible_values": []
    },
    "train-arrive_by": {
        "is_categorical": False,
        "possible_values": []
    },
    "train-leaveat": {
        "is_categorical": False,
        "possible_values": []
    },
    "train-people": {
        "is_categorical": False,
        "possible_values": []
    },
    "train-day": {
        "is_categorical": False,
        "possible_values": []
    },
    "hotel-area": {
        "is_categorical": True,
        "possible_values": ["east", "west", "centre", "north", "south"]
    },
    "hotel-stars": {
        "is_categorical": True,
        "possible_values": ["2", "4|5", "0", "5", "1", "3|4", "3", "4"]
    },
    "hotel-parking": {
        "is_categorical": True,
        "possible_values": ["free", "no", "yes"]
    },
    "hotel-name": {
        "is_categorical": False,
        "possible_values": []
    },
    "hotel-day": {
        "is_categorical": False,
        "possible_values": []
    },
    "hotel-people": {
        "is_categorical": False,
        "possible_values": []
    },
    "hotel-stay": {
        "is_categorical": False,
        "possible_values": []
    },
    "hotel-internet": {
        "is_categorical": True,
        "possible_values": ["free", "dontcare", "no", "yes"]
    },
    "hotel-price_range": {
        "is_categorical": True,
        "possible_values": ["expensive", "cheap", "moderate"]
    }
}


class TestSGD(unittest.TestCase):

    def test_create_data_single_domain(self):

        sgd_data = create_data(
            data_json="test_data/unittest/multiwoz/single_sample.json",
            domain_slots_check=domain_slots_check,
            domainslot_values_check=domainslot_values_check)

        dialogue = sgd_data[0]
        self.assertEqual(12, len(dialogue['turns']))
        for idx in range(12):
            self.assertEqual(len(dialogue['turns'][idx]["frames"]), 1)

    def test_create_data(self):

        sgd_data = create_data(
            data_json="test_data/unittest/multiwoz/data_sample.json",
            domain_slots_check=domain_slots_check,
            domainslot_values_check=domainslot_values_check)

        logging.debug(json.dumps(sgd_data, indent=2))
        dialogue = sgd_data[0]
        self.assertEqual('PMUL1635.json', dialogue['dialogue_id'])
        self.assertEqual(['hotel', 'train'], dialogue["services"])
        self.assertEqual(18, len(dialogue['turns']))

        for idx in range(18):
            self.assertGreater(len(dialogue['turns'][idx]["frames"]), 0)

        turn_0 = {
            "utterance":
                "I need to book a hotel in the east that has 4 stars .",
            "frames": [{
                "service": "hotel",
                "slots": [],
                "state": {
                    "active_intent": "hotel",
                    "requested_slots": [],
                    "slot_values": {
                        "area": ["east"],
                        "stars": ["4"]
                    }
                }
            }],
            "speaker":
                "USER"
        }
        self.assertEqual(turn_0, dialogue['turns'][0])

        turn_1 = {
            "utterance":
                "I can help you with that . What is your price range ?",
            "frames": [{
                "service":
                    "hotel",
                "slots": [],
                "actions": [{
                    "act": "REQUEST",
                    "slot": "price_range",
                    "values": []
                }]
            }],
            "speaker":
                "SYSTEM"
        }
        self.assertEqual(turn_1, dialogue['turns'][1])

        turn_2 = {
            "utterance":
                "That does not matter as long as it has free wifi and parking .",
            "frames": [{
                "service": "hotel",
                "slots": [],
                "state": {
                    "active_intent": "hotel",
                    "requested_slots": [],
                    "slot_values": {
                        "area": ["east"],
                        "parking": ["yes"],
                        "stars": ["4"],
                        "internet": ["yes"]
                    }
                }
            }],
            "speaker":
                "USER"
        }
        self.assertEqual(turn_2, dialogue['turns'][2])

        turn_3 = {
            "utterance":
                "If you would like something cheap , I recommend the Allenbell . For something moderately priced , I would recommend the Warkworth House .",
            "frames": [{
                "service":
                    "hotel",
                "slots": [],
                "actions": [{
                    "act": "OFFER",
                    "slot": "price_range",
                    "values": ["cheap"]
                }, {
                    "act": "OFFER",
                    "slot": "price_range",
                    "values": ["moderate"]
                }, {
                    "act": "OFFER",
                    "slot": "name",
                    "values": ["Allenbell"]
                }, {
                    "act": "OFFER",
                    "slot": "name",
                    "values": ["Warkworth House"]
                }]
            }],
            "speaker":
                "SYSTEM"
        }
        self.assertEqual(turn_3, dialogue['turns'][3])

        # domain switch
        turn_8 = {
            "utterance":
                "I am looking to book a train that is leaving from Cambridge to Bishops Stortford on Friday .",
            "frames": [{
                "service": "train",
                "slots": [],
                "state": {
                    "active_intent": "train",
                    "requested_slots": [],
                    "slot_values": {
                        "destination": ["bishops stortford"],
                        "day": ["friday"],
                        "departure": ["cambridge"]
                    }
                }
            }, {
                "service": "hotel",
                "slots": [],
                "state": {
                    "active_intent": "hotel",
                    "requested_slots": [],
                    "slot_values": {
                        "day": ["friday"],
                        "people": ["1"],
                        "stay": ["1"],
                        "name": ["wartworth"],
                        "area": ["east"],
                        "parking": ["yes"],
                        "stars": ["4"],
                        "internet": ["yes"]
                    }
                }
            }],
            "speaker":
                "USER"
        }
        self.assertEqual(turn_8, dialogue['turns'][8])

        turn_17 = {
            'utterance': "You're welcome . Have a nice day !",
            'frames': [{
                'actions': [],
                'service': 'hotel',
                'slots': []
            }],
            'speaker': 'SYSTEM'
        }
        self.assertEqual(turn_17, dialogue['turns'][17])


if __name__ == '__main__':
    logging.basicConfig(datefmt="%m/%d/%Y %H:%M:%S", level=logging.INFO)
    unittest.main()
