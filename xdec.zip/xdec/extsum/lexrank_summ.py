import os
import re
import joblib
from tqdm import tqdm
from LAC import LAC
from lexrank import STOPWORDS, LexRank
from xdec_config import get_logger


logger = get_logger(__name__)


def sent_split(sent, keep_last=False):
    if not sent:
        return []
    else:
        result = []
        m = re.search(r"[。？！]+", sent)
        while m:
            if m.end() > 0:
                content = sent[:m.end()].strip()
                if content:
                    result.append(content)
            sent = sent[m.end():]    
            m = re.search(r"[。？！]+", sent)
        if sent and keep_last:
            sent = sent.strip()
            if sent:
                result.append(sent)
        return result


def process_content(content, max_len=300):
    content = re.sub(r"\s+", " ", content)
    idx = max(content[:50].rfind(")"), content[:50].rfind(" "))
    if idx > 0:
        content = content[idx + 1:]
    indices = list(
        filter(lambda x: x > 0, [
            content[-20:].rfind("("), content[-20:].rfind("["),
            content[-20:].rfind(" "), content[-20:].rfind("作者"),
            content[-20:].rfind("记者")
        ]))
    idx = min(indices) if indices else -1
    if idx > 0:
        content = content[:idx - 20]
    contents = content.strip().split("。")
    result = ""
    i = 0
    while i < len(contents) and len(result) + len(contents[i]) < max_len - 1:
        if not contents[i]:
            i += 1
            continue
        result += contents[i] + "。"
        i += 1
    return result


def q2b(qstr):
    rstring = ""
    for uchar in qstr:
        inside_code = ord(uchar)
        if inside_code == 12288:
            inside_code = 32
        elif (inside_code >= 65281 and inside_code <= 65374):
            inside_code -= 65248
        if chr(inside_code) in [".", ",", ";", "!", '"', "'", "“", "”"]:
            inside_code = ord(uchar)
        if uchar == "．":
            rstring += "."
        else:
            rstring += chr(inside_code)
    return rstring


def post_process_trunk(s):
    if not s:
        return s
    result = ""
    for i in range(len(s)-1, -1, -1):
        if i in ["。", "，", "；", "？", "！"]:
             result = s[:i]
             break
    return s if not result else result + "。"


class ExtSummarizer:
    def __init__(self):
        self.lac = LAC(mode='seg')
        self.lxr = self.init_lexrank()

    def init_lexrank(self, doc_dir=".data/resources/sogou_corpus/", num_files=1000):
        documents = []
        for i in tqdm(range(1, num_files+1)):
            with open(os.path.join(doc_dir, f"{i}.txt")) as input_:
                documents.append(input_.readlines())
        return LexRank(documents)

    def lexrank_doc(self, paragraph, num_sents=2):
        paragraph = process_content(q2b(paragraph))
        sents = sent_split(paragraph)
        sents = [" ".join(self.lac.run(x)) for x in sents]
        scores = self.lxr.rank_sentences(sents)
        logger.info(f"Scores: {scores}")
        result = ""
        ids = list(reversed(scores.argsort().tolist()))
        # logger.info(f"ids: {ids}")
        ids = ids[:num_sents]
        # logger.info(f"ids: {ids}")
        if len(ids) == 0:
            return paragraph
        best_id = ids[0]
        for id in ids:
            result += sents[id]
        # result = re.sub(r"\s+", "", result)
        result = re.sub(r"\s+", "", sents[0])
        # if 5 > len(result) > 50:
        if len(result) < 10:
            result = re.sub(r"\s+", "", sents[best_id])
        elif scores[best_id] - 0.4 > scores[0] and len(result) / len(sents[best_id]) > 0.5:
            # logger.info(f"From: {result}")
            result += re.sub(r"\s+", "", sents[best_id])
            # logger.info(f"To: {result}")
        # logger.info(f"Result: {result}")
        return post_process_trunk(result[:100])


if __name__ == "__main__":
    summarizer = ExtSummarizer()
    lxr = summarizer.init_lexrank()
    joblib.dump(lxr, ".data/models/lxr.joblib.gz")
