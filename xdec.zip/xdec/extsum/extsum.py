import os
import torch
from utils_nlp.models.transformers.extractive_summarization import (
    ExtSumProcessor,
    ExtractiveSummarizer
)


def train(args):
    model_name = args.model_name  # rbt3
    batch_size = 4 # batch size, unit is the number of samples
    max_pos_length = 512
    # GPU used for training
    num_gpus = torch.cuda.device_count()
    # Encoder name. Options are: 1. baseline, classifier, transformer, rnn.
    encoder = "transformer"
    # Learning rate
    learning_rate = 2e-3
    # How often the statistics reports show up in training, unit is step.
    report_every = 100
    # total number of steps for training
    max_steps = 1e2
    # number of steps for warm up
    warmup_steps = 5e2
    quick_run = False
    cache_dir = ""
    if not quick_run:
        max_steps = 5e4
        warmup_steps = 5e3
    ext_sum_train = {}
    processor = ExtSumProcessor("hfl/rbt3")
    summarizer = ExtractiveSummarizer(processor, model_name=model_name, cache_dir=cache_dir)
    summarizer.fit(
            ext_sum_train,
            num_gpus=num_gpus,
            batch_size=batch_size,
            gradient_accumulation_steps=2,
            max_steps=max_steps,
            learning_rate=learning_rate,
            warmup_steps=warmup_steps,
            verbose=True,
            report_every=report_every,
            clip_grad_norm=False
    )
    summarizer.save_model(
        os.path.join(
            CACHE_DIR,
            "extsum_modelname_{0}_usepreprocess{1}_steps_{2}.pt".format(
                MODEL_NAME, USE_PREPROCSSED_DATA, MAX_STEPS
            ),
    )
)

if __name__ == "__main__":
    args = {}

