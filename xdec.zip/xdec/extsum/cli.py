import os
os.environ["MKL_NUM_THREADS"] = "4"
os.environ["OMP_NUM_THREADS"] = "4"
import re
import sys
import csv
import json
import click
from collections import defaultdict
from types import SimpleNamespace
from xdec_config import get_logger
from xdec_utils.lang import sent_split
from tqdm import tqdm


logger = get_logger(__name__)


@click.group()
def cli():
    pass


@click.command()
@click.option(
    "--input_file_name",
    default=".data/zj/train.clean.jsonl",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/zj/ext",
    help="output file name")
def process_zj_ext(input_file_name, output_file_name):
    with open(input_file_name) as input_:
        for i, line in enumerate(input_):
            if i > 50:
                sys.exit(-1)
            datum = json.loads(line)
            source = datum["src"]
            target = datum["tgt"]
            source_sents = sent_split(source)
            target_sents = sent_split(target)
            source_sents = [[tok for tok in sent] for sent in source_sents]
            target_sents = [[tok for tok in sent] for sent in target_sents]
            # TODO: preprocess data


if __name__ == "__main__":
    cli.add_command(process_zj_ext)
    cli()
