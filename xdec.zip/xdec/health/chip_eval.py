# _*_coding=utf-8_*_
'''
chip2020 评测F1值的计算函数，同时展示每个关系类别的一个预测结果
'''
import os
import re
import json
import click
import numpy as np
from xdec_config import get_logger

logger = get_logger(__name__)


@click.group()
def cli():
    pass


def load_line_json(path):
    with open(path, 'r', encoding='utf-8') as _infile:
        _data = [json.loads(line) for line in _infile]
    return _data


def dump_line_json(_data, out_path):
    with open(out_path, 'w', encoding='utf-8') as _outfile:
        for ins in _data:
            _outfile.write(json.dumps(ins, ensure_ascii=False) + '\n')


def extract_from_spo(spo):
    return spo['subject'], spo['subject_type'], spo['object']['@value'], spo[
        'object_type']['@value'], spo['predicate']


Spo_split = '[SpoSplit]'


def convert2str(spo_list):
    str_list = []
    for spo in spo_list:
        subj, subj_type, obj, obj_type, predicate = extract_from_spo(spo)
        if predicate == 'NA':
            continue
        str_list.append("%s%s%s%s%s%s%s%s%s" %
                        (subj, Spo_split, subj_type, Spo_split, obj, Spo_split,
                         obj_type, Spo_split, predicate))
    return str_list


def update_count(count_dict, pred, gold):
    '''
    count_dict = {
        'overall':{'TP': 0, 'FP': 0, 'FN': 0, 'TN':0},
        'each_relation':{'TP': 0, 'FP': 0, 'FN': 0, 'TN':0},
    }
    '''
    pred = convert2str(pred)
    gold = convert2str(gold)
    spo_list = list(set(pred + gold))
    for spo in spo_list:
        subj, subj_type, obj, obj_type, predicate = spo.split(Spo_split)
        if spo in pred and spo in gold:
            count_dict['overall']['TP'] += 1
            count_dict[predicate]['TP'] += 1
        elif spo in pred and spo not in gold:
            count_dict['overall']['FP'] += 1
            count_dict[predicate]['FP'] += 1
        elif spo not in pred and spo in gold:
            count_dict['overall']['FN'] += 1
            count_dict[predicate]['FN'] += 1
    return count_dict


def compute_p_r_f1(matrix):
    p = matrix['TP'] / (matrix['TP'] + matrix['FP']) if (
        matrix['TP'] + matrix['FP']) > 0 else 0
    r = matrix['TP'] / (matrix['TP'] + matrix['FN']) if (
        matrix['TP'] + matrix['FN']) > 0 else 0
    f1 = 2 * p * r / (p + r) if p + r > 0 else 0.0
    return p, r, f1


def metrics_report(count_dict, print_report=True):
    name_width = max([len(key) for key in count_dict])
    last_line_heading = 'macro avg'
    digits = 5
    width = max(name_width, len(last_line_heading), digits)

    headers = ["prec", "recall", "f1-score", "support"]
    head_fmt = u'{:>{width}s} ' + u' {:>9}' * len(headers)
    report = head_fmt.format(u'', *headers, width=width)
    report += u'\n\n'

    row_fmt = u'{:>{width}s} ' + u' {:>9.{digits}f}' * 3 + u' {:>9}\n'

    ps, rs, f1s, s = [], [], [], []
    for type_name in count_dict:
        if type_name == 'overall':
            continue
        p, r, f1 = compute_p_r_f1(count_dict[type_name])
        report += row_fmt.format(
            *[type_name, p, r, f1, count_dict[type_name]['TP']],
            width=width,
            digits=digits)
        ps.append(p)
        rs.append(r)
        f1s.append(f1)
        s.append(count_dict[type_name]['TP'])
    report += u'\n'

    # compute averages
    micro_p, micro_r, micro_f1 = compute_p_r_f1(count_dict['overall'])
    report += row_fmt.format(
        'micro avg',
        micro_p,
        micro_r,
        micro_f1,
        np.sum(s),
        width=width,
        digits=digits)
    if micro_f1 != 0:
        report += row_fmt.format(
            last_line_heading,
            np.average(ps, weights=s),
            np.average(rs, weights=s),
            np.average(f1s, weights=s),
            np.sum(s),
            width=width,
            digits=digits)
    if print_report:
        print(report)
    return micro_f1


@click.command()
@click.option(
    "--pred_file_name",
    default=".data/chip20/val_data.json",
    help="pred file name")
@click.option(
    "--gold_file_name",
    default=".data/chip20/val_data.json",
    help="gold file name")
@click.option(
    "--schema_file_name",
    default=".data/chip20/53_schemas.json",
    help="schema file name")
def run(pred_file_name, gold_file_name, schema_file_name):
    schemas = load_line_json(schema_file_name)
    pred_data = load_line_json(pred_file_name)
    gold_data = load_line_json(gold_file_name)
    count_dict = {'overall': {'TP': 0, 'FP': 0, 'FN': 0, 'TN': 0}}
    for s in schemas:
        predicate = s['predicate']
        count_dict[predicate] = {'TP': 0, 'FP': 0, 'FN': 0, 'TN': 0}
    # 整理成字典的形式（首先验证训练集和验证集以及测试集数据没有text重复的）(没有重复的句子）
    pred_data_dict = {ins['text']: ins['spo_list'] for ins in pred_data}
    gold_data_dict = {ins['text']: ins['spo_list'] for ins in gold_data}
    all_texts = list(
        set(list(pred_data_dict.keys()) + list(gold_data_dict.keys())))
    for text in all_texts:
        _pred_spo = pred_data_dict[text] if text in pred_data_dict else []
        _gold_spo = gold_data_dict[text] if text in gold_data_dict else []
        count_dict = update_count(count_dict, _pred_spo, _gold_spo)
    metrics_report(count_dict)


def re_f1_score(pred, gold, label_list, average=None, print_report=True):
    count_dict = {'overall': {'TP': 0, 'FP': 0, 'FN': 0, 'TN': 0}}
    for label in label_list:
        count_dict[label] = {'TP': 0, 'FP': 0, 'FN': 0, 'TN': 0}
    for i in range(len(pred)):
        if pred[i] == gold[i]:
            if pred[i] == 'NA':
                continue
            else:
                count_dict['overall']['TP'] += 1
                count_dict[pred[i]]['TP'] += 1
        else:
            if pred[i] == 'NA':
                count_dict[gold[i]]['FN'] += 1
                count_dict['overall']['FN'] += 1
            else:
                if gold[i] == 'NA':
                    count_dict[pred[i]]['FP'] += 1
                    count_dict['overall']['FP'] += 1
                else:
                    count_dict[pred[i]]['FP'] += 1
                    count_dict[gold[i]]['FN'] += 1
                    count_dict['overall']['FP'] += 1
                    count_dict['overall']['FN'] += 1
    return metrics_report(count_dict, print_report=print_report)


@click.command()
@click.option(
    "--schema_file_name",
    default=".data/chip20/53_schemas.json",
    help="schema file name")
@click.option(
    "--input_file_name",
    default="transformer_models/chip20_large_lr7e-5_s512_t128_ep50_b96/val.output.txt",
    help="input txt file name")
@click.option(
    "--source_file_name",
    default=".data/chip20/val_data.json",
    help="source file name")
@click.option(
    "--output_file_name",
    default="transformer_models/chip20_large_lr7e-5_s512_t128_ep50_b96/val.output.jsonl",
    help="output jsonl file name")
def convert_seq_to_triple(schema_file_name, input_file_name, source_file_name,
                          output_file_name):
    schema_types = {}
    with open(schema_file_name) as schema_file:
        for line in schema_file:
            obj = json.loads(line)
            if obj["predicate"] != "同义词":
                schema_types[obj["predicate"]] = obj
            else:
                schema_types[obj["predicate"] + "-" + obj["subject_type"]] = obj

    with open(input_file_name) as input_file, \
        open(source_file_name) as source_file, \
        open(output_file_name, "w") as output_file:
        sources = [json.loads(x)["text"] for x in source_file]
        inputs = [x.strip() for x in input_file]
        for src, inp in zip(sources, inputs):
            low_src = src.lower()
            inp = re.sub(r"\s+", "", inp)
            inp = inp[:-len("<endrels>")]
            idx = inp.find("</rel>")
            spo_list = []
            while idx > -1:
                head = inp[len("<rel>"):idx]
                head = head.replace("<obj>", "<subj>")
                try:
                    predicate, subj, obj = head.split("<subj>")
                except:
                    logger.warning(f"error processing input chunk: {inp}")
                    inp = inp[idx + len("</rel>"):]
                    idx = inp.find("</rel>")
                    continue
                if subj in low_src:
                    subj_idx = low_src.find(subj)
                    subj = src[subj_idx:subj_idx + len(subj)]
                if obj in low_src:
                    obj_idx = low_src.find(obj)
                    obj = src[obj_idx:obj_idx + len(obj)]
                if predicate in schema_types:
                    subject_type = schema_types[predicate]["subject_type"]
                    object_type = schema_types[predicate]["object_type"]
                    if "同义词-" in predicate:
                        predicate = "同义词"
                    spo_list.append({
                        "predicate": predicate,
                        "subject": subj,
                        "subject_type": subject_type,
                        "object": {
                            "@value": obj,
                        },
                        "object_type": {
                            "@value": object_type
                        }
                    })
                inp = inp[idx + len("</rel>"):]
                idx = inp.find("</rel>")
            output_file.write(
                json.dumps({
                    "text": src,
                    "spo_list": spo_list
                },
                           ensure_ascii=False) + "\n")


if __name__ == '__main__':
    cli.add_command(run)
    cli.add_command(convert_seq_to_triple)
    cli()
