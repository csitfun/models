import os
import re
import sys
import csv
import json
import math
import click
import random
from wikisql.processors import WikiSQL
from xdec_config import get_logger
from tqdm import tqdm
from summ import rouge
from s2s_ft.utils import detokenize
from collections import defaultdict
from bs4 import BeautifulSoup
from langdetect import detect

logger = get_logger(__name__)


@click.group()
def cli():
    pass


@click.command()
@click.option(
    "--gold_file_name",
    default=".data/health/test.200609.jsonl",
    help="gold file name")
@click.option(
    "--pred_file_name",
    default="transformer_models/health_cat_roberta_2e-5_b128/pred_results.txt",
    help="pred file name")
@click.option("--prob_threshold", default=0.99, help="prob threshold")
def eval_result(gold_file_name, pred_file_name, prob_threshold):
    golds = []
    tp = 0
    sp = 0
    co = 0
    with open(gold_file_name) as gold_file:
        for line in gold_file:
            golds.append(json.loads(line)["gold_label"] == "True")

    preds = []
    with open(pred_file_name) as pred_file:
        for line in pred_file:
            pos, neg = eval(line.split("\t")[2].strip())
            prob = math.exp(pos) / (math.exp(pos) + math.exp(neg))
            preds.append(prob > prob_threshold)

    for gold, pred in zip(golds, preds):
        if gold:
            tp += 1
        if pred:
            sp += 1
        if gold and pred:
            co += 1

    p = co / sp
    r = co / tp
    f = 2 * p * r / (p + r)
    print("P: {} R: {} F: {}".format(p, r, f))


@click.command()
@click.option(
    "--input_file_name",
    default=".data/rel/CDR_Data/CDR.Corpus.v010516/CDR_TrainingSet.PubTator.txt",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/rel/CDR_Data/CDR.Corpus.v010516/processed/train.causes.jsonl",
    help="output file name")
def process_cdr(input_file_name, output_file_name):
    with open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        chunks = input_.read().split("\n\n")
        for chunk in chunks:
            if not chunk.strip():
                continue
            data = chunk.split("\n")
            logger.debug(f"Head: {data[:2]}")
            doc_id, _, title = data[0].split("|", maxsplit=2)
            _, _, abstract = data[1].split("|", maxsplit=2)
            chemicals = {}
            diseases = {}
            relations = set()
            for datum in data[2:]:
                if "\tCID\t" in datum:
                    _sdatum = datum.split("\t")
                    logger.debug(f"datum: {_sdatum}")
                    _, _, chemical, disease = _sdatum
                    relations.add((chemical, disease))
                else:
                    _sdatum = datum.split('\t')
                    logger.debug(f"Datum: {_sdatum}")
                    try:
                        _, _, _, name, type_, eid = datum.split("\t")
                        eids = [eid]
                        mentions = [name]
                    except:
                        _, _, _, name, type_, eids, mentions = datum.split("\t")
                        eids = eids.split("|")
                        mentions = mentions.split("|")
                    for eid, name in zip(eids, mentions):
                        if type_ == "Chemical":
                            if eid not in chemicals:
                                chemicals[eid] = name
                            else:
                                if len(chemicals[eid]) < len(name):
                                    chemicals[eid] = name
                        elif type_ == "Disease":
                            if eid not in diseases:
                                diseases[eid] = name
                            else:
                                if len(diseases[eid]) < len(name):
                                    diseases[eid] = name
            logger.debug(f"Relations: {relations}")
            for cid in chemicals:
                for did in diseases:
                    example = {
                        "pairID": f"{doc_id}|{cid}|{did}",
                        "sentence1": f"{chemicals[cid]} causes {diseases[did]}",
                        "sentence2": f"Title: {title}, Abstract: {abstract}"
                    }
                    example["gold_label"] = "True" if (
                        cid, did) in relations else "False"
                    output.write(json.dumps(example, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--predict_file_name",
    default="transformer_models/xnli_rel_roberta_ep20/pred_results.txt",
    help="predict file name")
@click.option(
    "--gold_file_name",
    default=".data/rel/CDR_Data/CDR.Corpus.v010516/CDR_DevelopmentSet.PubTator.txt",
    help="gold file name")
def eval_cdr(predict_file_name, gold_file_name):
    rr = {}
    for item in open(
            ".data/rel/CDR_Data/CDR.Corpus.v010516/processed/dev.causes.jsonl"):
        datum = json.loads(item)
        pair_id = datum["pairID"]
        rr[pair_id] = datum
    with open(predict_file_name) as predict, \
            open(gold_file_name) as gold:
        chunks = gold.read().split("\n\n")
        relations = set()
        for chunk in chunks:
            if not chunk.strip():
                continue
            data = chunk.split("\n")
            logger.debug(f"Head: {data[:2]}")
            doc_id, _, title = data[0].split("|", maxsplit=2)
            _, _, abstract = data[1].split("|", maxsplit=2)
            chemicals = {}
            diseases = {}
            abstract = data[1]
            for datum in data[2:]:
                if "\tCID\t" in datum:
                    _sdatum = datum.split("\t")
                    logger.debug(f"datum: {_sdatum}")
                    _, _, chemical, disease = _sdatum
                    relations.add((doc_id, chemical, disease))
        preds = set()
        for pred_item in predict:
            ids, pred, _ = pred_item.split("\t")
            if pred == "True":
                try:
                    doc_id, cid, did = ids.split("|")
                    preds.add((doc_id, cid, did))
                except:
                    logger.warn(f"Unable to parse ids: {ids}")
        correct = 0
        for p in preds:
            if p in relations:
                correct += 1
            else:
                abstract = rr[f"{p[0]}|{p[1]}|{p[2]}"]
                logger.info(f"[Error] {abstract}")
        for p in relations:
            if p not in preds:
                try:
                    abstract = rr[f"{p[0]}|{p[1]}|{p[2]}"]
                    logger.info(f"[Error] {abstract}")
                except:
                    pass
        p = correct / len(preds)
        r = correct / len(relations)
        logger.info(f"P: {p}\tR: {r}\tF: {2*p*r/(p+r)}")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/chip20/train_data.json",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/chip20/train_processed.jsonl",
    help="output file name")
def process_chip20(input_file_name, output_file_name):
    with open(input_file_name) as input_,\
            open(output_file_name, "w") as output:
        for line in input_:
            datum = json.loads(line)
            source = re.sub(r"\s+", "", datum["text"].replace("@", "<ent>"))
            target = ""
            for spo in datum["spo_list"]:
                pred = spo["predicate"]
                if pred == "同义词":
                    pred += "-" + spo["subject_type"]
                subj = spo["subject"]
                obj = spo["object"]["@value"]
                target += f"<rel>{pred}<subj>{subj}<obj>{obj}</rel>"
            target += "<endrels>"
            output.write(
                json.dumps({
                    "src": source,
                    "tgt": target
                }, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--input_file_dir", default=".data/medguide", help="input file dir")
@click.option(
    "--input_file_list",
    default=".data/medguide/txt.filelist",
    help="input file list")
@click.option(
    "--output_file_name",
    default=".data/chip20/med_guide.txt",
    help="output file name")
def gen_med_guide(input_file_dir, input_file_list, output_file_name):
    STOP_LINE = "临床路径表单"
    with open(input_file_list) as input_list, \
        open(output_file_name, "w") as output:
        for input_file_name in input_list:
            with open(os.path.join(input_file_dir,
                                   input_file_name.strip())) as input_:
                for line in input_:
                    line = line.strip()
                    if line.startswith("（") or line.startswith("("):
                        continue
                    if not line:
                        continue
                    if line.endswith(STOP_LINE):
                        break
                    output.write(line.lower() + "\n")


@click.command()
@click.option(
    "--input_file_name", default=".data/chip20/bmj.txt", help="input file name")
@click.option(
    "--output_file_name",
    default=".data/chip20/bmj_processed.txt",
    help="output file name")
def process_bmj(input_file_name, output_file_name):

    def _process_buf(buf, visited):
        soup = BeautifulSoup(buf, "html5lib")
        dis_name = soup.find("head").find("title").text.split(" ")[0]
        meta_description = soup.find("meta", attrs={"name": "description"})
        if meta_description:
            meta_description = meta_description["content"]
            if meta_description.strip() and detect(meta_description) == "zh-cn":
                result = ""
                if dis_name not in visited:
                    result = dis_name + " @ " + meta_description.strip() + "\n"
                    paragraphs = soup.find_all("p", attrs={"class": "w-75"})
                    for paragraph in paragraphs:
                        spans = paragraph.find_all("span")
                        for span in spans:
                            span.decompose()
                        text = re.sub(r"\s+", " ", paragraph.text.strip())
                        if len(text) > 10:
                            result += text + "\n"
                result = result.strip()
                if not result:
                    return None
                logger.info(result)
                visited.add(dis_name)
                return result + "\n"
        return None

    with open(input_file_name) as input_, \
        open(output_file_name, "w") as output:
        buf = ""
        page_count = 0
        visited = set()
        for line in input_:
            if line.startswith("###"):
                page_count += 1
                result = _process_buf(buf, visited)
                if result:
                    output.write(result)
                buf = ""
                logger.info(f"Page processed: {page_count}")
            else:
                buf = buf + line


if __name__ == "__main__":
    cli.add_command(eval_result)
    cli.add_command(process_cdr)
    cli.add_command(eval_cdr)
    cli.add_command(process_chip20)
    cli.add_command(gen_med_guide)
    cli.add_command(process_bmj)
    cli()
