#!/usr/bin/env python
#--*-- coding: utf-8 --*--

import requests
from argparse import ArgumentParser
import logging
import json
from collections import defaultdict
import os

SYSTAGS = {
    "name": "name",
    'time': 'time',
    'date': 'date',
    'location': 'location',
    'station': 'location',
    'city': 'location',
    'destination': 'location',
    'number': 'number',
    'address': 'address',
    'rating': 'rating',
    'price': 'price',
    'fare': 'fare',
    'type': 'type'
}

OTHER = "other"
POSSIBLE_VALUES = 'possible_values'
TRUE_FALSE = set(["True", "False"])
CATEGORICAL_SLOT = 'categorical_slot'
BOOL_SLOT = "bool_slot"
NUMBER_SLOT = "number_slot"


def is_number_slot(system_slot):
    if len(system_slot['possible_values']) > 0:
        is_number = True
        for value in system_slot['possible_values']:
            if not value.isnumeric():
                is_number = False
        return is_number
    else:
        return False


def is_boolean_slot(system_slot):
    possible_values = system_slot.get(POSSIBLE_VALUES, [])
    return set(possible_values) == TRUE_FALSE


def get_slots(input_file, stat_dict):
    logging.info("Loading file: {}".format(input_file))
    with open(input_file) as schema_file:
        entry = json.load(schema_file)
        for service in entry:
            for slot in service['slots']:
                is_num = is_number_slot(slot)
                is_bool = is_boolean_slot(slot)
                is_cat = slot["is_categorical"]
                slot_name = slot['name']
                stat_dict['slot_name'][slot_name] += 1
                if is_num:
                    for pv in slot["possible_values"]:
                        stat_dict[NUMBER_SLOT][slot_name].add(int(pv))
                elif is_bool:
                    stat_dict[BOOL_SLOT].add(slot_name)
                elif is_cat:
                    for pv in slot["possible_values"]:
                        stat_dict[CATEGORICAL_SLOT][slot_name].add(pv)


def get_actions(input_path, stat_dict):
    for root, dirs, files in os.walk(input_path):
        logging.info("Loading data from {} {}".format(root, dirs))
        for f in files:
            if 'dialogues_' in f:
                logging.info("Loading file {}".format(f))
                with open(os.path.join(input_path, f)) as example_file:
                    entry = json.load(example_file)
                    for dialog in entry:
                        services = dialog["services"]
                        dialog_type = "Multi" if len(services) > 0 else "Single"
                        for turn in dialog["turns"]:
                            frames = turn["frames"]
                            dk = "{}-{}".format(dialog_type, turn["speaker"])
                            stat_dict["dial_services"][dk].append(len(frames))
                            for frame in frames:
                                actions = frame.get('actions', [])
                                for act in actions:
                                    stat_dict['action'][act['act']] += 1


def sort_kv(input_dict):
    return sorted([(k, v) for k, v in input_dict.items()],
                  reverse=True,
                  key=lambda x: x[1])


def print_dict(input_dict):
    return "\n".join(["{}: {}".format(k, v) for k, v in input_dict.items()])


def do_stat(input_path, output):
    stat_dict = {}
    stat_dict['slot_name'] = defaultdict(int)
    stat_dict['action'] = defaultdict(int)
    stat_dict['dial_services'] = defaultdict(list)
    stat_dict[NUMBER_SLOT] = defaultdict(set)
    stat_dict[CATEGORICAL_SLOT] = defaultdict(set)
    stat_dict[BOOL_SLOT] = set()

    for data in ["train", "dev", "test"]:
        get_slots(os.path.join(input_path, data, "schema.json"), stat_dict)
        get_actions(os.path.join(input_path, data), stat_dict)

    logging.info("################# Slot names ################# \n{}".format(
        print_dict(stat_dict['slot_name'])))
    sorted_slot_names = ('Slot names', sort_kv(stat_dict['slot_name']))

    logging.info("################# Actions ################# \n{}".format(
        print_dict(stat_dict['action'])))
    sorted_actions = ("Actions", sort_kv(stat_dict['action']))

    logging.info("################# Number slots ################# \n{}".format(
        print_dict(stat_dict[NUMBER_SLOT])))
    logging.info("################# Bool slots ################# \n{}".format(
        stat_dict[BOOL_SLOT]))
    logging.info("################# Cat slots ################# \n{}".format(
        print_dict(stat_dict[CATEGORICAL_SLOT])))

    logging.info("################# dial_services ##################### \n")
    for ds_name, ds_count in stat_dict['dial_services'].items():
        logging.info("{}: max: {} ({}), min: {} ({}), avg: {:.2f}".format(
            ds_name, max(ds_count), ds_count.count(max(ds_count)),
            min(ds_count), ds_count.count(min(ds_count)),
            sum(ds_count) / float(len(ds_count))))

    with open(output, 'w') as output_file:
        for (title, sorted_kv) in [sorted_slot_names, sorted_actions]:
            output_file.write("{}\n".format(title))
            for name, count in sorted_kv:
                output_file.write("{}\t{}\n".format(name, count))
            output_file.write("\n")


def parse():
    """
    Returns the arguments from the command line.
    """
    parser = ArgumentParser()
    parser.add_argument(
        '--input_path', default='.data/dstc/data/all', type=str, help='input')
    parser.add_argument('--output', default='stat.txt', type=str, help='output')

    args = parser.parse_args()
    return args


if __name__ == '__main__':
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    args = parse()

    do_stat(args.input_path, args.output)
