#!/usr/bin/env python
#--*-- coding:utf-8 --*--

import os
import logging
import json
from argparse import ArgumentParser
from nltk.tokenize import TreebankWordTokenizer

from preprocessing.translate import do_backtranslation
from dstc.generic import int_to_english

DESCRIPTION = "description"
SERVICE_NAME = "service_name_ "
SLOT_NAME = "slot_name_ "
INTENT_NAME = "intent_name_ "
TOKEN = "token"
POS = "pos"
NER = "ner"

SLOT_ID = "SLOTID"
SLOT_VALUE = "SLOTVALUE"
FRAMES = "frames"
STATE = "state"
ACTIONS = "actions"
SLOT_VALUES = "slot_values"
VALUE_ACTIONS = ["CONFIRM", "OFFER", "INFORM"]

YEAR_TO_NUMBER = []


def append_english(idx):
    engs = int_to_english(idx)
    if engs is not None:
        for eng in engs:
            YEAR_TO_NUMBER.append((eng, idx))


for idx in range(1919, 2021):
    append_english(idx)

YEAR_TO_NUMBER = sorted(
    YEAR_TO_NUMBER, key=lambda x: (len(x[0]), x[1]), reverse=True)


def english_norm(turn_u, phone_numbers):
    old_res = turn_u
    for (eng, idx) in YEAR_TO_NUMBER:
        raw_eng = " " + eng
        turn_u = turn_u.replace(raw_eng, " " + str(idx))

    for p_num in sorted([x for x in phone_numbers],
                        key=lambda x: len(x),
                        reverse=True):
        turn_u = turn_u.replace(p_num, "999-999-9999")

    if old_res != turn_u:
        logging.info("DIFF: \n{}\n{}".format(old_res, turn_u))
    return turn_u


def replace_brackets(w):
    w_r = w.replace('-LRB-', '(').replace('-RRB-', ')')
    w_r = w_r.replace('-LSB-', '[').replace('-RSB', ']')
    w_r = w_r.replace("\u00a0", '-')
    return w_r.replace('-LCB-', '{').replace('-RCB', '}')


def parse():
    """
    Returns the arguments from the command line.
    """
    parser = ArgumentParser()

    parser.add_argument(
        '--task',
        default='',
        type=str,
        help='task name: schema, utterance, merge, merge_schema')

    parser.add_argument(
        '--data',
        default='.data/dstc/data/all/dev',
        type=str,
        help='where to load data from.')
    parser.add_argument(
        '--output_file', default='', type=str, help='output file name')

    parser.add_argument(
        '--output_path',
        default='.data/dstc/data/all_pos/dev',
        type=str,
        help='where to write data.')
    parser.add_argument(
        '--norm',
        default=False,
        action="store_true",
        help='normalize the utterances')
    parser.add_argument(
        '--tag_file',
        nargs='+',
        default=[],
        type=str,
        help='tag file name list')

    parser.add_argument(
        '--schema_file', default='', type=str, help='schema file name')

    args = parser.parse_args()

    return args


def process_schema(schema_file, output_file):
    output_file = open(output_file, 'w')

    logging.info("Loading schema file {}".format(schema_file))
    with open(schema_file, 'r') as example_file:
        entry = json.load(example_file)
        for service in entry:

            service_name = service['service_name']
            description = service[DESCRIPTION]

            output_file.write("{}{}\n".format(SERVICE_NAME, service_name))
            output_file.write(description + "\n")
            output_file.write(do_backtranslation(description) + "\n")

            slots = service['slots']
            for _, s in enumerate(slots):
                s_name = s['name']
                s_description = s[DESCRIPTION]
                output_file.write("{}{}\n".format(SLOT_NAME, s_name))
                output_file.write(s_description + '\n')
                output_file.write(do_backtranslation(s_description) + "\n")

            intents = service['intents']
            for _, i in enumerate(intents):
                i_name = i['name']
                i_description = i[DESCRIPTION]
                output_file.write("{}{}\n".format(INTENT_NAME, i_name))
                output_file.write(i_description + '\n')
                output_file.write(do_backtranslation(i_description) + "\n")

    output_file.close()


def parse_slot_values(word, pos, ner):
    """
    word: [SLOTID cat SLOTVALUE Sps SLOTID city _ of _ event SLOTVALUE V1 ## V2]
    pos: [] ignore for now
    ner: [] ignore for now
    """
    slot_id_val = {}
    words = " ".join(word)
    if SLOT_VALUE in words:
        for id_val in words.split(SLOT_ID):
            if SLOT_VALUE in id_val:
                id, val = id_val.split(SLOT_VALUE)
                vals = [x.strip() for x in val.split(" ## ")]
                slot_id_val["".join(id.strip().split())] = vals
    return slot_id_val


def get_streams(stream_file, pos_map, is_schema=False):
    '''
    merge dialogues.

    {
    "docId": "input.txt",
    "sentences": [
        {
        "index": 0,
        "line": 1,
        "entitymentions": [
            {
            "docTokenBegin": 0,
            "docTokenEnd": 2,
            "tokenBegin": 0,
            "tokenEnd": 2,
            "text": "Stanford University",
            "characterOffsetBegin": 0,
            "characterOffsetEnd": 19,
            "ner": "ORGANIZATION"
            },
        ],
        "tokens": [
            {
            "index": 1,
            "word": "Stanford",
            "originalText": "Stanford",
            "lemma": "Stanford",
            "characterOffsetBegin": 0,
            "characterOffsetEnd": 8,
            "pos": "NNP",
            "ner": "ORGANIZATION",
            "before": "",
            "after": " "
            }
        ]
        }
    ]
    '''

    with open(stream_file) as example_file:
        entry = json.load(example_file)
        one_sent = []  # save all the tokens in one sentence
        for idx, sent in enumerate(entry['sentences']):

            is_head = idx % 3 == 0 if is_schema else idx % 4 == 0
            # schema: headline, description, back_translation
            # utterance: headline, utterance, action slots, state slots
            if is_head:
                one_sent = []  # start of one sentence
                word = [replace_brackets(tok['word']) for tok in sent['tokens']]
                if is_schema:
                    # service_name, ssi_info, and ssi_name
                    ssi_info, ssi_name = "".join(word[:4]), "".join(word[4:])
                    if ssi_info in SERVICE_NAME:
                        service_name = ssi_name
                    key = (service_name, ssi_info, ssi_name)
                else:
                    # dialog_id and turn_id
                    dialogue_id, turn_id = "".join(word[:-1]), word[-1]
                    key = (dialogue_id, turn_id)

            else:
                # the utterance
                word, pos, ner = [], [], []
                for tok in sent['tokens']:
                    word.append(replace_brackets(tok['word']))
                    pos.append(tok[POS])
                    ner.append(tok[NER])

                if is_schema and idx % 3 == 2:
                    # this is back translation
                    pos_map[key]["back_trans_tok"] = " ".join(word)
                    pos_map[key]["back_trans_pos"] = " ".join(pos)
                    pos_map[key]["back_trans_ner"] = " ".join(ner)

                elif not is_schema and idx % 4 == 2:
                    # this is state slot kv pairs
                    pos_map[key]["state_slot_values"] = parse_slot_values(
                        word, pos, ner)

                elif not is_schema and idx % 4 == 3:
                    # this is action slot kv pairs
                    pos_map[key]["action_slot_values"] = parse_slot_values(
                        word, pos, ner)

                else:
                    pos_map[key] = {
                        TOKEN: " ".join(word),
                        POS: " ".join(pos),
                        NER: " ".join(ner)
                    }

            one_sent.append(" ".join(word))
            if ((not is_schema and idx % 4 == 3) or
                (is_schema and idx % 3 == 2)) and (
                    idx % 5000 < 4 or
                    ('state_slot_values' in pos_map[key] and
                     len(pos_map[key]['state_slot_values']) > 0 and
                     idx % 10000 < 10)):
                logging.info("Sentent: {}".format(idx))
                logging.info("Input: {}".format("\n".join(one_sent)))
                logging.info("Output: {}\n".format(pos_map[key]))


def get_info_name(input):
    """
    input: service_NN __NN name_NN __NNP Alarm_NNP __VBD 1_CD
           slot_NN __NN name_NN __NN alarm_NN __NN time_NN
           intent_JJ __NN name_NN __NN GetAlarms_NNS
    return: 
           service_name_, Alarm_1
    """
    words = input.strip().split()
    ssi_info = "".join([x.rsplit("_", 1)[0] for x in words[:4]])
    ssi_name = "".join([x.rsplit("_", 1)[0] for x in words[4:]])
    return ssi_info, ssi_name


def merge_schema(schema_file, schema_pos_file_list, output_file):

    pos_map = {}
    for schema_pos_file in schema_pos_file_list:
        if schema_pos_file.endswith(".json"):
            logging.info("Reading json file {}".format(schema_pos_file))
            get_streams(schema_pos_file, pos_map, is_schema=True)
        else:
            pos_input = open(schema_pos_file, "r").read()
            pos_lines = pos_input.strip().split('\n')
            for idx in range(0, len(pos_lines), 2):
                ssi_info, ssi_name = get_info_name(pos_lines[idx])
                logging.info("{} {}".format(ssi_info, ssi_name))
                if ssi_info in SERVICE_NAME:
                    service_name = ssi_name
                tok, pos = get_tok_pos(pos_lines[idx + 1])
                pos_map[(service_name, ssi_info, ssi_name)] = {
                    TOKEN: tok,
                    POS: pos
                }

    output_file = open(output_file, 'w')

    logging.info("Loading schema file {}".format(schema_file))
    with open(schema_file, 'r') as example_file:
        entry = json.load(example_file)
        for service in entry:

            service_name = service['service_name'].strip()
            streams_dict = pos_map[(service_name, SERVICE_NAME.strip(),
                                    service_name)]
            for k, v in streams_dict.items():
                service[k] = v

            slots = service['slots']
            for _, s in enumerate(slots):
                s_name = s['name'].strip()
                streams_dict = pos_map[(service_name, SLOT_NAME.strip(),
                                        s_name)]
                for k, v in streams_dict.items():
                    s[k] = v

                # get back translation for possible_values
                pv_backtrans = []
                for pv in s['possible_values']:
                    pv_backtrans.append([do_backtranslation(pv)])
                s['possible_values_bak_trans'] = pv_backtrans
                # TODO(haitao.mi): manually add more general similar words
                # for True False etc., use a dict file

            intents = service['intents']
            for _, i in enumerate(intents):
                i_name = i['name']
                streams_dict = pos_map[(service_name, INTENT_NAME.strip(),
                                        i_name)]
                for k, v in streams_dict.items():
                    i[k] = v

        json.dump(entry, output_file, indent=2)
    output_file.close()


def get_slot_act_values(frames):
    '''
    write 'slot_values', and 'actions.values in format of 
    SLOTID category SLOTVALUE Sports SLOTID city_of_event SLOTVALUE V1 ## V2
    '''
    slot_values_str = ""
    action_values_str = ""
    for f in frames:
        if STATE in f:
            slot_values = f[STATE][SLOT_VALUES]
            for k, v in slot_values.items():
                slot_values_str += (" " + SLOT_ID + " " + k)
                slot_values_str += (" " + SLOT_VALUE + " " + " ## ".join(v))

        if ACTIONS in f:
            for act in f[ACTIONS]:
                if act['act'] in VALUE_ACTIONS:
                    v = act['values']
                    action_values_str += (" " + SLOT_ID + " " + act['slot'])
                    action_values_str += (" " + SLOT_VALUE + " " +
                                          " ## ".join(v))
    return slot_values_str.strip(), action_values_str.strip()


SHORT_YEARS = {
    "'10": "2010",
    "'11": "2011",
    "'12": "2012",
    "'13": "2013",
    "'14": "2014",
    "'15": "2015",
    "'16": "2016",
    "'17": "2017",
    "'18": "2018",
    "'19": "2019",
    "'20": "2020"
}


def fix_some_token_errors(input):
    input = input.replace(", ", " , ").replace("!", " ! ").replace(
        "?", " ? ").replace("I;m ", "I'm ")

    for k, v in SHORT_YEARS.items():
        input = input.replace(k, v)

    words = input.split()
    fix_words = []
    for w in words:
        if len(w) > 3 and "." in w and w.count(".") == 1:
            # possibly an error

            b, e = w.split(".")
            b_fix, e_fix = False, False
            if len(b) > 1 and (
                    b.isalpha() or
                (len(b) > 2 and b[0].isnumeric() and b[1:].isalpha()) or
                (len(b) > 3 and b[:2].isnumeric() and b[2:].isalpha()) or
                (len(b) > 4 and b[:3].isnumeric() and b[3:].isalpha())):
                # pm.I, Mr.John, pm.Drop-off, 11th.I'm, 2nd.I, 2nd,I'm,
                b_fix = True
            if (e.isalpha() or "'" in e or '-' in e):
                e_fix = True
            if b_fix and e_fix:
                new_tok = " . ".join([b, e]).replace("Mr . ", "Mr. ")
                fix_words.append(new_tok)
                logging.info("Fixing a token from '{}' to '{}'".format(
                    w, new_tok))
            elif len(b) == 0 and e.isnumeric():
                fix_words.extend([".", e])
                logging.info("Fixing a token from '{}' to '{}'".format(
                    w, " . ".join([b, e])))
            else:
                fix_words.append(w)
        elif len(w) > 3 and "?" in w and not w.endswith("?"):
            fix_words.append(" ? ".join(w.split("?")))
            logging.info("Fixing a token from '{}' to '{}'".format(
                w, " ? ".join(w.split("?"))))
        elif w.endswith(".Thanks."):
            fix_words.append(" . ".join(w.rsplit(".", 2)))
        elif w.endswith(".Bye."):
            fix_words.append(" . ".join(w.rsplit(".", 2)))
        elif w.endswith(".I'm") or w.endswith(".Correct?"):
            fix_words.append((" . ".join(w.rsplit(".", 1))))
        elif len(w) > 0 and w[0] == '.' and w[1:].isnumeric():
            fix_words.extend([".", w[1:]])
            logging.info("Fixing a token from '{}' to '{}'".format(
                w, "." + " " + w[1:]))
        else:
            fix_words.append(w)

    return " ".join(fix_words)


def get_utterances(expanded_path, ofile_prefix, norm=False):

    for root, dirs, files in os.walk(expanded_path):
        logging.info("Loading data from {} {}".format(root, dirs))
        logging.info("File name must be in format of dialogues_xxx.json")
        phone_numbers = set()
        for f in files:
            if 'dialogues_' not in f:
                continue

            logging.info("Loading file {}".format(f))

            file_num = f.rsplit("_", 1)[1].split(".", 1)[0]

            output_file = open(ofile_prefix + "_" + file_num + ".utterance",
                               'w')
            with open(os.path.join(expanded_path, f)) as example_file:
                entry = json.load(example_file)
                for dialogue in entry:
                    dialogue_id = dialogue['dialogue_id']
                    turns = dialogue['turns']
                    for idx, t in enumerate(turns):
                        turn_u = t['utterance'].strip().replace('\n', " ")
                        turn_u = fix_some_token_errors(turn_u)

                        # update phone numbers, replace them with 999-999-9999
                        for frame in t["frames"]:
                            acts = frame.get("actions", [])
                            for act in acts:
                                if act["slot"] == "phone_number":
                                    for v in act["values"]:
                                        phone_numbers.add(v.strip())

                        # do normalization here
                        if norm:
                            turn_u = english_norm(turn_u, phone_numbers)

                        output_file.write("{} {}\n".format(dialogue_id, idx))
                        output_file.write(
                            (turn_u if len(turn_u) > 0 else "EMPTY") + '\n')

                        # write 'slot_values', and 'actions.values
                        slot_v, act_v = get_slot_act_values(t['frames'])
                        output_file.write(
                            (slot_v if len(slot_v) > 0 else "EMPTY") + '\n')
                        output_file.write(
                            (act_v if len(act_v) > 0 else "EMPTY") + '\n')

            output_file.close()
        logging.info("Phone numbers: {}".format(
            sorted([x for x in phone_numbers],
                   key=lambda x: len(x),
                   reverse=True)))


def get_ids(input):
    """
    input:  9_CD __IN 00001_CD 14_CD
    return: (9_00001, 14)
    """
    words = input.strip().split()
    return ("".join([x.rsplit('_', 1)[0] for x in words[:-1]]),
            words[-1].rsplit("_", 1)[0])


def postprocess_pos(input):
    """
    input: Their_PRP$ contact_NN number_NN is_VBZ 55 5395 4586_CD 

    return: Their_PRP$ contact_NN number_NN is_VBZ 55-5395-4586_CD 
    """
    added_line = " ".join([
        "{}{}".format(x, "" if "_" in x else "-")
        for x in input.strip().split()
    ])
    return added_line.replace("- ", "-")


def get_tok_pos(input):
    """
    input:  Check_VB in_IN the_DT Philadelphia_NNP area_NN ._.
            Their_PRP$ contact_NN number_NN is_VBZ 55 5395 4586_CD 

    return: 

    """
    words = []
    pos = []
    for w_p in postprocess_pos(input).split():
        if "_" not in w_p:
            logging.warn("Wrong format of line {}".format(input))
            continue
        w, p = w_p.rsplit("_", 1)
        words.append(replace_brackets(w))
        pos.append(p)
    return " ".join(words), " ".join(pos)


def get_system_tag(turn):
    '''
    "frames": [
        {
            "actions": [
                {
                    "act": "CONFIRM",
                    "slot": "restaurant_name",
                    "values": [
                        "P.f. Chang's"
                    ],
                     "tok_values": [
                        "P.f. Chang 's"
                    ]
                },
                {
                    "act": "CONFIRM",
                    "slot": "location",
                    "values": [
                        "Corte Madera"
                    ],
                    "tok_values": [
                        "Corte Madera"
                    ]
                },
            ],
            "service": "Restaurants_2",
            "slots": [
                {
                    "exclusive_end": 47,
                    "slot": "restaurant_name",
                    "start": 35
                },
    ...
    "speaker": "SYSTEM",
    "utterance": "Please confirm your reservation at P.f. Chang's in Corte"
    "token": "Please confirm your reservation at P.f. Chang 's in Corte "
    '''
    system_tag = {}
    actions = turn[FRAMES][0][ACTIONS]
    token = " " + turn[TOKEN].lower() + " "
    tags = ["O" for _ in range(len(token.strip().split()))]
    for act in actions:
        if act["act"] in VALUE_ACTIONS:
            slot = act["slot"]
            val = act["values"][-1]
            tok_val = " ".join(TreebankWordTokenizer().tokenize(val))
            if tok_val == "None":
                continue

            if "tok_values" in act:
                tok_val = act["tok_values"][-1]

            tok_val_low = tok_val.lower().replace(" d.c .", " d.c.").replace(
                " co .", " co.").replace("m.d .", "m.d.")

            cands = [tok_val_low]
            if slot == 'phone_number':
                cands.append("999-999-9999")
            found = False
            for cand in cands:
                pos = token.find(" " + cand +
                                 ("" if cand.count(" ") > 1 else " "))
                if pos != -1:
                    s_pos = token[:pos].count(" ")
                    step = cand.count(" ") + 1
                    for i in range(step):
                        tags[s_pos + i] = slot
                    found = True
                    break
            if not found and tok_val_low not in ['true', 'false']:
                logging.info("Cannot find slot value: '{}' in '{}'".format(
                    tok_val, turn[TOKEN]))
    system_tag["system_tag"] = " ".join(tags)
    return system_tag


def merge(data_path, pos_file_list, output_path):

    pos_map = {}
    for pos_file in pos_file_list:
        if pos_file.endswith(".json"):
            logging.info("Reading {}".format(pos_file))
            get_streams(pos_file, pos_map)
        else:
            logging.info("Reading txt file: WORD_POS WORD_POS")
            pos_input = open(pos_file, "r").read()
            pos_lines = pos_input.strip().split('\n')
            for idx in range(0, len(pos_lines), 2):
                dialogue_id, turn_id = get_ids(pos_lines[idx])
                tok, pos = get_tok_pos(pos_lines[idx + 1])
                pos_map[(dialogue_id, turn_id)] = {TOKEN: tok, POS: pos}

    def update_actions(turn, slot_values):
        for f in turn[FRAMES]:
            if ACTIONS in f:
                for a in f[ACTIONS]:
                    if a['act'] in VALUE_ACTIONS and a['slot'] in slot_values:
                        a["tok_values"] = slot_values[a['slot']]

    def update_states(turn, tok_slot_values):
        for f in turn[FRAMES]:
            if STATE in f and SLOT_VALUES in f[STATE]:
                slot_values = f[STATE][SLOT_VALUES]
                new_att = {}
                for k, _ in slot_values.items():
                    if k in tok_slot_values:
                        new_att[k] = tok_slot_values[k]
                f[STATE]['tok_slot_values'] = new_att

    for root, dirs, files in os.walk(data_path):
        logging.info("Loading data from {} {}".format(root, dirs))
        for f in files:
            if 'dialogues_' not in f:
                continue

            logging.info("Loading file {}".format(f))
            with open(os.path.join(data_path, f)) as example_file:
                entry = json.load(example_file)
                for dialogue in entry:
                    dialogue_id = dialogue['dialogue_id']
                    turns = dialogue['turns']

                    try:
                        for idx, t in enumerate(turns):
                            streams_dict = pos_map[(dialogue_id, str(idx))]
                            for k, v in streams_dict.items():
                                if k == "action_slot_values":
                                    # update actions
                                    update_actions(t, v)
                                elif k == "state_slot_values":
                                    # update state
                                    update_states(t, v)
                                else:
                                    t[k] = v
                            # recover the CONFIRM, OFFER tags
                            if t["speaker"] == "SYSTEM":
                                system_tag = get_system_tag(t)
                                for k, v in system_tag.items():
                                    t[k] = v
                    except Exception as e:
                        logging.error("Error: {}".format(e))

                logging.info("Saving file {}".format(f))
                with open(os.path.join(output_path, f), 'w') as output_file:
                    json.dump(entry, output_file, indent=2)


def lower_case(data_path, output_path):
    '''
    to lower case of the dev set, used for lower cased model training.
    '''
    os.makedirs(output_path, exist_ok=True)

    for root, dirs, files in os.walk(data_path):
        logging.info("Loading data from {} {}".format(root, dirs))
        for f in files:
            if f == "schema.json":
                with open(os.path.join(data_path, f)) as schema_file:
                    entry = json.load(schema_file)
                    logging.info("Saving file {}".format(f))
                    with open(os.path.join(output_path, f), 'w') as output_file:
                        json.dump(entry, output_file, indent=2)
                continue

            if 'dialogues_' not in f:
                continue

            logging.info("Loading file {}".format(f))
            with open(os.path.join(data_path, f)) as example_file:
                entry = json.load(example_file)
                for dialogue in entry:
                    turns = dialogue['turns']

                    for _, t in enumerate(turns):
                        if t["speaker"] == "USER":
                            for frame in t["frames"]:
                                state = frame["state"]
                                slot_values = state["slot_values"]
                                for k, v in slot_values.items():
                                    slot_values[k] = [x.lower() for x in v]

                logging.info("Saving file {}".format(f))
                with open(os.path.join(output_path, f), 'w') as output_file:
                    json.dump(entry, output_file, indent=2)


if __name__ == '__main__':
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    args = parse()
    if args.task == 'utterance':
        get_utterances(args.data, args.output_file.strip(), norm=args.norm)
    elif args.task == 'merge':
        merge(args.data, args.tag_file, args.output_path)
    elif args.task == 'schema':
        process_schema(args.schema_file, args.output_file)
    elif args.task == "merge_schema":
        merge_schema(args.schema_file, args.tag_file, args.output_file)
    elif args.task == "lower_dev":
        lower_case(args.data, args.output_path)
