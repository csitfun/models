#!/usr/bin/env python
#--*-- coding: utf-8 --*--

import requests
from datetime import datetime
from argparse import ArgumentParser
import logging
import hashlib
import json
import truecase

URL = "http://gw.api.taobao.com/router/rest"
APPKEY = "24934846"
SECRET = "63c4adf152017d5cbb5b5186481a7382"
METHOD = "alibaba.intl.translationplatform.translate"


def parse():
    """
    Returns the arguments from the command line.
    """
    parser = ArgumentParser()
    parser.add_argument(
        '--format', default='json', type=str, help='format: json or xml')
    parser.add_argument(
        '--sign_method',
        default='md5',
        type=str,
        help='sign_method: md5 or hmac')
    parser.add_argument('--source', default='en', type=str, help='source')
    parser.add_argument('--target', default='zh', type=str, help='target')
    parser.add_argument('--retry', default=3, type=int, help='retry times')

    args = parser.parse_args()

    return args


def get_sign(pairs):
    ret = SECRET
    sorted_pairs = sorted([(k, v) for k, v in pairs.items()],
                          key=lambda x: x[0])
    ret += "".join(["{}{}".format(k, v) for (k, v) in sorted_pairs])
    ret += SECRET
    return hashlib.md5(ret.encode('utf-8')).hexdigest().upper()


def do_translate(input_text,
                 source='en',
                 target='zh',
                 sign_method='md5',
                 platform='2',
                 format='json',
                 retry=3):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    payload = {
        "app_key": APPKEY,
        "format": format,
        "method": METHOD,
        "sign_method": sign_method,
        "v": "2.0",
        "timestamp": timestamp,
        "partner_id": "apidoc",
        "source_text": input_text,
        "source": source,
        "target": target,
        "field_type": "query",
        "source_text_format": "text",
        "platform": platform,
    }
    payload["sign"] = get_sign(payload)

    s = "&".join(["{}={}".format(k, v) for k, v in payload.items()])
    logging.debug("{}?{}".format(URL, s))

    translated = ''
    for _ in range(retry):
        r = requests.post(URL, data=payload)
        logging.debug("r={}".format(r.text))
        if r.status_code == requests.codes['ok']:
            break
        logging.debug("retry ...")

    try:
        response = json.loads(r.text)
        resp = response["alibaba_intl_translationplatform_translate_response"]
        translated = resp["translated_text"]
    except Exception as e:
        logging.error("Error: {}".format(e))

    return translated


def do_backtranslation(input_text, source='en', target='zh'):
    translated = do_translate(input_text, source=source, target=target)
    back_trans = do_translate(translated, source=target, target=source)
    if len(back_trans.strip()) == 0:
        back_trans = "EMPTY"
    return truecase.get_true_case(back_trans) if source == 'en' else back_trans


if __name__ == '__main__':
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    args = parse()

    line = "Find Bourbon Steaks in San Francisco please."
    translated = do_translate(
        line,
        source=args.source,
        target=args.target,
        sign_method=args.sign_method,
        format=args.format,
        retry=args.retry)
    logging.info("Traslation: {}".format(translated))

    back_translated = do_backtranslation(
        line, source=args.source, target=args.target)
    logging.info("Back translated: {}".format(back_translated))