#!/bin/bash
set -e

INPUT_DIR=".data/dstc/data/all"
OUTPUT_DIR=".data/dstc/data/all_pos_norm"
PY_MAIN="preprocessing.preprocess"
echo "Input dir: ${INPUT_DIR}"

stanford_corenlp_path=$1

dir=$(pwd)

for d in dev test train
do 
    mkdir -p ${OUTPUT_DIR}/${d} 
    python -m ${PY_MAIN} --task utterance --data ${INPUT_DIR}/${d}/ \
        --output_file ${OUTPUT_DIR}/${d}/${d}.txt --norm
    python -m ${PY_MAIN} --task schema --schema_file ${INPUT_DIR}/${d}/schema.json \
        --output_file ${OUTPUT_DIR}/${d}/schema.txt
    cd ${stanford_corenlp_path}

    for file in `ls ${dir}/${OUTPUT_DIR}/${d}/${d}.txt_*.utterance`
    do 
        java -cp "*" -Xmx10g edu.stanford.nlp.pipeline.StanfordCoreNLP \
            -annotators tokenize,ssplit,pos,lemma,ner \
            -file ${file} \
            -ssplit.newlineIsSentenceBreak always \
            -outputFormat json -ssplit.eolonly \
            -outputDirectory ${dir}/${OUTPUT_DIR}/${d} -ner.nthreads 20
    done

    java -cp "*" -Xmx10g edu.stanford.nlp.pipeline.StanfordCoreNLP \
        -annotators tokenize,ssplit,pos,lemma,ner \
        -file ${dir}/${OUTPUT_DIR}/${d}/schema.txt \
        -ssplit.newlineIsSentenceBreak always \
        -outputFormat json -ssplit.eolonly \
        -outputDirectory ${dir}/${OUTPUT_DIR}/${d} -ner.nthreads 20

    cd ${dir}
    python -m ${PY_MAIN} --task merge_schema \
        --schema_file ${INPUT_DIR}/${d}/schema.json \
        --tag_file ${OUTPUT_DIR}/${d}/schema.txt.json \
        --output_file ${OUTPUT_DIR}/${d}/schema.json

    python -m ${PY_MAIN} --task merge --data ${INPUT_DIR}/${d}/ \
        --tag_file ${OUTPUT_DIR}/${d}/${d}.txt_*.utterance.json \
        --output_path ${OUTPUT_DIR}/${d}/

done


