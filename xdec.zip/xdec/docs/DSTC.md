# Dialog State Tracking

## Build DSTC data 

1. Download raw data from https://github.com/google-research-datasets/dstc8-schema-guided-dialogue

2. Create the following dir, and put data

``ls .data/dstc/data/all/``

train dev test

### Get token, pos, ner and back translation streams

1. Download stanford-corenlp-full-2018-10-05 (or run ``scripts/download.sh``)

2. Generate tokenized, pos tagged, and back translstion streams using ``./preprocessing/build_streaming.sh``

Check the script and modify the parameters 

```bash
INPUT_DIR=".data/dstc/data/all"
OUTPUT_DIR=".data/dstc/data/all_pos"
PY_MAIN="preprocessing/preprocess.py"
$1 is the abs path to stanford-corenlp
```

``./preprocessing/build_streaming.sh ~/work/stanford-corenlp-full-2018-10-05/``

### Generate four tasks 

1. Generate four sub-tasks using ./scripts/build_tasks.sh

Check the script and modify the parameters:

```bash
exp_name=$1
TURN_ROUNDS=20
INPUT_DIR=".data/dstc/data/all_pos" # change the path to your output dir in previous step
OUTPUT_DIR=".data/dstcslotall_${exp_name}_${TURN_ROUNDS}"
```

``bash ./scripts/build_tasks.sh task_name >& logs/log.buildtasks.task_name``

2. Outputs looks like:

``ls .data/dstcslotall_unittest_5*``

.data/dstcslotall_unittest_5:

dev.jsonl.gz  train.jsonl.gz

.data/dstcslotall_unittest_5_bool:  # four way classification

dev.jsonl.gz  train.jsonl.gz  xnli.dev.unittest.jsonl.gz  xnli.train.unittest.jsonl.gz

.data/dstcslotall_unittest_5_cat:  # binary classification

dev.jsonl.gz  train.ds.jsonl.gz  xnli.dev.unittest.jsonl.gz xnli.train.unittest.jsonl.gz feature.json  train.jsonl.gz     xnli.train.ds.unittest.jsonl.gz

.data/dstcslotall_unittest_5_non:  # MRC task

dev.jsonl.gz  squad.dev.unittest.json.gz  squad.train.unittest.json.gz  train.jsonl.gz

.data/dstcslotall_unittest_5_num:  # binary classification

dev.jsonl.gz  train.ds.jsonl.gz  xnli.dev.unittest.jsonl.gz xnli.train.unittest.jsonl.gz feature.json  train.jsonl.gz     xnli.train.ds.unittest.jsonl.gz

### Train models for each task 

1. xnli classification task:

e.g. ``scripts/run_xnli_unittest_cat.sh``

Parameters to change 

```bash
XNLI_DIR=.data/dstcslotall_unittest_5_cat/
    --train_file xnli.train.unittest.jsonl.gz \
    --predict_file xnli.dev.unittest.jsonl.gz \
    --output_dir transformer_models/xnli_unittest_wd \
    --input_file transformer_models/xnli_unittest_wd/pred_results.txt \
    --ref_file .data/dstcslotall_unittest_5_cat/dev.jsonl.gz
```

Run:

    bash scripts/run_xnli_unittest_cat.sh &>logs/log.xnli.unittest &

check the scores for this task.

    tail logs/log.xnli.unittest

{'exact': 66.66666666666667, 'f1': 66.66666666666667, 'total': 111, 'HasAns_exact': 0.0, 'HasAns_f1': 0, 'HasAns_total_ref': 37, 'HasAns_total_res': 0, 'NoAns_exact': 100.0, 'NoAns_f1': 80.0, 'NoAns_total_ref': 74, 'NoAns_total_res': 111, 'Cat_acc': 18.91891891891892, 'Cat_hasAns_f1': 0, 'Cat_hasAns_acc': 0.0, 'Cat_hasAns_rec': 0, 'Cat_hasAns_ref_num': 0, 'Cat_hasAns_res_num': 30}

1.1 Pair-wise classification task

e.g. ``scripts/run_xnli_cat_roberta_pair_sim_nonone.sh``

The usage is the same as the classification task, but it works better if the None
class in the data is removed. The None class can be determined by a threshold (``python -m dstc.cli merge-pretrained --prob_threshold 0.5``)

2. MRC squad task 

e.g. ``scripts/run_squad_roberta.sh``

Parameters to change 

```bash
SQUAD_DIR=.data/dstcslotall_unittest_5_non/
    --train_file squad.train.unittest.json \
    --predict_file squad.dev.unittest.json \
    --output_dir transformer_models/squad_unittest \
```
### Merge all task outputs

```bash
mkdir merge/pretrain_cat_mlm_num_norm_feats_bool_max
python -m dstc.cli merge_pretrained --non_cat_file_name merge/roberta/roberta_norm_pretrained.nbest.json.gz \
    --num_file_name transformer_models/xnli_final_num_norm_roberta/pred_results.txt \
    --bool_file_name transformer_models/xnli_final_bool_roberta/pred_results.txt \
    --cat_file_name transformer_models/xnli_final_cat_roberta/pred_results.txt \
    --old_predictions_path .data/dstc/data/all/dev/  \
    --new_predictions_path merge/pretrain_cat_mlm_num_norm_feats_bool_max \
    --output_metric_file merge/eval_pretrain_cat_mlm_num_norm_feats_bool_max.json
```

For categorical slots, we can use threshold for None class, by adding 
``--prob_threshold THRESHOLD_VALUE``

```bash
mkdir merge/pretrain_cat_mlm_num_norm_feats_bool_max_final
python -m dstc.cli post_process --input_dstc_dir merge/pretrain_cat_mlm_num_norm_feats_bool_max/ \
    --output_dstc_dir merge/pretrain_cat_mlm_num_norm_feats_bool_max_final/ \
    --output_metric_file merge/eval_pretrain_cat_mlm_num_norm_feats_bool_max_final.json
```

## Generate MultiWOZ 2.1 data 

1. load the raw MultiWOZ 2.1 data from web:

```bash
python -m multiwoz.create_dst_data --load 
```

or, if you have already downloaded the data, it's in data/MultiWOZ_2.1 then run 

```bash
python -m multiwoz.create_dst_data
```

the output files in data dir:

dev_dials.json  MultiWOZ_2.1  test_dials.json  train_dials.json  trainListFile

2. evaluate dst task

```bash
python -m multiwoz.evaluate_dst --pred_file path/to/pred_file --ref_file path/to/ref_file
```

prediction and reference file are in format of dev_dials.json

3. create NLG data

create nlg data from MultiWOZ 2.1, we first need the dbs from https://github.com/budzianowski/multiwoz/tree/master/db and put db under 'data' dir. 
Current the source code is hard coded.

```bash
python -m multiwoz.create_nlg_data
```

output files in data dir:

nlg_dev_dials.json  nlg_test_dials.json  nlg_train_dials.json input_lang.* output_lang.*

4. evaluate nlg task

```bash
python -m multiwoz.evaluate_nlg
```

5. convert MultiWOZ 2.1 data into Schema Guided Dataset

```bash
python -m multiwoz.create_schemaguided_data >&logs/log.multiwozonly.cat 
```

output files in data dir:

```bash
data/train/schema.json dialogues_xxx.json
data/dev/schema.json dialogues_xxx.json
data/test/schema.json dialogues_xxx.json
```

``grep "Switch turn" logs/log.multiwozonly.cat | wc -l``

we have 8926 switch turns in MultiWOZ.

NOTE: 2020.04.24:

``grep "Cannot find slot value" logs/log.multiwozonly.cat  | wc -l ``

we still have 1083 slot values used in system actions are not shown in candidate lists (no exact mach)


## Generate text data from MetalWoZ and MLM training

1. Download MetalWoZ from https://www.microsoft.com/en-us/research/project/metalwoz/

2. Generate text data from MetalWoZ

```bash
python -m dstc.corpus_util dump-text
```

Alternatively, use different task names to dump DSTC or MultiWoZ data:

```bash
python -m dstc.corpus_util dump-text --task dstc
python -m dstc.corpus_util dump-text --task woz
```

3. MLM training

```bash
scripts/run_lm_roberta.sh
```

After training, use output dir in run_lm_roberta.sh as model_name_or_path for subsequent tasks.

## Dropout for SQUAD training

1. Input processing

The question part of the SQUAD input can be dropped randomly with the following:

```bash
python -m dstc.cli dropout-squad-input \
    --squad_input_file mwoz-squad/squad.train.multiwozonly.json \
    --squad_output_file mwoz-squad/squad.train.pad_dropout0.3.multiwozonly.json \
    --dropout_token "<pad>"
```

By default, the dropout token is <blank>, but it can be replaced with any token with the 
--dropout_token option.

2. Input dropout

Dropout training is implemented in ``models/regularized_roberta.py`` Select this version of RoBERTa
squad with --model_type regularized

When <blank> is used as the dropout token, use the --input_dropout switch to add <blank> to the vocab. 
See ``scripts/run_mwoz_squad_roberta_after_pretrain_dropout0.3.sh`` for example. When <pad> is used as
the token, additional switch is not necessary as <pad> is already in the vocab.

3. RoBERTa output dropout

Set --model_type regularized and --output_dropout_prob 0.3 (or other desired probability). See 
``scripts/run_mwoz_squad_roberta_after_pretrain_pad0.3_output0.3_e5.sh`` for example.

## Generate Seq2Seq training / testing files

Files in Seq2Seq input format can be created with the following commands:

```bash
python -m dstc.corpus_util squad-to-seq
python -m dstc.corpus_util metal-to-seq
```

## Training

Use corresponding run_*.sh script files for training and evaluation.

- run_squad_roberta.sh
- run_xnli_bool_roberta.sh
- run_xnli_cat_roberta.sh
- run_xnli_num_roberta.sh
- run_xnli_num_norm_roberta.sh

Change SQUAD_DIR or XNLI_DIR as needed. Also change --train_file and --predict_file . transformers_cache/ can be preloaded with HuggingFace model files. Then run:

```bash
bash run_squad.sh &> squad.log &
```

## Seq2Seq Training and Testing

Use the following commands to train seq2seq models. These are currently based on Microsoft's [UniLM](https://github.com/microsoft/unilm).

- run_seq2seq.sh
- predict_seq2seq.sh


### Reranking task

1. Generate training dev test examples

```bash
python -m dstc.cli build_generation_examples \
    --ref_path .data/dstc/data/all_multiwoz_only_act/test \
    --hyp_path merge/multiwozonly_act_base_test_final \
    --output_file .data/gen_multiwoz/gen_test.jsonl

python -m dstc.cli build_generation_examples \
    --ref_path .data/dstc/data/all_multiwoz_only_act/dev \
    --hyp_path merge/multiwozonly_act_base_dev_final \
    --output_file .data/gen_multiwoz/gen_dev.jsonl
```

2. Training

```bash
bash ./scripts/run_seq2seq_multiwoz.sh >& logs/log.seq.multiwoz
```

3. Testing
```
bash ./scripts/predict_seq2seq_multiwoz.sh >& logs/log.seq.multiwoz.pred
```

4. Convert seqence prediction results to cat (xnli) and non-cat (squad) formats
```
python -m dstc.cli convert_seq_to_pred \
    --schema_file .data/dstc/data/all_multiwoz_only_act/test/schema.json \
    --seq_file .data/gen_multiwoz/gen_test.jsonl \
    --hyp_file ./transformer_models/seq_gen_multiwoz/ckpt-51000/test.output.txt \
    --cat_output_file ./transformer_models/seq_gen_multiwoz/ckpt-51000/cat_pred_results.txt \
    --non_output_file ./transformer_models/seq_gen_multiwoz/ckpt-51000/non_pred_results.txt \
    >& logs/log.convert
```

5. Evaluating

```bash
python -m dstc.cli merge_pretrained \
    --non_cat_file_name transformer_models/seq_gen_multiwoz/ckpt-51000/non_pred_results.txt \
    --cat_file_name transformer_models/seq_gen_multiwoz/ckpt-51000/cat_pred_results.txt \
    --num_file_name ''  \
    --bool_file_name '' \
    --old_predictions_path .data/dstc/data/all_multiwoz_only_act/test/ \
    --new_predictions_path merge/multiwozonly_act_rerank_test \
    --output_metric_file merge/eval_multiwozonly_act_rerank_test.json \
    --dstc_path .data/dstc/data/all_multiwoz_only_act \
    --ontology_file data/MultiWOZ_2.1/ontology.json \
    --eval_set test \
    --lower

python -m dstc.cli post_process \
    --input_dstc_dir merge/multiwozonly_act_rerank_test/ \
    --output_dstc_dir merge/multiwozonly_act_rerank_test_final \
    --output_metric_file merge/eval_multiwozonly_act_rerank_test_final.json \
    --train_schema_file .data/dstc/data/all_multiwoz_only_act/train/schema.json \
    --dev_schema_file .data/dstc/data/all_multiwoz_only_act/test/schema.json \
    --dstc_path .data/dstc/data/all_multiwoz_only_act/ \
    --eval_set test
```

### DST task

WIP (2020.05.07)

## Kubemaker on dev 

1. set up kubemaker running envrioments:

    https://yuque.antfin-inc.com/rpmtis/yxaqoi/fb9nab


2. create your dir for submit jobs, this dir contains two dirs (tools and xdec)

tools dir # tools we need, we have two tools right now

- ossutil64       # tool saves models to oss

- .ossutilconfig  # right now, we store our config directly

xdec dir  # source code

3. submit your jobs

```bash
kmcli run --src './' --enable-init-mode --user your_id --name unittest --no-tensorboard \
    --image 'reg.docker.alibaba-inc.com/chunbo/bertonk8s:pytorch_mrpc_ossodps' \
    --master 'cpu=1,memory=5000,disk=8000,gpu=2' \
    'sh /kubemaker/code/xdec/scripts/kubemaker_run.sh ./scripts/run_xnli_unittest_cat.sh xnli_unittest_wd'
```

4. check your jobs 

all jobs 

```bash
kmcli get jobs
```

your job by name

``kmcli get job unittest``

``kmcli logs job unittest``

5. download trained models 

```bash
ossutil64 --config-file=path_to_your_ossutilconfig \
    cp oss://csrobotmng-oss-dev/public_area/alipay-search-service/antassistant/haitao.mi/transformer_models/models.tgz models.tgz 
```

## Run xnli and squad tasks in local machine

1. Download training data from oss 

in your xdec dir:

```bash
ossutil64 --config-file=path/to/your/config cp oss://csrobotmng-oss-dev/public_area/alipay-search-service/antassistant/haitao.mi/transformer_models/data.tgz data.tgz
tar -xzf data.tgz 
```

you will see 

``ls .data/``

dstcslotall_all_20_cat    dstcslotall_dstc_20_cat                

dstcslotall_multiwozonly_care_20_cat  dstcslotall_unittest_5_cat

dstcslotall_all_20_num    dstcslotall_dstc_20_num                

dstcslotall_multiwozonly_care_20_non

dstcslotall_dstc_20_bool  dstcslotall_multiwozonly_care_20_bool  

dstcslotall_multiwozonly_care_20_num


2. Download pretained transformers 

also in your xdec dir:

```bash
ossutil64 --config-file=path/to/your/config cp oss://csrobotmng-oss-dev/public_area/alipay-search-service/antassistant/haitao.mi/transformer_models/transformers_cache.tgz transformers_cache.tgz

tar -xzf transformers_cache.tgz
```

you will see 

``ls .transformers_cache/``

3. Change your scripts and run experiments 

e.g. 

cat  scripts/run_xnli_cat_roberta.sh 

```bash
XNLI_DIR=.data/dstcslotall_dstc_20_cat/
python -m xnli \
    --model_type roberta \                  # pretrained model type: bert, roberta
    --model_name_or_path roberta-base \     # pretrained model name: roberta-base, roberta-large etc.
    --cache_dir .transformers_cache \       # pretrained model cache dir
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file xnli.train.dstc.jsonl.gz \    # training file
    --predict_file xnli.dev.dstc.jsonl.gz \    # dev file
    --task_type cat \
    --learning_rate 2e-5 \                     # learning rate, you can play with it
    --weight_decay 0.01 \                      # decay rate, you can play with it
    --num_train_epochs 1 \                     # number of training epochs, try 2?
    --max_seq_length 512 \                     # max concated seq lenght
    --gradient_accumulation_steps 4 \          # accumulate this number of batches, then do parameter updates
    --output_dir transformer_models/xnli_dstc_cat_roberta_b32 \         # IMPORTANT: this is where the models will be saved, use this in kubemaker run scripts
    --per_gpu_eval_batch_size 8 \              # batch size B for each gpu, if you have X gpus, and A gradient_accumulation_steps, the final bathes is B * X * A
    --per_gpu_train_batch_size 8 \
    --overwrite_output_dir \
    --seed 42 \                                # seeds for parameter initialization, you can play with it
    --save_steps 10000                         # save model steps: be careful of this setting if you run with kubemaker, too small will save too much and will run out of disk 

python -m dstc.cli compute_f1 --slot_type categorical \
    --input_file transformer_models/xnli_dstc_cat_roberta_b32/pred_results.txt \     # predict output file, consistant with --output_dir
    --ref_file .data/dstcslotall_dstc_20_cat/dev.jsonl.gz                            # reference file, be consistant with XNLI_DIR

```

Run in local machine


``bash ./scripts/run_xnli_cat_roberta.sh >& logs/log.xnli.dstc.meaningfulname``

Another example:

``cat scripts/run_xnli_num_norm_widedeep_roberta.sh ``

```bash
XNLI_DIR=.data/dstcslotall_dstc_20_num
python -m xnli \
    --model_type roberta_wd \
    --model_name_or_path roberta-base \
    --cache_dir .transformers_cache \
    --do_train \
    --do_eval \
    --data_dir ${XNLI_DIR} \
    --train_file xnli.train.dstc.jsonl.gz \
    --predict_file xnli.dev.dstc.jsonl.gz \
    --task_type cat \
    --learning_rate 2e-5 \
    --weight_decay 0.01 \
    --num_train_epochs 1 \
    --max_seq_length 512 \
    --use_wide \                        # use wide and deep model
    --use_tok \
    --use_layers 5 8 \                  # use different hidden layers, 0 to 9
    --output_hidden_states \            # combined with --use_layers
    --wide_dimension 30 \
    --wide_weight 0.5 \                 # wide features weight
    --wide_lr 2e-5 \                    # wide feature learning rate
    --output_dir transformer_models/xnli_dstc_num_norm_feats_roberta \
    --per_gpu_eval_batch_size 8 \
    --per_gpu_train_batch_size 8 \
    --gradient_accumulation_steps 4 \
    --seed 42 \
    --save_steps 20000

python -m dstc.cli compute_f1 --slot_type categorical \
    --input_file transformer_models/xnli_dstc_num_norm_feats_roberta/pred_results.txt \
    --ref_file .data/dstcslotall_dstc_20_num/dev.jsonl.gz
```

NOTE:
in kubemaker run

``sh /kubemaker/code/xdec/scripts/kubemaker_run.sh ./scripts/run_xnli_unittest_cat.sh xnli_unittest``

be sure which model you are training, and be sure which model output dir your will tar and save

here: "xnli_unittest" is the saved model dir name in ``./scripts/run_xnli_unittest_cat.sh``

see ``scripts/kubemaker_run.sh`` for details: (simply tar the transformer_models/xnli_unittest and tar and copy to oss)

