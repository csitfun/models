import os
import re
import sys
import csv
import json
import click
from collections import defaultdict
from types import SimpleNamespace
import ahocorasick
from wikisql.processors import WikiSQL
from xdec_config import get_logger
from tqdm import tqdm
from summ import rouge
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
from xpinyin import Pinyin
from time import time
import random
import heapq
import pandas as pd
from xpinyin import Pinyin
from s2s_ft.utils import detokenize
from multiprocessing.pool import Pool
import jieba
from lexrank import STOPWORDS, LexRank
from extsum.lexrank_summ import ExtSummarizer
from server.s2s_predictor import TOKENIZER_CLASSES, S2SPredictor
from server.run import load_args


logger = get_logger(__name__)


@click.group()
def cli():
    pass


def q2b(qstr):
    rstring = ""
    for uchar in qstr:
        inside_code = ord(uchar)
        if inside_code == 12288:
            inside_code = 32
        elif (inside_code >= 65281 and inside_code <= 65374):
            inside_code -= 65248
        if chr(inside_code) in [".", ",", ";", "!", '"', "'", "“", "”"]:
            inside_code = ord(uchar)
        if uchar == "．":
            rstring += "."
        else:
            rstring += chr(inside_code)
    return rstring


def process_title(title):
    mid_idx = len(title) // 2
    idx = title[:mid_idx].rfind(")")
    if idx > 0:
        title = title[idx + 1:]
    idx = title[mid_idx:].rfind("(")
    if idx > 0:
        title = title[:idx - len(title[mid_idx:])]
    title = re.sub(r"\s+", " ", title)
    title = title.replace(" ", "，")
    return title


def process_content(content, max_len=250):
    content = re.sub(r"\s+", " ", content)
    idx = max(content[:50].rfind(")"), content[:50].rfind(" "))
    if idx > 0:
        content = content[idx + 1:]
    indices = list(
        filter(lambda x: x > 0, [
            content[-20:].rfind("("), content[-20:].rfind("["),
            content[-20:].rfind(" "), content[-20:].rfind("作者"),
            content[-20:].rfind("记者")
        ]))
    idx = min(indices) if indices else -1
    if idx > 0:
        content = content[:idx - 20]
    contents = content.strip().split("。")
    result = ""
    i = 0
    while i < len(contents) and len(result) + len(contents[i]) < max_len - 1:
        if not contents[i]:
            i += 1
            continue
        result += contents[i] + "。"
        i += 1
    return result


def process_content_zj(content, max_len=250, trunk=False):
    content = content.replace("！", "。")
    content = content.replace("？", "。")
    contents = content.strip().split("。")
    if len(contents[-1].strip()) == 0:
        contents = contents[:-1]
    # logger.info(f"LOG CONTENTS: {contents}")
    if len(contents) > 1:
        last = contents[-1]
    else:
        last = ""
    result = contents[0] + "。"
    contents = contents[1:-1]
    i = 0
    if len(last) > max_len:
        last = ""
    while i < len(contents) and len(result) + len(
            contents[i]) < max_len - len(last) - 2:
        if not contents[i]:
            i += 1
            continue
        result += contents[i] + "。"
        i += 1
    if last:
        result += last + "。"
    return result[:max_len] if trunk else result


def process_content_zj2(content, max_len=250, trunk=False):
    content = content.replace("！", "。")
    content = content.replace("？", "。")
    contents = content.strip().split("。")
    i = 0
    result = ""
    while i < len(contents) and len(result) < max_len:
        if not contents[i]:
            i += 1
            continue
        result += contents[i] + "。"
        i += 1
    return result[:max_len] if trunk else result


@click.command()
@click.option(
    "--input_file_name",
    default=".data/sogou/news_tensite_xml.utf8.dat",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/sogou/s2s.jsonl",
    help="output file name")
@click.option("--max_len", default=250, help="max length")
def process_news(input_file_name, output_file_name, max_len):
    title = ""
    content = ""
    filter_target = ["(", "网易新闻"]
    with open(input_file_name) as input_, \
        open(output_file_name, "w") as output:
        for line in tqdm(input_):
            line = line.strip()
            if line.startswith("<contenttitle>"):
                title = line[len("<contenttitle>"):-len("</contenttitle>")]
            if line.startswith("<content>"):
                content = line[len("<content>"):-len("</content>")]
                if title and content:
                    if len(content) > 100:
                        processed_title = process_title(q2b(title))
                        invalid = False
                        for ft in filter_target:
                            if processed_title.startswith(ft):
                                invalid = True
                                break
                        if invalid:
                            continue
                        output.write(
                            json.dumps(
                                {
                                    "src":
                                        process_content(
                                            q2b(content), max_len=max_len),
                                    "tgt":
                                        processed_title,
                                },
                                ensure_ascii=False) + "\n")
                title, content = "", ""


@click.command()
@click.option(
    "--input_file_name",
    default=".data/chinese_data/news2016zh_train.json",
    help="input file name")
@click.option("--input_type", default="news", help="input type")
@click.option(
    "--output_file_name",
    default=".data/chinese_data/news2016zh_train.max500.jsonl",
    help="output file name")
@click.option("--max_len", default=500, help="max length")
def process_chinese_data(input_file_name, input_type, output_file_name,
                         max_len):
    type_dict = {"news": {"src": "content", "tgt": "title"}}
    with open(input_file_name) as input_, open(output_file_name, "w") as output:
        for line in tqdm(input_):
            datum = json.loads(line)
            source = datum[type_dict[input_type]["src"]]
            target = datum[type_dict[input_type]["tgt"]]
            source = re.sub(r"\s+", "", source.replace("<br>", ""))
            target = re.sub(r"\s+", "", target.replace("<br>", ""))
            source = process_content(q2b(source), max_len=max_len)
            target = process_title(q2b(target))
            if len(source) <= len(target) or len(source) < 50:
                continue
            output.write(
                json.dumps({
                    "src": source,
                    "tgt": target
                }, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/ssum/500gd.clean.utf8.txt",
    help="input file name")
@click.option(
    "--output_file_prefix",
    default=".data/ssum/s2s.long",
    help="output file prefix")
@click.option("--train_size", default=450, help="size of train set")
def csv_to_jsonl(input_file_name,
                 output_file_prefix,
                 train_size,
                 source_idx=4,
                 target_idx=3):
    with open(input_file_name) as input_:
        sources, targets = [], []
        for line in input_:
            parts = line.split("\t")
            sources.append(
                parts[source_idx].strip('"').strip().strip('"').strip())
            targets.append(
                parts[target_idx].strip('"').strip().strip('"').strip())
    dataset = list(zip(sources, targets))
    random.shuffle(dataset)
    with open(output_file_prefix + ".train.jsonl", "w") as output_train, \
            open(output_file_prefix + ".test.jsonl", "w") as output_test:
        c = 0
        for s, t in dataset:
            if c < train_size:
                output_train.write(
                    json.dumps({
                        "src": s.strip(),
                        "tgt": t.strip()
                    },
                               ensure_ascii=False) + "\n")
            else:
                output_test.write(
                    json.dumps({
                        "src": s.strip(),
                        "tgt": t.strip()
                    },
                               ensure_ascii=False) + "\n")
            c += 1


def load_edges(datum):
    nodes = datum["node"]
    tokens = []
    for node in nodes:
        words = node["word"]
        for word in words:
            if word["id"] < 0:
                continue
            tokens.append([word["id"], word["form"], None])
    edges = datum["edge"]
    for edge in edges:
        if edge["parent_id"] == -1:
            for token in tokens:
                if token[0] == edge["child_id"]:
                    token[2] = "root"
    return " ".join(
        map(lambda x: f"<{x[2]}> {x[1]} </{x[2]}>" if x[2] else x[1], tokens))


@click.command()
@click.option(
    "--input_prefix",
    default=".data/google_sc/data/sent-comp.train",
    help="Input file name/prefix")
@click.option(
    "--output_file",
    default=".data/google_sc/train.lower.stanza.jsonl",
    help="Output file name")
@click.option("--train/--no_train", default=True, help="Is training data")
@click.option("--edge/--no_edge", default=False, help="Load edge info")
@click.option(
    "--use_stanza/--no_use_stanza",
    default=True,
    help="Use stanza relations in source")
def dump_gsc(input_prefix, output_file, train, edge, use_stanza):
    import stanza
    nlp = stanza.Pipeline('en')

    def _dump_data(input_file_name, output):
        logger.info(f"Processing file: {input_file_name}")
        with open(input_file_name) as input_:
            content = input_.read().strip()
            data = content.split("\n\n")
            for datum in tqdm(data):
                datum = json.loads(datum)
                source = load_edges(datum["graph"]).lower(
                ) if edge else datum["graph"]["sentence"].lower()
                if use_stanza:
                    source = _find_root_stanza(
                        datum["graph"]["sentence"]).lower()
                logger.debug(source)
                output.write(
                    json.dumps({
                        "src":
                            source,
                        "tgt":
                            datum["compression_untransformed"]["text"].lower()
                    }) + "\n")

    def _find_root_stanza(sentence):
        doc = nlp(sentence)
        toks = []
        for sentence in doc.sentences:
            for tok in sentence.words:
                if tok.head == 0:
                    toks.append(f"<root> {tok.text} </root>")
                else:
                    toks.append(tok.text)
        return " ".join(toks)

    with open(output_file, "w") as output:
        if train:
            for i in range(1, 11):
                input_file_name = input_prefix + "%02d" % i + ".json"
                _dump_data(input_file_name, output)
        else:
            _dump_data(input_prefix, output)


@click.command()
@click.option(
    "--input_file_name",
    default=".data/ssum/500gd.clean.utf8.txt",
    help="input file name")
@click.option(
    "--output_file_prefix",
    default=".data/ssum/s2s.palm.long",
    help="output file prefix")
@click.option("--train_size", default=450, help="size of train set")
def csv_to_txt(input_file_name,
               output_file_prefix,
               train_size,
               source_idx=4,
               target_idx=2):
    with open(input_file_name) as input_:
        sources, targets = [], []
        for line in input_:
            parts = line.split("\t")
            sources.append(
                parts[source_idx].strip('"').strip().strip('"').strip())
            targets.append(
                parts[target_idx].strip('"').strip().strip('"').strip())
    dataset = list(zip(sources, targets))
    random.shuffle(dataset)
    with open(output_file_prefix + ".train.txt", "w") as output_train, \
            open(output_file_prefix + ".test.txt", "w") as output_test, \
            open(output_file_prefix + ".test.source.txt", "w") as output_test_source:
        c = 0
        for s, t in dataset:
            if c < train_size:
                output_train.write("{}\t{}\n".format(
                    re.sub(r'\s+', ' ', s).strip(),
                    re.sub(r'\s+', ' ', t).strip()))
            else:
                output_test.write("{}\t{}\n".format(
                    re.sub(r'\s+', ' ', s).strip(),
                    re.sub(r'\s+', ' ', t).strip()))
                output_test_source.write("{}\t\n".format(
                    re.sub(r'\s+', ' ', s).strip()))
            c += 1


@click.command()
@click.option(
    "--input_file_name",
    default=".data/sogou/s2s.500k.jsonl",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/sogou/s2s.500k.tab.txt",
    help="output file name")
@click.option(
    "--source_only/--no_source_only",
    default=False,
    help="if only source is used")
def jsonl_to_txt(input_file_name, output_file_name, source_only):
    with open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        for line in input_:
            datum = json.loads(line)
            source = datum["src"].strip()
            target = datum["tgt"].strip()
            result = source + "\t"
            if not source_only:
                result += target
            output.write(result + "\n")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/asrsum/asrsum01.test.jsonl",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/asrsum/asrsum01.test.tab.txt",
    help="output file name")
@click.option(
    "--source_only/--no_source_only",
    default=False,
    help="if only source is used")
def jsonl_to_txt_unused(input_file_name, output_file_name, source_only):
    sub = {" <u> ": "[unused80]", " <c> ": "[unused81]"}
    with open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        for line in input_:
            datum = json.loads(line)
            source = " " + datum["src"].strip() + " "
            for k in sub:
                source = source.replace(k, sub[k])
            source = source.strip()
            target = datum["tgt"].strip()
            result = source + "\t"
            if not source_only:
                result += target
            output.write(result + "\n")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/ssum/abstract200716.xlsx",
    help="input file name")
@click.option(
    "--output_file_prefix",
    default=".data/ssum/abstract200716",
    help="output file name")
def xlsx_to_jsonl(input_file_name, output_file_prefix):

    def _filter_content(text):
        result = ""
        texts = text.split()
        for t in texts:
            if len(t) < 10:
                continue
            if result and not t.startswith("来电人再次反映："):
                continue
            result += t.strip()
        logger.debug(f"result: {result}")
        return result

    short_data = []
    long_data = []
    for i in range(10):
        sheet = pd.read_excel(io=input_file_name, sheet_name=i)
        logger.debug(f"{sheet}")
        for _, row in sheet.iterrows():
            try:
                content = row[1].strip()
                short = row[2].strip()
                long_ = row[3].strip()
            except:
                logger.warn(f"Skip row: {row}")
                continue
            content = _filter_content(content)
            if len(content) > 10 and len(short) > 10 and len(long_) > 10:
                short_data.append({"src": content, "tgt": short})
                long_data.append({"src": content, "tgt": long_})

    with open(output_file_prefix + ".short.jsonl", "w") as output:
        for datum in short_data:
            output.write(json.dumps(datum, ensure_ascii=False) + "\n")

    with open(output_file_prefix + ".long.jsonl", "w") as output:
        for datum in long_data:
            output.write(json.dumps(datum, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--gold_file_name",
    default=".data/ssum/s2s.test.jsonl",
    help="gold file name")
@click.option(
    "--pred_file_name",
    default="transformer_models/ssum_lr1e-4_ep20_b32_on_gsum_rbtl3_lr2e-5_ep1_b32/test.output.txt",
    help="pred_file_name")
@click.option(
    "--print_predictions/--non_print_predictions",
    default=True,
    help="print content in gold and predict files")
def rouge_eval(gold_file_name, pred_file_name, print_predictions):
    golds = []
    sources = []
    with open(gold_file_name) as input_:
        for datum in input_:
            gold = json.loads(datum)["tgt"]
            gold = " ".join([c for c in gold])
            golds.append([gold])
            sources.append(json.loads(datum)["src"].strip())
    preds = []
    with open(pred_file_name) as input_:
        for pred in input_:
            pred = "".join(filter(lambda x: x != "[UNK]", pred.strip().split()))
            pred = " ".join([c for c in pred])
            preds.append(pred)
    evaluator = rouge.Rouge(
        metrics=['rouge-l'],
        apply_avg=True,
        apply_best=False,
        stemming=False,
        latin_only=False,
        use_wordnet=False,
        ensure_compatibility=True)
    scores = evaluator.get_scores(preds, golds)
    if print_predictions:
        for src, pred, gold in zip(sources, preds, golds):
            logger.info("\nSOURCE: {}\nPRED: {}\nGOLD: {}".format(
                src, re.sub(r"\s+", "", pred), re.sub(r"\s+", "", gold[0])))
    logger.info("Rouge-L:\n{}".format(scores))


@click.command()
@click.option(
    "--tab_file",
    default=".data/zj/test.clean.tab.txt",
    help="gold file name")
def lead_extract(tab_file):
    # logger.info(lead_summ("请愿 尊敬的国家信访局领导们：您们好！ 我是一名70后原国企下岗的厂级劳模，去年国际趋势、国家政策英明习主席、李总理多次新闻包括钨镇会议报道，互联网+大众创业、万众创新、股权众等争取2020年要7亿贫穷达到中产阶层小康生活的中国梦！而杭州龙炎公司就是响应党的政策号召紧跟党的路线方针实行互联网+大众创业、万众创新、股权众筹的模式并且有国家颁发的中国电子商务理事单位等多个牌照，公司以＂诚实诚信、大爱助人、厚德包容、惠普大众＂十六字方针下经营，龙炎公司在正常运行14个月中朋友引导下我投资了，包括几十万投资者在4月1日查封调查关网前没有听说一个未分利到帐的拖欠一分钱事实情况（我可用曾经国企劳模人格和良心保证）并且龙炎公司购物商城扶助了部分中小微企业和带动当地人就业和税收的为国为民分忧诚信公司，并且也对接了实体项目：2010655彩票超市、杭州亚运会、银行防范视频机、体育彩票运营系统等，还有投资者所遇到实际突发困难时，龙炎公司及部门会组织募捐款发放投资者困难给予帮助的大爱精神。前不久还在北京钓鱼台联合美丽乡村扶助媒体播放报道，确实我们投资者都解决就业和改善了很多年生活窘迫问题，可当这次被少部"))
    # return
    print_predictions = True
    sources, golds, preds = [], [], []
    with open(tab_file) as tab_file:
        for line in tab_file:
            source, target = line.strip().split("\t")
            orig_source = source
            summ = lead_summ(source)
            sources.append(orig_source)
            preds.append(" ".join([c for c in summ]))
            golds.append(" ".join([c for c in target]))
    evaluator = rouge.Rouge(
        metrics=['rouge-l'],
        apply_avg=True,
        apply_best=False,
        stemming=False,
        latin_only=False,
        use_wordnet=False,
        ensure_compatibility=True)
    scores = evaluator.get_scores(preds, golds)
    # print_predictions = False
    if print_predictions:
        for source, pred, gold in zip(sources, preds, golds):
            logger.info("SOURCE: {}\n\nPRED: {}\n\nGOLD: {}\n\n".format(
                source, re.sub(r"\s+", "", pred), re.sub(r"\s+", "", gold)))
    logger.info("Rouge-L:\n{}".format(scores))    


def lead_summ(source):
    while "：" in source[:20]:
        source = source[source.find("：")+1:]
    nihao_index = -1
    if "主席" in source:
        nihao_index = source.find("主席") 
    if nihao_index < 0 and "我是" in source:
        if source.find("我是") < 10:
            nihao_index = source.find("我是")
    if nihao_index < 0 and "你" in source:
        nihao_index = source.find("你")
    if nihao_index < 0 and "您" in source:
        nihao_index = source.find("您")
    if 0 <= nihao_index < 50:
        logger.debug(f"old source: {source}")
        logger.debug(f"nihao_index: {nihao_index}")
        for i, c in enumerate(source):
            logger.debug(c)
            if i > 100:
                break
            if i > nihao_index and c in ["。", "，", "！", ":"]:
                source = source[i+1:]
                break
        logger.debug(f"new source: {source}")
    summ = process_content_zj2(source, max_len=130, trunk=True)
    # if "。" in summ[-20:] and not summ.endswith("。"):
    #     summ= summ[:summ.find("。")+1]
    if not summ.endswith("。"):
        i = len(summ) - 1
        while i > 20:
            if summ[i] in ["。", "，", "！", ":"]:
                summ = summ[:i]
                break
            i -= 1        
    return summ


def detok_local(s):
    s = s.replace(" ' ", "'")
    s = s.replace(" / ", "/")
    return s


@click.command()
@click.option(
    "--gold_file_name",
    default=".data/google_sc/test.lower.edge.jsonl",
    help="gold file name")
@click.option(
    "--pred_file_name",
    default="transformer_models/gsc_edge_lr7e-5_ep1_b64/test.output.txt",
    help="pred_file_name")
@click.option(
    "--print_predictions/--non_print_predictions",
    default=True,
    help="print content in gold and predict files")
def rouge_eval_en(gold_file_name, pred_file_name, print_predictions):
    golds = []
    sources = []
    with open(gold_file_name) as input_:
        for datum in input_:
            gold = json.loads(datum)["tgt"]
            golds.append([gold])
            sources.append(json.loads(datum)["src"].strip())
    preds = []
    with open(pred_file_name) as input_:
        for pred in input_:
            pred = pred.strip()
            pred = detokenize(pred)
            pred = detok_local(pred)
            preds.append(pred)
    evaluator = rouge.Rouge(
        metrics=['rouge-l'],
        apply_avg=True,
        apply_best=False,
        stemming=False,
        latin_only=False,
        use_wordnet=False,
        ensure_compatibility=True)
    scores = evaluator.get_scores(preds, golds)
    if print_predictions:
        for src, pred, gold in zip(sources, preds, golds):
            logger.info("\nSOURCE: {}\nPRED: {}\nGOLD: {}\n".format(
                src, pred, gold[0]))
    logger.info("Rouge-L:\n{}".format(scores))


def extract_triples(doc):
    triples = []
    for sentence in doc.sentences:
        roots = {}
        for tok in sentence.words:
            if "subj" in tok.deprel or "obj" in tok.deprel:
                if tok.head in roots:
                    roots[tok.head][1].add(tok.text)
                else:
                    logger.debug(f"{sentence.words}, {tok.head}")
                    roots[tok.head] = [
                        sentence.words[tok.head - 1].text, {tok.text}
                    ]
        for k in roots:
            triples.append(roots[k])
    return triples


def triple_recall(gold_triples, pred_triples):
    match = 0
    for h, so_set in gold_triples:
        for ph, p_so_set in pred_triples:
            all_p = {ph} | p_so_set
            if h in all_p:
                match += 1
                break
            found_nominal = False
            for nominal in so_set:
                if nominal in all_p:
                    match += 1
                    found_nominal = True
                    break
            if found_nominal:
                break
    return match


@click.command()
@click.option(
    "--gold_file_name",
    default=".data/ssum/s2s.test.jsonl",
    help="gold file name")
@click.option(
    "--pred_file_name",
    default="transformer_models/ssum_lr1e-4_ep20_b32_on_gsum_rbtl3_lr2e-5_ep1_b32/test.output.txt",
    help="pred_file_name")
@click.option(
    "--print_predictions/--non_print_predictions",
    default=False,
    help="print content in gold and predict files")
def openie_eval(gold_file_name, pred_file_name, print_predictions):
    import stanza
    golds = []
    sources = []
    nlp = stanza.Pipeline('zh')
    with open(gold_file_name) as input_:
        for datum in input_:
            gold = json.loads(datum)["tgt"]
            gold = " ".join([c for c in gold])
            golds.append(gold)
            sources.append(json.loads(datum)["src"].strip())
    preds = []
    with open(pred_file_name) as input_:
        for pred in input_:
            pred = "".join(filter(lambda x: x != "[UNK]", pred.strip().split()))
            pred = " ".join([c for c in pred])
            preds.append(pred)
    match_count = 0
    gold_count = 0
    for g, p in zip(golds, preds):
        g_doc = nlp(g)
        p_doc = nlp(p)
        g_triples = extract_triples(g_doc)
        p_triples = extract_triples(p_doc)
        if print_predictions:
            logger.info(f"g_triples: {g_triples}")
            logger.info(f"p_triples: {p_triples}")
        match_count += triple_recall(g_triples, p_triples)
        gold_count += len(g_triples)
    if print_predictions:
        for src, pred, gold in zip(sources, preds, golds):
            logger.info("\nSOURCE: {}\nPRED: {}\nGOLD: {}".format(
                src, re.sub(r"\s+", "", pred), re.sub(r"\s+", "", gold)))
    logger.info("Gold recall: {}/{} = {}".format(match_count, gold_count,
                                                 match_count / gold_count))


@click.command()
@click.option(
    "--text_dir", default=".data/asrsum/text", help="dir of text (gold) file")
@click.option(
    "--asr_dir", default=".data/asrsum/raw", help="dir of asr (raw asr) file")
@click.option(
    "--output_file_name",
    default=".data/asrsum/asrsum01_11k.jsonl",
    help="output file name")
def dump_asr_data(text_dir, asr_dir, output_file_name):
    max_asr_len = 1100

    def _read_text(text_file_name):
        rows = []
        with open(text_file_name, newline="\r\n") as text_file:
            reader = csv.reader(text_file)
            headers = next(reader, None)
            for row in reader:
                datum = {}
                for h, c in zip(headers, row):
                    datum[h] = c
                rows.append(datum)
        return rows

    def _read_asr(asr_file_name, text_dict):
        result = {}
        with open(asr_file_name) as asr_file:
            next(asr_file, None)
            buf = []
            key = ""
            for line in asr_file:
                line = line.strip()
                if "," not in line:
                    if buf and key and key in text_dict:
                        result[key] = buf
                    buf = []
                    key = line
                else:
                    parts = line.split(",")
                    if len(parts) == 5:
                        buf.append((parts[1], parts[4]))
            if buf and key and key in text_dict:
                result[key] = buf
                buf = []
        return result

    text_rows = []
    for i in range(1, 2):
        file_name = os.path.join(text_dir, "TextFeb%02d.csv" % i)
        logger.info(f"Reading {file_name}")
        rows = _read_text(file_name)
        text_rows.extend(rows)
    text_dict = {}
    for row in text_rows:
        if "录音文件名" in row and row["录音文件名"]:
            k = row["录音文件名"].rsplit("\\", maxsplit=1)[-1]
            text_dict[k] = row

    for k in text_dict:
        logger.debug(f"{k} -> {text_dict[k]}")

    pairs = {}
    for i in range(1, 2):
        file_name = os.path.join(asr_dir, "ASRFeb%02d.csv" % i)
        logger.info(f"Reading {file_name}")
        pair_dict = _read_asr(file_name, text_dict)
        for k in pair_dict:
            if k not in pairs:
                pairs[k] = (pair_dict[k],
                            re.sub(r"\s+", "", text_dict[k]["反映内容"]))

    logger.info("Dumping results...")
    with open(output_file_name, "w") as output:
        for k in tqdm(pairs):
            dialog, summary = pairs[k]
            context = ""
            for party, utterance in dialog:
                current = ""
                current += " <u> " if party == "客户" else " <c> "
                current += utterance
                if len(current) + len(context) < max_asr_len:
                    context += current
            context = context.strip()
            left_bound = summary[:20].rfind("）")
            if left_bound > -1:
                summary = summary[left_bound + 1:]
            right_bound = summary.rfind("。此件曾")
            if right_bound > -1:
                summary = summary[:right_bound + 1]
            output.write(
                json.dumps({
                    "src": context,
                    "tgt": summary
                }, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/asrsum/asrsum01_11k.val.jsonl",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/asrsum/asrsum01_11k_ext.val.jsonl",
    help="output file name")
def generate_asr_ext_data(input_file_name, output_file_name):
    evaluator = rouge.Rouge(
        metrics=['rouge-l'],
        apply_avg=True,
        apply_best=False,
        stemming=False,
        latin_only=False,
        use_wordnet=False,
        ensure_compatibility=True)
    golds = []
    predictions = []
    upperbound = []
    total = 0
    correct = 0
    with open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        for line in input_:
            result = []
            best_rouge = 0
            best_summ = ""
            best_idx = 0
            datum = json.loads(line)
            source = datum["src"]
            target = datum["tgt"]
            c_buf = ""
            u_buf = ""
            m = re.search(r"<[cu]>", source)
            status = "u"
            logger.debug(f"datum: {datum}")
            idx = 0
            while m:
                tag = m.group(0)
                if tag == "<c>":
                    if status == "u":
                        u_buf += source[:m.start()].strip()
                    else:
                        c_buf += source[:m.start()].strip()
                    status = "c"
                    if u_buf:
                        result += [[c_buf, u_buf]]
                        scores = evaluator.get_scores(
                            [" ".join([c for c in u_buf])], 
                            [" ".join([c for c in target])]
                        )
                        rouge_l = scores["rouge-l"]["f"]
                        if rouge_l > best_rouge:
                            best_rouge = rouge_l
                            best_summ = u_buf
                            best_idx = idx
                        logger.debug(f"scores: {scores}")
                        c_buf = ""
                        u_buf = ""
                        idx += 1
                    source = source[m.end()+1:]
                else:
                    if status == "u":
                        u_buf += source[:m.start()].strip()
                    else:
                        c_buf += source[:m.start()].strip()
                    status = "u"
                    source = source[m.end()+1:]
                m = re.search(r"<[cu]>", source)
            if u_buf:
                result += [(c_buf, u_buf)]
                scores = evaluator.get_scores(
                            [" ".join([c for c in u_buf])], 
                            [" ".join([c for c in target])]
                        )
                rouge_l = scores["rouge-l"]["f"]
                if rouge_l > best_rouge:
                    best_rouge = rouge_l
                    best_summ = u_buf
                    best_idx = idx
            if result:
                out_datum = {"sents": result, "best_index": [best_idx], "target": target, "best_summ": best_summ}
                logger.info(f"Processed datum: {out_datum}")
                output.write(json.dumps(out_datum, ensure_ascii=False) + "\n")
                golds.append(" ".join([c for c in target]))
                prediction = result[0][1]
                for candidate in result:
                    cand_summ = candidate[1]
                    if len(cand_summ) > 25:
                        prediction = cand_summ
                        break
                predictions.append(" ".join([c for c in prediction]))
                upperbound.append(" ".join([c for c in result[best_idx][1]]))
                total += 1
                if result[best_idx][1] == prediction:
                    correct += 1
                else:
                    logger.info(f"PRED: {prediction} GOLD: {result[best_idx][1]}")
            else:
                logger.info(f"Problematic datum: {out_datum}")
    scores = evaluator.get_scores(predictions, golds)
    logger.info(f"Scores: {scores}")
    scores = evaluator.get_scores(upperbound, golds)
    logger.info(f"Upperbound: {scores}")
    logger.info(f"Correct: {correct} total: {total} acc: {correct/total}")


def process_source(source_text):
    next_start = 0
    result = []
    while next_start > -1:
        next_start = source_text.find("<", 1)
        if next_start == -1:
            current_str = source_text
        else:
            current_str = source_text[:next_start]
        result.append((current_str[:3], current_str[3:].strip()))
        if next_start > -1:
            source_text = source_text[next_start:]
    return result


def add_kb_info(task):
    xpy = Pinyin()
    line = task.line
    pinyins = task.pinyins
    words = task.words
    wp_dict = task.wp_dict
    datum = json.loads(line)
    source = datum["src"].strip()
    target = datum["tgt"].strip()
    utterances = process_source(source)
    local_match_scores = defaultdict(int)
    for speaker, src in utterances:
        src = src.strip()
        if not src:
            continue
        src_py = "_" + xpy.get_pinyin(src, "_") + "_"
        matches = process.extract(src_py, pinyins)
        logger.debug(f"{speaker} Utterance: {src} Py: {src_py}")
        logger.debug(f"\tMatches: {matches}")
        for py, score in matches:
            if score < 85 or len(src_py) < len(py):
                continue
            local_match_scores[py] += score
            logger.debug(f"local_match_scores: {local_match_scores}")
    sorted_source_match = sorted(
        list(local_match_scores.items()), key=lambda x: x[1], reverse=True)
    logger.debug(f"Source Match: {sorted_source_match[:3]}")
    kb_str = "<kb>"
    for kb_item, score in sorted_source_match[:3]:
        if score > 100:
            kb_str += f"<kbitem>{wp_dict[kb_item]}"
    kb_str += "</kb>"

    # target_py = xpy.get_pinyin(target)

    logger.debug(f"Target: {target}")
    for word in words:
        if word in target:
            logger.debug(f"\tMatch: {word}")

    source = source.replace(" ", "") + kb_str
    return {"src": source, "tgt": target}


@click.command()
@click.option(
    "--resource_dir_name",
    default=".data/resources/hz_geo",
    help="resource directory")
@click.option(
    "--input_file_name",
    default=".data/asrsum/asrsum01_11k.test.jsonl",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/asrsum/asrsum01_11k.test.enriched.jsonl",
    help="output file name")
@click.option("--workers", default=16, help="number of workers")
def recall_with_pinyin(resource_dir_name, input_file_name, output_file_name,
                       workers):
    with open(os.path.join(resource_dir_name, "index.json")) as resource_dir:
        resources = json.load(resource_dir)
    xpy = Pinyin()
    words, pinyins = set(), set()
    wp_dict = {}
    for i in range(len(resources["files"])):
        resource_file_name = os.path.join(resource_dir_name,
                                          resources["files"][i][1])
        with open(resource_file_name) as resource_file:
            for line in resource_file:
                datum = json.loads(line)
                word = datum["word"]
                py = datum["py"]
                words.add(word)
                py_enc = "_" + xpy.get_pinyin(word, "_")
                pinyins.add(py_enc)
                wp_dict[py_enc] = word
    words = list(words)
    pinyins = list(pinyins)
    logger.info("Dictionary ready. Processing input.")

    with open(input_file_name) as input_:
        input_lines = list(input_.readlines())
    pool = Pool(processes=workers)
    tasks = [
        SimpleNamespace(
            line=line, pinyins=pinyins, words=words, wp_dict=wp_dict)
        for line in input_lines
    ]
    results = pool.map(add_kb_info, tasks)
    pool.close()
    pool.join()

    logger.info("Writing output.")
    with open(output_file_name, "w") as output:
        for result_datum in results:
            output.write(json.dumps(result_datum, ensure_ascii=False) + "\n")


def mohu_pinyin(pinyin):
    # Source: https://gist.github.com/lotem/2320943
    # 模糊音定義
    # 需要哪組就刪去行首的 # 號，單雙向任選
    #- derive/^([zcs])h/$1/             # zh, ch, sh => z, c, s
    #- derive/^([zcs])([^h])/$1h$2/     # z, c, s => zh, ch, sh

    #- derive/^n/l/                     # n => l
    #- derive/^l/n/                     # l => n

    # 這兩組一般是單向的
    #- derive/^r/l/                     # r => l

    #- derive/^ren/yin/                 # ren => yin, reng => ying
    #- derive/^r/y/                     # r => y

    # 下面 hu <=> f 這組寫法複雜一些，分情況討論
    #- derive/^hu$/fu/                  # hu => fu
    #- derive/^hong$/feng/              # hong => feng
    #- derive/^hu([in])$/fe$1/          # hui => fei, hun => fen
    #- derive/^hu([ao])/f$1/            # hua => fa, ...

    #- derive/^fu$/hu/                  # fu => hu
    #- derive/^feng$/hong/              # feng => hong
    #- derive/^fe([in])$/hu$1/          # fei => hui, fen => hun
    #- derive/^f([ao])/hu$1/            # fa => hua, ...

    # 韻母部份
    #- derive/^([bpmf])eng$/$1ong/      # meng = mong, ...
    #- derive/([ei])n$/$1ng/            # en => eng, in => ing
    #- derive/([ei])ng$/$1n/            # eng => en, ing => in
    full = {
        "yin": "ren",
        "ying": "reng",
        "fu": "hu",
        "feng": "hong",
        "fei": "hui",
        "fen": "hun",
        "fa": "hua",
        "hu": "fu",
        "hong": "feng",
        "hui": "fei",
        "hun": "fen",
        "hua": "fa",
        "huo": "fo"
    }
    consonants = {
        "z": "zh",
        "c": "ch",
        "s": "sh",
        "zh": "z",
        "ch": "c",
        "sh": "s",
        "n": "l",
        "l": "n",
        "l": "r"
    }
    vowels = {"en": "eng", "in": "ing", "eng": "en", "ing": "in"}
    if pinyin in full:
        return [full[pinyin]]
    pinyin = "_" + pinyin + "_"
    c_results = [pinyin]
    for c in consonants:
        if pinyin.startswith("_" + c):
            c_results.append(pinyin.replace("_" + c, "_" + consonants[c]))
    v_results = [x for x in c_results]
    for v in vowels:
        for c_result in c_results:
            if c_result.endswith(v + "_"):
                v_results.append(c_result.replace(v + "_", vowels[v] + "_"))
    return [x[1:-1] for x in c_result]


@click.command()
@click.option(
    "--resource_dir_name",
    default=".data/resources/hz_geo",
    help="resource directory")
@click.option(
    "--input_file_name",
    default=".data/asrsum/asrsum01_11k.train.jsonl",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/asrsum/asrsum01_11k.train.enriched2.jsonl",
    help="output file name")
def recall_with_pinyin2(resource_dir_name, input_file_name, output_file_name):
    with open(os.path.join(resource_dir_name, "index.json")) as resource_dir:
        resources = json.load(resource_dir)
    xpy = Pinyin()
    words, pinyins = [], []
    wp_dict = {}
    for i in range(len(resources["files"])):
        resource_file_name = os.path.join(resource_dir_name,
                                          resources["files"][i][1])
        with open(resource_file_name) as resource_file:
            for line in resource_file:
                datum = json.loads(line)
                word = datum["word"]
                py = datum["py"]
                if word in words:
                    continue
                words.append(word)
                py_enc = "_" + xpy.get_pinyin(word, "_")
                pinyins.append(py_enc)
                wp_dict[py_enc] = word
    words = list(words)
    pinyins = list(pinyins)
    logger.info(f"Pinyin samples: {pinyins[:10]} Size: {len(pinyins)}")
    logger.info(f"Word samples: {words[:10]}")
    logger.info("Dictionary ready. Prepare automaton.")

    A = ahocorasick.Automaton()
    for py_enc in wp_dict:
        A.add_word(py_enc, (py_enc, wp_dict[py_enc]))
    A.make_automaton()

    logger.info("Automaton ready.")

    with open(input_file_name) as input_:
        input_lines = list(input_.readlines())
        results = []
        for line in tqdm(input_lines):
            datum = json.loads(line)
            source = datum["src"].strip()
            target = datum["tgt"].strip()
            utterances = process_source(source)
            new_utterances = []
            for speaker, utterance in utterances:
                logger.debug(utterance)
                upy = "_" + xpy.get_pinyin(utterance, "_")
                prev_end = -1
                offset = 0
                for end_index, (py_value, original_value) in A.iter(upy):
                    end_index += 1
                    start_index = end_index - len(py_value)
                    if start_index < prev_end:
                        continue
                    logger.debug(
                        f"\tstart: {start_index} py: {py_value} word: {original_value}"
                    )
                    logger.debug(
                        f"\tbefore: {upy[:start_index]} after: {upy[end_index:]}"
                    )
                    word_start = len(
                        list(
                            filter(lambda x: x == "_",
                                   [x for x in upy[:start_index]]))) + offset
                    word_end = word_start + len(original_value) + offset
                    logger.debug(
                        f"word_start: {word_start} word_end: {word_end}")
                    utterance = utterance[:word_start] + \
                        "<kbitem>" + original_value + "</kbitem>" + \
                            utterance[word_end:]
                    prev_end = end_index
                    offset += 15
                new_utterances.append(f"{speaker}{utterance}")
                logger.debug(f"{speaker}{utterance}")
            new_datum = {"src": "".join(new_utterances), "tgt": target}
            results.append(new_datum)

    logger.info("Writing output.")
    with open(output_file_name, "w") as output:
        for result_datum in results:
            output.write(json.dumps(result_datum, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--vocab_file",
    default="transformer_models/gsum_base_ext_512_256_lr1e-4_ep10_b256/vocab.txt",
    help="resource directory")
@click.option(
    "--consonant_file",
    default="summ/resources/py_con.txt",
    help="consonant file name")
@click.option(
    "--vowel_file", default="summ/resources/py_vow.txt", help="vowel file name")
@click.option(
    "--output_file",
    default="transformer_models/gsum_base_ext_512_256_lr1e-4_ep10_b256/vocab.pinyin.txt",
    help="output file name")
def build_pinyin_vocab(vocab_file, consonant_file, vowel_file, output_file):

    def _contains_chinese(c):
        return True if re.search(u'[\u4e00-\u9fff]', c) else False

    def _find_consonant_and_vowel(pinyin):
        vowels = ["a", "e", "i", "o", "u", "v"]
        i = 0
        for c in pinyin:
            if c in vowels:
                return pinyin[:i] if i > 0 else "<none>", pinyin[i:]
            i += 1
        return "<pyconunk>", "<pyvowunk>"

    consonants = {}
    xpy = Pinyin()
    with open(consonant_file) as f:
        for i, c in enumerate(f):
            consonants[c.strip()] = i
    vowels = {}
    with open(vowel_file) as f:
        for i, v, in enumerate(f):
            vowels[v.strip()] = i
    with open(vocab_file) as input_, \
            open(output_file, "w") as output:
        for c in input_:
            c = c.strip()
            if len(c) == 1 and _contains_chinese(c):
                pinyin = xpy.get_pinyin(c)
                consonant, vowel = _find_consonant_and_vowel(pinyin)
                cid = consonants[consonant] if consonant in consonants else 0
                vid = vowels[vowel] if vowel in vowels else 0
                output.write(f"{cid},{vid}\n")
            else:
                output.write("0,0\n")


@click.command()
@click.option(
    "--csv_file_name", default=".data/zj/hzxf.csv", help="input csv file")
@click.option(
    "--output_file_name",
    default=".data/zj/hzxf.clean.tab.txt",
    help="output tab txt file")
def process_zj(csv_file_name, output_file_name):
    visited = set()
    with open(csv_file_name) as csv_file, \
            open(output_file_name, "w") as output:
        df = pd.read_csv(csv_file)
        for index, row in df.iterrows():
            summ = row["概况"]
            content = row["诉求"]
            if content in visited:
                continue
            visited.add(content)
            if "模板" in summ:
                continue
            if "：" not in summ:
                continue
            summ = summ[summ.index("：") + 1:]
            if "。" not in summ:
                continue
            summ = summ[:summ.rindex("。")]
            content = content[:500]
            summ = summ[:220]
            content = re.sub(r"\s+", " ", content)
            summ = re.sub(r"\s+", " ", summ)
            output.write(f"{content.strip()}\t{summ.strip()}\n")


@click.command()
@click.option(
    "--csv_file_name", default=".data/zj/hzxf.csv", help="input csv file")
@click.option(
    "--output_file_name",
    default=".data/zj/hzxf.clean.jsonl",
    help="output tab txt file")
def process_zj_jsonl(csv_file_name, output_file_name):
    visited = set()
    with open(csv_file_name) as csv_file, \
            open(output_file_name, "w") as output:
        df = pd.read_csv(csv_file)
        for index, row in df.iterrows():
            summ = row["概况"]
            content = row["诉求"]
            if content in visited:
                continue
            visited.add(content)
            if "模板" in summ:
                continue
            if "：" not in summ:
                continue
            summ = summ[summ.index("：") + 1:]
            if "。" not in summ:
                continue
            summ = summ[:summ.rindex("。")]
            content = content[:500]
            summ = summ[:220]
            content = re.sub(r"\s+", " ", content)
            summ = re.sub(r"\s+", " ", summ)
            output.write(
                json.dumps({
                    "src": content.strip(),
                    "tgt": summ.strip()
                },
                           ensure_ascii=True) + "\n")


@click.command()
@click.option(
    "--csv_file_name", default=".data/zj/hzxf.csv", help="input csv file")
@click.option(
    "--output_file_name",
    default=".data/zj/hzxf.clean.256_96.jsonl",
    help="output tab txt file")
def process_zj_s_jsonl(csv_file_name, output_file_name):
    visited = set()
    visited_summ = set()
    max_src_len = 256
    max_tgt_len = 96
    with open(csv_file_name) as csv_file, \
            open(output_file_name, "w") as output:
        df = pd.read_csv(csv_file)
        for index, row in df.iterrows():
            summ = row["概况"]
            content = row["诉求"]
            content = re.sub(r"\s+", " ", content)
            if content in visited:
                continue
            if summ in visited_summ:
                continue
            visited.add(content)
            visited_summ.add(summ)
            if "模板" in summ:
                continue
            if "：" not in summ:
                continue
            summ = summ[summ.index("：") + 1:]
            if "。" not in summ:
                continue
            summ = summ[:summ.rindex("。")]
            orig_content = content
            orig_summ = summ
            content = process_content_zj(content, max_len=max_src_len)
            summ = process_content(summ, max_len=max_tgt_len)
            if not content or not summ:
                continue
            content = re.sub(r"\s+", " ", content)
            summ = re.sub(r"\s+", " ", summ)
            output.write(
                json.dumps(
                    {
                        "src": content.strip(),
                        "tgt": summ.strip(),
                        "orig_src": orig_content.strip(),
                        "orig_tgt": orig_summ.strip()
                    },
                    ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--tab_file_name",
    default=".data/zj/test.tab.200.txt",
    help="input csv file")
@click.option(
    "--output_file_name",
    default=".data/zj/test.tab0.200.txt",
    help="output tab txt file")
def remove_tab(tab_file_name, output_file_name):
    with open(tab_file_name) as tab_file, \
            open(output_file_name, "w") as output:
        for line in tab_file:
            line = line.split("\t")[0]
            output.write(line + "\t\n")


@click.command()
@click.option(
    "--input_file_name", 
    default=".data/zj/train.clean.jsonl", 
    help="input jsonl file")
@click.option(
    "--output_file_name",
    default=".data/zj_decanlp/train_val.jsonl",
    help="output jsonl file")
def unilm_to_decanlp(input_file_name, output_file_name):
    jieba.enable_paddle()
    with open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        input_ = list(input_.readlines())
        for line in tqdm(input_):
            datum = json.loads(line)
            question = "摘要"
            context = re.sub(r"\s+", " ", " ".join(jieba.cut(datum["src"])))
            answer = re.sub(r"\s+", " ", " ".join(jieba.cut(datum["tgt"])))
            out_datum = {"question": question, "context": context, "answer": answer}
            output.write(json.dumps(out_datum, ensure_ascii=False) + "\n")
        

@click.command()
@click.option(
    "--gold_file_name", 
    default=".data/zj_decanlp/20201202/zjsumm.gold.txt", 
    help="input jsonl file")
@click.option(
    "--pred_file_name",
    default=".data/zj_decanlp/20201202/zjsumm.txt",
    help="output jsonl file")
def score_decanlp(gold_file_name, pred_file_name):

    def repeats(source, n=4):
        result = []
        source = " " + source
        while source:
            source = source[1:]
            length = len(source)
            for j in range(length, n-2, -1):
                if source[:j+1] in source[j+1:]:
                    # logger.info(f"A: {source[:j+1]} B: {source[j+1:]}")
                    result.append(source[:j+1])
        result = sorted(result, key=len)
        result.reverse()
        logger.info(f"Repeats: {result}")
        return result
    
    with open(gold_file_name) as gold, \
            open(pred_file_name) as pred:
        gold = gold.readlines()
        pred = pred.readlines()
        golds = []
        preds = []
        evaluator = rouge.Rouge(
            metrics=['rouge-l'],
            apply_avg=True,
            apply_best=False,
            stemming=False,
            latin_only=False,
            use_wordnet=False,
            ensure_compatibility=True)
        for g, p in zip(gold, pred):
            g = re.sub(r"\s+", "", json.loads(g))
            p = re.sub(r"\s+", "", p)

            logger.info(f"PRED BEFORE: {p}")
            p_dedup = repeats(p)
            for repeat in p_dedup:
                if repeat in p:
                    p_head = p[:p.find(repeat) + len(repeat)]
                    p_tail = p[p.find(repeat) + len(repeat):].replace(repeat, "")
                    p = p_head + p_tail
            logger.info(f"PRED AFTER: {p}")
            logger.info(f"\nGold: {g}\nPred: {p}\n")
            golds.append(" ".join([_ for _ in g]))
            preds.append(" ".join([_ for _ in p]))
        scores = evaluator.get_scores(preds, golds)
        logger.info(f"Scores: {scores}")


def lexrank_doc(paragraph, num_sents=2):
    sents = sent_split(paragraph)
    sents = [" ".join(jieba.cut(x)) for x in sents]
    scores = lxr.rank_sentences(sents)
    logger.info(f"Scores: {scores}")
    result = ""
    ids = scores.argsort()[-num_sents:].tolist()
    ids.sort()
    logger.info(f"ids: {ids}")
    for id in ids:
        result += sents[id]
    result = re.sub(r"\s+", "", result)
    logger.info(f"Result: {result}")
    return result


@click.command()
@click.option(
    "--input_file_name", 
    default=".data/dumped_wikinews/AA/all_wiki_news.tail2000.jsonl", 
    help="input jsonl file")
@click.option(
    "--output_dir",
    default=".data/resources/corpus",
    help="output dir")
def build_corpus_from_jsonl(input_file_name, output_dir, max_docs=2000):
    # lac = LAC(mode="seg")
    with open(input_file_name) as input_data:
        data = list(input_data)[:max_docs]
        i = 1
        for datum in tqdm(data):
            with open(os.path.join(output_dir, f"{i}.txt"), "w") as output:
                source = json.loads(datum)["src"]
                sents = sent_split(source, keep_last=True)
                contents = " ".join(jieba.cut(source))
                for content in contents:
                    content = " ".join(content)
                    output.write(content + "\n")
            i += 1


@click.command()
@click.option(
    "--input_file_name", 
    default=".data/sogou/news_tensite_xml.utf8.dat", 
    help="input jsonl file")
@click.option(
    "--output_dir",
    default=".data/resources/general2",
    help="output dir")
def build_corpus_from_jsonl2(input_file_name, output_dir, max_docs=5000):
    with open(input_file_name) as input_data:
        data = list(input_data)[:max_docs]
        i = 0
        j = 1
        with open(input_file_name) as input_:
            for line in tqdm(input_):
                line = line.strip()
                if line.startswith("<contenttitle>"):
                    title = line[len("<contenttitle>"):-len("</contenttitle>")]
                if line.startswith("<content>"):
                    content = line[len("<content>"):-len("</content>")]
                    if title and content:
                        i += 1
                        if i < 50000:
                            title = ""
                            content = ""
                            continue
                        with open(os.path.join(output_dir, f"{j}.txt"), "w") as output:
                            sents = sent_split(content, keep_last=True)
                            contents = [jieba.cut(sent) for sent in sents]
                            for content in contents:
                                content = " ".join(content)
                                output.write(content + "\n")
                            j += 1
                            if j >= max_docs:
                                return


@click.command()
@click.option(
    "--input_file_name",
    default=".data/sogou/news_tensite_xml.utf8.dat",
    help="input file name")
@click.option("--max_len", default=300, help="max length")
def validate_news(input_file_name, max_len):
    title = ""
    content = ""
    filter_target = ["(", "网易新闻", "剩余"]
    summarizer = ExtSummarizer()
    evaluator = rouge.Rouge(
            max_n=1,
            metrics=['rouge-n'],
            apply_avg=True,
            apply_best=False,
            stemming=False,
            latin_only=False,
            use_wordnet=False,
            ensure_compatibility=True)
    i = 0
    golds = []
    predictions = []
    with open(input_file_name) as input_:
        for line in tqdm(input_):
            line = line.strip()
            if line.startswith("<contenttitle>"):
                title = line[len("<contenttitle>"):-len("</contenttitle>")]
            if line.startswith("<content>"):
                content = line[len("<content>"):-len("</content>")]
                if title and content:
                    if len(content) > 100:
                        processed_title = process_title(q2b(title))
                        if "香港" in processed_title:
                            continue
                        invalid = False
                        for ft in filter_target:
                            if processed_title.startswith(ft):
                                invalid = True
                                break
                        if invalid:
                            continue
                        if len(processed_title) < 20:
                            continue
                        prediction = summarizer.lexrank_doc(content, num_sents=1)
                        g = " ".join([c for c in processed_title])
                        p = " ".join([c for c in prediction])
                        logger.info(f"\nContent:{content}\nGold: {g}\nPredict: {p}")
                        logger.info(f"Rouge-1 : {evaluator.get_scores([p], [g])}\n")
                        golds.append(g)
                        predictions.append(p)
                        i += 1
                        if i == 1200:
                            break
    logger.info(f"Overall Rouge-L: {evaluator.get_scores(predictions, golds)}")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/dumped_wikinews/wikitest.jsonl",
    help="input file name")
@click.option("--max_len", default=300, help="max length")
def validate_news_gen(input_file_name, max_len):
    title = ""
    content = ""
    summarizer = ExtSummarizer(doc_dir=".data/resources/corpus", num_files=2000)
    evaluator = rouge.Rouge(
            max_n=1,
            metrics=['rouge-n', 'rouge-l'],
            apply_avg=True,
            apply_best=False,
            stemming=False,
            latin_only=False,
            use_wordnet=False,
            ensure_compatibility=True)
    i = 0
    correct = 0
    golds = []
    predictions = []
    with open(input_file_name) as input_, \
            open("wikitest.jsonl", "w") as output:
        url_line = ""
        for line in tqdm(input_):
            line = line.strip()
            # logger.info(f"Line: {line}")
            datum = json.loads(line)
            content = datum["src"]
            title = datum["tgt"]
            if title and content:
                valid = True
                for k in ["民主", "人权", "法轮功", "公安", "达赖", "台湾", "中华民国"]:
                    if k in content:
                        valid = False
                if not valid:
                    continue
                if len(content) > 100 and "zhhans" not in content:
                    processed_title = title
                    prediction = summarizer.lexrank_doc(content, num_sents=1)
                    g = " ".join([c for c in processed_title])
                    p = " ".join([c for c in prediction])
                    logger.info(f"\nContent:{content}\nGold: {g}\nPredict: {p}")
                    local_scores = evaluator.get_scores([p], [g])
                    k = [k for k in local_scores][0]
                    f_score = local_scores[k]["f"]
                    if f_score < 0.3:
                        if random.random() < 0.2:
                            continue
                    if f_score < 0.2:
                        if random.random() < 0.5:
                            continue
                    if f_score < 0.1:
                        if random.random() < 0.9:
                            continue
                    output.write(line + "\n")
                    if f_score > 0.2:
                        correct += 1
                    logger.info(f"{k}: {local_scores}\n")
                    golds.append(g)
                    predictions.append(p)                        
                    i += 1
                    if i == 1000:
                        logger.info(f"Total: {i} Correct: {correct}")
                        break
    logger.info(f"Overall Rouge: {evaluator.get_scores(predictions, golds)}")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/dumped_wikinews/AA/all_wiki_news.jsonl",
    help="input file name")
@click.option("--max_len", default=300, help="max length")
def validate_news_gen2(input_file_name, max_len):
    title = ""
    content = ""
    user_args = {
        "model_type": "unilm",
        "do_lower_case": True,
        "model_path": "transformer_models/gsum_rbt3_200_50_lr1e-4_ep10_b192",
        "max_seq_length": 128,
        "max_tgt_length": 24,
        "batch_size": 1,
        "beam_size": 1,
        "length_penalty": 0,
        "mode": "s2s"
    }
    args = load_args(user_args=user_args)
    model = S2SPredictor(args)
    filter_target = ["(", "网易新闻", "剩余"]
    evaluator = rouge.Rouge(
            max_n=1,
            metrics=['rouge-n', 'rouge-l'],
            apply_avg=True,
            apply_best=False,
            stemming=False,
            latin_only=False,
            use_wordnet=False,
            ensure_compatibility=True)
    i = 0
    correct = 0
    golds = []
    predictions = []
    with open(input_file_name) as input_, \
            open("testdata.txt", "w") as output:
        url_line = ""
        for line in tqdm(input_):
            datum = json.loads(line)
            content = datum["src"]
            title = datum["tgt"]
            if title and content:
                processed_title = process_title(q2b(title))
                time1 = time()
                prediction = re.sub(r"\s+", "", model.predict(content)).replace("[UNK]", "")
                time2 = time()
                logger.info(f"Gen result: {prediction}")
                logger.info(f"Predict time: {time2-time1}")
                g = " ".join([c for c in processed_title])
                p = " ".join([c for c in prediction])
                logger.info(f"\nContent:{content}\nGold: {g}\nPredict: {p}")
                local_scores = evaluator.get_scores([p], [g])
                k = [k for k in local_scores][0]
                f_score = local_scores[k]["f"]
                output.write(content + "\n")
                if f_score > 0.2:
                    correct += 1
                logger.info(f"{k}: {local_scores}\n")
                golds.append(g)
                predictions.append(p)                        
                i += 1
    logger.info(f"Total: {i} Correct: {correct}")
    logger.info(f"Overall Rouge: {evaluator.get_scores(predictions, golds)}")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/dumped_wikinews/AA/all_wiki_news",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/dumped_wikinews/AA/all_wiki_news.jsonl",
    help="output file name")
def process_wikinews_data(input_file_name, output_file_name):
    import opencc
    converter = opencc.OpenCC('t2s.json')
    with open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        buf = []
        for i, line in enumerate(input_):
            line = line.strip()
            if line == "</doc>":
                tgt = converter.convert(buf.pop(0))
                src = converter.convert("".join(buf)).replace("{", "").replace("}", "").replace("-", "")
                output.write(json.dumps({"src": src, "tgt": tgt},
                    ensure_ascii=False)+"\n")
                buf = []
            elif not line.startswith("<doc"):
                buf.append(line)           


@click.command()
@click.option(
    "--input_file",
    default=".data/zz/trans.txt",
    help="input file name")
@click.option(
    "--output_dir",
    default=".data/zz/trans-zz-xlsx-a",
    help="output dir name")
@click.option(
    "--size",
    default=50,
    help="number of dialogs per xlsx file")
def dialog_to_xlsx(input_file, output_dir, size):
    def process_chunks(current_chunks, output_file_name):
        print(f"\t{len(current_chunks)}")
        result = []
        for chunk in current_chunks:
            result.append(["SPEAKER", "UTTERANCE", "选中（是/否）", "概述"])
            sentences = chunk.split()
            for sentence in sentences:
                speaker = "A" if sentence[:2] == "0:" else "B"
                utterance = sentence[2:]
                result.append([speaker, utterance, "", ""])
            result.extend([["", "", "", ""], ["", "", "", ""]])
        df = pd.DataFrame.from_records(result)
        df.to_excel(output_file_name)

    os.makedirs(output_dir, exist_ok=True)
    output_id = 0
    with open(input_file) as input_:
        content = input_.read().strip()
        chunks = content.split('\n\n')
        print(len(chunks))
        dir_name = output_dir.split("/")[0]
        while chunks:
            current_chunks = chunks[:size]
            chunks = chunks[size:]
            process_chunks(current_chunks, 
                    f"{output_dir}/annotation_{dir_name}_{output_id}.xlsx")
            output_id += 1


def _xlsx_to_dialog_ext_jsonl(input_file_name, output):
    df = pd.read_excel(input_file_name, engine='openpyxl')
    df.columns = [0, 1, 2, 3, 4]
    logger.info(f"{df}")

    datum = {"src": [], "oracle_ids": [], "tgt": "", "tgt_txt": ""}
    sid = 0
    datum_len = 0
    for _, row in df.iterrows():
        logger.debug(f"Row: {row}")
        speaker = row[1]
        if not pd.isna(speaker) and speaker != "摘要":
            if pd.isna(row[2]):
                continue
            if row[2] != "UTTERANCE" and \
                    len(datum["src"]) < 20 and \
                    datum_len < 400:
                datum["src"].append(row[2].strip())
                if type(row[3]) == str and row[3].strip() == "是" and \
                        len(datum["oracle_ids"]) < 4:
                    datum["oracle_ids"].append(sid)
                    datum["tgt"] += row[2].strip()
                    datum["tgt_txt"] += row[2].strip()
                sid += 1
                datum_len += len(row[2])
        else:
            sid = 0
            datum_len = 0
            if datum["src"]:
                if datum["oracle_ids"]:
                    output.write(json.dumps(datum, ensure_ascii=False) + "\n")
                    logger.info(f"Output datum: {datum}")
                    srcs = datum["src"]
                    for oid in datum["oracle_ids"]:
                        logger.info(f"src[{oid}]: {srcs[oid]}")
                else:
                    logger.warning(f"Missing oracle_ids: {datum}")
            datum = {"src": [], "oracle_ids": [], "tgt": "", "tgt_txt": ""}


@click.command()
@click.option(
    "--input_file_name",
    default=".data/zzhot/annotation_test.xlsx",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/zzhot/annotation_test_output.jsonl",
    help="output file name")
def xlsx_to_dialog_ext_jsonl(input_file_name, output_file_name):
    with open(output_file_name, "w") as output:
        _xlsx_to_dialog_ext_jsonl(input_file_name, output)


@click.command()
@click.option(
    "--input_dir",
    default=".data/zzhot/zz_summ_data",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/zzhot/zz_summ_processed/all.jsonl",
    help="output file name")
def xlsx_dir_to_dialog_ext_jsonl(input_dir, output_file_name):
    import glob
    output_dir = output_file_name.rsplit(os.sep, maxsplit=1)[0]
    os.makedirs(output_dir, exist_ok=True)
    with open(output_file_name, "w") as output:
        for input_file_name in glob.glob(os.path.join(input_dir, "*.xlsx")):
            logger.info(f"Input file: {input_file_name}")
            try:
                _xlsx_to_dialog_ext_jsonl(input_file_name, output)
            except:
                logger.warning(f"Error processing file: {input_file_name}")


@click.command()
@click.option(
    "--input_dir",
    default=".data/meqsum/cqc",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/meqsum/cqc_all.jsonl",
    help="output file name")
@click.option(
    "--lower/--no-lower",
    default=True,
    help="lowercase data")
def medqsum_cqc_to_unilm(input_dir, output_file_name, lower):
    import glob
    from bs4 import BeautifulSoup as bs
    with open(output_file_name, "w") as output:
        for file_name in glob.glob(input_dir + os.sep + "*.xml"):
            logger.info(f"Processing {file_name}")
            with open(file_name) as f:
                content = f.read()
                soup = bs(content, "lxml")
                cqs = soup.find_all("clinical_question")
                for cq in cqs:
                    src = cq.find("original_question").text.strip()
                    tgt = cq.find("short_question").text.strip()
                    if lower:
                        src = src.lower()
                        tgt = tgt.lower()
                    output.write(json.dumps({"src": src, "tgt": tgt}) + "\n")



@click.command()
@click.option(
    "--input_file_name",
    default=".data/meqsum/medqsum/meqsum.xlsx",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/meqsum/all.jsonl",
    help="output file name")
@click.option(
    "--lower/--no-lower",
    default=True,
    help="lowercase data")
def medqsum_to_unilm(input_file_name, output_file_name, lower):
    df = pd.read_excel(input_file_name, engine='openpyxl')
    logger.info(f"{df}")
    with open(output_file_name, "w") as output:
        for _, row in df.iterrows():
            src = row[1]
            tgt = row[2]
            if src == "CHQ":
                continue
            src = re.sub(r"\s+", " ", src)
            if lower:
                src = src.lower()
                tgt = tgt.lower()
            output.write(json.dumps({"src": src, "tgt": tgt}) + "\n")


@click.command()
@click.option(
    "--input_file_name",
    default=".data/zzhot/zz_summ_processed/all.jsonl",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/zzhot/zz_summ_processed/all_xnli.jsonl",
    help="output file name")
def zzhot_to_xnli(input_file_name, output_file_name):
    """
        output:
        {
            "gold_label": gold_label,
            "pairID": aux,
            "sentence1": context,
            "sentence1_tokenized": context_tok,
            "sentence2": question + any_str,
            "sentence2_tokenized": question_tok + any_str,
            "wide_ids": wide_ids,
        }
    """
    with open(input_file_name) as input_, \
            open(output_file_name, "w") as output:
        for line_id, line in enumerate(input_):
            datum = json.loads(line)
            src = datum["src"]
            oracle_ids = datum["oracle_ids"]
            for sent_id, sent in enumerate(datum["src"]):
                pairID = f"{line_id}_{sent_id}"
                gold_label = "True" if sent_id in oracle_ids else "False"
                sent1 = "" if sent_id == 0 else src[sent_id-1]
                sent2 = src[sent_id]
                out_datum = {
                    "gold_label": gold_label,
                    "pairID": pairID,
                    "sentence1": sent1,
                    "sentence1_tokenized": sent1,
                    "sentence2": sent2,
                    "sentence2_tokenized": sent2
                }
                output.write(json.dumps(out_datum, ensure_ascii=False) + "\n")


@click.command()
@click.option(
    "--test_file_name",
    default=".data/zzhot/zz_summ_processed/test.jsonl",
    help="input file name")
@click.option(
    "--pred_file_name",
    default="transformer_models/zzhot_xnli_zzhot/pred_results.txt",
    help="output file name")
def score_zzhot_xnli(test_file_name, pred_file_name):
    tgt_sents = []
    pred_sents = []
    gold_data = []
    correct = 0
    gold_size = 0
    pred_size = 0
    with open(test_file_name) as input_:
        for line in input_:
            datum = json.loads(line)
            gold_data.append(datum)
    sources = [x["src"] for x in gold_data]
    tgt_sents = [x["tgt"] for x in gold_data]
    pred_sents = ["" for x in gold_data]
    for x in gold_data:
        gold_size += len(x["oracle_ids"])
    with open(pred_file_name) as pred:
        for line in pred:
            line = line.strip()
            ids, label, probs = line.split("\t")
            dialog_id, sent_id = ids.split("_")
            dialog_id = int(dialog_id)
            sent_id = int(sent_id)
            pred_sents[dialog_id] += gold_data[dialog_id]["src"][sent_id] \
                    if label == "True" else ""
            if label == "True":
                pred_size += 1
                if sent_id in gold_data[dialog_id]["oracle_ids"]:
                    correct += 1

    tgt_sents = [" ".join([c for c in x]) for x in tgt_sents]
    pred_sents = [" ".join([c for c in x]) for x in pred_sents]
    evaluator = rouge.Rouge(
        metrics=['rouge-l'],
        apply_avg=True,
        apply_best=False,
        stemming=False,
        latin_only=False,
        use_wordnet=False,
        ensure_compatibility=True)
    scores = evaluator.get_scores(pred_sents, tgt_sents)
    for src, pred, gold in zip(sources, pred_sents, tgt_sents):
        logger.info("\nSOURCE: {}\nPRED: {}\nGOLD: {}".format(
            src, re.sub(r"\s+", "", pred), re.sub(r"\s+", "", gold)))
    logger.info("Rouge-L:\n{}".format(scores))
    prec = correct / pred_size
    rec = correct / gold_size
    f1 = 2 * prec * rec / (prec + rec)
    logger.info(f"P: {prec} R: {rec} F1: {f1}")


if __name__ == "__main__":
    cli.add_command(process_news)
    cli.add_command(csv_to_jsonl)
    cli.add_command(csv_to_txt)
    cli.add_command(jsonl_to_txt)
    cli.add_command(jsonl_to_txt_unused)
    cli.add_command(rouge_eval)
    cli.add_command(rouge_eval_en)
    cli.add_command(openie_eval)
    cli.add_command(dump_gsc)
    cli.add_command(dump_asr_data)
    cli.add_command(recall_with_pinyin)
    cli.add_command(recall_with_pinyin2)
    cli.add_command(process_chinese_data)
    cli.add_command(build_pinyin_vocab)
    cli.add_command(xlsx_to_jsonl)
    cli.add_command(process_zj)
    cli.add_command(process_zj_jsonl)
    cli.add_command(process_zj_s_jsonl)
    cli.add_command(remove_tab)
    cli.add_command(lead_extract)
    cli.add_command(generate_asr_ext_data)
    cli.add_command(unilm_to_decanlp)
    cli.add_command(score_decanlp)
    cli.add_command(build_corpus_from_jsonl)
    cli.add_command(build_corpus_from_jsonl2)
    cli.add_command(validate_news)
    cli.add_command(validate_news_gen)
    cli.add_command(validate_news_gen2)
    cli.add_command(process_wikinews_data)
    cli.add_command(xlsx_to_dialog_ext_jsonl)
    cli.add_command(xlsx_dir_to_dialog_ext_jsonl)
    cli.add_command(zzhot_to_xnli)
    cli.add_command(medqsum_to_unilm)
    cli.add_command(medqsum_cqc_to_unilm)
    cli.add_command(score_zzhot_xnli)
    cli()
