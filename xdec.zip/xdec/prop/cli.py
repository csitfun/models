import os
import re
import sys
import csv
import json
import math
import click
import random
from collections import Counter
from xdec_config import get_logger
from tqdm import tqdm
from transformers.data.processors import DataProcessor


logger = get_logger(__name__)


@click.group()
def cli():
    pass


@click.command()
@click.option(
    "--input_file_name",
    default=".data/proptc/train.tsv",
    help="input file name")
@click.option(
    "--output_file_name",
    default=".data/proptc/train.jsonl",
    help="output file name")
def process_prop_tc(input_file_name, output_file_name, lower=True):
    processor = DataProcessor()
    lines = processor._read_tsv(input_file_name)
    with open(output_file_name, "w") as output:
        for (i, line) in enumerate(lines):
            if i == 0 or line == []:
                continue
            guid = str(i)
            text_a = line[3].replace('""', '"').strip('"')
            text_b = line[4].replace('""', '"').strip('"')
            if lower:
                text_a = text_a.lower()
                text_b = text_b.lower()
            label = line[5]
            output.write(json.dumps({
                "gold_label": label,
                "pairID": guid,
                "sentence1": text_a,
                "sentence1_tokenized": text_a,
                "sentence2": text_b,
                "sentence2_tokenized": text_b
            }) + "\n")


@click.command()
@click.option(
    "--input_file_name",
    default="/home/y.he/xdec2/transformer_models/xnli_proptc_roberta/pred_results.txt",
    help="input file name")
@click.option(
    "--gold_file_name",
    default="/home/y.he/xdec2/.data/proptc/dev.jsonl",
    help="output file name")
def prop_tc_eval(input_file_name, gold_file_name):
    label_names = sorted(['Appeal_to_Authority', 'Doubt', 'Repetition', 'Appeal_to_fear-prejudice', 'Slogans',
                          'Black-and-White_Fallacy', 'Loaded_Language', 'Flag-Waving', 'Name_Calling,Labeling',
                          'Whataboutism,Straw_Men,Red_Herring', 'Causal_Oversimplification',
                          'Exaggeration,Minimisation',
                          'Bandwagon,Reductio_ad_hitlerum', 'Thought-terminating_Cliches'])
    preds = []
    gold_labels = []
    output = []
    with open(input_file_name) as f:
        for line in f:
            pred = line.split('\t')[1].strip()
            assert pred in label_names
            preds.append(pred)
    with open(gold_file_name) as f:
        for line in f:
            dict = json.loads(line)
            gold_label = dict['gold_label']
            assert gold_label in label_names
            gold_labels.append(gold_label)
    _, _, macro_avg_f1 = precision_recall_fscore_support(y_true=gold_labels, y_pred=preds, average='macro')
    _, _, micro_avg_f1 = precision_recall_fscore_support(y_true=gold_labels, y_pred=preds, average='micro')
    output.append('macro avg f1: {}, micro avg f1: {}'.format(macro_avg_f1, micro_avg_f1))


    results = {}
    assert len(preds) == len(gold_labels)
    for i in label_names:
        results[i]['correct'], results[i]['proposed'], results['gold_counts'] = 0, 0, 0
    for i in range(0, len(preds)):
        if preds[i] == gold_labels[i]:
            results[preds[i]]['correct'] += 1
        results[preds[i]]['proposed'] += 1
        results[gold_labels[i]]['gold_counts'] += 1
    for i in label_names:
        precision = results[i]['correct'] / results[i]['proposed']
        recall = results[i]['correct'] / results[i]['gold_counts']
        f1 = 2 * precision * recall / (precision + recall)
        output.append('score for class {} -- accuracy:{}, precision:{}, recall:{}, F1 score:{}'.format(i, acc, p, r,
                                                                                                       f1) + '\n')
    with open('score.txt', 'a') as f:
        f.write(output)
        
if __name__ == "__main__":
    cli.add_command(process_prop_tc)
    cli.add_command(prop_tc_eval)
    cli()
